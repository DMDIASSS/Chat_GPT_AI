Research report only. No credentials, source models or user files. W/D/L describes simulator trials, not live RLBot rank.
