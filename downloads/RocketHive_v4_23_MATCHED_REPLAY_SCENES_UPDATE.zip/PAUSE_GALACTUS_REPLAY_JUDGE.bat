@echo off
setlocal
set "OPENBLAS_NUM_THREADS=1"
set "OMP_NUM_THREADS=1"
cd /d "%~dp0"
".venv\Scripts\python.exe" -c "from pathlib import Path; Path('STOP_GALACTUS_JUDGE422').touch(); print('Pause requested. Re-run the trainer to resume.')"
if errorlevel 1 echo COMMAND_FAILED - keep this output and use menu 9 for diagnostics.
pause
