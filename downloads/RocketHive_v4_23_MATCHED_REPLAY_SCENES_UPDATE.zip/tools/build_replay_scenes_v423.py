"""Build a game-balanced, training-only index of synchronized whole replay scenes."""
from pathlib import Path
import argparse,hashlib,json,math,time,os
import numpy as np
from src.dataset import dataset_split
from src.replay_final_data import active_mask
from src.galactus_replay_value_v422 import from_observation
from src.replay_scenes_v423 import view,coarse,CONTRACT
from src.hive_runtime_v415 import TeamLock
ROOT=Path(__file__).resolve().parents[1]

def build(root=ROOT,max_scenes=12000):
    root=Path(root);pool=root/'data/replay_final/train'
    if not pool.exists():pool=root/'data/replay419/train'
    files=sorted(pool.glob('*.npz'))
    if not files:raise ValueError('No parsed replay training chunks found')
    if max_scenes<len(files):raise ValueError('Scene budget must allow every training game to participate')
    out=root/'models/replay_scenes423.npz';out.parent.mkdir(exist_ok=True);lock=TeamLock(root/'runs/replay_scenes423/build.lock')
    if not lock.acquire():raise ValueError('Scene index is already being built')
    try:
        rng=np.random.default_rng(423);actions=[];modes=[];sources=[];ticks=[];vc=[];vb=[];vbox=[];sid=[];teams=[];mirrors=[];keys=[];manifest={};incomplete=0;duplicate_sources=set()
        for file_no,p in enumerate(files):
            with np.load(p,allow_pickle=False) as z:
                source=str(z['source_sha256'].item())
                if dataset_split(source)!='train':raise ValueError('Held-out replay found in the training index input')
                if source in duplicate_sources:raise ValueError('Duplicate raw replay in scene input')
                duplicate_sources.add(source);manifest[p.name]=hashlib.sha256(p.read_bytes()).hexdigest()
                if 'rows' not in z:incomplete+=1;continue
                x=z['obs'];y=z['actions'];rows=z['rows']
                if x.shape!=(len(x),240) or y.shape!=(len(x),32,8) or not np.isfinite(x).all() or not np.isfinite(y).all() or not np.isin(y[:,:,5:],[0,1]).all() or np.max(abs(y[:,:,:5]))>1.001:raise ValueError('Invalid replay scene input')
                keep=active_mask(x,y,rows);unique=np.unique(rows);rng.shuffle(unique);cap=max_scenes//len(files)+int(file_no<max_scenes%len(files));made=0
                for row in unique:
                    ids=np.flatnonzero((rows==row)&keep)
                    if not len(ids):continue
                    state,_=from_observation(x[ids[0]]);m=state['mode'];n=2*m
                    if len(ids)!=n:incomplete+=1;continue
                    controls=np.zeros((6,32,8),np.float32);seen=set()
                    for i in ids:
                        _,own=from_observation(x[i]);controls[own]=y[i];seen.add(own)
                    if len(seen)!=n:incomplete+=1;continue
                    group=len(actions);actions.append(controls);modes.append(m);sources.append(source);ticks.append(int(row))
                    for team in (0,1):
                        for mirror in (False,True):
                            c,b,boxes=view(state,team,mirror);pc=np.zeros((6,29),np.float32);pc[:n]=c;pb=np.full(6,-1,np.int8);pb[:n]=boxes
                            vc.append(pc);vb.append(b);vbox.append(pb);sid.append(group);teams.append(team);mirrors.append(mirror);keys.append(coarse(c,b,m))
                    made+=1
                    if made>=cap:break
                print('REPLAY_SCENES',file_no+1,'/',len(files),'scenes',len(actions),flush=True)
        if not actions:raise ValueError('No complete synchronized replay scenes; source rows and all car controls are required')
        temp=out.with_suffix('.tmp.npz')
        np.savez_compressed(temp,contract=CONTRACT,actions=np.asarray(actions,np.float32),modes=np.asarray(modes,np.uint8),sources=np.asarray(sources),rows=np.asarray(ticks,np.int64),view_cars=np.asarray(vc,np.float32),view_balls=np.asarray(vb,np.float32),view_boxes=np.asarray(vbox,np.int8),scene_ids=np.asarray(sid,np.int64),view_teams=np.asarray(teams,np.uint8),mirrors=np.asarray(mirrors,bool),keys=np.asarray(keys,np.float32),train_manifest=json.dumps(manifest,sort_keys=True))
        os.replace(temp,out);report=dict(scenes=len(actions),views=len(vc),training_games=len(files),indexed_games=len(set(sources)),incomplete_groups_skipped=incomplete,train_only=True,path=str(out),bytes=out.stat().st_size,playing_strength_verified=False)
        reports=root/'reports';reports.mkdir(exist_ok=True);(reports/'v415_scene_index423.json').write_text(json.dumps(report,indent=2));print('REPLAY_SCENE_INDEX_READY',report,flush=True);return report
    finally:lock.close()
if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--max-scenes',type=int,default=12000);a=p.parse_args();build(max_scenes=a.max_scenes)
