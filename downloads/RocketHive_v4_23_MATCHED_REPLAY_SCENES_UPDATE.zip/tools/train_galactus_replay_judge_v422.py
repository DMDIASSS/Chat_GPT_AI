"""Supervised next-goal/time value training; no actor logits used as value labels."""
from pathlib import Path
import argparse,hashlib,json,signal,time
import numpy as np
import torch
from src.galactus_replay_value_v422 import Extractor,ValueNet,CONTRACT
from src.replay_final import load_brain
from src.replay_final_data import load_pool
from src.hive_runtime_v415 import TeamLock
from tools.train_replay_final import atomic_save
ROOT=Path(__file__).resolve().parents[1]

def train(root=ROOT,updates=5000,train_rows=16000,val_rows=4000):
    import RocketSim as rs
    root=Path(root);run=root/'runs/galactus_judge422';run.mkdir(parents=True,exist_ok=True);lock=TeamLock(run/'train.lock')
    if not lock.acquire():raise ValueError('The Galactus replay judge trainer is already running')
    stop=root/'STOP_GALACTUS_JUDGE422';stop.unlink(missing_ok=True);old=signal.signal(signal.SIGINT,lambda *_:stop.touch())
    try:
        torch.set_num_threads(1);torch.manual_seed(422);rng=np.random.default_rng(422);pool=root/'data/replay_final'
        if not (pool/'train').exists():pool=root/'data/replay419'
        tr,va,hashes,info=load_pool(pool);identity=hashlib.sha256(json.dumps(hashes,sort_keys=True).encode()).hexdigest();extractor=Extractor();cache=run/'features.pt'
        budget=dict(train=train_rows,val=val_rows)
        if cache.exists():
            data=torch.load(cache,map_location='cpu',weights_only=True)
            if data['dataset_identity']!=identity or data['budgets']!=budget:raise ValueError('Dataset/cache budget changed; existing cache preserved. Keep the original replay pool for this experiment.')
        else:
            data=dict(dataset_identity=identity,budgets=budget,galactus_identity=extractor.identity)
            for name,split in [('train',tr),('val',va)]:
                obs,_,value,known=split;ix=np.flatnonzero(known);ix=rng.choice(ix,min(len(ix),budget[name]),replace=False);raw=[]
                if len(ix)<64:raise ValueError('Not enough known next-goal replay targets')
                for j,i in enumerate(ix):
                    if stop.exists():print('JUDGE_PAUSED: feature cache not complete; re-run to rebuild',flush=True);return
                    raw.append(extractor.replay_inputs(rs,obs[i]))
                    if j%100==0:print('GALACTUS_REPLAY_FEATURES',name,j,'/',len(ix),flush=True)
                h=extractor.encode(np.stack(raw));data[name]=dict(features=torch.from_numpy(h),value=torch.from_numpy(value[ix].copy()),observations=torch.from_numpy(obs[ix].copy()))
            atomic_save(cache,data)
        x=data['train']['features'];y=data['train']['value'];vx=data['val']['features'];vy=data['val']['value'];mean=x.mean(0);std=x.std(0).clamp_min(.1);x=(x-mean)/std;vx=(vx-mean)/std
        net=ValueNet();opt=torch.optim.AdamW(net.parameters(),lr=3e-4,weight_decay=1e-4);state=run/'training_state.pt';step=0;best=float('inf');zero=float(vy.square().mean())
        if state.exists():
            ck=torch.load(state,map_location='cpu',weights_only=True)
            if ck['dataset_identity']!=identity:raise ValueError('Dataset changed; checkpoint preserved')
            net.load_state_dict(ck['network']);opt.load_state_dict(ck['optimizer']);step=ck['step'];best=ck['best'];rng.bit_generator.state=ck['rng']
        replay=load_brain(root/'runs/replay_final/best_validation.pt')
        with torch.inference_mode():_,v=replay.predict_observations(data['val']['observations'].numpy());prior=float(np.square(v-vy.numpy()).mean())
        out=root/'models/galactus_replay_value.pt';end=step+updates;status={}
        def packet():return dict(contract=CONTRACT,network=net.state_dict(),mean=mean,std=std,galactus_identity=extractor.identity,dataset_identity=identity,step=step,validation_mse=best,zero_mse=zero,replay_value_mse=prior,health_ready=best<zero,playing_strength_verified=False)
        def save():atomic_save(state,dict(network=net.state_dict(),optimizer=opt.state_dict(),step=step,best=best,rng=rng.bit_generator.state,dataset_identity=identity))
        while step<end and not stop.exists():
            ix=torch.from_numpy(rng.integers(len(x),size=256));pred=net(x[ix]);loss=(pred-y[ix]).square().mean()
            if not torch.isfinite(loss):raise ValueError('Nonfinite judge loss; checkpoint preserved')
            opt.zero_grad();loss.backward();torch.nn.utils.clip_grad_norm_(net.parameters(),1);opt.step();step+=1
            if step%100==0 or step==end:
                with torch.inference_mode():mse=float((net(vx)-vy).square().mean())
                if mse<best:best=mse;atomic_save(out,packet())
                save();status=dict(step=step,validation_mse=mse,best_mse=best,zero_mse=zero,old_replay_value_mse=prior,health_ready=best<zero,training_rows=len(x),validation_rows=len(vx),playing_strength_verified=False)
                reports=root/'reports';reports.mkdir(exist_ok=True);(reports/'v415_galactus_judge422.json').write_text(json.dumps(status,indent=2));print('GALACTUS_JUDGE',status,flush=True)
        save();print('GALACTUS_JUDGE_SAVED:',out,'healthy:',best<zero,flush=True);return status
    finally:signal.signal(signal.SIGINT,old);lock.close()
if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--updates',type=int,default=5000);p.add_argument('--train-rows',type=int,default=16000);p.add_argument('--val-rows',type=int,default=4000);a=p.parse_args()
    if min(a.updates,a.train_rows,a.val_rows)<1:p.error('Positive budgets required')
    train(updates=a.updates,train_rows=a.train_rows,val_rows=a.val_rows)
