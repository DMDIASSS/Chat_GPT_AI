"""A NEW replay-trained value head over frozen Galactus V2 features.
Galactus's released actor logits are not a state value or win probability.
"""
from pathlib import Path
import hashlib,io
import numpy as np
import torch
from torch import nn
from .galactus_v416 import locate,HASHES,features
from .physics_search import replay_arena
CONTRACT='GALACTUS_REPLAY_VALUE_V422_MASK_HISTORY_PADS'

def from_observation(x):
    x=np.asarray(x,np.float32);mode=int(round(float(x[-1])*3));me=x[26:40].copy();me[:3]*=6000;me[7:10]*=2300;me[10:13]*=6
    cars=x[40:124].reshape(6,14)[:2*mode].copy();cars[:,:3]=cars[:,:3]*6000+me[:3];cars[:,7:10]=cars[:,7:10]*2300+me[7:10];cars[:,10:13]*=6
    ball=x[:13].copy();ball[:3]*=6000;ball[7:10]*=6000;ball[10:13]*=6
    names=np.array(['octane','dominus','plank','breakout','hybrid','merc','psyclops']);onehot=x[136:178].reshape(6,7)[:2*mode]
    if not np.all(onehot.sum(1)==1):raise ValueError('Replay hitboxes must be explicit')
    boxes=names[onehot.argmax(1)];own=int(np.argmin(np.linalg.norm(x[40:124].reshape(6,14)[:2*mode,:3],axis=1)))
    return dict(mode=mode,cars=cars,ball=ball,flags=x[178:238].reshape(6,10)[:2*mode].copy(),hitboxes=boxes),own

class Extractor:
    def __init__(self):
        folder=locate();layers=[];first=258
        for width in (1024,1024):layers.extend([nn.Linear(first,width),nn.LayerNorm(width),nn.LeakyReLU()]);first=width
        self.head=nn.Sequential(*layers).eval().requires_grad_(False)
        archive=torch.jit.load(str(folder/'SHARED_HEAD.lt'),map_location='cpu');self.head.load_state_dict(dict(archive.named_parameters()),strict=True)
        self.identity=HASHES.copy()
    def inputs(self,arena,cars,players):
        pred=arena.get_ball_prediction(273,1);prediction=np.array([[*pred[i].pos.as_tuple(),*pred[i].vel.as_tuple()] for i in (30,60,120,180,240)])
        out=[]
        for i in players:
            pos=np.asarray(cars[i].get_state().pos.as_tuple());distance=lambda j:np.linalg.norm(np.asarray(cars[j].get_state().pos.as_tuple())-pos)
            allies=sorted([j for j,c in enumerate(cars) if j!=i and c.team==cars[i].team],key=distance);enemies=sorted([j for j,c in enumerate(cars) if c.team!=cars[i].team],key=distance)
            slots=(allies+[None]*(2-len(allies)),enemies+[None]*(3-len(enemies)))
            x=features(arena,cars,i,np.zeros(8,np.float32),prediction,np.random.default_rng(0),slots=slots)
            # Replay chunks lack reliable previous-action/pad timing channels.
            # Mask the SAME channels in training and deployment.
            x[9:54]=0;out.append(x)
        return np.stack(out)
    @torch.inference_mode()
    def encode(self,inputs):return self.head(torch.as_tensor(inputs,dtype=torch.float32)).numpy()
    def replay_inputs(self,rs,observation):
        state,own=from_observation(observation);key=tuple(state['hitboxes'])
        if not hasattr(self,'arenas'):self.arenas={}
        if key not in self.arenas:
            if len(self.arenas)>=16:self.arenas.pop(next(iter(self.arenas)))
            self.arenas[key]=replay_arena(rs,state)
        arena,cars=self.arenas[key]
        from .physics_search import to_car_state,to_ball_state
        for c,x,f in zip(cars,state['cars'],state['flags']):c.set_state(to_car_state(rs,x,f))
        arena.ball.set_state(to_ball_state(rs,state['ball']))
        return self.inputs(arena,cars,[own])[0]

class ValueNet(nn.Module):
    def __init__(self):super().__init__();self.layers=nn.Sequential(nn.Linear(1024,128),nn.SiLU(),nn.Linear(128,1),nn.Tanh())
    def forward(self,x):return self.layers(x).flatten()

class GalactusReplayValue:
    def __init__(self,path):
        raw=Path(path).read_bytes();self.sha256=hashlib.sha256(raw).hexdigest();ck=torch.load(io.BytesIO(raw),map_location='cpu',weights_only=True)
        if ck.get('contract')!=CONTRACT or ck.get('galactus_identity')!=HASHES or not ck.get('health_ready'):raise ValueError('A validated replay-trained Galactus judge is required; run TRAIN_GALACTUS_REPLAY_JUDGE.bat')
        self.extractor=Extractor();self.net=ValueNet().eval().requires_grad_(False);self.net.load_state_dict(ck['network']);self.mean=ck['mean'].numpy();self.std=ck['std'].numpy();self.source='GALACTUS_FEATURES_REPLAY_TRAINED_NEXT_GOAL_VALUE'
        if self.mean.shape!=(1024,) or self.std.shape!=(1024,) or not np.isfinite(self.mean).all() or not np.isfinite(self.std).all() or (self.std<=0).any():raise ValueError('Invalid Galactus judge normalization')
    @torch.inference_mode()
    def score_arenas(self,arenas,team):
        inputs=[];sizes=[]
        for arena in arenas:
            cars=arena.get_cars();who=[i for i,c in enumerate(cars) if int(c.team)==team];inputs.append(self.extractor.inputs(arena,cars,who));sizes.append(len(who))
        h=self.extractor.encode(np.concatenate(inputs));v=self.net(torch.from_numpy((h-self.mean)/self.std)).numpy();offset=0;out=[]
        for n in sizes:out.append(float(v[offset:offset+n].mean()));offset+=n
        return np.asarray(out,np.float32)
