"""Whole-scene retrieval: all cars, true field location, orientation and motion.
Only recorded training-replay controls are copied; no pose teleporting occurs.
"""
from pathlib import Path
from itertools import permutations
import json,hashlib,time
import numpy as np
from .physics_search import rotation_axes,HITBOX_PRESETS
from .replay_final import ACTION_MIRROR
CONTRACT='WHOLE_REPLAY_SCENES_V423_LOCAL29'
WEIGHT=np.array([2]*3+[.6]*6+[1.2]*3+[.3]*3+[.6]+[.7]*3+[.8]*4+[2]*3+[1.2]*3,np.float32)

def view(state,team,mirror=False):
    m=int(state['mode']);n=2*m;order=list(range(team*m,(team+1)*m))+list(range((1-team)*m,(2-team)*m))
    sign=np.array([-1,-1,1] if team else [1,1,1],np.float32)
    if mirror:sign*=np.array([-1,1,1],np.float32)
    c=np.asarray(state['cars'],np.float32)[order];f=[];u=[]
    for q in c[:,3:7]:
        forward,_,up=rotation_axes(q);f.append(forward*sign);u.append(up*sign)
    pos=c[:,:3]*sign;vel=c[:,7:10]*sign;ang=c[:,10:13]*sign*(-1 if mirror else 1)
    flags=np.asarray(state['flags'],np.float32)[order,:4]
    forward=np.asarray(f);up=np.asarray(u);right=np.cross(up,forward);ballpos=np.asarray(state['ball'][:3])*sign;ballvel=np.asarray(state['ball'][7:10])*sign;basis=np.stack((forward,right,up),2)
    local=np.einsum('bi,bij->bj',ballpos-pos,basis)/1800;localvel=np.einsum('bi,bij->bj',ballvel-vel,basis)/1800
    car=np.concatenate((pos/2000,f,u,vel/1500,ang/3,c[:,13:14],(pos+.25*vel)/2000,flags,local,localvel),1).astype(np.float32)*WEIGHT
    ball=np.asarray(state['ball']);b=np.r_[ball[:3]*sign/2000*3,ball[7:10]*sign/1800*1.2,ball[10:13]*sign*(-1 if mirror else 1)/3*.15].astype(np.float32)
    boxes=np.asarray([HITBOX_PRESETS.index(str(x)) for x in np.asarray(state['hitboxes'])[order]],np.int8)
    return car,b,boxes

def coarse(car,ball,mode):
    result=[ball]
    for team in (0,1):
        a=car[team*mode:(team+1)*mode];order=np.lexsort((a[:,1],a[:,0]));pad=np.zeros((3,3),np.float32);pad[:mode]=a[order,:3]
        result.extend((pad.ravel(),a[:,9:12].mean(0),a[:,15:16].mean(0)))
    return np.concatenate(result).astype(np.float32)

def category(mode,boxes):return (int(mode),tuple(sorted(map(int,boxes[:mode]))),tuple(sorted(map(int,boxes[mode:2*mode]))))

class SceneIndex:
    def __init__(self,path,max_distance=.45):
        self.path=str(path);self.max_distance=max_distance
        with np.load(path,allow_pickle=False) as z:
            if str(z['contract'].item())!=CONTRACT:raise ValueError('Unknown scene index contract')
            self.actions=z['actions'].copy();self.modes=z['modes'].copy();self.sources=z['sources'].copy();self.rows=z['rows'].copy();self.cars=z['view_cars'].copy();self.balls=z['view_balls'].copy();self.boxes=z['view_boxes'].copy();self.scene_ids=z['scene_ids'].copy();self.teams=z['view_teams'].copy();self.mirrors=z['mirrors'].copy();self.keys=z['keys'].copy()
        g=len(self.modes);v=len(self.keys)
        if self.actions.shape!=(g,6,32,8) or self.cars.shape!=(v,6,29) or self.balls.shape!=(v,9) or self.boxes.shape!=(v,6) or self.scene_ids.shape!=(v,) or self.teams.shape!=(v,) or self.mirrors.shape!=(v,):raise ValueError('Malformed scene index')
        if not np.isin(self.modes,[1,2,3]).all() or not np.isin(self.teams,[0,1]).all() or not np.isin(self.mirrors,[0,1]).all() or (self.scene_ids<0).any() or (self.scene_ids>=g).any():raise ValueError('Invalid scene identities')
        if not all(np.isfinite(x).all() for x in (self.actions,self.cars,self.balls,self.keys)) or np.abs(self.actions[:,:,:,:5]).max()>1.001 or not np.isin(self.actions[:,:,:,5:],[0,1]).all():raise ValueError('Invalid replay scene controls/features')
        from .dataset import dataset_split
        if self.sources.shape!=(g,) or self.rows.shape!=(g,) or any(dataset_split(str(s))!='train' for s in np.unique(self.sources)):raise ValueError('Scene index includes invalid/held-out replay identity')
        self.buckets={};self.trees={}
        for i,sid in enumerate(self.scene_ids):
            m=int(self.modes[sid]);self.buckets.setdefault(category(m,self.boxes[i]),[]).append(i)
        self.buckets={k:np.asarray(v,np.int64) for k,v in self.buckets.items()}
        try:
            from scipy.spatial import cKDTree
            self.trees={k:cKDTree(self.keys[v]) for k,v in self.buckets.items()};self.backend='scipy_cKDTree'
        except ImportError:self.backend='numpy_exact_coarse_scan'
        self.perms={m:np.asarray(list(permutations(range(m))),np.int64) for m in (1,2,3)}
    def find(self,state,team=0,count=12,shortlist=512):
        started=time.perf_counter();m=int(state['mode']);qc,qb,qboxes=view(state,team);key=category(m,qboxes);bucket=self.buckets.get(key)
        if bucket is None:return []
        k=min(len(bucket),max(count,shortlist));q=coarse(qc,qb,m)
        if key in self.trees:_,ix=self.trees[key].query(q,k=k);ids=bucket[np.atleast_1d(ix)]
        else:
            d=((self.keys[bucket]-q)**2).sum(1);ix=np.argpartition(d,k-1)[:k];ids=bucket[ix]
        src=self.cars[ids,:2*m];p=self.perms[m];assign=[];costs=[]
        for t in (0,1):
            a=src[:,t*m:(t+1)*m];b=qc[t*m:(t+1)*m];d=((b[None,:,None,:]-a[:,None,:,:])**2).mean(-1)
            mismatch=qboxes[None,t*m:(t+1)*m,None]!=self.boxes[ids,None,t*m:(t+1)*m];d+=mismatch*1e6
            # Ground/air availability matters more than a small pose difference.
            ground=np.abs(b[None,:,None,19]-a[:,None,:,19])>.4;d+=ground*10
            pc=np.stack([d[:,np.arange(m),perm].mean(1) for perm in p],1);best=pc.argmin(1);costs.append(pc[np.arange(len(ids)),best]);assign.append(p[best])
        ballcost=((self.balls[ids]-qb)**2).mean(1);dist=np.sqrt((ballcost+costs[0]+costs[1])/3);ranking=np.argsort(dist,kind='stable')
        candidates=[];seen=set();near=[]
        for r in ranking:
            if dist[r]>100:continue # incompatible exact hitbox assignment
            i=int(ids[r]);sid=int(self.scene_ids[i]);source_team=int(self.teams[i]);mirror=bool(self.mirrors[i]);commands=np.zeros((2*m,32,8),np.float32)
            for t in (0,1):
                source_offset=(source_team if t==0 else 1-source_team)*m;target_offset=(team if t==0 else 1-team)*m
                commands[target_offset:target_offset+m]=self.actions[sid,source_offset+assign[t][r]]
            if mirror:commands*=ACTION_MIRROR
            own=commands[team*m:(team+1)*m];fingerprint=np.round(own,3).tobytes()
            if fingerprint in seen:continue
            seen.add(fingerprint);matched=src[r,:m][assign[0][r]];ownpos=float(np.linalg.norm(qc[:m,:3]-matched[:,:3],axis=1).max()*1000);boost=float(np.abs(qc[:m,15]-matched[:,15]).max()/.6);ballpos=float(np.linalg.norm(qb[:3]-self.balls[i,:3])*2000/3)
            allmatched=np.concatenate((src[r,:m][assign[0][r]],src[r,m:2*m][assign[1][r]]));position=float(np.linalg.norm(qc[:,:3]-allmatched[:,:3],axis=1).max()*1000);velocity=float(np.linalg.norm(qc[:,9:12]-allmatched[:,9:12],axis=1).max()*1500/1.2);allboost=float(np.abs(qc[:,15]-allmatched[:,15]).max()/.6)
            f0,u0=qc[:,3:6]/.6,qc[:,6:9]/.6;f1,u1=allmatched[:,3:6]/.6,allmatched[:,6:9]/.6;trace=(f0*f1+u0*u1+np.cross(u0,f0)*np.cross(u1,f1)).sum(1);orientation=float(np.degrees(np.arccos(np.clip((trace-1)/2,-1,1))).max());ballvel=float(np.linalg.norm(qb[3:6]-self.balls[i,3:6])*1800/1.2)
            localpos=float(np.linalg.norm(qc[:m,23:26]-allmatched[:m,23:26],axis=1).max()*1800/2);localvel=float(np.linalg.norm(qc[:m,26:29]-allmatched[:m,26:29],axis=1).max()*1800/1.2)
            meta=dict(max_own_local_ball_position_error=localpos,max_own_local_ball_velocity_error=localvel,source_sha256=str(self.sources[sid]),row=int(self.rows[sid]),distance=float(dist[r]),close=bool(dist[r]<=self.max_distance and position<1000 and ballpos<1000 and allboost<.35 and velocity<900 and orientation<45 and ballvel<1200),max_position_error=position,max_velocity_error=velocity,max_orientation_degrees=orientation,max_boost_difference=allboost,ball_velocity_error=ballvel,max_own_position_error=ownpos,ball_position_error=ballpos,max_own_boost_difference=boost,mirror=mirror,source_team=source_team,backend=self.backend)
            item=dict(controls=commands,own=own,metadata=meta)
            # Prefer different replay moments, not overlapping neighboring chunks.
            overlapping=any(s==str(self.sources[sid]) and abs(row-int(self.rows[sid]))<32 for s,row in near)
            candidates.append((overlapping,item));near.append((str(self.sources[sid]),int(self.rows[sid])))
            if len(candidates)>=count*4:break
        diverse=[x for overlap,x in candidates if not overlap];remaining=[x for overlap,x in candidates if overlap]
        result=(diverse+remaining)[:count]
        elapsed=(time.perf_counter()-started)*1000
        for item in result:item['metadata']['query_ms']=elapsed
        return result
