@echo off
setlocal
set "OPENBLAS_NUM_THREADS=1"
set "OMP_NUM_THREADS=1"
cd /d "%~dp0"
".venv\Scripts\python.exe" -u -m tools.build_replay_scenes_v423
if errorlevel 1 echo COMMAND_FAILED - keep the output above and use menu 9 for diagnostics.
pause
