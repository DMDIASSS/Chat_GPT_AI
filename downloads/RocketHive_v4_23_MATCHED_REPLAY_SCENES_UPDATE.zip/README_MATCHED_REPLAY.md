# Match the live situation to parsed replay scenes — v4.23

Extract into the existing RocketHive folder, beside V415_MENU.bat. Pause other trainers and close viewers first.

1. Run **BUILD_REPLAY_SCENES.bat**. This indexes the parsed training games you already have; no neural training is needed. Wait for REPLAY_SCENE_INDEX_READY.
2. Run **WATCH_MATCHED_REPLAY.bat**. Blue directly executes control sequences retrieved from the most similar available whole replay scenes; orange is Galactus V2. The existing neural actor is used only if no scene has a compatible team size/hitbox lineup. This is the first comparison to try.
3. Optional: **WATCH_MATCHED_REPLAY_SEARCH.bat** adds the previous Galactus-feature judge and native search. It requires the healthy judge produced by TRAIN_GALACTUS_REPLAY_JUDGE.bat. It proposes up to 12 distinct retrieved joint teammate moves and re-matches after each simulated chunk. This mode is slower; it is not necessary to try nearest-scene imitation.
4. **EXPORT_MATCHED_REPLAY_BOT.bat** exports the direct retrieval controller for RLBot4, including its scene index and fallback actor. Search export is also available through the existing export CLI with --replay-scenes --galactus-judge instead of --policy-only. No RLBot v5 export is claimed.
5. Menu 9 collects the index summary and live match report. The console/report marks LOW_SIMILARITY when the closest available scene still differs substantially.

The old menu watch/train commands remain available. Use the new launchers for this experiment. Ctrl+C stops viewing. Rebuild the index after adding/reparsing games; existing actor checkpoints are not retrained or replaced by building it.

## What is matched

The lookup compares the ball and EVERY car in the scene, including:

- Actual field position; forward/up orientation (including pitch and roll).
- Full linear velocity vector, not just speed, and angular velocity.
- Boost and available ground/jump/flip flags.
- The ball's position, velocity and spin.
- Each car's ball-relative position and relative velocity in that car's own orientation, plus its short linear motion projection.

Teams are rotated to a common attacking direction. Left/right field reflections also mirror steer/yaw/roll correctly. Teammates and opponents are assigned to their closest matching roles; replay player slot numbers are not treated as identities. Team size and the hitbox lineup must be compatible. Absolute location relative to the goals is retained; scenes are not freely translated around the field.

A fast coarse shortlist is followed by comparison of all possible player assignments within each team. This is an approximate nearest-scene search over the shortlist, not a proof of the global minimum over every database entry. SciPy's cKDTree is used when installed; a NumPy scan works without installing another library.

The default index samples up to 12,000 synchronized scenes across all training games. Every stored scene contains the original 32-tick reconstructed control sequence for ALL active cars. Candidate teammate actions come from the SAME replay moment. Validation/test replays are excluded by raw replay hash. Incomplete joint scenes are skipped instead of pretending unrelated player chunks happened together.

## How it plays

Direct mode finds the nearest compatible scene and executes its own team's stored controls, correctly permuted/reflected. It queries again as the current situation changes. It does not average controller labels, choose from the old 256-option book, teleport cars to replay positions, or force the real opponents to follow a replay. Opponents still make their own moves.

Search mode uses distinct retrieved teammate sequences as root options, simulates them in actual current-state physics, then re-matches simulated states for three continuation chunks. Opponent predictions come from a nearest-scene policy of the current simulated situation; the opponent's actual chosen plan is never read. Near-duplicate controls are discarded and different replay moments are preferred over overlapping clips. If fewer distinct options are available, fewer lines are searched.

The existing trained replay actor remains an explicit fallback for unsupported scene lineups/modes. Geometric fallback still exists when the background worker cannot respond in time; the source is reported rather than silently called replay imitation. The controller runs on the 120 Hz physics ticks, but queries and full searches can finish more slowly on the laptop. It requests current states every tick and skips queued stale requests in favor of the newest state.

## How to judge whether a match is close

The live report includes retrieval_quality.close_fraction and last_retrieval details: replay hash/row, position error in game units, velocity-vector error in units/second, orientation error in degrees, boost difference (0–1), ball error and query time. Close is a conservative diagnostic flag across all cars; it is not a win probability.

The closest AVAILABLE scene can still be a poor match. Whole 2v2/3v3 scenes have many independent quantities, and a limited replay collection leaves large gaps. In that case direct mode still tries the nearest recorded controls and labels LOW_SIMILARITY. The new relative-ball features help select relevant mechanics, but cannot create missing demonstrations. Raw reconstructed controls can also be imperfect. A short native test verified operation, not improved win rate; the first prototype test had mostly low-similarity matches.

Artifact: models/replay_scenes423.npz. Report: reports/v415_scene_index423.json. The export includes this derived scene/control index. The public code update does not include your replay data/index or new trained weights.

A diagnostic with 11,939 scenes from 96 training games found close matches for only about 7.6% of retrieved control ticks during a 12-second 2v2 test; the score was 0–2 against Galactus. This is a small execution/coverage check, not evidence of stronger play. Your larger local pool may change coverage. This opt-in experiment does not replace the existing default watch/training launchers or promote a new champion.
