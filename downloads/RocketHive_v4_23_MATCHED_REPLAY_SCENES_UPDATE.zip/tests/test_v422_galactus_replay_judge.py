import numpy as np
import pytest
import torch
from types import SimpleNamespace as NS
from tests.test_v415_live_replay_hive import state
from tests.test_v420_final_replay import checkpoint
from src.search_teacher import make_observation

def test_galactus_current_state_roundtrip_for_every_perspective():
    from src.galactus_replay_value_v422 import from_observation
    s=state(2);s['cars'][:,0]=[-500,500,-800,800];s['cars'][:,7:13]=np.arange(24).reshape(4,6);s['hitboxes']=np.array(['octane','breakout','octane','dominus']);s['flags'][:,0]=1
    for i in range(4):
        recovered,own=from_observation(make_observation(s,i));assert own==i
        np.testing.assert_allclose(recovered['cars'],s['cars'],atol=.001);np.testing.assert_array_equal(recovered['hitboxes'],s['hitboxes']);np.testing.assert_array_equal(recovered['flags'],s['flags'])

def test_unsupported_hitbox_identity_is_not_guessed():
    from src.galactus_replay_value_v422 import from_observation
    x=make_observation(state(),0);x[136:143]=0
    with pytest.raises(ValueError,match='explicit'):from_observation(x)

def test_diverse_proposals_are_unique_with_modal_candidate_retained(tmp_path):
    from src.replay_final import load_brain
    p=tmp_path/'model.pt';checkpoint(p);brain=load_brain(p);s=state(2)
    for count in (12,64):
        plans=np.asarray(brain.propose_team(s,0,count));assert len(plans)==count
        for j in range(2):assert len({np.round(p[j],3).tobytes() for p in plans})==count
        np.testing.assert_allclose(plans[0],brain.modal([s])[0,:2],atol=1e-6)

def test_replay_missing_history_and_pad_channels_masked_in_both_modes(monkeypatch):
    import src.galactus_replay_value_v422 as g
    pred=NS(pos=NS(as_tuple=lambda:(0,0,100)),vel=NS(as_tuple=lambda:(0,0,0)))
    arena=NS(get_ball_prediction=lambda *args:[pred]*273)
    cars=[NS(team=t,get_state=lambda:NS(pos=NS(as_tuple=lambda:(0,0,17)))) for t in (0,1)]
    monkeypatch.setattr(g,'features',lambda *args,**kwargs:np.arange(258,dtype=np.float32))
    x=g.Extractor.__new__(g.Extractor).inputs(arena,cars,[0,1]);assert x.shape==(2,258)
    assert not x[:,9:54].any();np.testing.assert_array_equal(x[:,54:],np.tile(np.arange(54,258),(2,1)))

def test_unhealthy_judge_is_rejected_before_loading_public_galactus(tmp_path):
    from src.galactus_replay_value_v422 import GalactusReplayValue,CONTRACT,HASHES
    p=tmp_path/'judge.pt';torch.save(dict(contract=CONTRACT,galactus_identity=HASHES,health_ready=False),p)
    with pytest.raises(ValueError,match='validated replay-trained'):GalactusReplayValue(p)

def test_one_tick_request_contract_remains_optional():
    from src.live_hive_v415 import HiveSettings
    assert HiveSettings().request_ticks==8 and HiveSettings(request_ticks=1).request_ticks==1
    with pytest.raises(ValueError,match='request_ticks'):HiveSettings(request_ticks=0)
