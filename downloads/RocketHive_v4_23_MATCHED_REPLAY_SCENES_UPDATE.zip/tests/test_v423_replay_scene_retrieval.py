import copy
from pathlib import Path
import numpy as np
import pytest
from tests.test_v415_live_replay_hive import state
from tests.test_v420_final_replay import source_id
from src.search_teacher import make_observation
from src.physics_search import rotation_axes,quaternion_from_axes
from src.replay_final import ACTION_MIRROR

def fixtures(root,source=None):
    p=root/'data/replay_final/train';p.mkdir(parents=True)
    s=state(2);s['cars'][:,:3]=[[-600,-1600,17],[900,-3000,17],[-1200,200,17],[450,1800,17]];s['cars'][:,7:10]=[[200,600,0],[-200,100,0],[300,-900,0],[-300,500,0]];s['cars'][:,13]=[.2,.6,.8,.4];s['flags'][:,0]=1;s['ball'][:3]=[300,-800,180];s['ball'][7:10]=[400,-600,20]
    for i,yaw in enumerate((.2,1.2,-.9,-2.1)):s['cars'][i,3:7]=[0,0,np.sin(yaw/2),np.cos(yaw/2)]
    controls=np.zeros((4,32,8),np.float32);controls[:,:,0]=.8
    for i in range(4):controls[i,:,1]=.2*(i+1);controls[i,2:5,5]=i%2;controls[i,:,6]=(i+1)%2
    obs=np.stack([make_observation(s,i) for i in range(4)]);np.savez_compressed(p/'game.npz',obs=obs,actions=controls,rows=np.full(4,100),source_sha256=source or source_id('train'))
    return s,controls

def index(root):
    from tools.build_replay_scenes_v423 import build
    from src.replay_scenes_v423 import SceneIndex
    build(root,max_scenes=4);return SceneIndex(root/'models/replay_scenes423.npz')

def test_exact_scene_retrieves_joint_original_controls_for_both_teams(tmp_path):
    s,controls=fixtures(tmp_path);bank=index(tmp_path)
    for team in (0,1):
        r=bank.find(s,team,1)[0];assert r['metadata']['distance']<1e-5 and r['metadata']['close']
        np.testing.assert_allclose(r['controls'],controls,atol=1e-6)

def test_matching_assigns_teammates_and_opponents_without_relying_on_slot_order(tmp_path):
    s,controls=fixtures(tmp_path);bank=index(tmp_path);order=[1,0,3,2]
    for name in ('cars','flags','hitboxes'):s[name]=np.asarray(s[name])[order]
    result=bank.find(s,0,1)[0];np.testing.assert_allclose(result['controls'],controls[order],atol=1e-6)

def test_mirrored_scene_inverts_local_steer_yaw_roll_and_matches_pose(tmp_path):
    s,controls=fixtures(tmp_path);bank=index(tmp_path);reflection=np.array([-1,1,1])
    for a in list(s['cars'])+[s['ball']]:
        a[:3]*=reflection;a[7:10]*=reflection;a[10:13]*=-reflection
        f,r,u=rotation_axes(a[3:7]);a[3:7]=quaternion_from_axes(f*reflection,-r*reflection,u*reflection)
    r=bank.find(s,0,1)[0];assert r['metadata']['distance']<1e-5
    np.testing.assert_allclose(r['controls'],controls*ACTION_MIRROR,atol=1e-6)

def test_velocity_orientation_boost_and_ball_motion_change_matching_error(tmp_path):
    s,_=fixtures(tmp_path);bank=index(tmp_path);base=bank.find(s,0,1)[0]['metadata']['distance']
    for field in ('velocity','orientation','boost','ball'):
        t=copy.deepcopy(s)
        if field=='velocity':t['cars'][0,7:10]*=-1
        if field=='orientation':t['cars'][0,3:7]=[0,0,1,0]
        if field=='boost':t['cars'][0,13]=1
        if field=='ball':t['ball'][7:10]*=-1
        assert bank.find(t,0,1)[0]['metadata']['distance']>base+.001

def test_true_hitbox_and_game_mode_constraints_do_not_substitute_another_scene(tmp_path):
    s,_=fixtures(tmp_path);bank=index(tmp_path);s['hitboxes']=np.array(['merc']*4);assert bank.find(s,0,1)==[]
    assert bank.find(state(1),0,1)==[]

def test_index_builder_refuses_heldout_source_before_overwriting_old_index(tmp_path):
    fixtures(tmp_path,source_id('val'));target=tmp_path/'models/replay_scenes423.npz';target.parent.mkdir();target.write_bytes(b'preserved index')
    from tools.build_replay_scenes_v423 import build
    with pytest.raises(ValueError,match='Held-out'):build(tmp_path,max_scenes=4)
    assert target.read_bytes()==b'preserved index'

def test_numpy_search_backend_works_without_scipy(tmp_path,monkeypatch):
    s,controls=fixtures(tmp_path);bank=index(tmp_path);bank.trees={};bank.backend='numpy_exact_coarse_scan';r=bank.find(s,0,1)[0]
    np.testing.assert_allclose(r['controls'],controls,atol=1e-6)

def test_policy_lane_copies_retrieved_controls_and_reports_missing_scene(tmp_path):
    from types import SimpleNamespace as NS
    from src.hive_runtime_v415 import policy_plan
    s,controls=fixtures(tmp_path);bank=index(tmp_path)
    brain=NS(modal=lambda states:np.zeros((1,2,32,8),np.float32));planner=NS(brain=brain,retriever=bank)
    result=policy_plan(planner,s,0);np.testing.assert_allclose(result['controls'],controls[:2],atol=1e-6)
    assert result['controller']=='REPLAY_SCENE_NEAREST'
    result=policy_plan(planner,state(1),0);assert result['controller']=='REPLAY_BC_NO_COMPATIBLE_REPLAY_SCENE'
