import json,threading,time
from types import SimpleNamespace as NS
from unittest.mock import patch
import numpy as np
import pytest
from tests.test_v415_live_replay_hive import state
from src.hive_runtime_v415 import TeamClient,atomic_json,policy_loop,policy_plan

def plan(root,name,age,command,controller='REPLAY_BC_WITH_LIVE_SEARCH',game_age=None,team=0):
    atomic_json(root/name,dict(team=team,posted=time.monotonic()-age,state_time=10-(age if game_age is None else game_age),roster='local',controls=[[[command,0,0,0,0,0,0,0]]*32],controller=controller))

def test_late_search_uses_fresh_neural_policy(tmp_path):
    c=TeamClient(0,'x',base=tmp_path)
    plan(c.root,'plan.json',2,.2);plan(c.root,'policy_plan.json',.01,.8,'REPLAY_BC_POLICY_SEARCH_LATE')
    with patch.object(c,'_spawn'):out=c.controls(state(),10)
    assert out[0][0]==pytest.approx(.8) and c.status=='REPLAY_BC_POLICY_SEARCH_LATE'

def test_fresh_search_keeps_priority(tmp_path):
    c=TeamClient(0,'x',base=tmp_path)
    plan(c.root,'plan.json',.01,.2);plan(c.root,'policy_plan.json',.01,.8,'REPLAY_BC_POLICY_SEARCH_LATE')
    with patch.object(c,'_spawn'):out=c.controls(state(),10)
    assert out[0][0]==pytest.approx(.2)

def test_fast_policy_still_rejects_foreign_and_expired_commands(tmp_path):
    c=TeamClient(0,'x',base=tmp_path)
    plan(c.root,'policy_plan.json',.01,.8,team=1)
    with patch.object(c,'_spawn'):c.controls(state(),10)
    assert c.status.startswith('GEOMETRIC')
    plan(c.root,'policy_plan.json',.01,.8,game_age=.5)
    with patch.object(c,'_spawn'):c.controls(state(),10)
    assert c.status.startswith('GEOMETRIC')

def test_simulation_and_wall_clock_can_advance_at_different_rates(tmp_path):
    c=TeamClient(0,'x',base=tmp_path)
    # Test clock-rate independence, not the Windows filesystem's write latency.
    with patch('src.hive_runtime_v415.time.monotonic',return_value=100.):
        plan(c.root,'policy_plan.json',.22,.8,'REPLAY_BC_POLICY_SEARCH_LATE',game_age=.01)
        with patch.object(c,'_spawn'):out=c.controls(state(),10)
    assert out[0][0]==pytest.approx(.8)

def test_fast_policy_publishes_without_search(tmp_path):
    s=state();request=dict(team=0,sequence=1,posted=time.monotonic(),state_time=10,roster='local',state=s)
    atomic_json(tmp_path/'request.json',request)
    p=NS(brain=object(),modal=lambda states:np.zeros((1,2,32,8),np.float32));stop=threading.Event()
    t=threading.Thread(target=policy_loop,args=(tmp_path,0,p,stop));t.start()
    try:
        end=time.monotonic()+2
        while not (tmp_path/'policy_plan.json').exists() and time.monotonic()<end:time.sleep(.01)
        result=json.loads((tmp_path/'policy_plan.json').read_text())
        assert result['controller']=='REPLAY_BC_POLICY_SEARCH_LATE' and np.shape(result['controls'])==(1,32,8)
    finally:stop.set();t.join(timeout=2)

def test_policy_only_rejects_missing_brain():
    with pytest.raises(ValueError,match='requires'):policy_plan(NS(brain=None),state(),0)

def test_audit_measures_free_policy_jump_failures():
    from tools.audit_replay_policy_v418 import action_metrics
    truth=np.zeros((10,32,8));truth[0,:,5]=1;codec=truth.copy();policy=np.zeros_like(truth)
    assert action_metrics(codec,truth)['buttons']['jump']['f1']==1
    assert action_metrics(policy,truth)['buttons']['jump']['recall']==0

def test_audit_forward_agrees_with_existing_modal():
    import torch
    from src.replay_bc_v415 import ReplayBrain,ReplayPolicy,ChunkCodec
    from src.search_teacher import make_observation
    from tools.audit_replay_policy_v418 import predict_observations
    torch.set_num_threads(1);torch.manual_seed(418)
    b=ReplayBrain.__new__(ReplayBrain);b.net=ReplayPolicy().eval();b.codec=ChunkCodec().eval();s=state(2)
    obs=np.stack([make_observation(s,i) for i in range(4)])
    np.testing.assert_array_equal(predict_observations(b,obs),b.modal([s])[0])
