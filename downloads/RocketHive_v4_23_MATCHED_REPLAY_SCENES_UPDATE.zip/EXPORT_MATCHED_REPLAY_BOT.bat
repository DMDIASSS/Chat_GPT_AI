@echo off
setlocal
set "OPENBLAS_NUM_THREADS=1"
set "OMP_NUM_THREADS=1"
cd /d "%~dp0"
".venv\Scripts\python.exe" -u -m tools.export_hive_v415 --replay-scenes --policy-only --model runs/replay_final/best_validation.pt --output exports/RocketHive_MatchedReplay_RLBot4.zip
if errorlevel 1 echo COMMAND_FAILED - keep the output above and use menu 9 for diagnostics.
pause
