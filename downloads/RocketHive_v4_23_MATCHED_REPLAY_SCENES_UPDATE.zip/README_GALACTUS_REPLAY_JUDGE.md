# Replay search with a Galactus-backed situation evaluator — v4.22

Extract this update beside V415_MENU.bat in your existing v4.20/v4.21 RocketHive folder. Close other trainers first.

1. Run TRAIN_GALACTUS_REPLAY_JUDGE.bat. It reads your parsed training/validation replay chunks, builds a feature cache, trains a new value head for 5,000 updates and then stops. Native feature extraction is the slow first phase; progress prints every 100 states. No replay policy retraining is required.
2. Wait for GALACTUS_JUDGE_SAVED and healthy: True. PAUSE_GALACTUS_REPLAY_JUDGE.bat or Ctrl+C can stop it. An incomplete feature cache restarts extraction; once the cache exists, model/optimizer training resumes. The same launcher adds another 5,000 updates.
3. Run WATCH_REPLAY_WITH_GALACTUS_JUDGE.bat. Blue is your replay-trained actor; orange is frozen Galactus V2. Live search uses the new Galactus-feature value head. Watching does not train.
4. EXPORT_REPLAY_GALACTUS_JUDGE.bat creates the RLBot4 export, including the replay actor, trained judge and pinned Galactus model files. It needs your existing meshes. No RLBot v5 claim is made.
5. Menu 9 collects the status and code. The live match report includes measured search frequency and controller source counts. Useful files are reports/v415_galactus_judge422.json and reports/v415_live_match.json.

## What Galactus supplies

The checked public Galactus V2 release contains POLICY.lt and SHARED_HEAD.lt. It does not provide a trained critic. Actor action logits do not measure how good a situation is.

This update freezes Galactus V2's shared feature network and trains a NEW value head on actual replay next-goal labels, signed by the observing player's team and discounted as exp(-seconds_to_goal/5). Unknown/censored replay tails are excluded. The model estimates next-goal value, not a calibrated match-win probability. Validation games remain outside training. The best validation checkpoint is saved; the runtime refuses a judge that fails to beat the zero-value baseline. The old replay value error is also reported; beating zero alone does not prove that the new evaluator is stronger than the old evaluator.

Training replay observations are restored into RocketSim with their verified hitboxes. Ball predictions come only from that current state. Previous-controller and boost-pad history are unavailable in these chunk files, so those channels are masked identically in judge training and inference. Native arenas are reused in a bounded cache during extraction. This is a deliberate partial Galactus feature contract, not identical to the released Galactus actor's full observation contract.

Artifacts: runs/galactus_judge422/features.pt, training_state.pt, and models/galactus_replay_value.pt. The frozen dataset hashes are checked on resume; changing the replay pool requires a separate experiment rather than silently mixing data. The original replay actor remains the move generator. This head does not automatically get Galactus's playing strength.

## RocketLM notes applied

The supplied RocketLM excerpt describes 64 flat candidate lines, a proposed first control chunk, three policy-argmax continuations recomputed from simulated states, other cars using the predicted argmax policy, and an endpoint value predicting who scores next discounted by time. Training was replay supervision; search was at inference. Those statements describe the supplied excerpt, not independently verified results for this project.

The new search follows that flat rollout structure using the existing replay actor and a Galactus-backed replay value head. Native goals terminate a line and receive the matching time discount. Nonterminal endpoint values receive the horizon discount too. Every team plans joint teammate controls independently; it cannot read the other team's actual chosen plan. Opponents are modeled by the replay policy, as in the quoted simple setup.

Proposals are real replay-derived options (including valid reflections and the existing small axis corrections). We retain the strongest policy option and select alternatives by both policy score and distance between decoded controls, emphasizing the immediate eight ticks. Duplicate decoded sequences are discarded. Each teammate gets a distinct option permutation; if the underlying book has too few genuinely distinct options, the planner reports fewer lines instead of inventing duplicates. The candidate pool is regenerated from each new searched state. A good option may be selected repeatedly; forcing a different choice every tick would cause control jitter.

Default: 12 candidates, approximately 1.07 simulated seconds per line. The existing watch CLI supports --candidates 64. Increase this only if measured latency allows it. This uses the project's replay option model, not the private RocketLM network/VQ-BeT implementation.

## Tick rate and limitations

The judge launcher requests replanning on every 120 Hz control tick. The worker consumes the newest available state, runs search as fast as it can and applies the corresponding tick of a selected chunk. Expensive 12–64-line searches are asynchronous; they do NOT finish every 8.3 ms. Late search uses the replay policy, with source counts reported. A short server smoke test measured about 8.8 full searches/second with 12 candidates; your laptop may be slower. Replanning requests at 120 Hz do not mean 120 completed searches/second.

This is an experimental evaluator/search update. Small validation and native execution checks do not demonstrate pro-level play or a higher win rate. Keep comparisons against Galactus separate from validation-loss improvements. This launcher is for replay search; START_GALACTUS_TRAINING.bat remains the separate v4.21 PPO experiment.
