"""Read-only steps 1–6 diagnostic bundle. Works without Torch/NumPy installed."""
from pathlib import Path
import ast,collections,hashlib,importlib.metadata,json,math,os,re,struct,sys,tempfile,time,zipfile
ROOT=Path(__file__).resolve().parents[1]
SECRET=re.compile(r'api.?key|access.?token|refresh.?token|authorization|password|secret|cookie',re.I)
CODE=['src/replay_chunks_v415.py','src/replay_bc_v415.py','src/replicar_dataset.py','src/hive_runtime_v415.py','src/live_hive_v415.py','src/galactus_v416.py','tools/train_replay_brain_v415.py','tools/prepare_chunks_v415.py','tools/watch_hive_v415.py','tools/rocketsimvis_v415.py','tools/verify_hive_v415.py','tools/run_stage_v416.py','tools/report_hive_v415.py','V415_MENU.bat']

def scrub(x):
    if isinstance(x,dict):return {str(k):('[REDACTED]' if SECRET.search(str(k)) else scrub(v)) for k,v in x.items()}
    if isinstance(x,list):return [scrub(v) for v in x]
    if isinstance(x,float) and not math.isfinite(x):return '[nonfinite]'
    if isinstance(x,str):return re.sub(r'(?i)((?:api[_-]?key|authorization|access[_-]?token|password|secret)\s*[:=]\s*)([^\s,;]+)',r'\1[REDACTED]',x)
    return x

def text(path,limit=1024*1024):
    with Path(path).open('rb') as f:b=f.read(limit+1)
    return b[:limit].decode('utf-8-sig',errors='replace')+('\n[TRUNCATED]' if len(b)>limit else '')

def load(path):
    try:return json.loads(text(path,4*1024**2))
    except Exception as e:return {'read_error':type(e).__name__+': '+str(e)}

def inventory(folder,pattern,cap=1000):
    result=[];count=0
    for p in sorted(Path(folder).rglob(pattern)):
        if p.is_symlink() or not p.is_file():continue
        count+=1
        if len(result)<cap:
            try:result.append(dict(path=str(p.relative_to(ROOT)),bytes=p.stat().st_size,modified=p.stat().st_mtime))
            except OSError:pass
    return dict(count=count,files=result,list_truncated=count>cap)

def npy_header(stream):
    if stream.read(6)!=b'\x93NUMPY':raise ValueError('Bad NPY magic')
    major,minor=stream.read(2);size=struct.unpack('<H' if major==1 else '<I',stream.read(2 if major==1 else 4))[0]
    if size>65536:raise ValueError('Oversized NPY header')
    h=ast.literal_eval(stream.read(size).decode('latin1'))
    if not isinstance(h.get('shape'),tuple) or any(type(n) is not int or n<0 for n in h['shape']):raise ValueError('Bad shape')
    if 'O' in str(h.get('descr')):raise ValueError('Object arrays not inspected')
    return h

def chunks(folder,cap):
    out=dict(files=0,usable_files=0,total_rows=0,training_cap_rows=0,known_values_within_cap=0,errors=[],entries=[])
    for p in sorted(Path(folder).glob('*.npz')):
        out['files']+=1
        try:
            with zipfile.ZipFile(p) as z:
                headers={}
                for name in ('obs','actions','value','value_known'):
                    with z.open(name+'.npy') as f:headers[name]=npy_header(f)
                n=headers['obs']['shape'][0]
                if len(headers['obs']['shape'])!=2 or headers['actions']['shape']!=(n,32,8) or headers['value']['shape']!=(n,) or headers['value_known']['shape']!=(n,):raise ValueError('Incompatible replay chunk shapes')
                take=min(n,max(0,cap-out['training_cap_rows']))
                known=None
                with z.open('value_known.npy') as f:
                    h=npy_header(f)
                    if h['descr'] in ('|b1','|u1','|i1','?'):known=sum(v!=0 for v in f.read(take))
                out['usable_files']+=1;out['total_rows']+=n;out['training_cap_rows']+=take
                if known is not None:out['known_values_within_cap']+=known
                if len(out['entries'])<500:out['entries'].append(dict(file=p.name,rows=n,known_values_within_cap=known,shapes={k:v['shape'] for k,v in headers.items()}))
        except Exception as e:out['errors'].append(dict(file=p.name,error=type(e).__name__+': '+str(e)))
    return out

def build_report(root):
    global ROOT
    ROOT=Path(root).resolve();issues=[];versions={}
    for n in ('numpy','torch','rocketsim','replicar','replicar-native','pyarrow','rlviser-py'):
        try:versions[n]=importlib.metadata.version(n)
        except importlib.metadata.PackageNotFoundError:versions[n]='not installed in report Python'
    split={k:chunks(ROOT/'data/v415_chunks'/k,24000 if k=='train' else 6000) for k in ('train','val','test')}
    if not split['val']['files']:issues.append('No validation chunk files. The replay-level hash split may not have selected validation games yet, or stage 5 rejected them. Validation frames are not manufactured from training games.')
    for k,min_files,min_rows,min_values in [('train',2,256,32),('val',2,64,16)]:
        s=split[k]
        if s['usable_files']<min_files or s['training_cap_rows']<min_rows or s['known_values_within_cap']<min_values:issues.append(f'{k}: needs >= {min_files} replay files, {min_rows} rows, {min_values} known values; found {s["usable_files"]}, {s["training_cap_rows"]}, {s["known_values_within_cap"]}.')
        if s['errors']:issues.append(k+': some chunk files are unreadable or have incompatible array shapes.')
    stages={str(i):dict(status='no_console_capture_yet',note='Previous console output cannot be recovered; saved artifacts below are still inspected.') for i in range(1,7)}
    for p in sorted((ROOT/'reports/v416_stages').glob('*.json')):
        j=load(p);i=str(j.get('stage'))
        if i in stages:stages[i]=j
    evidence={}
    for p in (ROOT/'reports').glob('v415_*'):
        if p.is_file() and p.suffix in ('.json','.jsonl','.txt'):
            evidence[p.name]=load(p) if p.suffix=='.json' else text(p)
    imports=evidence.get('v415_chunk_import.json',[])
    reject=collections.Counter(str(x.get('reason','')) for x in imports if isinstance(x,dict) and x.get('status')=='rejected') if isinstance(imports,list) else {}
    prospective=collections.Counter()
    for p in (ROOT/'replicar_120hz').glob('*.source.json'):
        meta=load(p);group=meta.get('replay_sha256')
        if isinstance(group,str):
            i=int(hashlib.sha256(group.casefold().encode()).hexdigest()[:12],16)%10;prospective['train' if i<8 else 'val' if i==8 else 'test']+=1
    gui=ROOT/'third_party/RocketSimVis';model=ROOT/'models/v415_replay_brain.pt';checkpoint=ROOT/'models/v415_training_state.pt'
    def stat(p):
        try:return dict(exists=p.is_file(),bytes=p.stat().st_size,modified=p.stat().st_mtime)
        except OSError:return dict(exists=False)
    summary=dict(version='v4.16-diagnostics',created_utc=time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime()),root=str(ROOT),python=sys.executable,python_version=sys.version,packages=versions,
                 stages=stages,issues=issues,chunk_splits=split,converted_replay_hash_splits=dict(prospective),rejection_reasons=dict(reject),
                 inputs={k:inventory(ROOT/folder,pattern) for k,folder,pattern in [('raw_replays','replays','*.replay'),('parquet_120hz','replicar_120hz','*.parquet'),('legacy_parquet','replicar_parquet','*.parquet')]},
                 viewer=dict(source_exists=(gui/'src/main.py').is_file(),gui_python=stat(gui/'.venv'/('Scripts/python.exe' if os.name=='nt' else 'bin/python')),ready_marker=load(gui/'.venv/rockethive_gui_ready.json') if (gui/'.venv/rockethive_gui_ready.json').is_file() else None),
                 training=dict(brain=stat(model),optimizer_checkpoint=stat(checkpoint),checkpoint_contents_not_loaded=True),evidence=evidence)
    return scrub(summary)

def report(root=None):
    global ROOT
    ROOT=Path(root or ROOT).resolve();summary=build_report(ROOT);out=ROOT/'reports';out.mkdir(exist_ok=True)
    target=out/f'RocketHive_steps_1_to_6_{time.time_ns()}.zip';code={};errors=[]
    with zipfile.ZipFile(target,'w',zipfile.ZIP_DEFLATED) as z:
        z.writestr('SUMMARY.json',json.dumps(summary,indent=2,allow_nan=False))
        lines=['RocketHive steps 1-6 report','',*summary['issues'],'','Stage console coverage:']
        lines += [f'{k}: {v.get("status")} exit={v.get("exit_code","unknown")}' for k,v in summary['stages'].items()]
        lines+=['','This collection does not execute stages, train, move replay files, or alter validation splits.','Older unsaved console output is unavailable. New stage launchers save outputs on future use.','Ball angular velocity is represented in ball features 10:13 and sent to RocketSimVis.','No API keys, replay contents or model/optimizer tensors are included.']
        z.writestr('START_HERE.txt','\n'.join(lines))
        for path in sorted((ROOT/'reports/v416_stages').glob('*'))[-120:]:
            if path.suffix not in ('.json','.log') or not path.is_file():continue
            try:
                content=json.dumps(scrub(load(path)),indent=2) if path.suffix=='.json' else scrub(text(path,2*1024**2))
                z.writestr('stage_console/'+path.name,content)
            except OSError as e:errors.append(str(e))
        for name in CODE:
            p=ROOT/name
            if p.is_file():
                try:
                    raw=p.read_bytes();code[name]=hashlib.sha256(raw).hexdigest();z.writestr('installed_code/'+name,scrub(raw.decode('utf-8-sig',errors='replace')))
                except OSError as e:errors.append(str(e))
        for p in sorted((Path(tempfile.gettempdir())/'RocketHive-v415').glob('*/team_*/error.json'))[:20]:
            try:z.writestr('worker_errors/'+str(len(errors))+'_'+p.parent.name+'_'+p.parent.parent.name+'.json',json.dumps(scrub(load(p)),indent=2))
            except OSError as e:errors.append(str(e))
        z.writestr('CODE_HASHES.json',json.dumps(code,indent=2));z.writestr('COLLECTION_ERRORS.json',json.dumps(errors,indent=2))
    print('REPORT:',target,flush=True)
    for message in summary['issues']:print('READINESS:',message,flush=True)
    return target
if __name__=='__main__':report()
