"""Live physics-controlled matches, independent team planning, RocketSimVis UDP."""
from pathlib import Path
import argparse,json,os,statistics,time,uuid
import numpy as np
from src.live_hive_v415 import HiveSettings,snapshot
from src.hive_runtime_v415 import TeamClient
from src.physics_search import action_controls
from tools.watch_bot_rlviser import make_match,kickoff
ROOT=Path(__file__).resolve().parents[1]

def run(seconds=120,mode=2,candidates=12,render=True,realtime=True,opponent="galactus"):
    import RocketSim as rs
    from tools.rocketsimvis_v415 import Viewer
    arena,cars=make_match(rs,mode);viewer=None
    session='watch-'+uuid.uuid4().hex;clients=[TeamClient(t,session,project=ROOT,settings=HiveSettings(candidates=candidates)) for t in ((0,) if opponent=='galactus' else (0,1))]
    enemy=None
    if opponent=='galactus':
        from src.galactus_v416 import GalactusTeam
        enemy=GalactusTeam(arena,cars,team=1);print('BLUE = RocketHive; ORANGE = frozen Galactus V2; Octane; model hashes',enemy.identity,flush=True)
    max_spin=0.
    old=[None,None];counts={};tick=0;start=time.monotonic();scores=[0,0];changes=[0]*(2*mode);previous=[None]*(2*mode);max_steer=[0.]*(2*mode)
    try:
        if render:viewer=Viewer()
        while seconds<=0 or tick<seconds*120:
            state=snapshot(arena,cars,dict(mode=mode,hitboxes=['octane']*(2*mode)))
            commands=[]
            for team,c in enumerate(clients):
                commands+=c.controls(state,tick/120)
                if c.status!=old[team]:print('TEAM',team,c.status,flush=True);old[team]=c.status
                counts[c.status]=counts.get(c.status,0)+1
            if enemy:commands+=enemy.commands(arena,cars)
            for i,(car,a) in enumerate(zip(cars,commands)):
                car.set_controls(action_controls(rs,a));changes[i]+=int(previous[i] is not None and a!=previous[i]);previous[i]=a;max_steer[i]=max(max_steer[i],abs(a[1]))
            before=(arena.blue_score,arena.orange_score);arena.step(1)
            omega=arena.ball.get_state().ang_vel;max_spin=max(max_spin,float(np.linalg.norm(omega.as_tuple())))
            if (arena.blue_score,arena.orange_score)!=before:
                scores[0]+=arena.blue_score-before[0];scores[1]+=arena.orange_score-before[1];kickoff(rs,arena,cars,mode)
                if enemy:enemy.reset(arena,cars)
                print('LIVE SCORE',scores,flush=True)
            if viewer and tick%4==0:viewer.send(arena)
            tick+=1
            if tick%1200==0:print('LIVE_PROGRESS',tick/120,'seconds; score',scores,'controller sources',counts,'ball spin rad/s',omega.as_tuple(),flush=True)
            if realtime:time.sleep(max(0,start+tick/120-time.monotonic()))
    except KeyboardInterrupt:pass
    finally:
        for c in clients:c.close()
        if viewer:viewer.close()
    report=dict(seconds=tick/120,mode=mode,score=scores,blue='RocketHive',orange='Galactus V2' if enemy else 'RocketHive',galactus_identity=enemy.identity if enemy else None,max_ball_spin_rad_s=max_spin,controller_source_ticks=counts,action_changes=changes,max_abs_steer=max_steer,live_physics=True,replay_playback=False,playing_strength_verified=False)
    (ROOT/'reports').mkdir(exist_ok=True);(ROOT/'reports/v415_live_match.json').write_text(json.dumps(report,indent=2));return report

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--seconds',type=float,default=120);p.add_argument('--mode',type=int,choices=[1,2,3],default=2);p.add_argument('--candidates',type=int,default=12);p.add_argument('--headless',action='store_true');p.add_argument('--fast',action='store_true');p.add_argument('--opponent',choices=['galactus','hive'],default='galactus');a=p.parse_args()
    if not 12<=a.candidates<=64:p.error('12–64 candidates')
    print(run(a.seconds,a.mode,a.candidates,not a.headless,not a.fast,a.opponent))
