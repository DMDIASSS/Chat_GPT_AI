"""Causal receding-horizon joint team control; never reads another team's plan.

Legacy pose models/action-table checkpoints are kept unchanged. The planner
supports continuous neutral/brake controls, replay-recovered chunks and optional
learned goal values. Search is bounded, not an optimal-play or strength claim.
"""
from __future__ import annotations
from dataclasses import dataclass,asdict
import math,time
import numpy as np
from .physics_search import (rotation_axes,replay_arena,car_features,ball_features,action_controls)

@dataclass
class HiveSettings:
    candidates:int=12
    segments:int=4
    ticks:int=32
    responses:int=3
    budget_ms:float=160.
    plan_max_age:float=.45
    evaluator:str='auto'
    bank:str='models/v415_replay_chunks.npz'
    search_enabled:bool=True
    brain:str='models/v415_replay_brain.pt'
    def __post_init__(self):
        if not 12<=self.candidates<=64:raise ValueError('candidates must be 12–64')
        if not 2<=self.segments<=8 or not 4<=self.ticks<=32:raise ValueError('Invalid horizon')
        if not 1<=self.responses<=8 or not 1<=self.budget_ms<=10000:raise ValueError('Invalid search budget')
        if not 0<self.plan_max_age<=self.segments*self.ticks/120:raise ValueError('Invalid expiry')

def control_tuple(a):
    x=np.asarray(a,dtype=float)
    if x.shape!=(8,) or not np.isfinite(x).all():raise ValueError('Malformed controller')
    return tuple(float(v) for v in np.clip(x[:5],-1,1))+tuple(bool(v>.5) for v in x[5:])

def state_key(state,player):
    me=state['cars'][player];ball=state['ball'];f,r,u=rotation_axes(me[3:7]);rot=np.stack([f,r,u])
    return np.r_[rot@(ball[:3]-me[:3])/2500,rot@(ball[7:10]-me[7:10])/2300,
                 rot@me[7:10]/2300,[me[2]/1500,me[13],float(me[2]<45)]]

def safe_drive(state,player,role=None):
    """Explicit geometric controller when search is late; not called trained AI."""
    cars=np.asarray(state['cars']);me=cars[player];b=np.asarray(state['ball']);mode=int(state['mode']);team=player//mode;direction=1 if team==0 else -1
    allied=range(team*mode,(team+1)*mode)
    striker=min(allied,key=lambda j:(np.linalg.norm(cars[j,:3]-b[:3]),j))
    role=('attack' if player==striker else 'cover') if role is None else role
    f,r,u=rotation_axes(me[3:7]);speed=float(me[7:10]@f);rel=b[:3]-me[:3]
    if me[2]>100 and not (state.get('flags') is not None and state['flags'][player,0]):
        target=rel/max(1.,np.linalg.norm(rel));local=np.array([target@f,target@r,target@u]);ang=me[10:13]
        return control_tuple([1,0,-2.5*local[2]+.2*float(ang@r),2*local[1]-.2*float(ang@u),-1.5*float(u@np.array([0,0,1]))*float(r[2])-.2*float(ang@f),0,local[0]>.85 and me[13]>.05,0])
    target=b[:2]+b[7:9]*np.clip(np.linalg.norm(rel[:2])/2500,.05,.5)
    if role=='cover':target=np.array([b[0]*.5,b[1]-direction*1400])
    elif role=='retreat':target=np.array([np.clip(b[0]*.3,-900,900),-direction*4400])
    # Attack the predicted ball centre. A stop point behind the ball plus a
    # braking radius left the old controller parked outside contact range.
    delta=target-me[:2];distance=float(np.linalg.norm(delta));local_x=float(delta@f[:2]);local_y=float(delta@r[:2]);angle=math.atan2(local_y,local_x)
    reverse=abs(angle)>2.3 and distance<650
    throttle=-.7 if reverse else 1.
    # Braking is possible at any speed; never hold forward through a close target.
    desired=min(2100.,max(0.,(distance-80)*2.0))
    if role=='attack':desired=max(1000.,desired)
    if not reverse and abs(speed)>desired+180:throttle=-1 if speed>0 else 1
    if distance<100 and abs(speed)<150:throttle=0
    steer=float(np.clip(angle*3,-1,1))*(-1 if reverse else 1)
    jump=False
    # Candidate launch only; never claim an interception solver or forced save.
    if role=='aerial':jump=180<b[2]<900 and np.linalg.norm(rel[:2])<1300 and abs(angle)<.45 and bool(me[2]<45)
    boost=role in ('attack','aerial') and abs(angle)<.18 and distance>1000 and speed<2150 and me[13]>.05
    return control_tuple([throttle,steer,-1 if jump else 0,0,0,jump,boost,abs(angle)>1.1 and abs(speed)>650])

class ReplayBank:
    def __init__(self,path):
        from pathlib import Path
        self.path=str(path);self.keys=None
        if Path(path).is_file():
            with np.load(path,allow_pickle=False) as z:
                if str(z['version'].item())!='recovered-replay-controls-v415':raise ValueError('Unknown replay bank')
                self.keys=z['keys'].copy();self.chunks=z['chunks'].copy();self.hitboxes=z['hitboxes'].copy();self.tick=int(z['ticks'])
            if self.keys.ndim!=2 or self.keys.shape[1]!=12 or not np.isfinite(self.keys).all() or self.chunks.shape[0]!=len(self.keys) or self.chunks.ndim!=3 or self.chunks.shape[2]!=8 or not np.isfinite(self.chunks).all():raise ValueError('Malformed replay bank')
    def retrieve(self,state,player,count,segments,ticks):
        if self.keys is None:return []
        ids=np.flatnonzero(self.hitboxes==str(state['hitboxes'][player]))
        ids=ids[np.argsort(np.square(self.keys[ids]-state_key(state,player)).sum(1),kind='stable')[:count]]
        sample=np.minimum((np.arange(segments)*ticks/self.tick).astype(int),self.chunks.shape[1]-1)
        return [tuple(control_tuple(x) for x in self.chunks[i,sample]) for i in ids]

def candidate_pool(state,player,count,segments,ticks,bank=None):
    plans=[]
    def add(seq):
        seq=tuple(control_tuple(x) for x in seq)
        if seq not in plans:plans.append(seq)
    # Keep purposeful fallback plans even with a biased neural/replay prior.
    for role in (None,'attack','cover','retreat','aerial'):
        a=safe_drive(state,player,role);add([a]*segments)
    if bank is not None:
        for seq in bank.retrieve(state,player,max(2,count//2),segments,ticks):add(seq)
    base=safe_drive(state,player)
    primitives=[(0,0,0,0,0,0,0,0),(-1,0,0,0,0,0,0,0),(1,0,0,0,0,0,1,0)]
    for steer in (-1,-.5,.5,1):primitives.append((1,steer,0,steer,0,0,0,abs(steer)==1))
    primitives += [(1,0,-1,0,0,1,1,0),(1,0,-1,0,0,0,1,0),(0,0,1,0,0,0,1,0),(0,0,0,0,1,0,0,0),(0,0,0,0,-1,0,0,0)]
    for a in primitives:
        # Jump-release is an explicit sequence, not an indefinite jump hold.
        add([a]+[tuple(list(base[:5])+[False,base[6],base[7]])]*(segments-1))
    for a in primitives:
        for b in primitives:
            add([a,b]+[base]*(segments-2))
            if len(plans)>=count:return plans[:count]
    raise ValueError('Not enough diverse candidates')

def snapshot(arena,cars,template):
    from .policy_inference import live_state_flags
    states=[c.get_state() for c in cars]
    fields=('air_time','air_time_since_jump','jump_time','flip_time','is_flipping','is_jumping','has_jumped','has_double_jumped','has_flipped','is_demoed','demo_respawn_timer','boosting_time','handbrake_val')
    timers=[{k:getattr(v,k) for k in fields if hasattr(v,k)} for v in states]
    return dict(cars=np.stack([car_features(v) for v in states]),ball=ball_features(arena.ball.get_state()),flags=np.asarray([live_state_flags(c) for c in cars]),mode=template['mode'],hitboxes=template['hitboxes'],timers=timers)

def restored_arena(rs,state):
    arena,cars=replay_arena(rs,state)
    allowed={'air_time','air_time_since_jump','jump_time','flip_time','is_flipping','is_jumping','has_jumped','has_double_jumped','has_flipped','is_demoed','demo_respawn_timer','boosting_time','handbrake_val'}
    for car,metadata in zip(cars,state.get('timers',[])):
        value=car.get_state()
        for k,v in metadata.items():
            if k in allowed and hasattr(value,k) and isinstance(v,(int,float,bool)) and math.isfinite(v):setattr(value,k,v)
        car.set_state(value)
    return arena,cars


class HivePlanner:
    """12–64 flat joint team lines; three conditional modal continuations.

    Opponent predictions use only the current simulated state. Search results
    for the other team are never arguments, files or model inputs.
    """
    def __init__(self,rs,settings=None):
        from pathlib import Path
        self.rs=rs;self.cfg=settings or HiveSettings();self.brain=None
        path=Path(self.cfg.brain)
        if path.is_file():
            from .replay_bc_v415 import ReplayBrain
            self.brain=ReplayBrain(path)
        from .evaluation_v414 import make_evaluator
        source=self.cfg.evaluator
        if source=='auto':source='replay_goal_value' if Path('models/v414_goal_value_best.pt').is_file() else 'physics_proxy'
        self.evaluator=None if self.brain else make_evaluator(dict(game_evaluator=source))
    def modal(self,states):
        if self.brain:return self.brain.modal(states)
        return np.asarray([[[safe_drive(s,i)]*32 for i in range(len(s['cars']))] for s in states])
    def plan(self,state,team):
        if team not in (0,1):raise ValueError('Team must be 0 or 1')
        mode=int(state['mode']);n=len(state['cars']);cfg=self.cfg
        if mode not in (1,2,3) or n!=2*mode:raise ValueError('Balanced teams required')
        started=time.perf_counter();initial=self.modal([state])[0]
        if self.brain:proposals=self.brain.propose_team(state,team,cfg.candidates)
        else:
            pools=[candidate_pool(state,team*mode+j,cfg.candidates,32,1) for j in range(mode)]
            proposals=[np.stack([pools[j][(k+3*j)%cfg.candidates if k else 0] for j in range(mode)]) for k in range(cfg.candidates)]
        base,_=restored_arena(self.rs,state)
        signature=(mode,tuple(state['hitboxes']),len(proposals))
        if getattr(self,'_signature',None)!=signature:
            self._worlds=[base.clone() for _ in proposals];self._signature=signature
            self.rs.Arena.multi_step(self._worlds,1) # warm native physics caches once
        worlds=self._worlds
        for arena in worlds:base.clone_into(arena)
        controls=[]
        for proposal in proposals:
            commands=initial.copy();commands[team*mode:(team+1)*mode]=proposal;controls.append(commands)
        goals=[None]*len(worlds);end_states=[]
        for chunk in range(4):
            active=[i for i in range(len(worlds)) if goals[i] is None];t=0
            commands=np.asarray(controls)
            while t<32 and active:
                run=1
                while t+run<32 and np.array_equal(commands[active,:,t+run],commands[active,:,t]):run+=1
                for i in active:
                    for car,action in zip(worlds[i].get_cars(),commands[i,:,t]):car.set_controls(action_controls(self.rs,action))
                self.rs.Arena.multi_step([worlds[i] for i in active],run);t+=run
                for i in active:
                    arena=worlds[i]
                    if arena.blue_score!=base.blue_score or arena.orange_score!=base.orange_score:
                        goals[i]=1. if (arena.blue_score-base.blue_score)>(arena.orange_score-base.orange_score) else -1.
                active=[i for i in active if goals[i] is None]
            end_states=[snapshot(a,a.get_cars(),state) for a in worlds]
            if chunk<3:controls=self.modal(end_states) # batched, re-predicted at every chunk boundary
        if self.brain:values=self.brain.team_values(end_states,team)
        else:values=np.array([self.evaluator.score(s)*(1 if team==0 else -1) for s in end_states])
        for i,g in enumerate(goals):
            if g is not None:values[i]=g*(1 if team==0 else -1)
        if not np.isfinite(values).all():raise ValueError('Nonfinite rollout values')
        best=int(np.argmax(values));elapsed=time.perf_counter()-started
        return dict(version='flat-replay-hive-v415',team=team,controls=np.asarray(proposals[best]).tolist(),ticks=1,
                    elapsed=elapsed,rollouts=len(worlds),candidates_per_player=cfg.candidates,
                    chosen_joint_candidate=best,value=float(values[best]),line_values=values.tolist(),
                    evaluator=self.brain.source if self.brain else self.evaluator.source,
                    controller='REPLAY_BC_WITH_LIVE_SEARCH' if self.brain else 'GEOMETRIC_SEARCH_DIAGNOSTIC_NOT_TRAINED',
                    budget_exceeded=elapsed>cfg.budget_ms/1000,
                    scope='Flat first-chunk proposals; 3 conditional policy-mode continuations; other team chosen plan never observed')
