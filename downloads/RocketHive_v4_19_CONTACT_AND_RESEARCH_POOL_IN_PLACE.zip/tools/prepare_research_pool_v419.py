"""Create a larger, separate replay research pool; never alter a frozen run."""
from pathlib import Path
import argparse,hashlib,json,shutil,time,zipfile
import numpy as np
from tools.prepare_replay_training_v417 import index_replays

TARGETS={'train':96,'val':12,'test':2}
def summary(pool):
    result={}
    for split in TARGETS:
        n=0;rows=0;by_mode={}
        for p in sorted((Path(pool)/split).glob('*.npz')):
            with np.load(p,allow_pickle=False) as z:
                x=z['obs'];assert x.ndim==2 and x.shape[1]==240 and len(x)>0
                m=int(round(float(x[0,-1])*3));by_mode[str(m)]=by_mode.get(str(m),0)+1;n+=1;rows+=len(x)
        result[split]=dict(files=n,rows=rows,modes=by_mode)
    return result

def choose(groups,counts,attempted,targets):
    for s in ('val','train','test'):
        enough=counts[s]['files']>=targets[s]
        if s=='val':enough=enough and counts[s]['modes'].get('2',0)>=2
        if enough:continue
        for p,h in groups[s]:
            if h not in attempted:return s,p,h
    return None

def prepare(root='.',max_files=96,minutes=30,targets=None):
    import replicar
    from src.replicar_dataset import find_meshes
    from src.replay_chunks_v415 import build
    from tools.prepare_chunks_v415 import convert_one
    root=Path(root).resolve();pool=root/'data/replay419';targets=targets or TARGETS
    if (pool/'FROZEN_DATASET.lock').exists():raise ValueError('This research pool is frozen by a training experiment. Keep it unchanged and use a new pool for additional games.')
    if max_files<=0 or minutes<=0:raise ValueError('Positive preparation budgets required')
    meshes=find_meshes(root)
    if not meshes:raise ValueError('Existing Soccar collision meshes are required')
    for split in TARGETS:
        dest=pool/split;dest.mkdir(parents=True,exist_ok=True)
        for p in (root/'data/v415_chunks'/split).glob('*.npz'):
            target=dest/p.name
            if not target.exists():shutil.copy2(p,target)
    groups=index_replays(root);attempted=set();rows=[];deadline=time.monotonic()+minutes*60
    for s,items in groups.items():
        for p,h in items:
            dest=root/'replicar_120hz'/(h+'.parquet')
            if dest.is_file():
                attempted.add(h)
                convert_one(root,p,meshes,replicar.convert)
                build(root,limit=1024,paths=[dest],output=pool,report_name='v415_research_import.json')
    counts=summary(pool)
    try:
        while len(rows)<max_files and time.monotonic()<deadline:
            pick=choose(groups,counts,attempted,targets)
            if pick is None:break
            split,p,h=pick;attempted.add(h)
            print('RESEARCH_PREPARE',len(rows)+1,'/',max_files,split,p.name,flush=True)
            row=dict(split=split,replay_sha256=h)
            try:
                dest=convert_one(root,p,meshes,replicar.convert)
                result=build(root,limit=1024,paths=[dest],output=pool,report_name='v415_research_import.json');row.update(result[0])
            except Exception as exc:row.update(status='rejected',reason=type(exc).__name__+': '+str(exc))
            rows.append(row);counts=summary(pool);print('RESEARCH_COUNTS',counts,flush=True)
    except KeyboardInterrupt:print('RESEARCH_PREPARATION_PAUSED: completed data preserved',flush=True)
    done=all(counts[s]['files']>=targets[s] for s in targets) and counts['val']['modes'].get('2',0)>=2
    report=dict(version='v4.19',pool=str(pool),targets=targets,counts=counts,attempts=rows,targets_met=done,old_data_and_checkpoints_unchanged=True,training_started=False,deadline_checked_between_games=True)
    (root/'reports').mkdir(exist_ok=True);(root/'reports/v415_research_pool.json').write_text(json.dumps(report,indent=2),encoding='utf8')
    print('RESEARCH_POOL_READY' if done else 'RESEARCH_POOL_INCOMPLETE: run the same preparation again to continue',flush=True)
    return report

def pack(root='.',part_limit=27*1024**2):
    root=Path(root).resolve();pool=root/'data/replay419';out=root/'reports';out.mkdir(exist_ok=True)
    files=[(s,p) for s in ('train','val') for p in sorted((pool/s).glob('*.npz'))]
    if not files:raise ValueError('Research pool is empty; prepare it first')
    # No raw replays, weights, environments, keys or test data in this share pack.
    archives=[];z=None;used=0
    try:
        for split,p in files:
            size=p.stat().st_size
            if size>part_limit:raise ValueError('One chunk exceeds the archive size budget')
            if z is None or used+size>part_limit:
                if z:z.close()
                target=out/f'Replay419_data_{time.time_ns()}_part{len(archives)+1:02d}.zip';archives.append(str(target));z=zipfile.ZipFile(target,'w',zipfile.ZIP_STORED);used=0
            z.write(p,split+'/'+p.name);used+=size
    finally:
        if z:z.close()
    for p in archives:print('RESEARCH_DATA_SHARE:',p,flush=True)
    return archives

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--pack-only',action='store_true');p.add_argument('--max-files',type=int,default=96);p.add_argument('--minutes',type=float,default=30);a=p.parse_args()
    if not a.pack_only:prepare(max_files=a.max_files,minutes=a.minutes)
    pack()
