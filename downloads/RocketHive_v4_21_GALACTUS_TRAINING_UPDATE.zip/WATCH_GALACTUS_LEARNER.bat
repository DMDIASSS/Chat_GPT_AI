@echo off
setlocal
cd /d "%~dp0"
".venv\Scripts\python.exe" -u -m tools.watch_hive_v415 --model runs/galactus421/latest.pt --controller policy --mode 2 --seconds 0
if errorlevel 1 echo COMMAND_FAILED - keep the output above.
pause
