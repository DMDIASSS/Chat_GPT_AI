"""Replay-anchored option-selector PPO against pinned Galactus V2.
Screening results select exploratory candidates, never certified champions.
"""
from pathlib import Path
import argparse,copy,hashlib,json,signal,time
import numpy as np
import torch
from torch import nn
from src.replay_final import load_brain,canonical
from src.replay_final_data import load_pool
from src.search_teacher import make_observation
from src.live_hive_v415 import snapshot
from src.physics_search import action_controls,replay_arena
from src.kickoff_v419 import kickoff
from src.galactus_v416 import GalactusTeam
from src.hive_runtime_v415 import TeamLock
from tools.train_replay_final import atomic_save,assign
ROOT=Path(__file__).resolve().parents[1]

class Match:
    def __init__(self,mode=2,seed=421,seconds=30):
        import RocketSim as rs
        from tools.watch_bot_rlviser import make_match
        self.rs=rs;self.mode=mode;self.rng=np.random.default_rng(seed);self.seconds=seconds
        self.arena,self.cars=make_match(rs,mode);self.enemy=GalactusTeam(self.arena,self.cars,1,seed);self.reset(0)
    def reset(self,side,replay=None):
        self.side=side;self.elapsed=0;self.goals=np.zeros(2,int)
        if replay is not None:self.arena,self.cars=replay_arena(self.rs,replay)
        else:kickoff(self.rs,self.arena,self.cars,self.mode,rng=self.rng)
        self.enemy.team=1-side;self.enemy.reset(self.arena,self.cars)
        return self.state()
    def state(self):return snapshot(self.arena,self.cars,dict(mode=self.mode,hitboxes=['octane']*(2*self.mode)))
    def step(self,chunk):
        reward=0.
        for tick in range(8):
            enemy=self.enemy.commands(self.arena,self.cars);commands=list(chunk[:,tick])
            all_actions=commands+enemy if self.side==0 else enemy+commands
            for car,a in zip(self.cars,all_actions):car.set_controls(action_controls(self.rs,a))
            before=np.array([self.arena.blue_score,self.arena.orange_score]);self.arena.step(1);delta=np.array([self.arena.blue_score,self.arena.orange_score])-before
            self.elapsed+=1
            if delta.any():
                self.goals+=delta;reward+=float(delta[self.side]-delta[1-self.side]);kickoff(self.rs,self.arena,self.cars,self.mode,rng=self.rng);self.enemy.reset(self.arena,self.cars)
            if self.elapsed>=round(self.seconds*120):break
        done=self.elapsed>=round(self.seconds*120)
        if done:reward+=float(np.sign(self.goals[self.side]-self.goals[1-self.side]))
        return self.state(),reward,done

def observations(s,side):
    m=s['mode'];return np.stack([make_observation(s,j) for j in range(side*m,(side+1)*m)])

def replay_start(obs,mode,rng):
    """Restore the current public state of a training replay, never its future actions."""
    from src.replay_final import rotation
    x=obs[int(rng.integers(len(obs)))];me=x[26:40].copy();me[:3]*=6000;me[7:10]*=2300;me[10:13]*=6
    cars=x[40:124].reshape(6,14)[:2*mode].copy();cars[:,:3]=cars[:,:3]*6000+me[:3];cars[:,7:10]=cars[:,7:10]*2300+me[7:10];cars[:,10:13]*=6
    ball=x[:13].copy();ball[:3]*=6000;ball[7:10]*=6000;ball[10:13]*=6
    names=np.array(['octane','dominus','plank','breakout','hybrid','merc','psyclops']);boxes=names[x[136:178].reshape(6,7)[:2*mode].argmax(1)]
    # This experiment is Octane. Do not silently re-simulate another hitbox.
    if np.any(boxes!='octane'):return None
    return dict(mode=mode,cars=cars,ball=ball,flags=x[178:238].reshape(6,10)[:2*mode].copy(),hitboxes=boxes)

@torch.inference_mode()
def evaluate(brain,mode,seeds,seconds):
    out=[];env=Match(mode,int(seeds[0]),seconds)
    for seed in seeds:
        for side in (0,1):
            env.rng=np.random.default_rng(int(seed));env.enemy.rng=np.random.default_rng(int(seed));s=env.reset(side);done=False
            while not done:
                a,_=brain.predict_observations(observations(s,side));s,_,done=env.step(a)
            gf,ga=int(env.goals[side]),int(env.goals[1-side]);out.append(dict(seed=int(seed),side=side,gf=gf,ga=ga,score=1. if gf>ga else 0. if gf<ga else .5))
        print('GALACTUS_EVAL',len(out),'games',flush=True)
    return out

def summary(matches):
    a=np.array([x['score'] for x in matches]);return dict(games=len(a),wins=int((a==1).sum()),draws=int((a==.5).sum()),losses=int((a==0).sum()),score_rate=float(a.mean()),goals_for=sum(x['gf'] for x in matches),goals_against=sum(x['ga'] for x in matches))

def train(root=ROOT,rounds=0,steps=512,seconds=30,eval_games=24,eval_seconds=60,eval_every=4,mode=2):
    root=Path(root).resolve();run=root/'runs/galactus421';run.mkdir(parents=True,exist_ok=True);lock=TeamLock(run/'training.lock')
    if not lock.acquire():raise ValueError('Galactus trainer is already running')
    if (root/'runs/replay_final/training.lock').exists():
        other=TeamLock(root/'runs/replay_final/training.lock')
        if not other.acquire():lock.close();raise ValueError('Pause the replay trainer first')
        other.close()
    stop=root/'STOP_GALACTUS421';stop.unlink(missing_ok=True);old=signal.signal(signal.SIGINT,lambda *_:stop.touch())
    try:
        torch.set_num_threads(1);torch.manual_seed(421);rng=np.random.default_rng(421)
        statefile=run/'training_state.pt'
        if statefile.exists():ck=torch.load(statefile,map_location='cpu',weights_only=True)
        else:
            src=root/'runs/replay_final/best_validation.pt';brain=load_brain(src)
            if brain.source!='REPLAY_DERIVED_OPTIONS_WITH_GOAL_VALUE':raise ValueError('The v4.20 replay-options model is required')
            raw=torch.load(src,map_location='cpu',weights_only=True);atomic_save(run/'baseline.pt',raw);ck=None
        protocol=dict(mode=mode,seconds=seconds,eval_seconds=eval_seconds,eval_games=eval_games)
        protocol_file=run/'protocol.json'
        if protocol_file.exists() and json.loads(protocol_file.read_text())!=protocol:raise ValueError('Resume with the original mode and match lengths')
        protocol_file.write_text(json.dumps(protocol))
        base=load_brain(run/'baseline.pt');brain=load_brain(run/'baseline.pt');net=brain.net
        net.requires_grad_(False);net.code.requires_grad_(True) # deterministic replay decoder remains fixed
        critic=nn.Linear(256,1);nn.init.zeros_(critic.weight);nn.init.zeros_(critic.bias)
        opt=torch.optim.Adam(list(net.code.parameters())+list(critic.parameters()),lr=1e-4)
        round_id=0;total=0
        if ck:net.load_state_dict(ck['network']);critic.load_state_dict(ck['critic']);opt.load_state_dict(ck['optimizer']);round_id=ck['round'];total=ck['decisions'];rng.bit_generator.state=ck['rng'];torch.set_rng_state(ck['torch_rng'])
        pool=root/'data/replay_final';pool=pool if (pool/'train').exists() else root/'data/replay419'
        tr,_,hashes,info=load_pool(pool);mask=np.rint(tr[0][:,-1]*3).astype(int)==mode;rx=tr[0][mask];ry=tr[1][mask]
        if len(rx)<64:raise ValueError('Need at least 64 training replay examples in the chosen mode')
        if ck and ck['train_manifest']!=hashes['train']:raise ValueError('Replay files changed; checkpoint preserved. Resume with the original pool')
        labels=assign(ry,base.books)
        with torch.no_grad():features=net.trunk(brain._input(rx)).clone();reference=base.net.code(features).softmax(-1).clone()
        env=Match(mode,421,seconds);side=int(rng.integers(2));s=env.reset(side);started=round_id
        reports=root/'reports';reports.mkdir(exist_ok=True);seedfile=run/'screen_seeds.json'
        if seedfile.exists():seeds=json.loads(seedfile.read_text())
        else:
            seeds=np.random.default_rng(8421).integers(1_000_000_000,2_000_000_000,size=eval_games//2).tolist();seedfile.write_text(json.dumps(seeds))
        baselinefile=run/'baseline_matches.json'
        if baselinefile.exists():baseline=json.loads(baselinefile.read_text())
        else:baseline=evaluate(base,mode,seeds,eval_seconds);baselinefile.write_text(json.dumps(baseline))
        if ck and ck['protocol']!=dict(mode=mode,seconds=seconds,eval_seconds=eval_seconds,eval_games=eval_games):raise ValueError('Resume with the original mode and match lengths')
        def packet():
            p=torch.load(run/'baseline.pt',map_location='cpu',weights_only=True);p['network']={k:v.detach().cpu().clone() for k,v in net.state_dict().items()};p['galactus_training']=dict(round=round_id,decisions=total,objective='goal difference plus terminal win/draw/loss, PPO with replay CE and baseline KL',playing_strength_verified=False);return p
        def save():
            atomic_save(run/'latest.pt',packet());atomic_save(statefile,dict(network=net.state_dict(),critic=critic.state_dict(),optimizer=opt.state_dict(),torch_rng=torch.get_rng_state(),round=round_id,decisions=total,rng=rng.bit_generator.state,train_manifest=hashes['train'],protocol=dict(mode=mode,seconds=seconds,eval_seconds=eval_seconds,eval_games=eval_games)))
        print('GALACTUS_TRAIN: CPU native play; replay-derived move options. Search is disabled during training/evaluation. Pause with Ctrl+C.',flush=True)
        while not stop.exists() and (rounds<=0 or round_id<started+rounds):
            hs=[];ids=[];logs=[];values=[];rewards=[];dones=[]
            for i in range(steps):
                with torch.no_grad():
                    h=net.trunk(brain._input(observations(s,side)));d=torch.distributions.Categorical(logits=net.code(h));chosen=d.sample();commands=net.decode(h,chosen,brain.books).numpy();value=critic(h).mean()
                hs.append(h);ids.append(chosen);logs.append(d.log_prob(chosen).sum());values.append(value);s,r,done=env.step(commands);rewards.append(r);dones.append(done);total+=1
                if done:
                    side=int(rng.integers(2));replay=replay_start(rx,mode,rng) if rng.random()<.5 else None;s=env.reset(side,replay)
                if stop.exists():break
            with torch.no_grad():tail=critic(net.trunk(brain._input(observations(s,side)))).mean()
            vals=torch.stack(values);advantages=torch.zeros(len(rewards));last=0.
            for i in reversed(range(len(rewards))):
                next_value=tail if i==len(rewards)-1 else vals[i+1];live=1-float(dones[i]);delta=rewards[i]+.995*live*next_value-vals[i];last=delta+.995*.95*live*last;advantages[i]=last
            returns=advantages+vals;advantages=(advantages-advantages.mean())/advantages.std(unbiased=False).clamp_min(1e-6);h=torch.stack(hs);actions=torch.stack(ids);oldlog=torch.stack(logs)
            for epoch in range(3):
                for batch in rng.permutation(len(h)).reshape(-1,64) if len(h)%64==0 else np.array_split(rng.permutation(len(h)),max(1,(len(h)+63)//64)):
                    j=torch.as_tensor(batch);dist=torch.distributions.Categorical(logits=net.code(h[j]));ratio=(dist.log_prob(actions[j]).sum(-1)-oldlog[j]).exp();pl=-torch.minimum(ratio*advantages[j],ratio.clamp(.85,1.15)*advantages[j]).mean();vl=(critic(h[j]).mean(1).flatten()-returns[j]).square().mean()
                    k=torch.from_numpy(rng.integers(len(features),size=128));z=net.code(features[k]);bc=nn.functional.cross_entropy(z,labels[k]);kl=nn.functional.kl_div(z.log_softmax(-1),reference[k],reduction='batchmean')
                    loss=pl+.5*vl+.1*bc+.03*kl-.005*dist.entropy().mean()
                    if not torch.isfinite(loss):raise ValueError('Nonfinite loss; prior checkpoint retained')
                    opt.zero_grad();loss.backward();nn.utils.clip_grad_norm_(list(net.code.parameters())+list(critic.parameters()),.5);opt.step()
            round_id+=1;save();print('GALACTUS_ROUND',round_id,'decisions',total,'goals/result reward',sum(rewards),'replay_loss',round(float(bc.detach()),4),flush=True)
            status=dict(round=round_id,decisions=total,replay_games=info['train']['files'],mode=mode,baseline_sha256=hashlib.sha256((run/'baseline.pt').read_bytes()).hexdigest(),candidate_sha256=hashlib.sha256((run/'latest.pt').read_bytes()).hexdigest(),galactus_identity=env.enemy.identity,playing_strength_verified=False)
            if round_id%eval_every==0 and not stop.exists():
                results=evaluate(brain,mode,seeds,eval_seconds);status.update(candidate=summary(results),baseline=summary(baseline),evaluation='Repeated screening panel; not held-out proof of improvement')
                path=run/f'round_{round_id:06d}_matches.json';detail=json.dumps(dict(protocol='galactus421-policy-screen',candidate=results,baseline=baseline,summary=status),indent=2);path.write_text(detail);(reports/'v415_galactus421_wdl.json').write_text(detail)
                previous=json.loads((run/'selection.json').read_text()) if (run/'selection.json').exists() else {'score_rate':summary(baseline)['score_rate']}
                if status['candidate']['score_rate']>previous['score_rate']:
                    atomic_save(run/'screen_candidate.pt',packet());(run/'selection.json').write_text(json.dumps(dict(round=round_id,score_rate=status['candidate']['score_rate'],playing_strength_verified=False),indent=2));print('SCREEN_CANDIDATE_SAVED: exploratory; requires fresh evaluation',flush=True)
                print('GALACTUS_WDL',status['candidate'],'BASELINE',status['baseline'],flush=True)
            (reports/'v415_galactus421_status.json').write_text(json.dumps(status,indent=2))
        save();print('GALACTUS_PAUSED: saved',run,flush=True)
    finally:signal.signal(signal.SIGINT,old);lock.close()

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--rounds',type=int,default=0);p.add_argument('--steps',type=int,default=512);p.add_argument('--seconds',type=float,default=30);p.add_argument('--eval-games',type=int,default=24);p.add_argument('--eval-seconds',type=float,default=60);p.add_argument('--eval-every',type=int,default=4);p.add_argument('--mode',type=int,choices=[1,2,3],default=2);a=p.parse_args()
    if a.steps<8 or a.seconds<=0 or a.eval_seconds<=0 or a.eval_games<2 or a.eval_games%2 or a.eval_every<1:p.error('Positive budgets, >=8 steps, and an even evaluation game count required')
    train(rounds=a.rounds,steps=a.steps,seconds=a.seconds,eval_games=a.eval_games,eval_seconds=a.eval_seconds,eval_every=a.eval_every,mode=a.mode)
