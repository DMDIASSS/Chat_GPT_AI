# Galactus training update v4.21
Extract beside V415_MENU.bat in the existing v4.20 RocketHive folder. Pause the replay trainer first.

1. Run START_GALACTUS_TRAINING.bat. The first panel measures your frozen replay model against Galactus; progress prints every two evaluation games. This can take several minutes.
2. Leave running until PAUSE_GALACTUS_TRAINING.bat or Ctrl+C. Wait for GALACTUS_PAUSED. Reuse Start to resume.
3. Run WATCH_GALACTUS_LEARNER.bat to see the latest experimental policy in live 2v2 against Galactus. Search is disabled for this comparison. This can be worse than the starting model.
4. REPORT_LIVE_HIVE.bat collects status; also send runs/galactus421/round_*_matches.json for detailed evaluations. Export with EXPORT_GALACTUS_LEARNER.bat (RLBot4 policy-only export, using the same controller mode as training/evaluation).

The learner plays 2v2 against hash-verified frozen Galactus V2, alternates colors, and maximizes goal difference plus terminal win/draw/loss using categorical PPO. It chooses amongst the existing replay-derived move options. A supervised replay action loss and KL penalty to the frozen starting policy constrain updates. This first small update changes the option selection head, preserving the replay decoder, shared features and replay-trained search evaluator. CPU native simulation is used; it does not train the full network or accelerate search.

Half the training episode resets attempt verified Octane training-replay current states; the remainder use standard kickoffs. Random replay starts restore observed positions/velocities/flags but cannot recover all unrecorded physics timers. Evaluation always uses standard kickoffs, both colors, modal policy moves, 24 sixty-second games. A draw counts as half a win. Training episodes last 30 simulated seconds. Evaluation every four 512-decision rounds compares to the frozen starting model on the same seeds.

All artifacts are under runs/galactus421. baseline.pt is pinned once; latest.pt and training_state.pt save after every round and graceful pause. The original replay model is not overwritten. screen_candidate.pt saves only when the repeated panel score exceeds the prior selected score, starting from baseline score. Repeated screening is exploratory, not held-out evidence or a certified promotion. No stronger-bot guarantee is made, and zero wins can persist against a strong opponent. The frozen replay value head remains imperfect. Match logs and actual behavior should decide the next experiment.

Local reports/v415_galactus421_status.json records progress. This launcher does not add remote W&B logging. Close other trainers/games to reduce laptop contention. Menu 6 continues to launch the original supervised trainer; use the new Start launcher for this experiment.
