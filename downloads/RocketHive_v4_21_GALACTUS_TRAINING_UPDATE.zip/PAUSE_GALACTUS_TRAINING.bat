@echo off
setlocal
cd /d "%~dp0"
".venv\Scripts\python.exe" -c "from pathlib import Path; Path('STOP_GALACTUS421').touch(); print('Pause requested; wait for GALACTUS_PAUSED.')"
if errorlevel 1 echo COMMAND_FAILED - keep the output above.
pause
