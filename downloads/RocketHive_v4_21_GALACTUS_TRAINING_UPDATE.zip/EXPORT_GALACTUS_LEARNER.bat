@echo off
setlocal
cd /d "%~dp0"
".venv\Scripts\python.exe" -u -m tools.export_hive_v415 --policy-only --model runs/galactus421/latest.pt --output exports/RocketHive_Galactus421_RLBot4.zip
if errorlevel 1 echo COMMAND_FAILED - keep the output above.
pause
