@echo off
setlocal
cd /d "%~dp0"
".venv\Scripts\python.exe" -u -m tools.train_galactus_v421
if errorlevel 1 echo COMMAND_FAILED - keep the output above.
pause
