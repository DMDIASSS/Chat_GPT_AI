"""RLBot v4 live-search controller; a shared worker plans all teammates."""
from pathlib import Path
import atexit,hashlib,json,os,sys,time
from rlbot.agents.base_agent import BaseAgent,SimpleControllerState
ROOT=Path(__file__).resolve().parent
if str(ROOT) not in sys.path:sys.path.insert(0,str(ROOT))
from packet_adapter import packet_state,PacketHistory
from src.hive_runtime_v415 import TeamClient
from src.live_hive_v415 import HiveSettings

class RocketHiveBot(BaseAgent):
    def initialize_agent(self):
        # A configurable match ID also lets separately launched clients share a hive.
        session=os.environ.get('ROCKETHIVE_MATCH_ID','RLBot4-local')
        count=int(os.environ.get('ROCKETHIVE_CANDIDATES','12'))
        config=ROOT/'controller_settings.json'
        options=json.loads(config.read_text()) if config.exists() else {}
        self.hive=TeamClient(int(self.team),session,project=ROOT,settings=HiveSettings(candidates=count,search_enabled=bool(options.get('search_enabled',True)),evaluator=options.get('evaluator','auto'),request_ticks=int(options.get('request_ticks',8))))
        self.history=PacketHistory();self.last_status=None;atexit.register(self.hive.close)
        print('[RocketHive] LIVE controller:', 'search' if options.get('search_enabled',True) else 'policy only', '; separate team workers; controller sources are logged.',flush=True)
    def get_output(self,packet):
        if not hasattr(self,'hive'):return SimpleControllerState()
        if not getattr(packet.game_info,'is_round_active',True):return SimpleControllerState()
        state,position=packet_state(packet,self.index)
        if hasattr(self,'history'):self.history.update(packet,state)
        roster=hashlib.sha256(str([(int(c.team),str(getattr(c,'name','')),i) for i,c in enumerate(packet.game_cars[:packet.num_cars])]).encode()).hexdigest()
        commands=self.hive.controls(state,float(packet.game_info.seconds_elapsed),roster)
        a=commands[position%int(state['mode'])]
        if self.hive.status!=self.last_status:
            print('[RocketHive controller]',self.hive.status,flush=True);self.last_status=self.hive.status
        out=SimpleControllerState()
        for key,value in zip(('throttle','steer','pitch','yaw','roll','jump','boost','handbrake'),a):setattr(out,key,value)
        return out
    def retire(self):
        if hasattr(self,'hive'):self.hive.close()
