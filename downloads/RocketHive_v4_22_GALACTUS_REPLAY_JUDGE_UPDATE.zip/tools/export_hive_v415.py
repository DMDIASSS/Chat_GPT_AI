"""Portable RLBot4 live search. No keys, replay logs, or existing model overwrite."""
from pathlib import Path
import argparse,json,shutil,tempfile,zipfile,sys
ROOT=Path(__file__).resolve().parents[1]

def export(output='exports/RocketHive_Live_Hive_RLBot4.zip',allow_geometric=False,model=None,policy_only=False,galactus_judge=False):
    from tools.replay_readiness_v417 import require_brain
    require_brain(ROOT,allow_geometric,model)
    if galactus_judge:
        if policy_only:raise ValueError('The Galactus judge requires search mode')
        from src.galactus_replay_value_v422 import GalactusReplayValue
        judge=GalactusReplayValue(ROOT/'models/galactus_replay_value.pt')
    output=Path(output).resolve();output.parent.mkdir(parents=True,exist_ok=True)
    from tools.native_rlviser import find_meshes
    meshes=find_meshes()
    if meshes is None:raise ValueError('Live search export needs your installed Soccar meshes; keep them in third_party/collision_meshes or set REPLICAR_MESHES')
    brain=Path(model) if model else ROOT/'models/v415_replay_brain.pt'
    if not brain.is_absolute():brain=ROOT/brain
    with tempfile.TemporaryDirectory() as temp:
        digest=None
        included=brain.exists()
        if included:
            from src.replay_final import pin_checkpoint
            brain,digest=pin_checkpoint(brain,Path(temp)/'checkpoint')
        base=Path(temp)/'RocketHiveBot';shutil.copytree(ROOT/'rlbot_hive/RocketHiveBot',base,ignore=shutil.ignore_patterns('__pycache__','*.pyc'))
        for folder in ('src','tools'):
            (base/folder).mkdir()
            names=[p.name for p in (ROOT/folder).glob('*.py')] if folder=='src' else ['native_rlviser.py','hive_worker_v415.py']
            for name in names:shutil.copy2(ROOT/folder/name,base/folder/name)
        (base/'controller_settings.json').write_text(json.dumps(dict(search_enabled=not policy_only,evaluator='galactus_replay' if galactus_judge else 'auto',request_ticks=1 if galactus_judge else 8)))
        (base/'worker_python.json').write_text(json.dumps(dict(python=sys.executable,purpose='Reuse the exporting project Python for the background search worker; no second Torch/CUDA install'),indent=2))
        if brain.exists():
            (base/'models').mkdir();shutil.copy2(brain,base/'models/v415_replay_brain.pt')
        if galactus_judge:
            from src.galactus_v416 import locate,HASHES
            (base/'models').mkdir(exist_ok=True);shutil.copy2(ROOT/'models/galactus_replay_value.pt',base/'models/galactus_replay_value.pt')
            (base/'models/galactus_v2').mkdir()
            for name in HASHES:shutil.copy2(locate()/name,base/'models/galactus_v2'/name)
        shutil.copytree(meshes,base/'third_party/collision_meshes')
        (base/'EXPORT_STATUS.json').write_text(json.dumps(dict(controller='REPLAY_BC_WITH_LIVE_SEARCH' if brain.exists() else 'GEOMETRIC_SEARCH_DIAGNOSTIC_NOT_TRAINED',format='RLBot4',search_enabled=not policy_only,model_sha256=digest,galactus_judge=galactus_judge,playing_strength_verified=False),indent=2))
        (base/'INSTALL.bat').write_text('@echo off\r\ncd /d "%~dp0"\r\npython -m pip install -r requirements.txt\r\nif errorlevel 1 exit /b 1\r\necho If EXPORT_STATUS says replay BC, use your existing PyTorch-enabled Python for RLBot.\r\npause\r\n')
        with zipfile.ZipFile(output,'w',zipfile.ZIP_DEFLATED) as z:
            for p in base.rglob('*'):
                if p.is_file():z.write(p,p.relative_to(base.parent))
    print('EXPORTED:',output,'replay brain included:',included,flush=True);return output
if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--output',default='exports/RocketHive_Live_Hive_RLBot4.zip');p.add_argument('--allow-geometric',action='store_true');p.add_argument('--model');p.add_argument('--policy-only',action='store_true');p.add_argument('--galactus-judge',action='store_true');a=p.parse_args();export(a.output,a.allow_geometric,a.model,a.policy_only,a.galactus_judge)
