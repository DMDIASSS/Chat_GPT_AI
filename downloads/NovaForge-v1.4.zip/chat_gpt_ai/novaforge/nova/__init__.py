"""NovaForge: a small, reproducible RocketSim 1v1 research bot."""
__version__ = '1.4.0'
