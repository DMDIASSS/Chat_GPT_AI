@echo off
cd /d "%~dp0"
if exist ".venv\Scripts\python.exe" (set "PY=.venv\Scripts\python.exe") else (set "PY=python")
%PY% -m tools.enable_v414_defaults
if errorlevel 1 echo Settings not updated. Inspect the traceback above.
pause
