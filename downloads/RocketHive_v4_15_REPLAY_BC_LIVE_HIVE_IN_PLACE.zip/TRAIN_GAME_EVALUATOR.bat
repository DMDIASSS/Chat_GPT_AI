@echo off
cd /d "%~dp0"
if exist ".venv\Scripts\python.exe" (set "PY=.venv\Scripts\python.exe") else (set "PY=python")
echo Training a BLUE vs ORANGE next-goal model on parsed replay goal events.
echo It does not predict full-match winners and it uses data/val for hold-out evaluation.
%PY% -m tools.train_game_evaluator_v414 --steps 800
if errorlevel 1 (echo Failed. See the first [value] error above.) else (echo Value-head training complete.)
pause
