@echo off
setlocal
cd /d "%~dp0"
".venv\Scripts\python.exe" -m tools.monitor_v44 --watch --interval 10
pause
