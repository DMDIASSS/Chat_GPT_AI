@echo off
setlocal
cd /d "%~dp0"
if not exist ".venv\Scripts\python.exe" (
  echo Existing .venv was not found.
  pause
  exit /b 2
)
".venv\Scripts\python.exe" -m tools.train_action_controller_v48 --diagnose-only --config config_v4.json
pause
