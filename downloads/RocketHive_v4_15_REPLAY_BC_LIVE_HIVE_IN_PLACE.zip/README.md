# RocketHive replay BC and live hive search

This folder contains the v4.15 in-place code update. Read [the complete start/train/watch/export instructions](README_V4_15_REPLAY_BC_LIVE_HIVE.md).

The new main path learns 32-tick reconstructed human control chunks and discounted next-goal values, then uses live flat search with joint team plans. It does not replace the saved pose champion or claim that the legacy search-distilled action policy already implements this architecture.

No strong pretrained replay brain is bundled. VERIFY_LIVE_HIVE works immediately as a labelled geometric/native-search diagnostic; the learned mode requires importing and training on your own replays.

Extract directly into the existing RocketHive project folder, merge code files, and keep your .venv, models, configs, keys, and data.
