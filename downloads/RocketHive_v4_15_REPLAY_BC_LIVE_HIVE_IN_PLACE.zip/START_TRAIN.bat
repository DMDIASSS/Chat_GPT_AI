@echo off
setlocal
cd /d "%~dp0"
set "PYEXE=py -3.12"
py -3.12 -V >nul 2>&1 || (set "PYEXE=python")
if not exist ".venv\Scripts\python.exe" (
    echo No existing virtual environment found. Creating .venv for a FIRST-TIME setup...
    %PYEXE% -m venv .venv || goto :error
    set "NEEDS_SETUP=1"
) else (
    echo Reusing original .venv and installed libraries; skipping setup / pip.
)
set "PY=.venv\Scripts\python.exe"
if defined NEEDS_SETUP (
    "%PY%" tools\setup.py || goto :error
)
echo Parsing replays and training using existing environment...
"%PY%" -m src.pipeline --config config.json || goto :error
echo.
echo Success! See models\ and reports\.
pause
exit /b 0
:error
echo.
echo Training failed. If a Python module is missing, install that module into .venv explicitly.
echo Existing installed libraries will not be upgraded automatically.
pause
exit /b 1
