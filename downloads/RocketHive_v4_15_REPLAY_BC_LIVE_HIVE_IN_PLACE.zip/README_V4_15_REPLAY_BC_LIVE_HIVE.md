# RocketHive 4.15: replay chunk imitation + live search

Merge this update INTO the existing RocketHive folder containing START_V4.bat.
Stop trainers/viewers/bots first. The update contains code and tests, no model,
API key, replay, CUDA installer or replacement ML environment. Existing models,
configs, W&B bindings, credentials and datasets are preserved. No old model is
silently renamed as the new bot. The new trained file is models/v415_replay_brain.pt.

## The important change

Previous exports ran a tiny search-distilled 22-action policy independently for
each car. They did not run live search or a teammate hive. That legacy action
space also lacks neutral/coast. These observations do NOT identify the exact
cause of collapse in a checkpoint whose weights were not supplied.

The new path reconstructs controls from human replays, learns tick-level chunks
and a discounted next-goal value, and searches during actual gameplay. It does
not train on search labels or simulated self-play. START_V4.bat still runs the
legacy pose-training pipeline; it is not the launcher for this new method.

## First test, before training

1. Run VERIFY_LIVE_HIVE.bat. It simulates 1v1/2v2/3v3 and writes
   reports/v415_live_verify.json. Without a new trained brain it explicitly says
   GEOMETRIC_SEARCH_DIAGNOSTIC_NOT_TRAINED, not "trained AI".
2. Run SETUP_ROCKETSIMVIS.bat once. It downloads the pinned ZealanL/RocketSimVis
   source and installs GUI dependencies in third_party/RocketSimVis/.venv.
   The separate GUI environment is necessary because upstream's older graphics
   stack needs NumPy 1.x; your ML/RLViser environment is not downgraded.
3. WATCH_LIVE_HIVE_ROCKETSIMVIS.bat starts a LIVE 2v2 RocketSim match with
   independent team workers. No replay file drives the displayed cars. Logs
   distinguish replay BC, geometric search, and temporary fallback controls.
   Ctrl+C closes the simulation and its team workers. The viewer is a separate
   app and can be closed normally.

## Train from replays

1. Put your .replay files under replays/. CONVERT_REPLAYS_120HZ.bat reconstructs
   up to 8 NEW games per invocation into replicar_120hz/, preserving old 15 Hz
   Parquets and parsed data. Repeat for more games. It uses the installed
   Replicar converter and your existing Soccar meshes, not a new CUDA install.
   Alternatively provide preconverted tick_step=1 Parquets there.
2. BUILD_REPLAY_CHUNKS.bat imports genuine per-tick reconstructed controls.
   It refuses 15 Hz or pose-only inputs instead of inventing button timing by
   interpolation. It requires verified hitboxes and complete, contiguous
   32-tick windows within one replay segment. Controls are labelled as inferred,
   not claimed to be the player's exact recorded buttons. Source files are
   hashed; entire replay files are split into train/val/test.
3. TRAIN_REPLAY_BRAIN.bat runs a bounded 30-minute invocation and resumes the
   same optimizer checkpoint on another invocation. Defaults: 1,000 codec
   updates then 2,000 policy/value updates. Requires >=2 replays per train/val
   split, 256/64 chunks, and 32/16 known next-goal examples. If validation is
   insufficient, convert/import more games; do not mix validation into training.
4. PAUSE_REPLAY_BRAIN.bat or Ctrl+C requests a safe checkpoint. Data/recipe
   changes are refused on resume: preserve models/v415_training_state.pt and
   use a separate project copy for a changed experiment. Models are never
   silently reset. JSON training logs: reports/v415_bc_metrics.jsonl.
5. VERIFY_LIVE_HIVE.bat, then WATCH_LIVE_HIVE_ROCKETSIMVIS.bat test the candidate.
   A failed diversity/jump reconstruction check blocks deployment of that
   checkpoint and produces a visible worker error, rather than claiming it is
   a useful trained controller. Passing that check is NOT a strength result.
6. EXPORT_LIVE_HIVE_RLBOT4.bat (also EXPORT_RLBOT_V4.bat) produces
   exports/RocketHive_Live_Hive_RLBot4.zip. Extract it, run its INSTALL.bat using
   the Python used by RLBot, and add RocketHiveBot/RocketHive.cfg to RLBot v4.
   This export runs live search. It includes the new brain only when it passed
   its loader checks, and includes your local collision meshes for portability.
   EXPORT_STATUS.json states whether it is trained or diagnostic. Use the
   existing Torch-enabled Python when a replay brain is included; the export
   does not install another CPU/CUDA Torch wheel. This is not an RLBot v5 export.
7. REPORT_LIVE_HIVE.bat packages new reports and model metadata for feedback.
   It excludes model weights, API keys, replay bodies and private chat messages.

No strong pretrained model is included. The old pose champion and old action
checkpoint do not magically become a replay-trained action-chunk policy.

## Implemented algorithm

* A learned VQ-VAE encodes each 32 x 8 control chunk using four residual codebooks
  of 64 entries, with jump/boost/button weighting and a small continuous axis
  correction. A current-state network predicts four codes autoregressively and
  predicts a next-goal value. This is an original small implementation in the
  same family, not an official reproduction of VQ-BeT or someone else's bot.
* Next-goal targets use actual replay goal events: sign for the observing team,
  discounted by exp(-seconds_to_goal/5). Unknown/censored tails are not invented
  as negative examples. No search or self-play feedback enters this training.
* During live search, 12–64 ranked joint-team first chunks are proposed. Each
  line then simulates three more 32-tick modal chunks, with ALL cars' policies
  re-queried from that line's new state after each chunk. Policy inference is
  batched across lines. There is no 64^depth search tree.
* Teammates choose one jointly evaluated first chunk per player. The candidate
  combinations are bounded; they do not enumerate every Cartesian product of
  teammate possibilities. Both teams have separate planner processes/namespaces.
  An opponent's real selected plan is never read. Predicted opponent actions
  come only from current simulated state and the frozen imitation policy.
* Search requests are submitted every 8 ticks. Finished-search frequency depends
  on hardware; it is not guaranteed to be 15 Hz. The callback never blocks for
  search. A late/missing plan uses fresh geometric steering/braking, labelled
  as fallback. Plans expire within the first 32-tick chunk. Startup and game
  clock rewinds cannot latch the previous forward command indefinitely.
* Persistent rollout arenas use clone_into and batched multi_step. This avoids
  reconstructing cold physics worlds for every candidate. Actual cloned
  rollouts still step real RocketSim collisions, cars and ball.

Default is 12 candidates for the laptop. Example manual runs:

    .venv\Scripts\python.exe -m tools.watch_hive_v415 --candidates 32 --mode 2
    .venv\Scripts\python.exe -m tools.watch_hive_v415 --candidates 64 --mode 1

For RLBot set ROCKETHIVE_CANDIDATES=12..64 before launch. The default shared
session is RLBot4-local, with separate team and roster validation. Set distinct
ROCKETHIVE_MATCH_ID values if running simultaneous independent matches on one
machine. Teammates in the same match must use the same value and model version.

## Limits and validation

The supplied neurlcar-python repository currently has only an empty README;
it provides no usable pretrained evaluator. The new value head is trained
locally from replay hindsight. Without it, geometric search uses a clearly
labelled untrained physics proxy. No private model or claimed stream result is
included or independently reproduced.

Replay input recovery and RLBot state restoration are approximate. Public live
packets lack exact suspension and several internal flip timers. Causal contact
history provides an airtime estimate; it is not presented as exact simulator
parity. Recorded game engine physics can also differ from the installed binding.

Linux validation covers native 1v1/2v2/3v3 rollout execution, team IPC/plan expiry,
clock resets, controller braking and steering, actual 120 Hz label timing,
RVQ training gradients, source-format preservation, and the old test suite.
RocketSimVis was run under a real X11/OpenGL display with live UDP frames, not
only a mocked renderer. These checks do not establish better match results or
constitute a live Rocket League/RLBot Windows match. Keep a fixed original bot
for fair paired W/D/L testing after training, and test against several opponents.

RocketSimVis credit: ZealanL and contributors; upstream commit
074a4368f31668ccd651087eebf6a1b459564ad7. Official source:
https://github.com/ZealanL/RocketSimVis. Its custom assets are downloaded from the
pinned upstream archive and are not redistributed in this code update.
