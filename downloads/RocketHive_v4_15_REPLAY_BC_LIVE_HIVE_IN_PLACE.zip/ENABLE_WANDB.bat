@echo off
setlocal
cd /d "%~dp0"
if not exist ".venv\Scripts\python.exe" (
  echo Existing .venv missing. This update never recreates it.
  pause
  exit /b 1
)
echo Installing only the optional Weights ^& Biases package into the existing virtual environment.
".venv\Scripts\python.exe" -m pip install wandb
if errorlevel 1 (
  echo Installation failed; local JSONL training metrics still work.
  pause
  exit /b 1
)
echo Done. Restart START_V4.bat and enter the W^&B key in the popup.
pause
