@echo off
cd /d "%~dp0"
call "%~dp0WATCH_REPLAY.bat"
