@echo off
cd /d "%~dp0"
if not exist .venv\Scripts\python.exe (
 echo Run START_TRAIN.bat first.
 pause
 exit /b 1
)
.venv\Scripts\python.exe -m src.export
pause
