@echo off
setlocal
cd /d "%~dp0"
if not exist ".venv\Scripts\python.exe" (
 echo Missing RocketHive virtual environment.
 pause
 exit /b 1
)
".venv\Scripts\python.exe" -m tools.verify_rlviser_camera_v411
set "RESULT=%ERRORLEVEL%"
pause
exit /b %RESULT%
