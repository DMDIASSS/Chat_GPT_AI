"""RLBot v4 live packet -> exact RocketHive current-state observation schema.

No replay future, no inferred human inputs. Hitbox identification is strict:
unknown hitbox dimensions must be configured, not silently replaced by Octane.
"""
from __future__ import annotations
import os
import math
import numpy as np

# Approximate Rocket League in-game hitbox dimensions (length,width,height) in uu.
# Only used to identify one of the presets, not simulate collisions.
_PRESETS = {
    'octane': (118.01,84.20,36.16),
    'dominus': (127.93,83.28,31.30),
    'breakout': (127.93,80.52,30.30),
    'plank': (128.82,84.67,29.39),
    'hybrid': (127.02,82.19,34.16),
    'merc': (120.71,76.71,41.66),
}


def q_from_rlbot_rot(pitch, yaw, roll):
    """RLBot forward z = sin(pitch). R = Rz(yaw) * Ry(-pitch) * Rx(roll)."""
    cy,sy=math.cos(yaw/2),math.sin(yaw/2)
    cp,sp=math.cos(-pitch/2),math.sin(-pitch/2)
    cr,sr=math.cos(roll/2),math.sin(roll/2)
    # quaternion q_z(yaw) q_y(-pitch) q_x(roll), xyzw
    return np.asarray([cy*cp*sr - sy*sp*cr,
                       cy*sp*cr + sy*cp*sr,
                       sy*cp*cr - cy*sp*sr,
                       cy*cp*cr + sy*sp*sr], dtype=np.float32)


def vec(v):
    return (float(v.x),float(v.y),float(v.z))


def pose(physics, boost=None):
    p=physics
    x=np.zeros(14 if boost is not None else 13,dtype=np.float32)
    x[:3]=vec(p.location)
    r=p.rotation
    x[3:7]=q_from_rlbot_rot(float(r.pitch),float(r.yaw),float(r.roll))
    x[7:10]=vec(p.velocity)
    x[10:13]=vec(p.angular_velocity)
    if boost is not None:
        x[13]=float(np.clip(float(boost)/100.,0.,1.))
    return x


def identify_hitbox(box, override=None):
    if override is not None:
        if override not in (*_PRESETS,'psyclops'):
            raise ValueError('Invalid hitbox override '+repr(override))
        return override
    if box is None:
        raise ValueError('RLBot v4 packet lacks hitbox dimensions; set ROCKETHIVE_RLBOT_HITBOXES')
    dims=np.asarray([float(box.length),float(box.width),float(box.height)])
    if not np.all(np.isfinite(dims)):
        raise ValueError('Nonfinite RLBot hitbox')
    distances=sorted(((float(np.linalg.norm(dims-np.asarray(d))),key)
                      for key,d in _PRESETS.items()))
    if distances[0][0]>5.0:
        raise ValueError(f'Unrecognized hitbox dimensions {dims.tolist()}. '
                         'Set ROCKETHIVE_RLBOT_HITBOXES to comma-separated presets.')
    return distances[0][1]


def packet_state(packet, controlled_index, hitboxes_override=None):
    count=int(packet.num_cars)
    if count not in (2,4,6):
        raise ValueError('RocketHive policy supports exactly balanced 1v1, 2v2, 3v3')
    indexes=sorted(range(count),key=lambda i:(int(packet.game_cars[i].team),i))
    half=count//2
    if any(int(packet.game_cars[i].team)!=0 for i in indexes[:half]) or any(
           int(packet.game_cars[i].team)!=1 for i in indexes[half:]):
        raise ValueError('Expected balanced Blue/Orange teams')
    if controlled_index not in indexes:
        raise IndexError(controlled_index)
    if hitboxes_override is None:
        var=os.environ.get('ROCKETHIVE_RLBOT_HITBOXES','').strip()
        hitboxes_override=[v.strip().lower() for v in var.split(',')] if var else None
    if hitboxes_override and len(hitboxes_override)!=count:
        raise ValueError('ROCKETHIVE_RLBOT_HITBOXES must specify one preset per packet car')
    cars=[]; flags=[]; boxes=[]
    for i in indexes:
        c=packet.game_cars[i]
        cars.append(pose(c.physics, c.boost))
        flags.append([float(bool(getattr(c,'has_wheel_contact',False))),
                      float(bool(getattr(c,'jumped',False))),
                      float(bool(getattr(c,'double_jumped',False))),
                      0.,0.,0.,0.,0.,0.,0.])
        override=hitboxes_override[i] if hitboxes_override else None
        boxes.append(identify_hitbox(getattr(c,'hitbox',None),override))
    return ({'cars':np.stack(cars), 'ball':pose(packet.game_ball.physics),
             'flags':np.asarray(flags,dtype=np.float32), 'hitboxes':np.asarray(boxes),
             'mode':half}, indexes.index(controlled_index))

class PacketHistory:
    """Causal airtime estimate; RLBot does not expose exact suspension/flip state."""
    def __init__(self):self.air_since={};self.previous=None
    def update(self,packet,state):
        now=float(packet.game_info.seconds_elapsed)
        if self.previous is not None and now<self.previous:self.air_since.clear()
        self.previous=now;indexes=sorted(range(packet.num_cars),key=lambda i:(int(packet.game_cars[i].team),i));timers=[]
        for idx in indexes:
            c=packet.game_cars[idx];ground=bool(c.has_wheel_contact)
            if ground:self.air_since[idx]=None
            elif idx not in self.air_since:self.air_since[idx]=now-2 # first observed mid-air: time unknown
            elif self.air_since[idx] is None:self.air_since[idx]=now
            air=0. if ground else max(0.,now-self.air_since[idx])
            timers.append(dict(air_time=air,air_time_since_jump=air,has_jumped=bool(getattr(c,'jumped',False)),has_double_jumped=bool(getattr(c,'double_jumped',False)),is_demoed=bool(getattr(c,'is_demolished',False))))
        state['timers']=timers
