@echo off
setlocal
cd /d "%~dp0"
echo ==============================================================
echo RECORDED HUMAN REPLAY - NOT A TRAINED BOT
 echo Cars are placed on their pre-recorded trajectories.
echo This is a visual reference / demonstration, NOT bot skill.
echo Camera: follows car 1 with BALLCAM by default.
echo ==============================================================
call "%~dp0WATCH_REPLAY_RLVISER.bat"
