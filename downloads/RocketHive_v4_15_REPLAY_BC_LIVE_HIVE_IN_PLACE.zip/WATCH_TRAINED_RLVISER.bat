@echo off
setlocal
cd /d "%~dp0"
if not exist ".venv\Scripts\python.exe" (echo Missing .venv&pause&exit /b 1)
if not exist "models\v4_action_policy_search_teacher.pt" (
 echo There is NO trained action controller yet.
 echo The pose champion cannot drive a car.
 echo Run VERIFY_PHYSICS_SEARCH.bat, then TRAIN_ACTION_CONTROLLER.bat.
 echo Wait for an actual controller optimizer update: updates=1 or higher.
 pause
 exit /b 2
)
".venv\Scripts\python.exe" tools\install_rlviser.py || goto :fail
echo =============================================================
echo RLViser: click window, Esc to close menu, press 1 for car camera.
echo Shows ACTUAL search controller, NOT the old heuristic or pose model.
echo =============================================================
".venv\Scripts\python.exe" -m tools.watch_bot_rlviser --trained-policy --team-size 2 --seconds 0
if errorlevel 1 goto :fail
exit /b 0
:fail
pause
exit /b 1
