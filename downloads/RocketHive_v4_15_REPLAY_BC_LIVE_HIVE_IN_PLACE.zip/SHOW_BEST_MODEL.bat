@echo off
setlocal
cd /d "%~dp0"
if not exist ".venv\Scripts\python.exe" (
  echo RocketHive virtual environment missing.
  pause
  exit /b 2
)
".venv\Scripts\python.exe" -m tools.show_best_pose_v46
pause
