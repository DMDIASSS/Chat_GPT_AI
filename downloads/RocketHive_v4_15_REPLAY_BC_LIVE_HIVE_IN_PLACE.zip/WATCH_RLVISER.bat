@echo off
cd /d "%~dp0"
call "%~dp0WATCH_BOT_RLVISER.bat"
