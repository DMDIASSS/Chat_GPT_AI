@echo off
cd /d "%~dp0"
where python
where git
where cmake
where nvcc
nvidia-smi
if exist ".venv\Scripts\python.exe" .venv\Scripts\python.exe tools\diagnose.py
pause
