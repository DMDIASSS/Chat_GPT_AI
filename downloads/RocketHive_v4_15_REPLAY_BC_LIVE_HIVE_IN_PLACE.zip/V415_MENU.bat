@echo off
setlocal
cd /d "%~dp0"
:menu
cls
echo RocketHive v4.15 - replay BC and LIVE team search
echo.
echo 1 Verify live native search
echo 2 Set up RocketSimVis in its separate GUI environment
echo 3 Watch live 2v2 - shows whether trained or diagnostic
echo 4 Convert up to 8 new replays to 120 Hz
echo 5 Build reconstructed action chunks
echo 6 Train or resume replay brain - bounded invocation
echo 7 Request safe training pause
echo 8 Export live hive for RLBot v4
echo 9 Package feedback report
echo 0 Exit
echo.
echo No pretrained strong bot is included. Existing data and models are preserved.
choice /c 1234567890 /n /m "Choose: "
set "PICK=%errorlevel%"
if "%PICK%"=="10" exit /b 0
if "%PICK%"=="1" call VERIFY_LIVE_HIVE.bat
if "%PICK%"=="2" call SETUP_ROCKETSIMVIS.bat
if "%PICK%"=="3" call WATCH_LIVE_HIVE_ROCKETSIMVIS.bat
if "%PICK%"=="4" call CONVERT_REPLAYS_120HZ.bat
if "%PICK%"=="5" call BUILD_REPLAY_CHUNKS.bat
if "%PICK%"=="6" call TRAIN_REPLAY_BRAIN.bat
if "%PICK%"=="7" call PAUSE_REPLAY_BRAIN.bat
if "%PICK%"=="8" call EXPORT_LIVE_HIVE_RLBOT4.bat
if "%PICK%"=="9" call REPORT_LIVE_HIVE.bat
goto menu
