@echo off
setlocal
cd /d "%~dp0"
if not exist ".venv\Scripts\python.exe" (echo Missing RocketHive .venv & pause & exit /b 2)
echo Testing a REAL RocketSim sequence search without changing any checkpoint.
".venv\Scripts\python.exe" -m tools.check_sequence_search_v412 --candidates 12 --segments 3 --ticks 8
if errorlevel 1 (
  echo Search verification failed. Read the FIRST error above.
  pause
  exit /b 1
)
pause
