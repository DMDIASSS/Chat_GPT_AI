@echo off
setlocal
cd /d "%~dp0"
if not exist ".venv\Scripts\python.exe" (
 echo Missing existing virtual environment: .venv\Scripts\python.exe
 pause
 exit /b 1
)
echo Bind the existing W^&B run named likely-sea-1 (not a new run).
".venv\Scripts\python.exe" -m tools.bind_wandb_run_v45
if errorlevel 1 (
 echo No run binding was changed. Read the error above.
 pause
 exit /b 1
)
pause
