@echo off
setlocal
cd /d "%~dp0"
if not exist ".venv\Scripts\python.exe" (
  echo Your existing .venv was not found. Set up RocketHive first.
  echo No libraries are automatically reinstalled or upgraded by this launcher.
  pause
  exit /b 2
)
echo Starting indefinite v4 replay pretraining ^(Ctrl+C to stop^).
echo Saved API keys will be reused automatically. For changes run MANAGE_API_KEYS.bat.
".venv\Scripts\python.exe" -m src.continuous --config config_v4.json
if errorlevel 1 (
  echo Training stopped or failed; review the error above and reports\v4_metrics.jsonl.
  pause
  exit /b 1
)
pause
