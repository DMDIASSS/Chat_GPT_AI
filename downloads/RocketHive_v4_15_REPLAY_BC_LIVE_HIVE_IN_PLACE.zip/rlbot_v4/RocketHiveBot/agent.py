"""RLBot v4, not v5. Experimental search-distilled action controller only.

Loads a saved ACTION policy. A pose forecaster cannot be used to drive a car.
No automatic RLBot v4 online compatibility claim until tested on Windows.
"""
from pathlib import Path
import os
import sys

from rlbot.agents.base_agent import BaseAgent, SimpleControllerState

ROOT=Path(__file__).resolve().parent
if str(ROOT) not in sys.path:
    sys.path.insert(0,str(ROOT))
# Exported package contains src/ next to this agent; in-place development also works.
PACKAGE=ROOT if (ROOT/'src').is_dir() else ROOT.parents[1]
if str(PACKAGE) not in sys.path:
    sys.path.insert(0,str(PACKAGE))
from src.policy_inference import SearchPolicyController
from src.physics_search import ACTIONS
from packet_adapter import packet_state


class RocketHiveBot(BaseAgent):
    def initialize_agent(self):
        checkpoint=Path(os.environ.get('ROCKETHIVE_CONTROLLER_CHECKPOINT',
                                     PACKAGE/'models'/'v4_action_policy_search_teacher.pt'))
        self.policy=SearchPolicyController(checkpoint=str(checkpoint),device='cpu')
        self.previous_decision_t=float('-inf')
        self.previous_control=SimpleControllerState()
        print(f'[RocketHive RLBot v4] Search controller step={self.policy.checkpoint_step}; '
              'NOT the pose champion; aerial skill not yet validated.')

    def get_output(self,packet):
        if not hasattr(self,'policy'):
            return SimpleControllerState()
        now=float(packet.game_info.seconds_elapsed)
        if now-self.previous_decision_t < 8/120 - 0.00001:
            return self.previous_control
        state, self_position=packet_state(packet,self.index)
        index=self.policy.action_indices(state)[self_position]
        throttle,steer,pitch,yaw,roll,jump,boost,handbrake=ACTIONS[index]
        c=SimpleControllerState()
        c.throttle=float(throttle)
        c.steer=float(steer)
        c.pitch=float(pitch)
        c.yaw=float(yaw)
        c.roll=float(roll)
        c.jump=bool(jump)
        c.boost=bool(boost)
        c.handbrake=bool(handbrake)
        self.previous_control=c
        self.previous_decision_t=now
        return c
