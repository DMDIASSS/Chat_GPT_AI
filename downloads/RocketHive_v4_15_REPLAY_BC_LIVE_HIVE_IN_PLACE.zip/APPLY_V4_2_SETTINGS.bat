@echo off
setlocal
cd /d "%~dp0"
if not exist ".venv\Scripts\python.exe" (
 echo Existing Python environment not found. Run from your RocketHive install directory.
 pause
 exit /b 1
)
".venv\Scripts\python.exe" tools\enable_v42_defaults.py
if errorlevel 1 pause
