@echo off
setlocal
cd /d "%~dp0"
if not exist ".venv\Scripts\python.exe" (
    echo Existing .venv\Scripts\python.exe not found. No new installation performed.
    goto :error
)
set "PY=.venv\Scripts\python.exe"
echo Checking existing Python libraries (no pip install)...
"%PY%" -c "import numpy, RocketSim, rlviser_py" 2>nul || (
    echo Missing numpy or viewer bindings in the old environment.
    echo If necessary: .venv\Scripts\python.exe -m pip install "rocketsim>=2.2.1" rlviser-py
    goto :error
)
"%PY%" tools\install_rlviser.py || goto :error
"%PY%" -m tools.watch_rlviser --data data
if errorlevel 1 goto :error
pause
exit /b 0
:error
echo.
echo Native replay playback failed. Your installed packages were not changed.
pause
exit /b 1
