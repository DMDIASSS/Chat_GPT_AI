@echo off
setlocal
cd /d "%~dp0"
if not exist ".venv\Scripts\python.exe" (echo Missing RocketHive .venv & pause & exit /b 2)
echo Running a SAME-SETUP 2v2 physics report using the OLD heuristic baseline.
echo This is NOT the trained policy.
".venv\Scripts\python.exe" -m tools.report_controller_v412 --baseline --seconds 35 --team-size 2
if errorlevel 1 (pause & exit /b 1)
pause
