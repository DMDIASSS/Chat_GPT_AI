@echo off
setlocal
cd /d "%~dp0"
if not exist ".venv\Scripts\python.exe" (
  echo Existing .venv not found. Set up RocketHive first.
  pause
  exit /b 2
)
".venv\Scripts\python.exe" -m tools.enable_v46_defaults
if errorlevel 1 (
  echo Could not merge configuration. Existing config is unchanged.
  pause
  exit /b 1
)
endlocal
pause
