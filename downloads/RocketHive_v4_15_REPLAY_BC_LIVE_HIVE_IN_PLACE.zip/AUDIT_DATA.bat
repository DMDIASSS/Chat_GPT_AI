@echo off
setlocal
cd /d "%~dp0"
".venv\Scripts\python.exe" -m tools.audit_data_v44
pause
