@echo off
setlocal
cd /d "%~dp0"
if not exist ".venv\Scripts\python.exe" (echo [ERROR] Existing RocketHive .venv not found.&pause&exit /b 2)
echo Checking saved action-policy model (read-only, no viewer needed).
".venv\Scripts\python.exe" -m tools.check_action_controller_v410
if errorlevel 1 (
  echo The driving model is missing or not ready.
  echo 1. Run VERIFY_PHYSICS_SEARCH.bat
  echo 2. Run TRAIN_ACTION_CONTROLLER.bat and wait for updates ^>= 1
  pause
  exit /b 2
)
echo READY. Run WATCH_TRAINED_RLVISER.bat to see the actual model.
pause
