@echo off
setlocal
cd /d "%~dp0"
if not exist ".venv\Scripts\python.exe" (
  echo [ERROR] RocketHive .venv is missing.
  pause
  exit /b 2
)
echo Running a 35-second headless RocketSim match with the ACTUAL TRAINED policy.
echo Reports saved under reports\v412_behavior_report.json and .txt
".venv\Scripts\python.exe" -m tools.report_controller_v412 --seconds 35 --team-size 2
if errorlevel 1 (
  echo Report failed. See the error above.
  pause
  exit /b 1
)
pause
