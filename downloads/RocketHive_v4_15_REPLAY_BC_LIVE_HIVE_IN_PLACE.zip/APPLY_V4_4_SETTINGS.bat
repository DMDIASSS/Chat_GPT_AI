@echo off
setlocal
cd /d "%~dp0"
if not exist ".venv\Scripts\python.exe" (
  echo Existing .venv not found. Please use your original RocketHive Python environment.
  pause
  exit /b 2
)
".venv\Scripts\python.exe" -m tools.enable_v44_defaults
if errorlevel 1 pause
