"""Install pip dependencies without admin elevation. CUDA driver/toolkit is NOT silently installed.

Use CUDA-enabled PyTorch wheels where a functioning NVIDIA driver is detected.
Installed Torch's actual cuda availability is checked, rather than trusting nvcc.
"""
from pathlib import Path
import subprocess
import sys
import shutil
import os

ROOT=Path(__file__).resolve().parents[1]

def run(args, *, check=True):
    print('>', ' '.join(map(str,args)),flush=True)
    return subprocess.run(args,check=check)

def main():
    if sys.version_info < (3,10) or sys.version_info >= (3,13):
        print('WARNING: Python 3.10-3.12 is recommended for these native packages.')
    run([sys.executable,'-m','pip','install','--upgrade','pip'])
    run([sys.executable,'-m','pip','install','-r',str(ROOT/'requirements.txt')])
    try: import torch
    except ImportError:
        if shutil.which('nvidia-smi'):
            print('NVIDIA driver detected; installing CUDA-enabled PyTorch wheels (cu126).')
            # Vendor index tracks wheels for driver compatibility; CPU fallback on installation error.
            r=run([sys.executable,'-m','pip','install','torch','--index-url','https://download.pytorch.org/whl/cu126'],check=False)
            if r.returncode:
                print('CUDA wheel install failed, falling back to PyPI torch.')
                run([sys.executable,'-m','pip','install','torch'])
        else:
            print('No NVIDIA driver detected: installing CPU-capable PyTorch.')
            run([sys.executable,'-m','pip','install','torch','--index-url','https://download.pytorch.org/whl/cpu'])
    import torch
    print('PyTorch',torch.__version__,'CUDA available:',torch.cuda.is_available())
    if not torch.cuda.is_available():
        print('CPU training remains available. NVIDIA driver/CUDA Toolkit installations require manual system setup.')
    print('Replicar v2 reader/native conversion is installed as a dependency (when wheels are available).')
    print('Soccar collision meshes must be provided from your own game; see README.')
    print('Optional RocketGPU, RocketChad3, RLViser remain separate; see README.')
    return 0
if __name__=='__main__':raise SystemExit(main())
