"""Zero-extra-dependencies read-only training status viewer."""
from __future__ import annotations
import argparse
import json
from pathlib import Path
import time
from src.system_guard_v44 import free_gib


def summarize(root='.'):
    root=Path(root)
    status=root/'reports'/'v4_status.json'
    data=json.loads(status.read_text(encoding='utf-8')) if status.exists() else {}
    models={name:(root/'models'/name).exists() for name in (
        'v4_pose_resume.pt','v4_pose_best.pt',
        'v4_action_policy_search_teacher.pt','best_playing_controller.pt')}
    return {'updated_utc':data.get('updated_utc','not yet started'),
            'pose_optimizer_steps':data.get('pose_step',0),
            'best_pose_val_loss':data.get('best_pose_validation_loss'),
            'device':data.get('device','unknown'),
            'pose_updates_per_sec':data.get('metrics',{}).get('performance/pose_updates_per_sec'),
            'pose_examples_per_sec':data.get('metrics',{}).get('performance/pose_samples_per_sec'),
            'adaptive_pose_stage':data.get('metrics',{}).get('curriculum/pose_stage'),
            'available_disk_gib':round(free_gib(root),2),
            'checkpoint_exists':models,
            'reminder':'These are offline pose examples/sec, not simulated game SPS.'}


def main():
    parser=argparse.ArgumentParser(description='RocketHive status (no API tokens)')
    parser.add_argument('--watch',action='store_true')
    parser.add_argument('--interval',type=float,default=10)
    a=parser.parse_args()
    while True:
        print(json.dumps(summarize(),indent=2),flush=True)
        if not a.watch:break
        try:time.sleep(max(2,a.interval))
        except KeyboardInterrupt:break

if __name__=='__main__':main()
