"""Read-only diagnostic for the v4.8 fixed validation cohort."""
from pathlib import Path
import json
from src.train import ReplaySampler
from src.validation_v44 import FixedValidation


def main():
    cfg=json.loads(Path('config_v4.json').read_text(encoding='utf-8'))
    val=ReplaySampler('data','val',float(cfg.get('fps',15)),
                      float(cfg.get('forecast_seconds',.53333)),
                      int(cfg.get('seed',42))+999)
    print('[validation] usable held-out replays:',len(val.available))
    if not val.available:
        print('[validation] BLOCKED: data/val has no valid replay clips.')
        return 2
    cohort=FixedValidation(val,max_replays=int(cfg.get('validation_max_replays',24)),
                              frames_per_replay=int(cfg.get('validation_frames_per_replay',16)))
    print('[validation] fixed examples:',cohort.count)
    print('[validation] cohort path:',cohort.manifest)
    print('[validation] missing replays:',cohort.missing)
    print('[validation] modified replays:',cohort.changed)
    if cohort.changed:
        print('[validation] START_V4 will safely back up and rebaseline this cohort '
              'if validation_auto_rebaseline=true and nothing is missing.')
    if cohort.missing:
        print('[validation] missing holdout files: restore the missing files. '
              'This diagnostic will not silently shrink the cohort.')
    if not (cohort.missing or cohort.changed) and cohort.count:
        print('[validation] PASS. The saved champion can be compared against this cohort.')
        return 0
    return 2

if __name__=='__main__':raise SystemExit(main())
