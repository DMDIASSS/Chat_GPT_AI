from pathlib import Path
import argparse,hashlib,json,os,subprocess,sys

def convert(max_files=8):
    import replicar
    root=Path('.').resolve();out=root/'replicar_120hz';out.mkdir(exist_ok=True)
    from src.replicar_dataset import find_meshes
    meshes=find_meshes(root)
    if not meshes:raise ValueError('Use the existing Soccar collision meshes; REPLICAR_MESHES must contain soccar/*.cmf')
    files=sorted((root/'replays').rglob('*.replay'))
    count=0
    for file in files:
        digest=hashlib.sha256(file.read_bytes()).hexdigest();dest=out/(digest+'.parquet')
        if dest.is_file():continue
        if count>=max_files:break
        temp=dest.with_suffix('.tmp.parquet');print('120Hz conversion:',file.name,flush=True)
        replicar.convert(file,temp,tick_step=1,meshes=meshes);os.replace(temp,dest)
        dest.with_suffix('.source.json').write_text(json.dumps(dict(source=str(file.relative_to(root)),replay_sha256=digest),indent=2))
        count+=1
    print('Converted',count,'new replays. Existing data and 15 Hz Parquets preserved.')

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('command',choices=['convert','build']);p.add_argument('--max-files',type=int,default=8);a=p.parse_args()
    if a.command=='convert':convert(a.max_files)
    else:
        from src.replay_chunks_v415 import build
        build(max_files=300)
