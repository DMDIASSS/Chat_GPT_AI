"""Portable RLBot v4 package of the action policy. Keeps user data and keys out."""
from pathlib import Path
import shutil
import zipfile
import argparse
import tempfile

ROOT=Path(__file__).resolve().parents[1]
EXCLUDED={'__pycache__','*.pyc'}


def export(target,ckpt):
    target=Path(target)
    ckpt=Path(ckpt)
    if not ckpt.is_file():
        raise FileNotFoundError('No trained action policy checkpoint: '+str(ckpt)+
                                '. Pose champion is NOT a control policy.')
    import torch
    saved=torch.load(ckpt,map_location='cpu',weights_only=False)
    if saved.get('type')!='SEARCH_DISTILLED_ACTION_POLICY_unvalidated':
        raise ValueError('Refusing to package a pose model as a controller')
    target.parent.mkdir(parents=True,exist_ok=True)
    with tempfile.TemporaryDirectory() as tmpdir:
        base=Path(tmpdir)/'RocketHiveBot'
        shutil.copytree(ROOT/'rlbot_v4'/'RocketHiveBot',base)
        mods=base/'src';mods.mkdir()
        for p in (ROOT/'src').glob('*.py'):
            shutil.copy2(p,mods/p.name)
        model_dir=base/'models';model_dir.mkdir()
        shutil.copy2(ckpt,model_dir/'v4_action_policy_search_teacher.pt')
        # Do NOT export API tokens, wandb state, other models, replays or credentials.
        with zipfile.ZipFile(target,'w',compression=zipfile.ZIP_DEFLATED) as z:
            for file in sorted(base.rglob('*')):
                if file.is_file():z.write(file,file.relative_to(base.parent))
    return target


if __name__=='__main__':
    p=argparse.ArgumentParser(description='Export RLBot v4 action policy (not pose model)')
    p.add_argument('--checkpoint',default=str(ROOT/'models'/'v4_action_policy_search_teacher.pt'))
    p.add_argument('--output',default=str(ROOT/'exports'/'RocketHive_RLBot_v4.zip'))
    a=p.parse_args()
    try:print('Exported',export(a.output,a.checkpoint))
    except (ValueError,FileNotFoundError) as exc:p.exit(2,str(exc)+'\n')
