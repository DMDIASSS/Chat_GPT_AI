"""Send current simulated physics to ZealanL/RocketSimVis; not replay playback."""
from pathlib import Path
import hashlib,json,os,socket,subprocess,sys,urllib.request,zipfile
ROOT=Path(__file__).resolve().parents[1]
COMMIT='074a4368f31668ccd651087eebf6a1b459564ad7'
URL='https://codeload.github.com/ZealanL/RocketSimVis/zip/'+COMMIT
# Source archive hash is checked by the installer; filled from the pinned download.
SOURCE_SHA256='b58ec3af47550ea7173f72d65b1ff9d239d29e007820b7ac1abd071bb0b061ff'

def install():
    target=ROOT/'third_party/RocketSimVis';target.parent.mkdir(exist_ok=True)
    archive=target.parent/'RocketSimVis-source.zip'
    if not target.exists():
        with urllib.request.urlopen(URL,timeout=60) as r:data=r.read(8*1024*1024)
        if hashlib.sha256(data).hexdigest()!=SOURCE_SHA256:raise ValueError('RocketSimVis pinned source checksum mismatch')
        archive.write_bytes(data)
        with zipfile.ZipFile(archive) as z:
            for entry in z.infolist():
                p=Path(*Path(entry.filename).parts[1:])
                if p.is_absolute() or '..' in p.parts:raise ValueError('Unsafe viewer archive')
                if str(p)=='.' or entry.is_dir():continue
                out=target/p;out.parent.mkdir(parents=True,exist_ok=True);out.write_bytes(z.read(entry))
        (target/'ROCKETHIVE_UPSTREAM.txt').write_text('RocketSimVis by ZealanL and contributors; upstream '+COMMIT+'\n'+URL+'\n')
    # Upstream moderngl-window 2.x requires NumPy 1.x. Keep this GUI in its own
    # tiny environment so the user's NumPy/Torch/RLViser environment is untouched.
    import venv
    env=target/'.venv';python=env/('Scripts/python.exe' if os.name=='nt' else 'bin/python')
    ready=env/'rockethive_gui_ready.json'
    if not python.is_file():venv.EnvBuilder(with_pip=True).create(env)
    if not ready.exists():
        packages=['numpy>=1.26,<2','moderngl>=5.8,<6','moderngl-window>=2.4,<3','PyOpenGL>=3.1,<4','pyrr>=0.10,<1','PyWavefront>=1.3,<2','PyQt5>=5.15,<5.16']
        subprocess.run([str(python),'-m','pip','install',*packages],check=True)
        ready.write_text(json.dumps(dict(source_commit=COMMIT,source_archive_sha256=SOURCE_SHA256,scope='GUI only; no Torch/CUDA installation')))
    print('ROCKETSIMVIS_READY:',target,flush=True);return target

def phys(s):
    return dict(pos=list(s.pos.as_tuple()),vel=list(s.vel.as_tuple()),ang_vel=list(s.ang_vel.as_tuple()),forward=list(s.rot_mat.forward.as_tuple()),up=list(s.rot_mat.up.as_tuple()))

def packet(arena):
    cars=[]
    for c in arena.get_cars():
        s=c.get_state();a=s.last_controls
        cars.append(dict(team_num=int(c.team),phys=phys(s),boost_amount=float(s.boost),on_ground=bool(s.is_on_ground),is_demoed=bool(s.is_demoed),has_flipped_or_double_jumped=bool(s.has_flipped or s.has_double_jumped),controls={k:getattr(a,k) for k in ('throttle','steer','pitch','yaw','roll','boost','jump','handbrake')}))
    return dict(ball_phys=phys(arena.ball.get_state()),cars=cars,boost_pad_states=[bool(p.get_state().is_active) for p in arena.get_boost_pads()],boost_pad_locations=[list(p.get_pos().as_tuple()) for p in arena.get_boost_pads()])

class Viewer:
    def __init__(self,launch=True,port=9273):
        self.sock=socket.socket(socket.AF_INET,socket.SOCK_DGRAM);self.address=('127.0.0.1',port);self.process=None
        if launch:
            target=ROOT/'third_party/RocketSimVis'
            if not (target/'src/main.py').is_file():raise FileNotFoundError('Run SETUP_ROCKETSIMVIS.bat once')
            python=os.environ.get('ROCKETHIVE_VIEWER_PYTHON') or str(target/'.venv'/('Scripts/python.exe' if os.name=='nt' else 'bin/python'))
            if not Path(python).is_file():raise FileNotFoundError('Run SETUP_ROCKETSIMVIS.bat to prepare its separate GUI environment')
            self.process=subprocess.Popen([python,str(target/'src/main.py')],cwd=target)
    def send(self,arena):self.sock.sendto(json.dumps(packet(arena),allow_nan=False).encode(),self.address)
    def close(self):self.sock.close()

if __name__=='__main__':install()
