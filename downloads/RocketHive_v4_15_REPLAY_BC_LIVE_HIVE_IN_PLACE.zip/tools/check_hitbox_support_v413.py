"""Read-only check for available replay hitboxes in the installed native binding."""
from __future__ import annotations
import argparse
from pathlib import Path
from tools.train_action_controller_v48 import candidates
from tools.native_rlviser import init_arena
from src.hitbox_compat_v413 import probe_hitboxes, filter_replays, save_report


def main(argv=None):
    p = argparse.ArgumentParser()
    p.add_argument('--train-dir', default='data/train')
    args = p.parse_args(argv)
    try:
        import RocketSim as rs
        init_arena(rs)
        supported, unsupported = probe_hitboxes(rs, init_arena)
        valid, bad = candidates(args.train_dir)
        usable, skipped = filter_replays(valid, supported)
        all_skipped = bad + skipped
        save_report('reports/v413_hitbox_compatibility.json',rs,supported,
                    unsupported,usable,all_skipped)
        print('[hitbox-check] RocketSim binding:',getattr(rs,'__file__','unknown'))
        print('[hitbox-check] supported presets:', ', '.join(supported) or 'none')
        for name,reason in unsupported.items():
            print(f'[hitbox-check] not supported: {name}: {reason}')
        print(f'[hitbox-check] usable={len(usable)}, skipped={len(all_skipped)}')
        for name,reason in all_skipped[:10]:
            print(f'[hitbox-check] skipped {name}: {reason}')
        print('[hitbox-check] details: reports/v413_hitbox_compatibility.json')
        return 0 if usable else 2
    except Exception as exc:
        print('[hitbox-check] FAILED:',type(exc).__name__,str(exc))
        return 2


if __name__ == '__main__':
    raise SystemExit(main())
