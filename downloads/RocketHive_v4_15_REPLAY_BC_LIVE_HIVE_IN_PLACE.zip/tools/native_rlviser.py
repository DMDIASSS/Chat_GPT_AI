"""Native RLViser adapter shared by live RocketSim and replay state playback."""
from pathlib import Path
import os
import shutil
from threading import Lock

ROOT = Path(__file__).resolve().parents[1]


def find_binary():
    explicit = os.environ.get('RLVISER_EXE')
    if explicit and Path(explicit).is_file():
        return Path(explicit).resolve()
    for name in ('rlviser.exe', 'rlviser'):
        found = ROOT / 'third_party' / 'rlviser' / name
        if found.is_file():
            return found.resolve()
        found = shutil.which(name)
        if found:
            return Path(found).resolve()
    # Allow nested paths in official release archive. No recursive scanning of Downloads.
    local = ROOT / 'third_party' / 'rlviser'
    if local.is_dir():
        for file in sorted(local.rglob('rlviser.exe')):
            return file.resolve()
    return None


def find_meshes():
    paths = [os.environ.get('REPLICAR_MESHES'), ROOT / 'third_party' / 'collision_meshes',
             ROOT / 'collision_meshes']
    for p in paths:
        if p and list((Path(p) / 'soccar').glob('*.cmf')):
            return Path(p).resolve()
    return None


def enter_viewer_directory():
    binary = find_binary()
    if binary is None:
        raise FileNotFoundError('RLViser executable not found. Run WATCH_BOT_RLVISER.bat to install, '
                                'or set RLVISER_EXE to a verified rlviser.exe.')
    # RLViser reads settings.txt relative to its current working directory.
    # Its default free camera makes replay and live-control modes confusing.
    # Set a real car-follow camera with ballcam *before* the viewer starts.
    from tools.rlviser_camera_v411 import (configure_rlviser_camera,
                                           load_camera_preferences)
    preferences = load_camera_preferences(ROOT)
    settings = configure_rlviser_camera(binary, **preferences)
    print(f'[camera] RLViser: following car {preferences["car"]}; '
          f'ballcam={"ON" if preferences["ball_cam"] else "OFF"}; '
          f'settings={settings}', flush=True)
    # rlviser-py launches the executable from its current working directory.
    os.chdir(binary.parent)
    return binary


# RocketSim.init() is a one-time *native process* operation. The controller
# deliberately makes a new Arena for every counterfactual physics rollout,
# but re-initializing RocketSim for each Arena raises RuntimeError('Already inited').
# Keep actual simulator objects alive to prevent id reuse, and guard concurrent
# rollouts in case a future trainer uses multiple threads. Each new Python
# process gets a fresh registry and initializes its native RocketSim once.
_INIT_LOCK = Lock()
_INITIALIZED_SIMULATORS = {}


def ensure_rocketsim_initialized(rs):
    """Initialize the native simulator once per process, not once per Arena.

    If another legitimate caller initialized it before this module was loaded,
    the *specific* RocketSim 'Already inited' error is also safe to accept.
    Other initialization errors (missing meshes, incompatibility, etc.) must
    propagate instead of being incorrectly reported as successful startup.
    """
    with _INIT_LOCK:
        key = id(rs)
        if _INITIALIZED_SIMULATORS.get(key) is rs:
            return
        meshes = find_meshes()
        if meshes is None:
            raise FileNotFoundError('Soccar collision meshes not found. Copy your own meshes to '
                                    'third_party/collision_meshes/soccar/*.cmf or set REPLICAR_MESHES.')
        if hasattr(rs, 'init'):
            try:
                rs.init(str(meshes))
            except RuntimeError as exc:
                # RocketSim's init() is not idempotent. Only this exact native
                # state error is expected; never swallow a bad mesh/path error.
                if str(exc).strip().lower() not in ('already inited', 'already initialized'):
                    raise
        _INITIALIZED_SIMULATORS[key] = rs


def init_arena(rs):
    """Create a fresh Soccar world with shared one-time RocketSim initialization."""
    ensure_rocketsim_initialized(rs)
    return rs.Arena(rs.GameMode.SOCCAR)


def vec(rs, v):
    return rs.Vec(x=float(v[0]), y=float(v[1]), z=float(v[2]))


def rot_from_xyzw(rs, q):
    """Replicar quaternions are xyzw; RocketSim RotMat uses 3 column vectors."""
    x, y, z, w = map(float, q)
    magnitude = (x*x + y*y + z*z + w*w) ** 0.5
    if magnitude < 1e-6:
        x = y = z = 0.0
        w = 1.0
    else:
        x /= magnitude; y /= magnitude; z /= magnitude; w /= magnitude
    forward = (1-2*(y*y+z*z), 2*(x*y+z*w), 2*(x*z-y*w))
    right = (2*(x*y-z*w), 1-2*(x*x+z*z), 2*(y*z+x*w))
    up = (2*(x*z+y*w), 2*(y*z-x*w), 1-2*(x*x+y*y))
    return rs.RotMat(vec(rs, forward), vec(rs, right), vec(rs, up))


def send_frame(rv, arena, count, tick_rate, game_mode):
    pads = [pad.get_state().is_active for pad in arena.get_boost_pads()]
    rv.render(count, float(tick_rate), game_mode,
              pads, arena.ball.get_state(),
              [(c.id, c.team, c.get_config(), c.get_state()) for c in arena.get_cars()])
