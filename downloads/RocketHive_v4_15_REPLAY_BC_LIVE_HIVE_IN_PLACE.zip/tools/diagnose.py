import importlib.util,os,shutil,subprocess
from pathlib import Path
for x in ['git','cmake','nvcc','nvidia-smi','rlviser','rlviser.exe']:
    print(x, '=>',shutil.which(x) or '(not on PATH)')
for x in ['torch','numpy','subtr_actor','rlviser_py','rocketsim','RocketSim','rocketgpu_py','rocketchad']:
    try: print(x,'=>',bool(importlib.util.find_spec(x)))
    except Exception:print(x, '=> check failed')
for p in [Path.cwd()/'third_party',Path.home()/'Downloads',Path(os.environ.get('LOCALAPPDATA','C:/'))/'RLBot5']:
    if p.exists():
        matches=list(p.rglob('rlviser.exe'))[:5]
        for match in matches:print('found RLViser:',match)
