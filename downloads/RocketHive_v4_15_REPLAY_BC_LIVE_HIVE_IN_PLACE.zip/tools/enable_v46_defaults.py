"""Merge v4.6 settings without clobbering user preferences/tokens."""
from pathlib import Path
import json

DEFAULTS = {
    'auto_resume_champion': True,
    'champion_resume_min_loss_gap': 0.0001,
    'champion_max_imported': 24,
}
METRICS = {
    'pose/champion_val_loss': [5, 'low'],
    'pose/champion_source_step': [0, 'neutral'],
}

def migrate(path='config_v4.json'):
    path=Path(path)
    before=path.read_bytes()
    cfg=json.loads(before)
    if not isinstance(cfg,dict):raise ValueError('Expected dict config')
    for k,v in DEFAULTS.items():cfg.setdefault(k,v)
    metrics=cfg.setdefault('wandb_skill_metrics',{})
    for k,v in METRICS.items():metrics.setdefault(k,v)
    if json.loads(before)==cfg:return False
    backup=path.with_name('config_v4_before_v46.json')
    if not backup.exists():backup.write_bytes(before)
    temp=path.with_name(path.name+'.new')
    try:
        temp.write_text(json.dumps(cfg,indent=2,ensure_ascii=False)+'\n',encoding='utf-8')
        temp.replace(path)
    finally:temp.unlink(missing_ok=True)
    return True

if __name__=='__main__':
    print('v4.6 settings added; existing preferences preserved.' if migrate()
          else 'Already has v4.6 settings; unchanged.')
