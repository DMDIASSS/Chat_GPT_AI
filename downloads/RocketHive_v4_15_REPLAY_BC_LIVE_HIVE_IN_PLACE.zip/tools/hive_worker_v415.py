"""Start the shared team planner in the existing ML Python, independent of RLBot's Python."""
from pathlib import Path
import argparse,json
from src.hive_runtime_v415 import worker_main
if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--root',required=True);p.add_argument('--team',required=True,type=int);p.add_argument('--settings',required=True);a=p.parse_args()
    worker_main(a.root,a.team,str(Path(__file__).resolve().parents[1]),json.loads(a.settings))
