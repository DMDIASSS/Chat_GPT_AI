"""Manual, conservative promotion from supplied side-swapped H2H match reports."""
from __future__ import annotations
import argparse
import json
from src.policy_gate_v44 import promote_from_report


def main():
    p=argparse.ArgumentParser(description='Promote only after external side-swapped matches')
    p.add_argument('--candidate',required=True,help='FROZEN action-policy snapshot .pt')
    p.add_argument('--champion',default='models/best_playing_controller.pt')
    p.add_argument('--results',default='reports/external_matches.jsonl')
    p.add_argument('--min-matches',type=int,default=24)
    p.add_argument('--min-per-side',type=int,default=6)
    p.add_argument('--initialize',action='store_true',help='Seed an unvalidated baseline if none exists')
    p.add_argument('--commit',action='store_true',help='Write champion only if gate passes')
    a=p.parse_args()
    decision=promote_from_report(a.candidate,a.champion,a.results,
        min_matches=a.min_matches,min_per_side=a.min_per_side,
        commit=a.commit,initialize=a.initialize)
    print(json.dumps(decision,indent=2))
    if not decision['ok']:raise SystemExit(1)
    if a.commit:print('Champion updated. External matches are not automatically verified.')
    else:print('DRY RUN: add --commit to promote')

if __name__=='__main__':main()
