"""Merge only missing v4.4 settings. Never touch tokens or existing preference ratings."""
from pathlib import Path
import json

DEFAULTS={
    'event_focus_probability':0.25,
    'validation_max_replays':24,
    'validation_frames_per_replay':16,
    'validation_batch_size':32,
    'min_disk_free_gib':2.0,
    'adaptive_search':True,
    'search_stage_trials':12,
    'search_stage_survival':0.70,
    'search_max_rollouts_per_update':2048,
    'search_max_seconds_per_update':12.0,
}
NEW_METRICS=(
    'curriculum/event_focused_samples','validation/fixed_examples',
    'performance/search_rollouts_per_sec','performance/search_seconds',
    'curriculum/search_candidates','curriculum/search_opponent_pool',
    'curriculum/search_stage','evaluation/match_count',
)

def migrate(path='config_v4.json'):
    p=Path(path)
    if not p.exists():raise FileNotFoundError(p)
    old=p.read_bytes();cfg=json.loads(old.decode('utf-8'))
    if not isinstance(cfg,dict):raise ValueError('Expected a JSON config object')
    for k,v in DEFAULTS.items():cfg.setdefault(k,v)
    user_metrics=cfg.setdefault('wandb_skill_metrics',{})
    for name in NEW_METRICS:user_metrics.setdefault(name,[0,'neutral'])
    user_metrics.setdefault('curriculum/search_early_stop',[8,'low'])
    user_metrics.setdefault('evaluation/head_to_head_lower_bound',[10,'high'])
    new=(json.dumps(cfg,indent=2,ensure_ascii=False)+'\n').encode('utf-8')
    if json.loads(old)==cfg:return False
    backup=p.with_name('config_v4_before_v44.json')
    if not backup.exists():backup.write_bytes(old)
    tmp=p.with_name(p.name+'.v44new')
    try:tmp.write_bytes(new);tmp.replace(p)
    finally:tmp.unlink(missing_ok=True)
    return True

if __name__=='__main__':
    print('Added missing v4.4 settings; backup written.' if migrate()
          else 'v4.4 settings already present; no changes made.')
