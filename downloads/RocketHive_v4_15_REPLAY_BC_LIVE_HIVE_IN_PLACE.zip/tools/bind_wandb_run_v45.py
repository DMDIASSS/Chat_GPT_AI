"""Optional manual binding when W&B API cannot discover the original run."""
import argparse
import json
from pathlib import Path
from src.wandb_resume_v45 import binding_from_url, save_binding, RunBindingError, BINDING_FILE


def main():
    parser=argparse.ArgumentParser(description='Bind an EXISTING W&B run without storing an API key')
    parser.add_argument('--url',default=None,help='Full URL of the run, not its display name')
    opt=parser.parse_args()
    cfg=json.loads(Path('config_v4.json').read_text(encoding='utf-8'))
    url=opt.url or input('Paste URL for likely-sea-1 from the W&B browser: ').strip()
    binding=binding_from_url(url,expected_project=cfg.get('wandb_project','RocketHive-v4'))
    if BINDING_FILE.exists():
        old=json.loads(BINDING_FILE.read_text(encoding='utf-8'))
        if old.get('run_id') != binding['run_id']:
            answer=input('Replace existing W&B run binding? Type YES: ')
            if answer != 'YES':
                print('Unchanged.');return
    save_binding(binding)
    print('Saved existing-run ID:',binding['run_id'])
    print('Next launch with START_V4.bat will resume this run (never create a new one).')


if __name__=='__main__':
    try:
        main()
    except (ValueError,OSError,RunBindingError) as exc:
        print('Binding failed:',exc)
        raise SystemExit(1)
