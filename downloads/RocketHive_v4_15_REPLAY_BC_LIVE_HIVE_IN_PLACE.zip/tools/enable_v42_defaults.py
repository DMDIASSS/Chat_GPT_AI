"""Optional non-destructive config_v4.json migration for RocketHive v4.2."""
from pathlib import Path
import json

p=Path('config_v4.json')
if not p.exists():
    raise SystemExit('Run from your existing RocketHive root (config_v4.json not found).')
cfg=json.loads(p.read_text(encoding='utf-8'))
original=json.dumps(cfg,sort_keys=True)
new={
  'adaptive_training': True,
  'adaptive_min_steps': 10,
  'adaptive_max_steps': 200,
  'adaptive_min_improvement': 0.05,
  'adaptive_evals_per_stage': 3,
  'auto_batch_probe': True,
  'auto_batch_candidates': [24,48,64,96],
  'policy_snapshot_every': 10,
  'policy_snapshot_keep': 10,
}
for k,v in new.items():
    cfg.setdefault(k,v)
labels=cfg.setdefault('wandb_skill_metrics',{})
for key in ('performance/pose_updates_total','performance/search_updates_total',
            'performance/pose_updates_per_sec','performance/pose_samples_per_sec',
            'performance/probe_best_samples_per_sec','performance/batch_size',
            'curriculum/pose_stage','curriculum/next_updates_per_chunk'):
    labels.setdefault(key,[0,'neutral'])
if json.dumps(cfg,sort_keys=True)==original:
    print('Config already contains v4.2 keys. Your settings were not changed.')
else:
    backup=p.with_name('config_v4_before_v42.json')
    if not backup.exists():
        backup.write_bytes(p.read_bytes())
    tmp=p.with_suffix('.v42tmp')
    tmp.write_text(json.dumps(cfg,indent=2,ensure_ascii=False)+'\n',encoding='utf-8')
    tmp.replace(p)
    print('Merged only missing v4.2 defaults; existing settings preserved. Backup:',backup)
