"""Read-only Windows RocketSim preflight for the physics-search trainer.

Exercises the exact initialization + reconstructed replay-world rollout path.
No model, replay, configuration, token or optimizer checkpoint is modified.
"""
from __future__ import annotations
import argparse
from pathlib import Path
import numpy as np

from src.physics_search import ACTIONS, SearchContext
from src.search_teacher import replay_state, teacher_indices
from tools.native_rlviser import init_arena


def check_simulator(rs, train_dir='data/train', max_replays=50, print_fn=print):
    # First two calls reproduce the original preflight + first search bug.
    init_arena(rs)
    init_arena(rs)
    print_fn('[physics-check] repeated Arena construction PASS; no second native init')
    paths = sorted(Path(train_dir).glob('*.npz'))
    if not paths:
        raise FileNotFoundError('No parsed replays in ' + str(train_dir))
    failures = []
    for p in paths[:max_replays]:
        try:
            with np.load(p, allow_pickle=False) as z:
                replay = {k: z[k] for k in z.files}
            pairs = teacher_indices(replay, horizon_ticks=16)
            if not pairs:
                raise ValueError('no valid replay-time-aligned future frame pairs')
            state = replay_state(replay, pairs[0][0])
            mode = int(state['mode'])
            plan = (ACTIONS[0],) * mode
            # Only one simple rollout, not the expensive 12x12 minimax search.
            future = SearchContext(rs, our_team=0, ticks=16).rollout(state, plan, plan)
            if not (np.isfinite(future['cars']).all() and np.isfinite(future['ball']).all()):
                raise ValueError('non-finite values returned by physics rollout')
            print_fn(f'[physics-check] replay rollout PASS: {p.name}; '
                     f'{2*mode} cars, hitboxes={list(state["hitboxes"])}')
            print_fn('[physics-check] READY: run TRAIN_ACTION_CONTROLLER.bat')
            return True
        except (KeyboardInterrupt, SystemExit):
            raise
        except Exception as exc:
            failures.append((p.name, f'{type(exc).__name__}: {exc}'))
    for name, reason in failures[:5]:
        print_fn(f'[physics-check] skipped {name}: {reason}')
    raise RuntimeError(f'No usable simulated replay in first {min(max_replays,len(paths))} '
                       'replays. Check hitbox compatibility, parser fields, and mesh files.')


def main(argv=None):
    p = argparse.ArgumentParser(description='Check RocketSim rollout without training')
    p.add_argument('--train-dir', default='data/train')
    p.add_argument('--max-replays', type=int, default=50)
    args=p.parse_args(argv)
    if args.max_replays <= 0:
        p.error('--max-replays must be positive')
    try:
        import RocketSim as rs
        print('[physics-check] binding:', getattr(rs, '__file__', '<unknown>'))
        check_simulator(rs, args.train_dir, args.max_replays)
    except KeyboardInterrupt:
        return 130
    except Exception as exc:
        print(f'[physics-check] FAILED: {type(exc).__name__}: {exc}')
        return 2
    return 0


if __name__=='__main__':
    raise SystemExit(main())
