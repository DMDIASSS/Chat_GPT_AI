from pathlib import Path
import hashlib,json,time,zipfile
ROOT=Path(__file__).resolve().parents[1]

def report():
    target=ROOT/'reports'/f'RocketHive_v415_report_{time.time_ns()}.zip';target.parent.mkdir(exist_ok=True)
    with zipfile.ZipFile(target,'w',zipfile.ZIP_DEFLATED) as z:
        for p in sorted((ROOT/'reports').glob('v415_*')):
            if p.is_file() and p.suffix in ('.json','.jsonl','.txt'):z.write(p,'reports/'+p.name)
        for p in (ROOT/'models').glob('v415_replay_brain.pt'):
            import torch
            ck=torch.load(p,map_location='cpu',weights_only=True)
            z.writestr('replay_brain_metadata.json',json.dumps({k:ck.get(k) for k in ('type','codec_steps','policy_steps','validation','health_ready','dataset_recipe')},indent=2))
            z.writestr('replay_brain_sha256.txt',hashlib.sha256(p.read_bytes()).hexdigest())
        z.writestr('scope.txt','Reports and metadata only. No trained weights, API keys, replay bodies or private messages are included.')
    print('REPORT:',target);return target
if __name__=='__main__':report()
