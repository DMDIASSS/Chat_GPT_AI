"""Set persisted RLViser camera preferences for subsequent RocketHive viewer launches."""
import argparse
from tools.native_rlviser import ROOT
from tools.rlviser_camera_v411 import load_camera_preferences, save_camera_preferences


def main(argv=None):
    p = argparse.ArgumentParser(description='Default RLViser camera for RocketHive playback/live matches')
    p.add_argument('--car', type=int, help='Car 1 through 8 (first followed car is 1)')
    p.add_argument('--ballcam', choices=['on', 'off'], help='Ballcam ON/OFF')
    p.add_argument('--interactive', action='store_true', help='Ask for preferred car and ballcam')
    ns = p.parse_args(argv)
    try:
        current = load_camera_preferences(ROOT)
        if ns.interactive:
            value = input(f'Follow car (1-8) [{current["car"]}]: ').strip()
            if value:
                ns.car = int(value)
            value = input(f'Ballcam (on/off) [{"on" if current["ball_cam"] else "off"}]: ').strip().lower()
            if value:
                if value not in ('on', 'off'):
                    raise ValueError('Enter on or off for ballcam')
                ns.ballcam = value
        car = ns.car if ns.car is not None else current['car']
        ball_cam = (ns.ballcam == 'on') if ns.ballcam is not None else current['ball_cam']
        target = save_camera_preferences(ROOT, car, ball_cam)
        print(f'[camera] Saved follow car {car}, ballcam={"ON" if ball_cam else "OFF"} in {target}')
        print('[camera] Close RLViser before restarting a viewer to apply these settings.')
    except (OSError, ValueError, KeyError) as exc:
        p.exit(2, f'[camera] ERROR: {exc}\n')
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
