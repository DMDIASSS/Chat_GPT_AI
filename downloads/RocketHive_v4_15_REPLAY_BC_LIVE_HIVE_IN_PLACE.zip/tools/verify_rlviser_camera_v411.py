"""Read-only camera verification; does not change viewer settings or model files."""
from tools.native_rlviser import find_binary, ROOT
from tools.rlviser_camera_v411 import load_camera_preferences


def main():
    try:
        prefs = load_camera_preferences(ROOT)
    except (OSError, ValueError) as exc:
        print('[camera-check] BAD PREFERENCES:', exc)
        return 2
    binary = find_binary()
    if binary is None:
        print('[camera-check] RLViser executable not found. Launch a viewer to install it.')
        return 2
    target = binary.parent / 'settings.txt'
    print('[camera-check] executable:', binary)
    print('[camera-check] desired: car', prefs['car'], 'ballcam=', prefs['ball_cam'])
    if not target.exists():
        print('[camera-check] No settings.txt yet. First viewer launch will create it.')
        return 0
    try:
        lines = target.read_text(encoding='utf-8-sig').splitlines()
    except (OSError, UnicodeError) as exc:
        print('[camera-check] Cannot read settings file:', exc)
        return 2
    keys = {}
    for line in lines:
        if '=' in line:
            key, value = line.split('=', 1)
            keys[key] = value
    expected = ('{"TrackCar":' + str(prefs['car']) + '}')
    good = (keys.get('camera_state') == expected and
            keys.get('ball_cam') == str(prefs['ball_cam']).lower())
    if good:
        print('[camera-check] READY — native settings contain follow camera + ballcam defaults.')
        return 0
    print('[camera-check] NOT APPLIED YET — close RLViser and start a viewer to set them.')
    print('[camera-check] currently: camera_state=', keys.get('camera_state'),
          'ball_cam=', keys.get('ball_cam'))
    return 1


if __name__ == '__main__':
    raise SystemExit(main())
