"""Watch a LIVE controller-driven RocketSim match in the native RLViser window.

No replay file, trained network, RLBot/game process, or browser needed. The active
controller is the transparent heuristic in src.bot_controller, not the pose model.
"""
import argparse
import time
from pathlib import Path
from tools.native_rlviser import ROOT, enter_viewer_directory, init_arena, send_frame
from src.bot_controller import decide
from src.flight_diagnostics_v47 import FlightStats, classify_flight
from src.behavior_report_v412 import BehaviorReport


def kickoff(rs, arena, cars, team_size):
    """Reset physics-controlled cars and ball at the start or after a goal."""
    for team_num in (0, 1):
        for slot in range(team_size):
            car = cars[team_num * team_size + slot]
            state = rs.CarState()
            x = (slot - (team_size - 1) / 2) * 1400
            y = -2550 if team_num == 0 else 2550
            state.pos = rs.Vec(x=float(x), y=float(y), z=17.5)
            state.vel = rs.Vec()
            state.ang_vel = rs.Vec()
            state.boost = 65.0
            f = 1 if team_num == 0 else -1
            state.rot_mat = rs.RotMat(rs.Vec(0, f, 0), rs.Vec(-f, 0, 0), rs.Vec(0, 0, 1))
            car.set_state(state)
    arena.ball.set_state(rs.BallState(pos=rs.Vec(x=0, y=0, z=100)))


def make_match(rs, team_size, hitboxes=None):
    arena = init_arena(rs)
    cars = []
    hitboxes=hitboxes or ['octane']*(2*team_size)
    if len(hitboxes)!=2*team_size:
        raise ValueError('Specify one hitbox for every car')
    from src.physics_search import configure_car
    for team_idx,team in enumerate((rs.Team.BLUE, rs.Team.ORANGE)):
        for slot in range(team_size):
            cars.append(configure_car(arena,rs,team,hitboxes[team_idx*team_size+slot]))
    kickoff(rs, arena, cars, team_size)
    return arena, cars


def run(rs, rv, seconds=120., team_size=2, speed=1., render=True, sleep=time.sleep,
        clock=time.monotonic, trained_controller=None, flight_probe=None,
        report_path="reports/v47_flight_report.json", hitboxes=None,
        behavior_path="reports/v412_behavior_report.json"):
    if team_size not in (1, 2, 3):
        raise ValueError('team-size must be 1, 2 or 3')
    if speed <= 0:
        raise ValueError('speed must be positive')
    hitboxes=hitboxes or ['octane']*(2*team_size)
    arena, cars = make_match(rs, team_size, hitboxes)
    mode = rs.GameMode.SOCCAR
    if trained_controller is not None and flight_probe is not None:
        raise ValueError('Choose one controller mode')
    if flight_probe is not None:
        # Height target makes clear this tests jump and flight, not ground chase.
        arena.ball.set_state(rs.BallState(pos=rs.Vec(x=0,y=0,z=800)))
    stats=FlightStats()
    behavior=BehaviorReport(len(cars),rate=float(arena.tick_rate))
    last_controls=[None]*len(cars)
    if render:
        rv.set_boost_pad_locations([p.get_pos().as_tuple() for p in arena.get_boost_pads()])
    rate = float(arena.tick_rate)
    total_ticks = max(1, round(seconds * rate)) if seconds > 0 else None
    start = clock()
    tick = 0
    score = [0, 0]
    controller_label=('search-distilled network (UNVALIDATED)' if trained_controller else
                      'AERIAL SMOKE TEST (UNTRAINED)' if flight_probe else 'heuristic ground baseline')
    print(f'LIVE RocketSim {team_size}v{team_size} | Controller: {controller_label} | '
          'RLViser native desktop | Ctrl+C to stop', flush=True)
    if render:
        print('CAMERA: car-follow + ballcam loaded automatically from RLViser settings.', flush=True)
        print('Press Esc to hide menu. Keys 1-8 switch followed car, 9 director, 0 free.',flush=True)
    try:
        while total_ticks is None or tick < total_ticks:
            if tick % 8 == 0:
                ball = arena.ball.get_state()
                if trained_controller is not None:
                    controls=trained_controller.controls(rs,cars,ball,hitboxes=hitboxes)
                elif flight_probe is not None:
                    controls=flight_probe.controls(rs,cars,ball)
                else:
                    controls=[]
                    for i,car in enumerate(cars):
                        action=decide(cars,ball,int(car.team),i)
                        controls.append(rs.CarControls(**vars(action)))
                for i,(car,ctrl) in enumerate(zip(cars,controls)):
                    car.set_controls(ctrl)
                    last_controls[i]=ctrl
            arena.step(1)
            if all(c is not None for c in last_controls):
                physical_states=[car.get_state() for car in cars]
                stats.observe(physical_states,last_controls)
                behavior.observe(physical_states,last_controls,arena.ball.get_state())
            if tick>0 and tick%int(max(1,rate*10))==0:
                snapshots=behavior.summary(controller_label,getattr(trained_controller,'checkpoint',None))
                print('[behavior] '+', '.join(f'car {c["car_index"]}: '
                      f'boost={c["final_boost"]:.0f}, speed_max={c["max_speed_uu_s"]:.0f}, '
                      f'action_changes={c["action_changes"]}' for c in snapshots['cars']),flush=True)
            if tick % 8 == 0:
                ball_state = arena.ball.get_state()
                # Conservative goal-volume crossing check, not an authoritative
                # RocketSim scoring callback. Keeps the demonstration playing.
                if (abs(ball_state.pos.y) > 5190 and abs(ball_state.pos.x) < 880
                        and ball_state.pos.z < 650):
                    scorer = 0 if ball_state.pos.y > 0 else 1
                    score[scorer] += 1
                    print(f'Goal! Blue {score[0]} : {score[1]} Orange', flush=True)
                    if flight_probe is None:
                        kickoff(rs, arena, cars, team_size)
                        behavior.mark_kickoff()
            if render:
                send_frame(rv, arena, tick, rate, mode)
            tick += 1
            sleep(max(0., start + tick / (rate * speed) - clock()))
    except KeyboardInterrupt:
        print('Stopped by user.')
    finally:
        status=stats.save(report_path,controller_label,
                          getattr(trained_controller,'checkpoint',None))
        print('[flight] '+classify_flight(stats),status,flush=True)
        result=behavior.save(behavior_path,controller_label,
                             getattr(trained_controller,'checkpoint',None))
        for c in result['cars']:
            print(f'[behavior] car {c["car_index"]} ({c["team"]}): '
                  + '; '.join(c['diagnosis']),flush=True)
        print('[behavior] per-car JSON and readable TXT:',behavior_path,flush=True)
        if render:
            rv.quit()
    return tick


def main():
    a = argparse.ArgumentParser(description='Watch live RocketSim bots in the RLViser DESKTOP window')
    a.add_argument('--seconds', type=float, default=120, help='0 means play indefinitely')
    a.add_argument('--team-size', type=int, default=2, choices=(1, 2, 3))
    a.add_argument('--speed', type=float, default=1.)
    modes=a.add_mutually_exclusive_group()
    modes.add_argument('--trained-policy',action='store_true',help='Use models/v4_action_policy_search_teacher.pt')
    modes.add_argument('--aerial-probe',action='store_true',help='Untrained physical flight diagnostic, NOT AI')
    a.add_argument('--hitboxes',default='',
                   help='Comma-separated per-car presets in blue-then-orange order')
    a.add_argument('--checkpoint',default='models/v4_action_policy_search_teacher.pt',
                   help='Action policy checkpoint for --trained-policy; NOT a pose model')
    ns = a.parse_args()
    try:
        import RocketSim as rs
        import rlviser_py as rv
    except ImportError as exc:
        a.error(f'{exc}. Install with: python -m pip install "rocketsim>=2.2.1" rlviser-py')
    try:
        # IMPORTANT: RLViser changes the working directory to the executable's
        # folder. Resolve and LOAD the model first: otherwise a perfectly valid
        # models/*.pt file appears to be missing inside third_party/rlviser.
        controller=None
        probe=None
        if ns.trained_policy:
            from src.policy_inference import SearchPolicyController
            requested=Path(ns.checkpoint).expanduser()
            # Default checkpoint always belongs to this source tree. Custom
            # relative paths are relative to the user's current directory.
            checkpoint=((ROOT / requested) if ns.checkpoint ==
                        'models/v4_action_policy_search_teacher.pt' else requested).resolve()
            if not checkpoint.is_file():
                raise FileNotFoundError(
                    f'Controller checkpoint missing: {checkpoint}. '
                    'Run VERIFY_PHYSICS_SEARCH.bat, then TRAIN_ACTION_CONTROLLER.bat '
                    'until updates >= 1. A pose champion cannot drive a car.')
            controller=SearchPolicyController(checkpoint=checkpoint)
        # Keeping flight reports in RocketHive/reports instead of the RLViser
        # binary directory avoids diagnostics vanishing after a viewer launch.
        report_path=(ROOT / 'reports/v47_flight_report.json').resolve()
        behavior_path=(ROOT / 'reports/v412_behavior_report.json').resolve()
        # rlviser-py expects the executable in the current working directory.
        exe = enter_viewer_directory()
        print('Launching native RLViser:', exe, flush=True)
        if ns.aerial_probe:
            from src.aerial_probe_v47 import AerialProbe
            probe=AerialProbe()
        boxes=[v.strip().lower() for v in ns.hitboxes.split(',') if v.strip()] if ns.hitboxes else None
        return 0 if run(rs, rv, ns.seconds, ns.team_size, ns.speed,
                        trained_controller=controller,flight_probe=probe,hitboxes=boxes,
                        report_path=report_path,behavior_path=behavior_path) >= 0 else 1
    except (OSError, RuntimeError, ValueError) as exc:
        a.exit(2, f'RLViser live match failed: {exc}\n')


if __name__ == '__main__':
    raise SystemExit(main())
