"""Watch Replicar trajectories in the *native* RLViser desktop application.

This is REPLAY PLAYBACK (ghost states), not a live controller. For a bot actually
making control decisions in RocketSim, run WATCH_BOT_RLVISER.bat instead.
"""
import argparse
import time
from pathlib import Path
import numpy as np
from tools.native_rlviser import enter_viewer_directory, init_arena, send_frame, rot_from_xyzw, vec


def load(path=None, folder='data'):
    if path:
        source = Path(path)
    else:
        choices = sorted(Path(folder).rglob('*.npz'))
        source = choices[0] if choices else None
    if not source or not source.is_file():
        raise FileNotFoundError('No parsed .npz replay found. Run START_TRAIN.bat or supply --file.')
    with np.load(source, allow_pickle=False) as z:
        data = {k: z[k] for k in z.files}
    return data, source


def update_state(rs, arena, cars, data, frame):
    """Copy all available *recorded* physics fields including quaternion orientation."""
    ball = data['ball'][frame]
    bs = arena.ball.get_state()
    bs.pos = vec(rs, ball[:3])
    bs.rot_mat = rot_from_xyzw(rs, ball[3:7])
    bs.vel = vec(rs, ball[7:10])
    bs.ang_vel = vec(rs, ball[10:13])
    arena.ball.set_state(bs)
    for i, car in enumerate(cars):
        x = data['cars'][frame, i]
        st = car.get_state()
        st.pos = vec(rs, x[:3])
        st.rot_mat = rot_from_xyzw(rs, x[3:7])
        st.vel = vec(rs, x[7:10])
        st.ang_vel = vec(rs, x[10:13])
        st.boost = float(np.clip(x[13] * 100, 0, 100))
        car.set_state(st)


def play(rs, rv, data, speed=1., max_seconds=0., clock=time.monotonic, sleep=time.sleep):
    if speed <= 0: raise ValueError('speed must be positive')
    arena = init_arena(rs)
    slots = np.flatnonzero(data['mask'])
    from src.physics_search import configure_car
    cars = [configure_car(arena,rs,rs.Team.BLUE if int(data['team'][i]) == 0 else rs.Team.ORANGE,
                          str(data['hitboxes'][i])) for i in slots]
    if not cars: raise ValueError('No cars in replay.')
    rv.set_boost_pad_locations([pad.get_pos().as_tuple() for pad in arena.get_boost_pads()])
    first_valid = np.flatnonzero(data['valid'])
    if not len(first_valid): raise ValueError('Replay contains no valid frames.')
    start_frame = int(first_valid[0])
    start_time = float(data['time'][start_frame])
    start_wall = clock()
    print('CAMERA: following car 1 with ballcam by default; press Esc to hide menu.',flush=True)
    print(f'Native RLViser replay: {len(cars)} cars, {len(data["time"])} frames. '
          'These are recorded states, NOT live AI decisions.', flush=True)
    try:
        for k in range(start_frame, len(data['time'])):
            if not bool(data['valid'][k]): continue
            elapsed = (float(data['time'][k]) - start_time) / speed
            if max_seconds > 0 and elapsed > max_seconds: break
            sleep(max(0., start_wall + elapsed - clock()))
            # The import data uses contiguous blue then orange active car slots.
            update_state(rs, arena, cars, data, k)
            send_frame(rv, arena, k, float(data['fps']) * speed, rs.GameMode.SOCCAR)
    except KeyboardInterrupt:
        print('Stopped by user.')
    finally:
        rv.quit()


def main():
    p = argparse.ArgumentParser(description='Native RLViser replay playback, NOT browser')
    p.add_argument('--file', type=Path)
    p.add_argument('--data', default='data')
    p.add_argument('--speed', type=float, default=1.)
    p.add_argument('--max-seconds', type=float, default=0.)
    ns = p.parse_args()
    try:
        import RocketSim as rs
        import rlviser_py as rv
    except ImportError as exc:
        p.exit(2, f'Missing viewer packages: {exc}. Run WATCH_REPLAY.bat on Windows.\n')
    try:
        data, source = load(ns.file, ns.data)
        binary = enter_viewer_directory()
        print('Using native RLViser:', binary, 'source:', source)
        play(rs, rv, data, ns.speed, ns.max_seconds)
        return 0
    except (OSError, ValueError, RuntimeError) as exc:
        p.exit(2, f'Native replay visualization failed: {exc}\n')


if __name__ == '__main__':
    raise SystemExit(main())
