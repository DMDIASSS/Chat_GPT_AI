"""Safe, persistent RLViser follow-car/ball-cam defaults.

RLViser (VirxEC, MIT) reads settings.txt relative to its process cwd:
  camera_state={"TrackCar":1}     # 1-indexed, follows the first car
  ball_cam=true                  # point the following camera at the ball

This module does not fake an in-game camera or alter RocketSim states. It edits
only these RLViser settings, taking a one-time backup if the file already exists.
"""
from __future__ import annotations

import json
import os
from pathlib import Path
import tempfile

DEFAULT = {"car": 1, "ball_cam": True}
PREFS_FILE = "viewer_camera.json"


def validate_camera_preferences(car: int, ball_cam: bool) -> dict:
    if type(car) is not int or not 1 <= car <= 8:
        raise ValueError("RLViser car camera must be 1 through 8")
    if type(ball_cam) is not bool:
        raise ValueError("ball_cam must be true or false")
    return {"car": car, "ball_cam": ball_cam}


def load_camera_preferences(project_root: Path) -> dict:
    target = Path(project_root) / PREFS_FILE
    if not target.exists():
        return DEFAULT.copy()
    try:
        saved = json.loads(target.read_text(encoding="utf-8"))
        return validate_camera_preferences(saved["car"], saved["ball_cam"])
    except (OSError, ValueError, TypeError, KeyError, json.JSONDecodeError) as exc:
        raise ValueError(f"Invalid {target}. Fix/remove the file to restore default camera: {exc}") from exc


def save_camera_preferences(project_root: Path, car: int, ball_cam: bool) -> Path:
    prefs = validate_camera_preferences(car, ball_cam)
    target = Path(project_root) / PREFS_FILE
    target.parent.mkdir(parents=True, exist_ok=True)
    _atomic_write(target, (json.dumps(prefs, indent=2) + "\n").encode("utf-8"))
    return target


def _atomic_write(target: Path, content: bytes) -> None:
    temp_name = None
    try:
        with tempfile.NamedTemporaryFile(prefix=".rockethive-camera-", suffix=".tmp",
                                         dir=target.parent, delete=False) as stream:
            temp_name = stream.name
            stream.write(content)
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(temp_name, target)
    finally:
        if temp_name and Path(temp_name).exists():
            Path(temp_name).unlink()


def configure_rlviser_camera(binary: Path, car: int = 1, ball_cam: bool = True) -> Path:
    """Set RLViser camera on startup; preserve all unrelated settings and make backup.

    Must run *before* RLViser is launched. A running RLViser can write its own
    settings back to disk, so settings are not guaranteed to update live.
    """
    prefs = validate_camera_preferences(car, ball_cam)
    executable = Path(binary).resolve()
    if not executable.is_file():
        raise FileNotFoundError(f"RLViser executable not found: {executable}")
    settings = executable.parent / "settings.txt"
    new_values = {"camera_state": json.dumps({"TrackCar": prefs["car"]}, separators=(",", ":")),
                  "ball_cam": str(prefs["ball_cam"]).lower()}
    if settings.exists():
        original = settings.read_bytes()
        # RLViser settings.txt uses UTF-8; refuse to damage unusual data instead
        # of replacing invalid bytes. Preserve CRLF/LF and unrelated settings.
        text = original.decode("utf-8-sig")
        newline = "\r\n" if "\r\n" in text else "\n"
        bom = b"\xef\xbb\xbf" if original.startswith(b"\xef\xbb\xbf") else b""
    else:
        original = None
        text = ""
        newline = "\n"
        bom = b""

    seen = set()
    lines = []
    for line in text.splitlines():
        key = line.split("=", 1)[0]
        if key in new_values:
            # Remove duplicate camera entries so the last one cannot undo ours.
            if key not in seen:
                lines.append(f"{key}={new_values[key]}")
                seen.add(key)
        else:
            lines.append(line)
    for key in ("ball_cam", "camera_state"):
        if key not in seen:
            lines.append(f"{key}={new_values[key]}")

    result = bom + (newline.join(lines) + newline).encode("utf-8")
    if result == original:
        return settings
    if original is not None:
        backup = settings.with_name("settings.txt.rockethive-original.bak")
        if not backup.exists():
            # Exclusive open: never overwrite previous user's original backup.
            try:
                with backup.open("xb") as stream:
                    stream.write(original)
            except FileExistsError:
                pass
    _atomic_write(settings, result)
    return settings
