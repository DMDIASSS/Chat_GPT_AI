from src.data_health_v44 import audit,write_audit
import json
if __name__=='__main__':
    r=audit('data')
    print(json.dumps(r,indent=2))
    print('Saved',write_audit(r))
    if not r['ok']:raise SystemExit(1)
