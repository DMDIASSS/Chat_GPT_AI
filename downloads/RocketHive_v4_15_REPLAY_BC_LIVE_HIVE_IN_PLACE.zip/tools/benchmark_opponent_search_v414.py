"""Benchmark actual native RocketSim opponent-first planner (read-only)."""
from __future__ import annotations
import json,time
from pathlib import Path
import numpy as np
from src.search_teacher import build_policy,make_observation,replay_state,teacher_indices
from src.learned_candidates_v414 import LearnedCandidateProposer
from src.chunk_proposer_v414 import ChunkPrior,ChunkCandidateProposer
from src.opponent_first_v414 import OpponentFirstSearch
from src.sequence_search_v412 import replay_targets
from src.evaluation_v414 import make_evaluator
from src.physics_search import UnsupportedHitboxError,ACTIONS


def main():
    cfg=json.loads(Path('config_v4.json').read_text(encoding='utf-8'))
    eva=make_evaluator(cfg)
    import torch,RocketSim as rs
    from tools.native_rlviser import init_arena
    init_arena(rs)
    ckpath=Path('models/v4_action_policy_search_teacher.pt')
    if not ckpath.exists():
        print('[benchmark] action model missing; run TRAIN_ACTION_CONTROLLER.bat');return 2
    ck=torch.load(ckpath,map_location='cpu',weights_only=False)
    if ck.get('obs_dim') is None or list(map(tuple,ck.get('action_table',[])))!=list(map(tuple,ACTIONS)):
        print('[benchmark] incompatible action checkpoint');return 2
    pol=build_policy();pol.load_state_dict(ck['model']);pol.eval()
    seg=int(cfg.get('sequence_segments',3));ticks=int(cfg.get('sequence_ticks',8))
    priorpath=Path('models/v414_chunk_prior.pt')
    if priorpath.exists():
        prior=ChunkPrior(priorpath)
        proposer=(ChunkCandidateProposer(prior,make_observation,seg,ticks)
          if prior.steps>=int(cfg.get('chunk_prior_warmup',32)) else
          LearnedCandidateProposer(pol,make_observation,seg,ticks))
    else:
        proposer=LearnedCandidateProposer(pol,make_observation,seg,ticks)
    count=int(cfg.get('search_candidates',12))
    engine=OpponentFirstSearch(rs,count,seg,ticks,
        opponent_responses=int(cfg.get('opponent_responses',4)),
        ally_probes=int(cfg.get('opponent_ally_probes',3)),
        evaluator=eva,proposer=proposer)
    output={'planner':type(proposer).__name__,'evaluator':eva.source,
            'candidates':count,'segments':seg,'ticks':ticks,'searches':[]}
    for path in sorted(Path('data/train').glob('*.npz'))[:80]:
        try:
            with np.load(path,allow_pickle=False) as f:
                d={key:f[key] for key in f.files}
            possible=teacher_indices(d,seg*ticks)
            if not possible:continue
            idx=possible[len(possible)//2][0]
            state=replay_state(d,idx);refs=replay_targets(d,idx,seg,ticks)
            t=time.perf_counter();found=engine.search(state,refs)
            duration=(time.perf_counter()-t)*1000
            result={'replay':path.name,'mode':int(state['mode']),
                    'milliseconds':duration,'rollouts':found.rollouts,
                    'candidate_source':found.opponent_first_info['candidate_source'],
                    'blue_robust_value':found.opponent_first_info['blue_robust_value'],
                    'orange_robust_value':found.opponent_first_info['orange_robust_value']}
            output['searches'].append(result)
            print('[benchmark]  %s  %s v %s  %.0f ms  %s rollouts' %
                  (path.name,int(state['mode']),int(state['mode']),duration,found.rollouts),flush=True)
            if len(output['searches'])>=3:break
        except (UnsupportedHitboxError,ValueError,KeyError,RuntimeError) as exc:
            print('[benchmark] skip',path.name,type(exc).__name__,str(exc)[:120],flush=True)
    target=Path('reports/v414_search_latency.json');target.parent.mkdir(exist_ok=True,parents=True)
    target.write_text(json.dumps(output,indent=2),encoding='utf-8')
    if not output['searches']:
        print('[benchmark] no compatible replay available');return 2
    print('[benchmark] report:',target)
    print('[benchmark] 8 ticks = 66.7ms at 120Hz. Slower searches cannot be deployed synchronously.')
    print('[benchmark] This is an OFFLINE teacher: trained-model RLViser currently uses direct policy inference.')
    return 0

if __name__=='__main__':raise SystemExit(main())
