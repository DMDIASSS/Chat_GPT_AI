from pathlib import Path
import json,time,statistics
import numpy as np
from src.live_hive_v415 import HivePlanner,HiveSettings,snapshot
from tools.watch_bot_rlviser import make_match

def main():
    import RocketSim as rs
    results=[]
    for mode in (1,2,3):
        arena,cars=make_match(rs,mode);state=snapshot(arena,cars,dict(mode=mode,hitboxes=['octane']*(2*mode)));planner=HivePlanner(rs)
        for team in (0,1):
            for repetition in range(3):
                result=planner.plan(state,team)
                if np.shape(result['controls'])!=(mode,32,8) or not np.isfinite(result['controls']).all():raise ValueError('Malformed team plan')
                results.append({k:v for k,v in result.items() if k not in ('controls','line_values')})
        print('HIVE_NATIVE_PASS',mode,'v',mode,results[-1]['controller'],flush=True)
    Path('reports').mkdir(exist_ok=True);Path('reports/v415_live_verify.json').write_text(json.dumps(results,indent=2))
    print('LIVE_HIVE_CONTRACT_PASS. This verifies live search execution, not bot strength or Windows RLBot deployment.')
if __name__=='__main__':main()
