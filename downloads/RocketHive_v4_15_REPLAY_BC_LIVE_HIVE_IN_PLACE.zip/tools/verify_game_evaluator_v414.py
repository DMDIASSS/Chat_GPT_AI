import json
from pathlib import Path
from src.evaluation_v414 import make_evaluator
from src.search_teacher import replay_state
import numpy as np


def main():
    cfg=json.loads(Path('config_v4.json').read_text(encoding='utf-8'))
    try:
        eval=make_evaluator(cfg)
    except Exception as exc:
        print('[value] NOT READY:',str(exc));return 2
    print('[value] evaluator:',eval.source)
    replays=sorted(Path('data/train').glob('*.npz'))
    for p in replays:
        try:
            with np.load(p,allow_pickle=False) as f:
                if not all(k in f for k in ('cars','ball','valid','hitboxes','mode')):continue
                d={key:f[key] for key in ('cars','ball','valid','hitboxes','mode')}
                if 'car_flags' in f:d['car_flags']=f['car_flags']
            idx=int(np.flatnonzero(d['valid'])[0])
            val=eval.score(replay_state(d,idx))
            print(f'[value] READY: sample blue-advantage={val:+.4f}; source={eval.source}')
            print('[value] This is NEXT-GOAL advantage, not match win probability.')
            return 0
        except (ValueError,KeyError,IndexError) as exc:
            print('[value] skipped sample',p.name,str(exc))
    print('[value] evaluator loads but no compatible replay state was available')
    return 2

if __name__=='__main__':raise SystemExit(main())
