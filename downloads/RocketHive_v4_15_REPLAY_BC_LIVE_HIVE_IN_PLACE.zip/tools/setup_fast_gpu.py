"""Optional RocketGPU + RocketChad3 repo installer for existing CUDA toolchains.

No hidden admin installers or copyrighted collision meshes. Does NOT automatically
wire our pose-forecast weights into RocketChad PPO: that requires custom state
setters and reward callbacks, and is a separate unverified integration.
"""
from pathlib import Path
import subprocess,os,shutil,sys

root=Path(__file__).resolve().parents[1];third=root/'third_party'

def cmd(xs,check=True):
    print('>',xs,flush=True)
    return subprocess.run(xs,check=check)

def main():
    for prog in ('git','cmake','nvcc'):
        if not shutil.which(prog):
            print(f'Cannot build RocketGPU CUDA: {prog} is unavailable. See README for installation steps.')
            return 2
    import torch
    if not torch.cuda.is_available():
        print('CUDA-enabled PyTorch not working. Check nvidia-smi / driver compatibility.')
        return 2
    third.mkdir(exist_ok=True)
    for name,url in [('RocketGPU','https://github.com/thecosmicskye/RocketGPU'),
                     ('RocketChad3','https://github.com/thecosmicskye/RocketChad3')]:
        if not (third/name/'.git').exists():cmd(['git','clone','--depth','1',url,str(third/name)])
    mesh=os.environ.get('ROCKETGPU_COLLISION_MESH_DIR') or str(third/'collision_meshes')
    if not (Path(mesh)/'soccar').exists():
        print('Soccar collision meshes are missing. They must be dumped from your OWN Rocket League installation.')
        print('See ZealanL/RLArenaCollisionDumper and RocketGPU README; expected',Path(mesh)/'soccar')
        return 2
    cmd(['cmake','-S',str(third/'RocketGPU'),'-B',str(third/'RocketGPU'/'build'),
         '-DROCKETGPU_USE_CUDA=ON','-DROCKETGPU_BUILD_PYTHON=ON','-DCMAKE_BUILD_TYPE=Release'])
    cmd(['cmake','--build',str(third/'RocketGPU'/'build'),'--config','Release','--parallel','4'])
    cmd([sys.executable,'-m','pip','install','-e',str(third/'RocketChad3')])
    print('Installed dependencies. For self-play baseline use:')
    print('python -m rocketchad --config third_party/RocketChad3/examples/basic/config.py --out runs/chad_baseline')
    print('This baseline is NOT replay-trajectory PPO until custom callbacks are built.')
    return 0
if __name__=='__main__':raise SystemExit(main())
