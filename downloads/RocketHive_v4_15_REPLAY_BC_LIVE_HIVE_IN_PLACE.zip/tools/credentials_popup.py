"""RocketHive API credentials, protected per Windows user with native DPAPI.

Only Windows user-context encrypted blobs are written. Tokens never go into the
project config, logs, command line, .bat files, or the distributed ZIP. On
non-Windows platforms saving is deliberately disabled (no plaintext fallback).
"""
from __future__ import annotations

import argparse
import json
import os
from pathlib import Path
import sys


class CredentialError(RuntimeError):
    """Local credential storage could not be accessed."""


def _secret_path() -> Path:
    if sys.platform != 'win32':
        raise CredentialError('Encrypted API key storage requires Windows.')
    base = os.environ.get('APPDATA')
    if not base:
        base = str(Path.home() / 'AppData' / 'Roaming')
    return Path(base) / 'RocketHive' / 'credentials.dpapi'


def _crypt(data: bytes, *, decrypt: bool) -> bytes:
    """Call Windows Crypt(Un)ProtectData using current-user DPAPI.

    The DPAPI output buffer belongs to Windows and must be released by LocalFree.
    """
    if sys.platform != 'win32':
        raise CredentialError('Windows DPAPI is unavailable on this operating system.')
    import ctypes
    from ctypes import wintypes

    class DataBlob(ctypes.Structure):
        _fields_ = [('size', wintypes.DWORD), ('data', ctypes.POINTER(ctypes.c_ubyte))]

    source = (ctypes.c_ubyte * len(data)).from_buffer_copy(data)
    input_blob = DataBlob(len(data), ctypes.cast(source, ctypes.POINTER(ctypes.c_ubyte)))
    output_blob = DataBlob()
    crypt32 = ctypes.WinDLL('Crypt32.dll', use_last_error=True)
    kernel32 = ctypes.WinDLL('Kernel32.dll', use_last_error=True)
    signature = [ctypes.POINTER(DataBlob), ctypes.c_void_p, ctypes.POINTER(DataBlob),
                 ctypes.c_void_p, ctypes.c_void_p, wintypes.DWORD, ctypes.POINTER(DataBlob)]
    # Both APIs have the same pointer shapes: the second is an optional text
    # description for ProtectData and an optional output pointer for UnprotectData.
    api = crypt32.CryptUnprotectData if decrypt else crypt32.CryptProtectData
    api.argtypes = signature
    api.restype = wintypes.BOOL
    kernel32.LocalFree.argtypes = [ctypes.c_void_p]
    kernel32.LocalFree.restype = ctypes.c_void_p
    if not api(ctypes.byref(input_blob), None, None, None, None, 0,
               ctypes.byref(output_blob)):
        raise CredentialError('Windows could not decrypt the saved tokens.' if decrypt
                              else 'Windows could not encrypt the tokens.')
    try:
        return ctypes.string_at(output_blob.data, output_blob.size)
    finally:
        kernel32.LocalFree(ctypes.cast(output_blob.data, ctypes.c_void_p))


def load_saved_tokens() -> tuple[str, str] | None:
    """Return credentials or None if never saved; wrong-user data fails closed."""
    if sys.platform != 'win32':
        return None
    path = _secret_path()
    if not path.exists():
        return None
    try:
        if path.stat().st_size > 32768:
            raise CredentialError('Encrypted token file is unexpectedly large.')
        payload = _crypt(path.read_bytes(), decrypt=True)
        saved = json.loads(payload.decode('utf-8'))
        if not isinstance(saved, dict) or saved.get('version') != 1:
            raise CredentialError('Unsupported saved-token format.')
        ball = saved.get('ballchasing', '')
        wandb = saved.get('wandb', '')
        if not isinstance(ball, str) or not isinstance(wandb, str):
            raise CredentialError('Invalid saved-token format.')
        return ball, wandb
    except (OSError, ValueError, UnicodeError) as exc:
        raise CredentialError('Could not read saved API tokens.') from exc


def clear_saved_tokens() -> None:
    """Remove the encrypted blob; no plaintext copy is created."""
    if sys.platform == 'win32':
        try:
            _secret_path().unlink(missing_ok=True)
        except OSError as exc:
            raise CredentialError('Could not delete saved tokens.') from exc


def save_tokens(ball: str, wandb: str) -> None:
    """Encrypt secrets under the current Windows login (not portable to others)."""
    ball, wandb = ball.strip(), wandb.strip()
    if not ball and not wandb:
        clear_saved_tokens()
        return
    path = _secret_path()
    payload = json.dumps({'version': 1, 'ballchasing': ball, 'wandb': wandb},
                         separators=(',', ':')).encode('utf-8')
    encrypted = _crypt(payload, decrypt=False)
    try:
        path.parent.mkdir(parents=True, exist_ok=True)
        # Write only the encrypted bytes to disk. Replace atomically so a
        # crash during editing cannot destroy otherwise valid saved keys.
        temp = path.with_name(path.name + '.new')
        try:
            with temp.open('wb') as f:
                f.write(encrypted)
            temp.replace(path)
        finally:
            temp.unlink(missing_ok=True)
    except OSError as exc:
        raise CredentialError('Could not save encrypted API tokens.') from exc


def prompt_tokens(ball: str = '', wandb: str = '', *, has_saved: bool = False) -> tuple[str, str]:
    """Prompt once; selected credentials may be saved for automatic future use."""
    try:
        import tkinter as tk
        from tkinter import messagebox
    except ImportError:
        print('[tokens] Tkinter unavailable; use process environment variables.', flush=True)
        return ball, wandb
    try:
        root = tk.Tk()
    except tk.TclError:
        print('[tokens] Popup could not open; use process environment variables.', flush=True)
        return ball, wandb
    root.title('RocketHive — API tokens')
    root.resizable(False, False)
    root.columnconfigure(0, weight=1)
    entries = []
    for i, (heading, value) in enumerate([
        ('Ballchasing API token (optional)', ball),
        ('Weights & Biases API key (optional)', wandb),
    ]):
        tk.Label(root, text=heading).grid(row=i*2, column=0, sticky='w', padx=16, pady=(10, 0))
        var = tk.StringVar(value=value)
        tk.Entry(root, textvariable=var, show='*', width=58).grid(
            row=i*2+1, column=0, sticky='we', padx=16)
        entries.append(var)

    remember = tk.BooleanVar(value=(sys.platform == 'win32'))
    chk = tk.Checkbutton(root, variable=remember,
        text='Remember securely for my Windows user account (automatic next time)')
    chk.grid(row=4, column=0, sticky='w', padx=12, pady=(12, 0))
    if sys.platform != 'win32':
        chk.configure(state='disabled')
    tk.Label(root, text='Saved with Windows encryption, outside your project folder.').grid(
        row=5, column=0, sticky='w', padx=16, pady=(1, 6))
    chosen = []

    def start():
        values = tuple(var.get().strip() for var in entries)
        if remember.get():
            try:
                save_tokens(*values)
            except CredentialError:
                messagebox.showwarning('API token storage',
                    'Could not securely save the keys. Training can still run this time.')
        elif has_saved:
            try:
                clear_saved_tokens()
            except CredentialError:
                messagebox.showwarning('API token storage',
                    'Could not remove the previously saved keys. Use Manage API Keys to retry.')
        chosen.extend(values)
        root.destroy()

    def delete():
        if messagebox.askyesno('Forget API keys?',
                               'Delete both locally saved API keys?'):
            try:
                clear_saved_tokens()
            except CredentialError:
                messagebox.showerror('API token storage', 'Unable to remove saved tokens.')
                return
            for var in entries:
                var.set('')
            remember.set(False)
            messagebox.showinfo('API tokens', 'Saved keys deleted for this Windows user.')

    buttons = tk.Frame(root)
    buttons.grid(row=6, column=0, padx=16, pady=(8, 16), sticky='w')
    tk.Button(buttons, text='Save and Continue', command=start).pack(side='left')
    tk.Button(buttons, text='Delete Saved Keys', command=delete).pack(side='left', padx=(10, 0))
    root.protocol('WM_DELETE_WINDOW', root.destroy)
    root.mainloop()
    return tuple(chosen) if chosen else (ball, wandb)


def resolve_tokens(ball: str = '', wandb: str = '', *, no_popup: bool = False,
                   force_popup: bool = False) -> tuple[str, str]:
    """Prefer explicit environment tokens, then saved ones. Skip repeat popups.

    Closing a popup never modifies stored credentials. --no-popup still uses
    previously saved tokens. --manage always opens the edit popup.
    """
    try:
        saved = load_saved_tokens()
    except CredentialError:
        saved = None
        print('[tokens] Saved keys are unreadable for this Windows user. '
              'Use Manage API Keys to replace them.', flush=True)
    ball = ball or (saved[0] if saved else '')
    wandb = wandb or (saved[1] if saved else '')
    if no_popup or (saved is not None and not force_popup):
        if saved is not None and not force_popup:
            print('[tokens] Using Windows-protected saved API credentials.', flush=True)
        return ball, wandb
    return prompt_tokens(ball, wandb, has_saved=(saved is not None))


def main():
    parser = argparse.ArgumentParser(description='Edit Windows-protected RocketHive API tokens')
    parser.add_argument('--manage', action='store_true', help='Open the API-key editor, without training')
    parser.add_argument('--clear', action='store_true', help='Delete locally encrypted saved API keys')
    args = parser.parse_args()
    if args.clear:
        clear_saved_tokens()
        print('Saved RocketHive API keys deleted (if present).')
    else:
        resolve_tokens(os.environ.get('BALLCHASING_TOKEN', ''),
                       os.environ.get('WANDB_API_KEY', ''), force_popup=True)
        print('API key editor closed. Run START_V4.bat to train.')


if __name__ == '__main__':
    main()
