"""Merge v4.7 defaults without replacing the user's W&B metric importance."""
import json
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
path=ROOT/'config_v4.json'
if not path.is_file():raise FileNotFoundError(path)
config=json.loads(path.read_text(encoding='utf-8'))
config.setdefault('aerial_teacher_prob',0.35)
metrics=config.setdefault('wandb_skill_metrics',{})
metrics.setdefault('curriculum/search_aerial_focused',[0,'neutral'])
# Save only when changed: do not rewrite user tokens / overwrite other config.
tmp=path.with_suffix('.v47tmp')
tmp.write_text(json.dumps(config,indent=2,ensure_ascii=False)+'\n',encoding='utf-8')
tmp.replace(path)
print('v4.7 config defaults merged; existing model/data/metrics values preserved.')
