"""Verify one REPLAY physics-sequence search without modifying model weights."""
from __future__ import annotations
import argparse
import json
from pathlib import Path
import numpy as np
from src.search_teacher import replay_state,teacher_indices
from src.sequence_search_v412 import SequenceSearch,replay_targets,compact_result


def main(argv=None):
    p=argparse.ArgumentParser()
    p.add_argument('--samples',type=int,default=30,help='Maximum files to check for a valid target')
    p.add_argument('--candidates',type=int,default=12)
    p.add_argument('--segments',type=int,default=3)
    p.add_argument('--ticks',type=int,default=8)
    ns=p.parse_args(argv)
    if not 12<=ns.candidates<=64:p.error('candidates must be 12..64')
    try:
        import RocketSim as rs
    except ImportError as e:
        p.error(f'RocketSim binding missing: {e}')
    files=sorted(Path('data/train').glob('*.npz'))
    if not files:
        print('[sequence-check] No replay datasets in data/train',flush=True)
        return 2
    failed=[]
    for path in files[:max(1,ns.samples)]:
        try:
            with np.load(path,allow_pickle=False) as f:
                data={k:f[k] for k in f.files}
            pairs=teacher_indices(data,ns.segments*ns.ticks)
            if not pairs:continue
            # Choose the middle eligible frame to test a real replay world.
            frame=pairs[len(pairs)//2][0]
            initial=replay_state(data,frame)
            ref=replay_targets(data,frame,ns.segments,ns.ticks)
            if ref is None:continue
            engine=SequenceSearch(rs,ns.candidates,ns.segments,ns.ticks,1,seed=42)
            print('[sequence-check] starting real physics replay:',path.name,flush=True)
            result=engine.search(initial,ref)
            report=compact_result(result)
            report['replay']=path.name
            dest=Path('reports/v412_sequence_diagnostic.json')
            dest.parent.mkdir(parents=True,exist_ok=True)
            tmp=dest.with_suffix('.tmp')
            tmp.write_text(json.dumps(report,indent=2),encoding='utf-8')
            tmp.replace(dest)
            print('[sequence-check] PASS: candidate rollouts=',result.rollouts,
                  'deviated=',result.terminated, 'reward=',round(result.reward,4),flush=True)
            for car in report['players']:
                print(f'[sequence-check] car {car["index"]}: actions={car["actions"]} '
                      f'type={car["motion_type"]}, score={car["trajectory_score"]}',flush=True)
            print('[sequence-check] Report:',dest,flush=True)
            return 0
        except (ValueError,KeyError,OSError,RuntimeError) as exc:
            failed.append(f'{path.name}: {type(exc).__name__}: {exc}')
    print('[sequence-check] ERROR: no runnable replay search among scanned files',flush=True)
    for row in failed[:5]:print('[sequence-check] skipped',row,flush=True)
    return 2

if __name__=='__main__':raise SystemExit(main())
