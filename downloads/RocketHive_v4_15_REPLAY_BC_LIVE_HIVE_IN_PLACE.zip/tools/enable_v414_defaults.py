"""Merge v4.14 defaults without deleting existing settings or credentials."""
from pathlib import Path
import json

NEW_METRICS={
 'evaluation/blue_advantage':[0,'neutral'],
 'search/blue_robust_value':[7,'high'],
 'search/orange_robust_value':[7,'high'],
 'search/blue_second_best_value':[3,'high'],
 'search/orange_second_best_value':[3,'high'],
 'search/opponent_threats':[0,'neutral'],
 'policy/mean_unique_first_actions':[5,'high'],
 'policy/proposal_regret':[8,'low'],
 'policy/top2_joint_prior_recall':[7,'high'],
 'policy/chunk_prior_train_loss':[5,'low'],
 'policy/chunk_prior_steps':[0,'neutral'],
 'value/heldout_loss':[8,'low'],
 'value/train_loss':[3,'low'],
 'value/optimizer_steps':[0,'neutral'],
}

def update(path='config_v4.json'):
    p=Path(path)
    cfg=json.loads(p.read_text(encoding='utf-8'))
    previous=cfg.get('search_strategy','replay_sequences')
    backup=p.with_name(p.name+'.pre_v414.bak')
    if not backup.exists():backup.write_bytes(p.read_bytes())
    # This update explicitly enables the requested opponent-first mode.
    cfg['search_strategy']='opponent_first'
    if cfg.get('game_evaluator') in (None,'physics_proxy'):
        cfg['game_evaluator']='replay_goal_value'
    defaults={
      'evaluator_checkpoint':'models/v414_goal_value_best.pt',
      'opponent_responses':4,
      'opponent_ally_probes':3,
      'adversarial_refinement':1,
      'opponent_replay_weight':0.01,
      'chunk_prior_warmup':32,
      'chunk_prior_lr':0.0002,
      'sequence_segments':3,
      'sequence_ticks':8,
      'adaptive_search':False,
      'search_candidates':12,
    }
    for key,value in defaults.items():cfg.setdefault(key,value)
    # Previous replay-survival curriculum is NOT a reliable skill metric for
    # value-guided opponent search. Freeze its old stage for this new teacher.
    cfg['adaptive_search']=False
    annotations=cfg.setdefault('wandb_skill_metrics',{})
    for metric,rating in NEW_METRICS.items():annotations.setdefault(metric,rating)
    save=p.with_suffix('.tmp')
    save.write_text(json.dumps(cfg,indent=2,ensure_ascii=False)+'\n',encoding='utf-8')
    save.replace(p)
    print(f'[v414] search_strategy: {previous} -> opponent_first')
    print(f'[v414] evaluator: {cfg["game_evaluator"]}')
    print('[v414] all existing models, replays, W&B history, API keys preserved')
    return cfg

if __name__=='__main__':update()
