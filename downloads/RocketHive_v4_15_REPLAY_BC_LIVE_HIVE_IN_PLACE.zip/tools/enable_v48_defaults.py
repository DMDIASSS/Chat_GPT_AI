"""Opt-in v4.8 settings: never overwrite existing user preferences or W&B keys."""
import json
from pathlib import Path


def apply(path='config_v4.json'):
    path=Path(path)
    data=json.loads(path.read_text(encoding='utf-8'))
    changed=False
    defaults={'validation_auto_rebaseline':True}
    for key,value in defaults.items():
        if key not in data:
            data[key]=value;changed=True
    skills=data.setdefault('wandb_skill_metrics',{})
    if 'validation/valid' not in skills:
        skills['validation/valid']=[0,'neutral'];changed=True
    if changed:
        backup=path.with_suffix('.v48_before.json')
        if not backup.exists():backup.write_bytes(path.read_bytes())
        path.write_text(json.dumps(data,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    return changed

if __name__=='__main__':print('[v4.8] merged missing settings' if apply() else '[v4.8] settings already present; unchanged')
