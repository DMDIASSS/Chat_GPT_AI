"""Two-stage replay-only VQ-VAE + autoregressive BC/value; resumable and bounded."""
from pathlib import Path
import argparse,copy,hashlib,json,os,tempfile,time,signal
import numpy as np
import torch
from src.replay_bc_v415 import ChunkCodec,ReplayPolicy,reconstruction_loss,controls
from src.search_teacher import OBS_DIM

def atomic_save(path,obj):
    path=Path(path);path.parent.mkdir(parents=True,exist_ok=True)
    fd,n=tempfile.mkstemp(dir=path.parent,suffix='.tmp');os.close(fd)
    try:torch.save(obj,n);os.replace(n,path)
    finally:
        if os.path.exists(n):os.unlink(n)

def load_data(folder,max_samples=24000):
    xs=[];ys=[];vs=[];ks=[];hashes={};total=0
    for p in sorted(Path(folder).glob('*.npz')):
        hashes[p.name]=hashlib.sha256(p.read_bytes()).hexdigest()
        with np.load(p,allow_pickle=False) as z:
            take=min(len(z['obs']),max_samples-total)
            if take<=0:break
            xs.append(z['obs'][:take]);ys.append(z['actions'][:take]);vs.append(z['value'][:take]);ks.append(z['value_known'][:take]);total+=take
    if not xs:raise ValueError('No tick-level replay chunks in '+str(folder)+'. Run BUILD_REPLAY_CHUNKS.bat; old pose NPZs are deliberately not used as button labels.')
    return tuple(np.concatenate(v) for v in (xs,ys,vs,ks)),hashes

def train(root='.',codec_steps=1000,policy_steps=2000,minutes=30,device='auto',batch=128):
    root=Path(root).resolve();device='cuda' if device=='auto' and torch.cuda.is_available() else ('cpu' if device=='auto' else device)
    torch.set_num_threads(1);torch.manual_seed(415)
    tr,th=load_data(root/'data/v415_chunks/train');va,vh=load_data(root/'data/v415_chunks/val',6000)
    if set(th)&set(vh):raise ValueError('A replay appears in both train and validation')
    if len(th)<2 or len(vh)<2 or len(tr[0])<256 or len(va[0])<64 or tr[3].sum()<32 or va[3].sum()<16:
        raise ValueError('Need >=2 whole replays per split, 256 train/64 validation chunks, and 32/16 known next-goal labels. No censored tails are invented as negatives.')
    for ds in (tr,va):
        if ds[1].shape[1:]!=(32,8) or ds[0].shape[1]!=OBS_DIM or not all(np.isfinite(x).all() for x in ds):raise ValueError('Malformed replay dataset')
    implementation=hashlib.sha256(Path(__file__).read_bytes()+(Path(__file__).resolve().parents[1]/'src/replay_bc_v415.py').read_bytes()).hexdigest()
    recipe=dict(implementation_sha256=implementation,codec_steps=codec_steps,policy_steps=policy_steps,batch=batch,train=th,validation=vh,seed=415)
    codec=ChunkCodec().to(device);net=ReplayPolicy().to(device);co=torch.optim.Adam(codec.parameters(),lr=2e-4);po=torch.optim.Adam(net.parameters(),lr=2e-4)
    state=root/'models/v415_training_state.pt';cstep=pstep=0;best=float('inf');best_ready=False
    if state.exists():
        ck=torch.load(state,map_location=device,weights_only=True)
        if ck['recipe']!=recipe:raise ValueError('Dataset or recipe changed. Keep the existing training checkpoint and use a separate project/run for a changed experiment.')
        codec.load_state_dict(ck['codec']);net.load_state_dict(ck['policy']);co.load_state_dict(ck['codec_optimizer']);po.load_state_dict(ck['policy_optimizer']);cstep=ck['codec_steps'];pstep=ck['policy_steps'];best=ck['best'];best_ready=ck.get('best_ready',False)
    stop=root/'STOP_REPLAY_BC';stop.unlink(missing_ok=True);deadline=time.monotonic()+minutes*60
    def checkpoint():atomic_save(state,dict(recipe=recipe,codec=codec.state_dict(),policy=net.state_dict(),codec_optimizer=co.state_dict(),policy_optimizer=po.state_dict(),codec_steps=cstep,policy_steps=pstep,best=best,best_ready=best_ready))
    def sample(ds,size,seed):
        ix=np.random.default_rng(seed).integers(len(ds[0]),size=size)
        return [torch.as_tensor(a[ix],device=device) for a in ds]
    old_handler=signal.signal(signal.SIGINT,lambda *_:stop.touch())
    try:
        while cstep<codec_steps:
            if stop.exists() or time.monotonic()>deadline:checkpoint();print('REPLAY_BC_PAUSED: codec checkpoint saved');return
            _,y,_,_=sample(tr,batch,415+cstep)
            if cstep==0:codec.initialize(y)
            raw,_,vq=codec(y);loss=reconstruction_loss(raw,y)+.1*vq
            if not torch.isfinite(loss):raise ValueError('Nonfinite codec loss')
            co.zero_grad(set_to_none=True);loss.backward();torch.nn.utils.clip_grad_norm_(codec.parameters(),1);co.step();cstep+=1
            if cstep%50==0:checkpoint();print('CODEC',cstep,'loss',float(loss),flush=True)
        codec.eval().requires_grad_(False)
        while pstep<policy_steps:
            if stop.exists() or time.monotonic()>deadline:checkpoint();print('REPLAY_BC_PAUSED: policy checkpoint saved');return
            x,y,v,known=sample(tr,batch,100415+pstep)
            with torch.no_grad():_,ids,_=codec.encode(y);decoded=codec.decode(ids)
            logits=net.teacher_logits(x,ids);ce=torch.nn.functional.cross_entropy(logits.flatten(0,1),ids.flatten())
            offset,value=net.heads(x);axes=controls(decoded,offset)[:,:,:5]
            mse=(axes-y[:,:,:5]).square().mean();vl=(value[known]-v[known]).square().mean() if known.any() else value.sum()*0
            loss=ce+mse+vl
            if not torch.isfinite(loss):raise ValueError('Nonfinite BC/value loss')
            po.zero_grad(set_to_none=True);loss.backward();torch.nn.utils.clip_grad_norm_(net.parameters(),1);po.step();pstep+=1
            if pstep%50==0 or pstep==policy_steps:
                net.eval()
                with torch.no_grad():
                    vx,vy,vv,vk=sample(va,min(512,len(va[0])),4415);raw,ids,_=codec(vy)
                    vce=torch.nn.functional.cross_entropy(net.teacher_logits(vx,ids).flatten(0,1),ids.flatten())
                    _,pred=net.heads(vx);vvalue=(pred[vk]-vv[vk]).square().mean();rec=reconstruction_loss(raw,vy)
                    jump=controls(raw)[:,:,5];truth=vy[:,:,5];tp=((jump>.5)&(truth>.5)).sum().item();f1=2*tp/max(1,jump.sum().item()+truth.sum().item())
                    usage=[int(torch.unique(ids[:,i]).numel()) for i in range(4)]
                    greedy=torch.empty((len(vx),0),dtype=torch.long,device=device)
                    for _ in range(4):greedy=torch.cat((greedy,net.code_logits(vx,greedy).argmax(-1)[:,None]),1)
                    gc=controls(codec.decode(greedy),net.heads(vx)[0]);unique=int(torch.unique(greedy,dim=0).shape[0]);jump_rate=float(gc[:,:,5].mean())
                    axis_mae=float((torch.tanh(raw[:,:,:5])-vy[:,:,:5]).abs().mean());constant_mse=float(vv[vk].square().mean())
                    metrics=dict(codec_axis_mae=axis_mae,constant_value_mse=constant_mse,greedy_unique_chunks=unique,greedy_jump_rate=jump_rate,code_ce=float(vce),value_mse=float(vvalue),codec_reconstruction=float(rec),jump_f1=f1,code_usage=usage,policy_steps=pstep,codec_steps=cstep)
                    score=float(vce+vvalue+rec)
                net.train();ready=cstep>=200 and pstep>=200 and axis_mae<.35 and float(vvalue)<constant_mse and sum(usage)>=12 and unique>=4 and (truth.sum()<4 or (f1>.4 and jump_rate>.001))
                if (ready and not best_ready) or (ready==best_ready and score<best):
                    best=score;best_ready=ready;atomic_save(root/'models/v415_replay_brain.pt',dict(type='REPLAY_RVQ_BC_V415',obs_dim=OBS_DIM,codec=codec.state_dict(),policy=net.state_dict(),codec_steps=cstep,policy_steps=pstep,validation=metrics,health_ready=ready,dataset_recipe=recipe))
                (root/'reports').mkdir(exist_ok=True)
                with (root/'reports/v415_bc_metrics.jsonl').open('a') as f:f.write(json.dumps(metrics)+'\n')
                checkpoint();print('REPLAY_BC',metrics,'health_ready',ready,flush=True)
        print('REPLAY_BC_COMPLETE: this is an unverified game-playing candidate; run VERIFY_LIVE_HIVE and bounded match tests, not an automatic champion promotion.',flush=True)
    except KeyboardInterrupt:checkpoint();print('REPLAY_BC_PAUSED: saved complete optimizer state')
    finally:signal.signal(signal.SIGINT,old_handler)

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--codec-steps',type=int,default=1000);p.add_argument('--policy-steps',type=int,default=2000);p.add_argument('--minutes',type=float,default=30);p.add_argument('--device',choices=['auto','cpu','cuda'],default='auto');a=p.parse_args()
    if min(a.codec_steps,a.policy_steps,a.minutes)<=0:p.error('Positive budgets required')
    train(codec_steps=a.codec_steps,policy_steps=a.policy_steps,minutes=a.minutes,device=a.device)
