"""Read-only check for the action-controller weights used by RLViser.

It intentionally never initializes RocketSim or launches RLViser. Exit code 0
means a shape-compatible, updated controller exists, not that it is strong.
"""
import argparse
from pathlib import Path


def main(argv=None):
    parser=argparse.ArgumentParser(description='Check saved search-distilled car-driving model')
    parser.add_argument('--checkpoint', default='models/v4_action_policy_search_teacher.pt')
    args=parser.parse_args(argv)
    from src.policy_inference import SearchPolicyController
    try:
        controller=SearchPolicyController(checkpoint=args.checkpoint)
    except (FileNotFoundError, ValueError, OSError, KeyError, RuntimeError) as exc:
        print(f'[controller-check] NOT READY: {type(exc).__name__}: {exc}',flush=True)
        print('[controller-check] Next: VERIFY_PHYSICS_SEARCH.bat then TRAIN_ACTION_CONTROLLER.bat; '
              'look for updates=1 or more.',flush=True)
        return 2
    print(f'[controller-check] READY: checkpoint={controller.checkpoint}, '
          f'optimizer_updates={controller.checkpoint_step}',flush=True)
    print('[controller-check] Model loaded, but aerial skill and win-rate still need real evaluation.',flush=True)
    return 0


if __name__=='__main__':
    raise SystemExit(main())
