"""Trains a Blue/Orange next-goal evaluator from LOCAL parsed replay goal events.

Requires distinct data/train and data/val replay splits. Does not fetch or
misrepresent any external pretrained model. No private tokens required.
"""
import argparse, json
from pathlib import Path
from src.goal_value_v414 import load_replay_examples,fit_value_model


def main():
    p=argparse.ArgumentParser();p.add_argument('--steps',type=int,default=800)
    p.add_argument('--batch-size',type=int,default=128)
    a=p.parse_args()
    if a.steps<=0:raise ValueError('Steps must be positive')
    print('[value] loading training data/goal events...',flush=True)
    x,y,n,e=load_replay_examples('data/train',max_replays=1200)
    print(f'[value] train: {len(y)} frames from {n} replays; skipped {len(e)}',flush=True)
    vx,vy,v,ve=load_replay_examples('data/val',max_replays=300,frames_per_replay=128,seed=4747)
    print(f'[value] val: {len(vy)} frames from {v} different replays; skipped {len(ve)}',flush=True)
    train_files={p.name for p in Path('data/train').glob('*.npz')}
    val_files={p.name for p in Path('data/val').glob('*.npz')}
    if train_files & val_files:
        print('[value] ERROR: train and val contain identical replay filenames. '
              'Fix replay-level data leakage first.',flush=True)
        return 2
    if not v:
        print('[value] ERROR: no held-out val replays; do not evaluate on training clips',flush=True)
        return 2
    import torch
    device='cuda' if torch.cuda.is_available() else 'cpu'
    try:
        result=fit_value_model((x,y),(vx,vy),steps=a.steps,batch_size=a.batch_size,device=device)
    except ValueError as exc:
        print('[value] ERROR:',str(exc),flush=True)
        print('[value] Check that Replicar .npz replays contain goal_rows/goal_teams. '
              'This evaluator must not learn from invented goals.',flush=True)
        return 2
    print('[value] saved best validation checkpoint:',result['checkpoint'],flush=True)
    print('[value] best val cross entropy:',round(result['best_val_loss'],4),flush=True)
    report=Path('reports/v414_game_evaluator.json');report.parent.mkdir(parents=True,exist_ok=True)
    report.write_text(json.dumps({'train_frames':len(y),'train_replays':n,
        'val_frames':len(vy),'val_replays':v,**result},indent=2),encoding='utf-8')
    # Reuse only the EXISTING bound W&B run; never create a new numbered run.
    # The same encrypted Windows key store used by START_V4 is read silently.
    try:
        from tools.credentials_popup import resolve_tokens
        _,wandb_key=resolve_tokens(no_popup=True)
        from src.continuous import Logger
        cfg=json.loads(Path('config_v4.json').read_text(encoding='utf-8'))
        logger=Logger(project=cfg.get('wandb_project','RocketHive-v4'),
            entity=cfg.get('wandb_entity'),token=wandb_key,
            skill_metrics=cfg.get('wandb_skill_metrics',{}))
        try:
            for line in result['evaluations']:
                logger.log({'value/train_loss':line['train_loss'],
                            'value/heldout_loss':line['val_loss'],
                            'value/optimizer_steps':line['step']},line['step'])
        finally:logger.close()
    except Exception as exc:
        print('[value] Optional W&B logging unavailable; local report preserved:',str(exc),flush=True)
    return 0

if __name__=='__main__':raise SystemExit(main())
