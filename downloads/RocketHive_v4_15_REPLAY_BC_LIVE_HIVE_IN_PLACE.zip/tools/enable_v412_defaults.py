"""Preserve all existing settings while enabling replay-sequence search."""
from __future__ import annotations
import json
import shutil
from pathlib import Path


def update(path='config_v4.json'):
    path=Path(path)
    old_controller=path.parent/'models/v4_action_policy_search_teacher.pt'
    snapshot=path.parent/'models/v4_action_policy_pre_sequences_v412.pt'
    if old_controller.is_file() and not snapshot.exists():
        snapshot.parent.mkdir(parents=True,exist_ok=True)
        temp=snapshot.with_suffix('.tmp')
        shutil.copy2(old_controller,temp)
        temp.replace(snapshot)
        print('[v4.12] protected previous action controller:',snapshot,flush=True)
    original=path.read_text(encoding='utf-8')
    cfg=json.loads(original)
    changes=[]
    defaults={
        'search_strategy':'replay_sequences',
        'sequence_segments':3,
        'sequence_ticks':8,
        'sequence_sweeps':1,
        'aerial_teacher_prob':0.4,
    }
    for k,v in defaults.items():
        if k not in cfg:
            cfg[k]=v;changes.append(k)
    ratings=cfg.setdefault('wandb_skill_metrics',{})
    new_ratings={
        'search/sequence_segments':[0,'neutral'],
        'search/candidates_per_player':[0,'neutral'],
        'search/players_searched':[0,'neutral'],
        'policy/distilled_examples':[0,'neutral'],
    }
    for k,v in new_ratings.items():
        if k not in ratings:ratings[k]=v;changes.append('wandb_skill_metrics:'+k)
    if changes:
        backup=path.with_name(path.name+'.pre_v412.bak')
        if not backup.exists():backup.write_text(original,encoding='utf-8')
        temporary=path.with_suffix('.json.tmp')
        temporary.write_text(json.dumps(cfg,indent=2)+'\n',encoding='utf-8')
        temporary.replace(path)
    return changes


def main():
    changes=update()
    if changes:print('[v4.12] enabled new defaults:',', '.join(changes))
    else:print('[v4.12] config already contains settings; nothing overwritten')
    print('[v4.12] training model/checkpoint weights untouched')

if __name__=='__main__':main()
