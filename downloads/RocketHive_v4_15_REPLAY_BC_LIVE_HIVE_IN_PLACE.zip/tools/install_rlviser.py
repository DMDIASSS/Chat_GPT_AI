"""Optional auto-discovery/installer for RLViser Windows release, from official GitHub.

This downloads a community-made EXE/ZIP; verify provenance if you don't trust
community executables. Network and GitHub release assets required.
"""
import json
from pathlib import Path
from urllib.request import Request,urlopen
from urllib.error import URLError
import zipfile
import io
import shutil
import os
import sys

HOME=Path(__file__).resolve().parents[1]

def find_viser():
    explicit=os.environ.get('RLVISER_EXE')
    if explicit and Path(explicit).is_file(): return Path(explicit)
    direct=shutil.which('rlviser.exe')
    if direct:return Path(direct)

    for place in (HOME/'third_party',Path.home()/'Downloads',Path(os.environ.get('LOCALAPPDATA','C:/'))/'RLBot5'):
        if place.exists():
            for f in place.rglob('rlviser.exe'):return f
    return None

def main():
    found=find_viser()
    if found:print('RLViser detected at',found);return 0
    if sys.platform!='win32':
        print('This installer supports Windows only. See https://github.com/VirxEC/rlviser/releases');return 2
    print('Looking up official VirxEC/rlviser latest release...')
    req=Request('https://api.github.com/repos/VirxEC/rlviser/releases/latest',headers={'User-Agent':'Rocket-Hivemind-User-Installer','Accept':'application/vnd.github+json'})
    try:
        with urlopen(req,timeout=25) as response:release=json.load(response)
    except Exception as exc:
        print('Could not load releases:',exc);return 2
    assets=release.get('assets') or []
    candidates=[]
    for a in assets:
        s=a.get('name','').lower()
        if (s.endswith(('.zip','.exe'))
                and (any(x in s for x in ('win','windows','x64','x86_64')) or s == 'rlviser.exe')
                and all(x not in s for x in ('linux','macos','darwin','arm64'))):candidates.append(a)
    if not candidates:
        print('No recognized Windows binary in release assets:',[(a.get('name')) for a in assets]);return 2
    chosen=sorted(candidates,key=lambda a:(a.get('name','').lower()!='rlviser.exe', a.get('name','')))[0]
    url=chosen['browser_download_url']
    print('Downloading community application',chosen['name'],'from',url)
    req=Request(url,headers={'User-Agent':'Rocket-Hivemind-User-Installer'})
    try:
        with urlopen(req,timeout=90) as resp:
            payload=resp.read(150*1024*1024)
    except Exception as exc:
        print('Download failed:',exc);return 2
    if len(payload)>=150*1024*1024:
        print('Refusing oversized asset');return 2
    folder=HOME/'third_party'/'rlviser';folder.mkdir(parents=True,exist_ok=True)
    if chosen['name'].lower().endswith('.exe'):
        (folder/'rlviser.exe').write_bytes(payload)
    else:
        try:
            with zipfile.ZipFile(io.BytesIO(payload)) as z:
                for m in z.infolist():
                    if m.is_dir():continue
                    # Extract only executable and bundled assets, rejecting unsafe paths.
                    p=Path(m.filename)
                    if p.is_absolute() or '..' in p.parts:continue
                    target=folder/p;target.parent.mkdir(parents=True,exist_ok=True)
                    if m.file_size>100*1024*1024:continue
                    target.write_bytes(z.read(m))
        except zipfile.BadZipFile:
            print('Downloaded asset is not a ZIP');return 2
    found=find_viser()
    if found:print('RLViser ready:',found);return 0
    print('Archive extracted but no rlviser.exe found. Inspect',folder);return 2
if __name__=='__main__':raise SystemExit(main())
