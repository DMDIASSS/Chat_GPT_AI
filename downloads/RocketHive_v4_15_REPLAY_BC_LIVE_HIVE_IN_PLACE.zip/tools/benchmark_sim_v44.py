"""Optional native RocketSim physics microbenchmark (NOT PPO training SPS)."""
from __future__ import annotations
import argparse
import json
import time
from pathlib import Path


def benchmark(rs, num_cars=2, ticks=2400, tick_chunk=8):
    from tools.native_rlviser import init_arena
    arena=init_arena(rs)
    if num_cars not in (2,4,6):raise ValueError('num_cars must be 2, 4 or 6')
    for i in range(num_cars):
        team=rs.Team.BLUE if i<num_cars//2 else rs.Team.ORANGE
        car=arena.add_car(team)
        car.set_controls(rs.CarControls(throttle=1.,steer=.15,
                                       pitch=0.,yaw=0.,roll=0.,jump=False,
                                       boost=False,handbrake=False))
    for _ in range(10):arena.step(tick_chunk)
    start=time.perf_counter()
    for _ in range(ticks//tick_chunk):arena.step(tick_chunk)
    elapsed=max(1e-9,time.perf_counter()-start)
    completed=(ticks//tick_chunk)*tick_chunk
    return {'cars':num_cars,'physics_ticks':completed,'seconds':elapsed,
            'arena_ticks_per_sec':completed/elapsed,
            'player_timestep_per_sec':completed*num_cars/elapsed,
            'not_ppo_sps':True}


def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--cars',type=int,default=2,choices=(2,4,6))
    parser.add_argument('--ticks',type=int,default=2400)
    a=parser.parse_args()
    try:
        import RocketSim as rs
    except ImportError:
        try:import rocketsim as rs
        except ImportError as exc:
            raise SystemExit('No compatible native RocketSim binding installed. '
                'Use the original GigaLearn benchmark for actual PPO SPS.') from exc
    try:
        data=benchmark(rs,num_cars=a.cars,ticks=a.ticks)
    except (OSError,RuntimeError,FileNotFoundError,AttributeError) as exc:
        raise SystemExit('Native binding/mesh error: '+str(exc)) from exc
    print(json.dumps(data,indent=2))
    p=Path('reports/v4_native_physics_benchmark.json')
    p.parent.mkdir(parents=True,exist_ok=True)
    p.write_text(json.dumps(data,indent=2),encoding='utf-8')
    print('This is PHYSICS ONLY, not GigaLearn or RocketChad end-to-end SPS.')

if __name__=='__main__':main()
