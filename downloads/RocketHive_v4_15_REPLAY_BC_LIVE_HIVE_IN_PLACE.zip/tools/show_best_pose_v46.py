"""Read-only champion summary; safe while indefinite trainer is running."""
from pathlib import Path
import json


def show(root='.'):
    root=Path(root)
    status=root/'reports/v4_champion_selection.json'
    if not status.is_file():
        return {'status':'no selection yet; launch START_V4.bat with parsed validation replays'}
    content=json.loads(status.read_text(encoding='utf-8'))
    return {
        'purpose':'Offline pose forecast; NOT a playing-bot rating',
        'winner':content.get('winner'),
        'validation_cohort_id':content.get('validation_cohort_id'),
        'fixed_validation_loss':content.get('best_loss'),
        'step':content.get('source_step'),
        'checkpoint_on_disk':(root/'models/v4_pose_champion.pt').is_file(),
        'candidate_details_file':str(root/'reports/v4_champion_candidates.json'),
    }

if __name__=='__main__':print(json.dumps(show(),indent=2))
