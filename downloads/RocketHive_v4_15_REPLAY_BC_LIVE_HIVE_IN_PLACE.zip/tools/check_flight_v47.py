"""Run a real RocketSim action controller without RLViser for automated metrics.

No training happens; this is a diagnostic run using the saved action controller.
"""
import argparse
from pathlib import Path
from src.flight_diagnostics_v47 import classify_flight,FlightStats
from tools.watch_bot_rlviser import run


def main():
    p=argparse.ArgumentParser(description='Headless RocketSim controller flight diagnostics')
    p.add_argument('--seconds',type=float,default=30.)
    p.add_argument('--team-size',type=int,choices=(1,2,3),default=2)
    p.add_argument('--checkpoint',default='models/v4_action_policy_search_teacher.pt')
    args=p.parse_args()
    if not Path(args.checkpoint).is_file():
        p.exit(2,'No action-controller checkpoint. The pose champion is not a driving model.\n')
    try:
        import RocketSim as rs
        from src.policy_inference import SearchPolicyController
        ctl=SearchPolicyController(checkpoint=args.checkpoint)
        run(rs,None,seconds=args.seconds,team_size=args.team_size,speed=100,
            render=False,sleep=lambda _delay:None,trained_controller=ctl,
            report_path='reports/v47_trained_flight_report.json')
        print('Diagnostic written: reports/v47_trained_flight_report.json')
        return 0
    except (ImportError,RuntimeError,ValueError,FileNotFoundError) as exc:
        p.exit(2,f'Flight diagnostic failed: {exc}\n')


if __name__=='__main__':raise SystemExit(main())
