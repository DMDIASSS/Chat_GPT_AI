"""Train/check real physics-search driving policy without waiting for pose updates.

This does NOT imitate replay controller inputs and does not claim to be PPO.
The teacher searches state transitions in RocketSim; successful teacher actions
are distilled into a separate car-driving policy checkpoint.
"""
from __future__ import annotations
import argparse
import json
from pathlib import Path
import time
import traceback
import numpy as np
from src.search_teacher import PhysicsSearchTeacher, sample_replay, teacher_indices
from src.physics_search import UnsupportedHitboxError
from src.hitbox_compat_v413 import probe_hitboxes, filter_replays, save_report
from src.telemetry_v44 import append_jsonl


class LocalLogger:
    def log(self, stats, step):
        append_jsonl('reports/v48_controller_metrics.jsonl',{'controller_step':step,**stats})


def candidates(folder='data/train', max_sample=24):
    paths=sorted(Path(folder).glob('*.npz'))
    valid=[]; bad=[]
    for p in paths:
        try:
            with np.load(p,allow_pickle=False) as f:
                r={k:f[k] for k in ('time','valid','segment','fps') if k in f.files}
                pair_count=len(teacher_indices(r))
                if pair_count:valid.append(p)
                else:bad.append((p.name,'no valid same-segment target frames'))
        except (OSError,ValueError,KeyError) as exc:
            bad.append((p.name,f'{type(exc).__name__}: {exc}'))
    return valid,bad


def main(argv=None):
    p=argparse.ArgumentParser(description='Real RocketSim physics-search action controller')
    p.add_argument('--config',default='config_v4.json')
    p.add_argument('--iterations',type=int,default=0,help='0=continuous; 1=one replay search')
    p.add_argument('--diagnose-only',action='store_true')
    args=p.parse_args(argv)
    cfg=json.loads(Path(args.config).read_text(encoding='utf-8'))
    print('[controller] independent physics teacher; no replay human inputs',flush=True)
    valid,bad=candidates()
    print(f'[controller] usable training replays: {len(valid)}; unusable: {len(bad)}',flush=True)
    for name,reason in bad[:5]:print('[controller] unusable',name,reason,flush=True)
    if not valid:
        print('[controller] ERROR: no compatible parsed replays. Check data/train, '
              'the Replicar conversion, and goal/kickoff segments.',flush=True)
        return 2
    try:
        import RocketSim as rs
        print('[controller] RocketSim Python binding imported:',getattr(rs,'__file__','unknown'),flush=True)
        from tools.native_rlviser import init_arena
        arena=init_arena(rs)
        print('[controller] Soccar arena initialization passed',flush=True)
    except Exception as exc:
        print('[controller] ERROR: RocketSim import/arena initialization failed:',repr(exc),flush=True)
        print('[controller] Use the SAME .venv where the aerial smoke test works. '
              'See installed Soccar collision meshes and RocketSim binding.',flush=True)
        return 2
    from tools.native_rlviser import init_arena
    try:
        supported, unsupported = probe_hitboxes(rs, init_arena)
    except Exception as exc:
        print('[controller] ERROR: hitbox compatibility probe failed:',repr(exc),flush=True)
        return 2
    print('[controller] native hitboxes supported:', ', '.join(supported) or '<none>', flush=True)
    for kind, reason in unsupported.items():
        print(f'[controller] hitbox not supported: {kind}: {reason}',flush=True)
    valid, excluded = filter_replays(valid, supported)
    excluded = list(bad) + excluded
    report = save_report('reports/v413_hitbox_compatibility.json',rs,supported,
                         unsupported,valid,excluded)
    print(f'[controller] hitbox-filtered replays: {len(valid)} usable, '
          f'{len(excluded)} omitted; details: reports/v413_hitbox_compatibility.json',flush=True)
    for name,reason in excluded[:8]:
        print('[controller] skipped replay',name,reason,flush=True)
    if not valid:
        print('[controller] ERROR: no replays have compatible hitboxes. '
              'Keep the original replays and use bindings with the necessary car presets.',flush=True)
        return 2
    if str(cfg.get('search_strategy','')).lower()=='opponent_first':
        try:
            from src.evaluation_v414 import make_evaluator
            evaluator=make_evaluator(cfg)
            print('[controller] opponent-first evaluator ready:',evaluator.source,flush=True)
            if 'physics_proxy' in evaluator.source:
                print('[controller] WARNING: UNTRAINED positional proxy, NOT calibrated Blue/Orange probabilities',flush=True)
        except Exception as exc:
            print('[controller] ERROR: opponent-first evaluator not ready:',str(exc),flush=True)
            print('[controller] Run TRAIN_GAME_EVALUATOR.bat first, then VERIFY_GAME_EVALUATOR.bat',flush=True)
            return 2
    if args.diagnose_only:
        print('[controller] physics + replay + hitbox preflight PASS; '
              'no model was modified.',flush=True)
        return 0
    try:
        worker=PhysicsSearchTeacher(cfg,logger=LocalLogger(),simulator=rs)
    except Exception as exc:
        print('[controller] ERROR loading controller checkpoint:',repr(exc),flush=True)
        return 2
    print(f'[controller] begin, existing optimizer updates={worker.step}; '
          'separate pose champion remains untouched.',flush=True)
    iteration=0; rng=worker.rng; failures=0
    try:
        while args.iterations==0 or iteration<args.iterations:
            iteration+=1
            replay_path=valid[int(rng.integers(len(valid)))]
            replay=sample_replay([replay_path],rng)
            t0=time.monotonic()
            print(f'[controller] replay search {iteration}; '
                  f'checkpoint updates={worker.step}; replay set has {len(valid)} files',flush=True)
            try:
                metrics=worker.train_replay(replay)
            except UnsupportedHitboxError as exc:
                # An unsupported native preset must not terminate an indefinite
                # trainer or be replaced with Octane. Preserve the checkpoint.
                print('[controller] SKIP incompatible hitbox:',str(exc),flush=True)
                valid.remove(replay_path)
                excluded.append((replay_path.name,str(exc)))
                save_report('reports/v413_hitbox_compatibility.json',rs,supported,
                            unsupported,valid,excluded)
                if not valid:
                    print('[controller] ERROR: no compatible replays remain.',flush=True)
                    return 2
                continue
            except Exception as exc:
                print('[controller] physics search failed:',type(exc).__name__,str(exc),flush=True)
                traceback.print_exc()
                return 2
            if metrics is not None and getattr(worker,'last_sequence_report',None) is not None:
                path=Path('reports/v412_last_sequence_search.json')
                path.parent.mkdir(parents=True,exist_ok=True)
                temporary=path.with_suffix('.tmp')
                temporary.write_text(json.dumps(worker.last_sequence_report,indent=2),encoding='utf-8')
                temporary.replace(path)
                print('[controller] per-player chosen action sequences:',path,flush=True)
                for row in worker.last_sequence_report['players']:
                    print(f'[controller] car {row["index"]}: {row["motion_type"]}, '
                          f'actions={row["actions"]}, score={row["trajectory_score"]}',flush=True)
            if metrics is None:
                failures+=1
                print('[controller] sample has no replay-consistent physics target. '
                      'Trying another.',flush=True)
            else:
                failures=0
                print('[controller] search done in %.1fs; updates=%d, survived=%s, '
                      'rollouts=%d' % (time.monotonic()-t0,worker.step,
                       bool(metrics['tracking/survival_fraction']),int(metrics['search/rollouts'])),flush=True)
                if worker.step==0:
                    print('[controller] still no successful policy optimizer update; '
                          'no untrained checkpoint is being published',flush=True)
                else:
                    print('[controller] trained (not gameplay-validated) policy saved:',worker.path,flush=True)
            if failures>=min(30,len(valid)*3):
                print('[controller] ERROR: too many replay starts lack valid search targets.',flush=True)
                return 2
    except KeyboardInterrupt:
        print('[controller] stopped. Completed checkpoints remain intact.',flush=True)
    finally:
        worker.close()
    return 0


if __name__=='__main__':raise SystemExit(main())
