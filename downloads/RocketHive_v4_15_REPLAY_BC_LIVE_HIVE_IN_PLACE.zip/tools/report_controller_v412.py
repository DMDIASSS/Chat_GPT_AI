"""Headless independent controller performance report: RocketSim, no RLViser needed."""
from __future__ import annotations
import argparse
from pathlib import Path
from tools.native_rlviser import ROOT
from tools.watch_bot_rlviser import run


def main(argv=None):
    p=argparse.ArgumentParser(description='Report observed per-player behavior in a real RocketSim match')
    p.add_argument('--seconds',type=float,default=35)
    p.add_argument('--team-size',type=int,choices=(1,2,3),default=2)
    p.add_argument('--checkpoint',default=str(ROOT/'models/v4_action_policy_search_teacher.pt'))
    p.add_argument('--baseline',action='store_true',help='Report old heuristic controller instead of trained controller')
    a=p.parse_args(argv)
    if not 5<=a.seconds<=600:p.error('seconds must be between 5 and 600')
    try:
        import RocketSim as rs
        if a.baseline:
            c=None
        else:
            from src.policy_inference import SearchPolicyController
            c=SearchPolicyController(Path(a.checkpoint).resolve())
        path=ROOT/('reports/v412_baseline_behavior.json' if a.baseline else 'reports/v412_behavior_report.json')
        print('[report] REAL physics; mode:',
              'heuristic baseline' if a.baseline else 'trained action controller',flush=True)
        run(rs,None,seconds=a.seconds,team_size=a.team_size,render=False,
            sleep=lambda _:None,trained_controller=c,
            report_path=str(ROOT/'reports/v412_flight_report.json'),
            behavior_path=str(path))
        print('[report] DONE:',path,flush=True)
        return 0
    except (ImportError,RuntimeError,ValueError,OSError,KeyError) as exc:
        print('[report] FAILED:',type(exc).__name__,str(exc),flush=True)
        return 2


if __name__=='__main__':raise SystemExit(main())
