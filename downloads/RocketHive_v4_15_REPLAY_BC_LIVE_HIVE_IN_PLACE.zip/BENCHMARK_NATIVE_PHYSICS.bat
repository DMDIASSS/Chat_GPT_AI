@echo off
setlocal
cd /d "%~dp0"
".venv\Scripts\python.exe" -m tools.benchmark_sim_v44 --cars 2 --ticks 2400
pause
