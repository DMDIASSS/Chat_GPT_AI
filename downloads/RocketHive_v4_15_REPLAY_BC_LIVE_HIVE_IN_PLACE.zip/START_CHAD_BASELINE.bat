@echo off
cd /d "%~dp0"
if not exist third_party\RocketChad3\examples\basic\config.py (
 echo First run SETUP_OPTIONAL_ROCKETCHAD_GPU.bat, then resolve prerequisites.
 pause
 exit /b 1
)
set "PYTHONPATH=%CD%\third_party\RocketGPU\build\python;%PYTHONPATH%"
if not defined ROCKETGPU_COLLISION_MESH_DIR set "ROCKETGPU_COLLISION_MESH_DIR=%CD%\third_party\collision_meshes"
.venv\Scripts\python.exe -m rocketchad --config third_party\RocketChad3\examples\basic\config.py --out runs\chad_baseline
pause
