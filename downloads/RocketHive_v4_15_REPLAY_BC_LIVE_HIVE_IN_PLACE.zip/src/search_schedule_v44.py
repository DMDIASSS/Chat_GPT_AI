"""Conservative search rollout budget based on *actual replay physics outcomes*.

Unlike offline pose loss, replay-tracking survival is meaningful evidence of
short-horizon control fidelity, though it is NOT match skill or Elo. Keep the
schedule bounded on smaller laptops; no guarantee of maximum game SPS.
"""
from __future__ import annotations
from dataclasses import dataclass, asdict

LEVELS=(12,16,24,32,48,64)

@dataclass
class SearchBudget:
    stage:int=0
    observations:int=0
    successes:int=0
    failure_streak:int=0
    evals_per_stage:int=12
    min_success_rate:float=0.70
    max_rollouts:int=2048
    max_seconds:float=12.0

    @classmethod
    def from_config(cls,cfg,state=None):
        s=cls(evals_per_stage=int(cfg.get('search_stage_trials',12)),
              min_success_rate=float(cfg.get('search_stage_survival',.70)),
              max_rollouts=int(cfg.get('search_max_rollouts_per_update',2048)),
              max_seconds=float(cfg.get('search_max_seconds_per_update',12.0)))
        if state:
            for k in ('stage','observations','successes','failure_streak'):
                if k in state:setattr(s,k,int(state[k]))
        if not 1<=s.evals_per_stage<=10000 or not 0<s.min_success_rate<=1:
            raise ValueError('Invalid search curriculum configuration')
        if not 288<=s.max_rollouts<=16384 or s.max_seconds<=0:
            raise ValueError('Invalid search budget limit')
        s.stage=min(max(s.stage,0),len(LEVELS)-1)
        return s

    def candidates(self):
        return LEVELS[self.stage]

    def opponent_pool(self):
        # 2 minimax team searches (blue+orange); cap total rollout count.
        n=self.candidates()
        return max(12,min(LEVELS[self.stage], self.max_rollouts//(2*n)))

    def observe(self, survived, seconds, rollouts):
        self.observations+=1
        self.successes+=int(bool(survived))
        if survived:self.failure_streak=0
        else:self.failure_streak+=1
        if self.observations>=self.evals_per_stage:
            success_rate=self.successes/max(self.observations,1)
            # Do not increase candidate search if this step is already too slow.
            if (self.stage<len(LEVELS)-1 and success_rate>=self.min_success_rate
                    and seconds<=self.max_seconds):
                next_n=LEVELS[self.stage+1]
                if 2*next_n*12<=self.max_rollouts:
                    self.stage+=1
            # Too much failure -> allow one level down; hysteresis avoids thrashing.
            elif success_rate<self.min_success_rate/2 and self.stage>0:
                self.stage-=1
            self.observations=self.successes=0
        return self.candidates()

    def state_dict(self):return asdict(self)
