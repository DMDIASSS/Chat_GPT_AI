"""Skill relevance annotations for W&B chart names.

Ratings express how *diagnostic* a metric is of actual Rocket League skill,
NOT reward multipliers or statistically validated causal importance.

0 = neutral / not a skill indicator. 1..10 = user's subjective importance.
low = lower is better; high = higher is better. 0 is always neutral.
"""
from __future__ import annotations
import json
from pathlib import Path

# Conservative starting estimates. Configure to your own interpretation.
DEFAULT_SKILL_METRICS = {
    'pose/train_loss': {'importance': 3, 'direction': 'low'},
    'pose/val_loss': {'importance': 5, 'direction': 'low'},
    'pose/best_val_loss': {'importance': 5, 'direction': 'low'},
    'pose/regression_rollback': {'importance': 3, 'direction': 'low'},
    'pose/train_replays': {'importance': 0, 'direction': 'neutral'},
    'pose/val_replays': {'importance': 0, 'direction': 'neutral'},
    'replays/downloaded_total': {'importance': 0, 'direction': 'neutral'},
    'replays/downloaded_pass': {'importance': 0, 'direction': 'neutral'},
    'tracking/reward': {'importance': 7, 'direction': 'high'},
    'tracking/survival_fraction': {'importance': 8, 'direction': 'high'},
    'tracking/early_termination_rate': {'importance': 8, 'direction': 'low'},
    'search/robust_score': {'importance': 4, 'direction': 'high'},
    'search/rollouts': {'importance': 0, 'direction': 'neutral'},
    'policy/distillation_loss': {'importance': 4, 'direction': 'low'},
    'evaluation/win_rate': {'importance': 10, 'direction': 'high'},
    'evaluation/elo': {'importance': 10, 'direction': 'high'},
    'performance/pose_updates_total': {'importance': 0, 'direction': 'neutral'},
    'performance/search_updates_total': {'importance': 0, 'direction': 'neutral'},
    'performance/pose_updates_per_sec': {'importance': 0, 'direction': 'neutral'},
    'performance/pose_samples_per_sec': {'importance': 0, 'direction': 'neutral'},
    'performance/probe_best_samples_per_sec': {'importance': 0, 'direction': 'neutral'},
    'performance/batch_size': {'importance': 0, 'direction': 'neutral'},
    'curriculum/pose_stage': {'importance': 0, 'direction': 'neutral'},
    'curriculum/next_updates_per_chunk': {'importance': 0, 'direction': 'neutral'},
    'curriculum/event_focused_samples': {'importance': 0, 'direction': 'neutral'},
    'validation/fixed_examples': {'importance': 0, 'direction': 'neutral'},
    'performance/search_rollouts_per_sec': {'importance': 0, 'direction': 'neutral'},
    'performance/search_seconds': {'importance': 0, 'direction': 'neutral'},
    'curriculum/search_candidates': {'importance': 0, 'direction': 'neutral'},
    'curriculum/search_opponent_pool': {'importance': 0, 'direction': 'neutral'},
    'curriculum/search_stage': {'importance': 0, 'direction': 'neutral'},
    'curriculum/search_early_stop': {'importance': 8, 'direction': 'low'},
    'evaluation/head_to_head_lower_bound': {'importance': 10, 'direction': 'high'},
    'evaluation/match_count': {'importance': 0, 'direction': 'neutral'},
}


def validate_spec(spec):
    if isinstance(spec, (list, tuple)) and len(spec) == 2:
        importance, direction = spec
    elif isinstance(spec, dict):
        importance, direction = spec.get('importance'), spec.get('direction')
    else:
        raise ValueError('Use [0..10, low|high|neutral] or an object with importance/direction')
    # bool is an int, but doesn't make sense as a rating.
    if isinstance(importance, bool) or not isinstance(importance, int) or not 0 <= importance <= 10:
        raise ValueError(f'Metric importance must be integer 0..10: {importance!r}')
    direction = str(direction).lower()
    if direction not in ('low', 'high', 'neutral'):
        raise ValueError(f'Metric direction must be low, high or neutral: {direction!r}')
    if importance == 0:
        direction = 'neutral'
    elif direction == 'neutral':
        raise ValueError('Nonzero metric importance requires low or high')
    return {'importance': importance, 'direction': direction}


class SkillMetricNames:
    def __init__(self, overrides=None):
        self.specs = {name: validate_spec(value) for name, value in DEFAULT_SKILL_METRICS.items()}
        for name, value in (overrides or {}).items():
            if not isinstance(name, str) or not name or '(' in name or ')' in name:
                raise ValueError(f'Invalid metric name: {name!r}')
            self.specs[name] = validate_spec(value)

    def annotated(self, name):
        spec = self.specs.get(name, {'importance': 0, 'direction': 'neutral'})
        return f"{name}({spec['importance']},{spec['direction']})"

    def rename_values(self, values):
        # Only named numeric metrics, no double metrics or leaking tokens/metadata.
        return {self.annotated(key): float(value) if value is not None else None
                for key, value in values.items() if value is not None
                and isinstance(value, (int, float)) and not isinstance(value, bool)}

    def save_legend(self, filepath):
        p = Path(filepath)
        p.parent.mkdir(parents=True, exist_ok=True)
        data = {'description': 'Subjective importance for judging bot skill; not an objective skill estimate or reward multiplier. 0 = neutral.',
                'metrics': {k: {'chart': self.annotated(k), **v} for k, v in sorted(self.specs.items())}}
        p.write_text(json.dumps(data, indent=2), encoding='utf-8')
        return p
