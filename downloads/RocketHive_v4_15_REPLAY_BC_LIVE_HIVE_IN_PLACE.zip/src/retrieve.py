"""Retrieve replay moments with similar ALL-player poses, using car/team/hitbox masks.

Uses same-mode 1v1, 2v2, 3v3 memories. Different opponent hitboxes must
match their own categories, never silently convert to Octane.
"""
from itertools import permutations
from pathlib import Path
import numpy as np


def cost(state,target,permutation):
    # target slot mapping in canonical blue first, orange second ordering.
    a=state['cars'];b=target['cars'][permutation]
    position=((a[:,:3]-b[:,:3])/1500)**2
    q1=a[:,3:7];q2=b[:,3:7]
    d=np.sum(q1*q2,axis=-1)/np.maximum(np.linalg.norm(q1,axis=-1)*np.linalg.norm(q2,axis=-1),1e-8)
    rotation=1-np.clip(d*d,0,1)
    ball=((state['ball'][:3]-target['ball'][:3])/1500)**2
    return float(position.sum()+rotation.sum()*1.5+ball.sum()*3)


def compatible_permutations(mode,our_boxes,ref_boxes):
    # group slots per team; exact multiset match preserves collision hitbox family
    for b in (0,mode):
        if sorted(our_boxes[b:b+mode])!=sorted(ref_boxes[b:b+mode]):return []
    def perm(part,ref):
        for tup in permutations(range(len(ref))):
            if all(part[i]==ref[tup[i]] for i in range(len(part))):yield tup
    out=[]
    for left in perm(our_boxes[:mode],ref_boxes[:mode]):
        for right in perm(our_boxes[mode:2*mode],ref_boxes[mode:2*mode]):
            out.append(tuple(left)+tuple(mode+i for i in right))
    return out


def retrieve(state,data_dir='data',top_k=16,max_frames_per_replay=150):
    """state is a dict with ball[13],cars[mode*2,14],hitboxes[mode*2],mode.

    Returns ranked replay fragments (replay, time, next state) of the same mode.
    Ranking is a pose similarity, NOT a guarantee of executable controller inputs.
    """
    mode=int(state['mode']);n=2*mode
    results=[]
    for path in Path(data_dir).rglob('*.npz'):
        with np.load(path) as r:
            if int(r['mode'])!=mode:continue
            boxes=r['hitboxes'][:n].tolist()
            perms=compatible_permutations(mode,list(state['hitboxes']),boxes)
            if not perms:continue
            valid=np.flatnonzero(r['valid'])
            if len(valid)<12:continue
            idx=valid[np.linspace(0,len(valid)-11,min(max_frames_per_replay,max(1,len(valid)-11)),dtype=int)]
            cur_ball=r['ball'][idx,:3]
            ball_dist=np.sum(((cur_ball-state['ball'][:3])/1500)**2,axis=-1)
            best_ball=idx[np.argsort(ball_dist)[:min(len(idx),25)]]
            for t in best_ball:
                if t+8>=len(r['ball']) or not r['valid'][t+8]:continue
                ref={'cars':r['cars'][t,:n],'ball':r['ball'][t]}
                for perm in perms:
                    score=cost(state,ref,perm)
                    results.append((score,str(path),int(t),list(perm)))
    results.sort(key=lambda x:x[0])
    return [{'score':s,'path':p,'frame':t,'car_permutation':perm} for s,p,t,perm in results[:top_k]]
