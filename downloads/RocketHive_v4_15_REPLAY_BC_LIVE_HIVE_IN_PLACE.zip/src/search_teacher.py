"""Search distillation: use physics + replay future *as teacher*, never as policy input.

The 12..64-action joint minimax planner picks actions for blue and orange cars.
Every car gets its own supervision target derived from actual RocketSim rollouts.
An independently trained policy sees only current observations, not reference
future states or reconstructed human controls.

Requires working RocketSim bindings + owned Soccar collision meshes, which are
not included in the download. Offline state-pose training runs without it.
"""
from __future__ import annotations
import json
import shutil
import time
from .search_schedule_v44 import SearchBudget
from pathlib import Path
import numpy as np
from .physics_search import ACTIONS, SearchContext
from .tracking_v4 import replay_score, should_terminate

ACTION_TABLE = {tuple(a): i for i, a in enumerate(ACTIONS)}
HITBOXES = ('octane','dominus','plank','breakout','hybrid','merc','psyclops')
OBS_DIM = 13 + 13 + 14 + 6 * 14 + 6 + 6 + 7 * 6 + 6 * 10 + 2  # current-state tokens only


def replay_state(data, frame):
    """Copy one true replay frame; omit any non-active padded cars."""
    mode=int(np.asarray(data['mode']).item())
    n=2*mode
    if not bool(data['valid'][frame]):raise ValueError('Replay frame is invalid/inactive')
    boxes=np.asarray(data['hitboxes'][:n]).astype(str)
    if any(b not in HITBOXES for b in boxes):raise ValueError('Unknown car hitbox')
    car_flags=(np.asarray(data['car_flags'][frame,:n],dtype=np.float32).copy()
               if 'car_flags' in data else np.zeros((n,10),dtype=np.float32))
    return {'flags':car_flags,
            'ball':np.asarray(data['ball'][frame],dtype=np.float32).copy(),
            'cars':np.asarray(data['cars'][frame,:n],dtype=np.float32).copy(),
            'mask':np.ones(n,bool),'hitboxes':boxes,'team':np.r_[[0]*mode,[1]*mode],
            'mode':mode}


def teacher_indices(data, horizon_ticks=16, rng=None):
    """Valid starts and future targets, aligned by replay time and kickoff segment."""
    rng=rng or np.random.default_rng()
    time=np.asarray(data['time']);valid=np.asarray(data['valid'],bool)
    seg=np.asarray(data['segment']) if 'segment' in data else np.zeros(len(time),dtype=np.int32)
    horizon=horizon_ticks/120.
    future=np.searchsorted(time,time+horizon,side='left')
    good=[]
    # Use a tight replay-clock tolerance; never silently cross a kickoff/gap.
    for i, j in enumerate(future):
        if j>=len(time) or not valid[i] or not valid[j] or seg[i]!=seg[j]:continue
        if abs(time[j]-time[i]-horizon)>1/max(5,float(np.asarray(data.get('fps',15.))))+0.012:continue
        if not np.all(valid[i:j+1]) or not np.all(seg[i:j+1]==seg[i]):continue
        good.append((i,int(j)))
    return good


def make_observation(state, player):
    """Only current causal state + hitbox identities, padded to 3v3.

    Non-entity MLP baseline: own car + ball-relative + other cars, with a mask.
    All opponents and teammates are included, not just the ball.
    """
    n=len(state['cars']);mode=int(state['mode'])
    if not 0 <= player < n:raise IndexError(player)
    me=state['cars'][player]
    ball=np.asarray(state['ball'])
    ball_n=ball.copy();ball_n[:3]/=6000;ball_n[7:10]/=6000;ball_n[10:13]/=6
    relative=ball.copy();relative[:3]=(ball[:3]-me[:3])/6000
    relative[7:10]=(ball[7:10]-me[7:10])/6000;relative[10:13]/=6
    myself=me.copy();myself[:3]/=6000;myself[7:10]/=2300;myself[10:13]/=6
    other=np.zeros((6,14),dtype=np.float32);present=np.zeros(6,dtype=np.float32)
    relation=np.zeros(6,dtype=np.float32);onehot=np.zeros((6,7),dtype=np.float32)
    for j in range(n):
        other[j]=state['cars'][j];other[j,:3]=(state['cars'][j,:3]-me[:3])/6000
        other[j,7:10]=(state['cars'][j,7:10]-me[7:10])/2300
        other[j,10:13]/=6
        present[j]=1
        relation[j]=1 if (j<mode)==(player<mode) else -1
        onehot[j,HITBOXES.index(str(state['hitboxes'][j]))]=1
    flags=np.zeros((6,10),dtype=np.float32)
    if 'flags' in state:
        raw=np.asarray(state['flags'],dtype=np.float32)
        flags[:min(6,len(raw)),:min(10,raw.shape[1])]=raw[:6,:10]
    role=np.array([1. if player<mode else -1.,mode/3.],dtype=np.float32)
    vector=np.concatenate([ball_n,relative,myself,other.ravel(),present,relation,onehot.ravel(),flags.ravel(),role])
    assert vector.shape==(OBS_DIM,), (vector.shape,OBS_DIM)
    return vector


def build_policy():
    import torch
    from torch import nn
    return nn.Sequential(nn.Linear(OBS_DIM,192),nn.LayerNorm(192),nn.SiLU(),
                         nn.Linear(192,192),nn.SiLU(),nn.Linear(192,len(ACTIONS)))


class PhysicsSearchTeacher:
    """Uses true physics and all-car plans; produces examples for action-policy training."""
    def __init__(self,cfg,logger=None,simulator=None):
        import torch
        self.cfg=cfg;self.logger=logger;self.torch=torch
        self.device=torch.device('cuda' if torch.cuda.is_available() else 'cpu')
        if simulator is None:
            try:
                import RocketSim as simulator  # mtheall-compatible binding used by v3 viewer
            except ImportError:
                try:import rocketsim as simulator  # alternative RocketGPU namespace
                except ImportError as exc:
                    raise RuntimeError('Search teacher needs RocketSim or a compatible RocketGPU CPU binding') from exc
        self.rs=simulator
        self.rng=np.random.default_rng(int(cfg.get('seed',42)))
        self.policy=build_policy().to(self.device)
        self.opt=torch.optim.AdamW(self.policy.parameters(),lr=float(cfg.get('policy_lr',2e-4)))
        self.path=Path('models/v4_action_policy_search_teacher.pt');self.path.parent.mkdir(parents=True,exist_ok=True)
        from .controller_lock_v48 import ControllerProcessLock
        self._process_lock=ControllerProcessLock(self.path)
        self.step=0;self.best_mean=-float('inf');self._checkpoint_strategy=None
        self.search_budget=SearchBudget.from_config(cfg)
        self.chunk_prior=None
        if str(cfg.get('search_strategy','')).lower()=='opponent_first':
            from .chunk_proposer_v414 import ChunkPrior
            self.chunk_prior=ChunkPrior(device=self.device,lr=float(cfg.get('chunk_prior_lr',2e-4)))
        if self.path.exists():
            saved=torch.load(self.path,map_location=self.device,weights_only=False)
            self.policy.load_state_dict(saved['model']);self.opt.load_state_dict(saved['optimizer'])
            self.step=int(saved.get('step',0));self.best_mean=float(saved.get('best_mean',-float('inf')))
            self._checkpoint_strategy=str(saved.get('cfg',{}).get('search_strategy','single_tick'))
            self.search_budget=SearchBudget.from_config(cfg,saved.get('search_budget'))

    def close(self):
        if getattr(self,'_process_lock',None):
            self._process_lock.close()
            self._process_lock=None

    def __del__(self):
        if getattr(self,'_process_lock',None):
            try:self._process_lock.close()
            except Exception:pass

    def train_replay(self, replay):
        """One replay start per world; search independently for BOTH teams.

        The teaching target is a short-horizon *counterfactual*: best plan
        against adverse sampled replies, not copied buttons.
        """
        self.last_sequence_report=None
        strategy=str(self.cfg.get('search_strategy','single_tick')).lower()
        sequence_mode=(strategy in ('replay_sequences','opponent_first'))
        if strategy not in ('single_tick','replay_sequences','opponent_first'):
            raise ValueError('Unknown search_strategy: '+strategy)
        segments=int(self.cfg.get('sequence_segments',3)) if sequence_mode else 1
        segment_ticks=int(self.cfg.get('sequence_ticks',8)) if sequence_mode else 0
        horizon=(segments*segment_ticks if sequence_mode else int(self.cfg.get('search_horizon_ticks',16)))
        pairs=teacher_indices(replay,horizon,self.rng)
        if not pairs:return None
        # Target aerial/wall sequences deliberately: otherwise most SSL replay
        # frames are ground play and the action policy rarely sees takeoffs.
        # Sampling applies to the *offline teacher* only and never feeds future
        # states into the policy observation.
        aerial=[]
        for k,(start,end) in enumerate(pairs):
            cars=np.asarray(replay['cars'][start])
            target=np.asarray(replay['cars'][end])
            n=2*int(np.asarray(replay['mode']).item())
            if (np.any(cars[:n,2]>230) or np.any(target[:n,2]>260) or
                np.any(np.abs(target[:n,9])>350) or
                float(replay['ball'][start,2])>500):
                aerial.append(k)
        focus=(bool(aerial) and self.rng.random()<float(self.cfg.get('aerial_teacher_prob',0.35)))
        ix=int(self.rng.choice(aerial)) if focus else int(self.rng.integers(len(pairs)))
        f,next_f=pairs[ix]
        state=replay_state(replay,f)
        target=replay_state(replay,next_f)
        ref=(target['ball'],target['cars'])
        budget=(self.search_budget.candidates() if self.cfg.get('adaptive_search',True)
                else int(self.cfg.get('search_candidates',12)))
        if sequence_mode:
            from .sequence_search_v412 import SequenceSearch,replay_targets,compact_result
            references=replay_targets(replay,f,segments,segment_ticks)
            if references is None:
                return None
            if strategy=='opponent_first':
                from .learned_candidates_v414 import LearnedCandidateProposer
                from .chunk_proposer_v414 import ChunkCandidateProposer
                from .opponent_first_v414 import OpponentFirstSearch
                from .evaluation_v414 import make_evaluator
                # Never call a placeholder 'pretrained'. The explicit evaluator
                # source is logged and a missing trained value model fails early.
                evaluator=make_evaluator(self.cfg)
                if self.chunk_prior is not None and self.chunk_prior.steps >= int(self.cfg.get('chunk_prior_warmup',32)):
                    proposer=ChunkCandidateProposer(self.chunk_prior,make_observation,
                        segments=segments,ticks_per_segment=segment_ticks)
                else:
                    proposer=LearnedCandidateProposer(self.policy,make_observation,
                        segments=segments,ticks_per_segment=segment_ticks)
                    proposer.updates=self.step
                engine=OpponentFirstSearch(self.rs,candidates=budget,segments=segments,
                    ticks_per_segment=segment_ticks,
                    opponent_responses=min(budget,int(self.cfg.get('opponent_responses',4))),
                    ally_probes=int(self.cfg.get('opponent_ally_probes',3)),
                    adversarial_refinement=int(self.cfg.get('adversarial_refinement',1)),
                    replay_weight=float(self.cfg.get('opponent_replay_weight',0.01)),
                    evaluator=evaluator,proposer=proposer)
            else:
                engine=SequenceSearch(self.rs,candidates=budget,segments=segments,
                                      ticks_per_segment=segment_ticks,
                                      sweeps=int(self.cfg.get('sequence_sweeps',1)),
                                      seed=int(self.rng.integers(2**30)))
            result=engine.search(state,references)
            # Train the same inference network on ALL intermediate decisions.
            # Future reference is used solely by the offline teacher, never
            # appended to the player's causal observation vector.
            sequence_states=[state]+list(result.states[:-1])
            mode=int(state['mode'])
            observations=np.stack([make_observation(s,i) for s in sequence_states
                                   for i in range(2*mode)])
            actions=np.asarray([result.plans[i][t]
                                for t in range(segments) for i in range(2*mode)],dtype=np.int64)
            reward=result.reward;terminated=result.terminated
            rollouts=result.rollouts;elapsed=max(1e-6,result.elapsed)
            self.last_sequence_report=compact_result(result)
            if strategy=='opponent_first':
                self.last_sequence_report['opponent_first']=result.opponent_first_info
                # Replay similarity remains a DIAGNOSTIC, not a requirement
                # for a good defensive/attacking counterfactual.
                reward=float(np.mean(result.individual_scores))
                terminated=False
            search_metrics={
                'search/robust_score':float(np.mean(result.individual_scores)),
                'search/rollouts':rollouts,
                'search/sequence_segments':segments,
                'search/candidates_per_player':budget,
                'search/players_searched':2*mode,
                'policy/distilled_examples':int(len(actions)),
                'performance/search_rollouts_per_sec':rollouts/elapsed,
                'performance/search_seconds':elapsed,
                'curriculum/search_candidates':budget,
                'curriculum/search_opponent_pool':0,
                'curriculum/search_stage':self.search_budget.stage,
                'curriculum/search_early_stop':int(terminated),
                'curriculum/search_aerial_focused':int(focus),
            }
            for i,score in enumerate(result.individual_scores):
                search_metrics[f'tracking/player_{i}_trajectory_score']=float(score)
            if strategy=='opponent_first':
                info=result.opponent_first_info
                search_metrics.update({
                  'evaluation/blue_advantage':float(info['blue_advantage']),
                  'search/blue_robust_value':float(info['blue_robust_value']),
                  'search/orange_robust_value':float(info['orange_robust_value']),
                  'search/blue_second_best_value':float(info['blue_second_best_value']),
                  'search/orange_second_best_value':float(info['orange_second_best_value']),
                  'search/opponent_threats':float(len(info['blue_enemy_threat_ids'])),
                  'policy/mean_unique_first_actions':float(np.mean([
                      row['first_action_diversity'] for row in info['candidate_stats'].values()])),
                  'policy/proposal_regret':float((info['blue_top2_prior_regret']+
                      info['orange_top2_prior_regret'])/2),
                  'policy/top2_joint_prior_recall':float((int(info['blue_top2_prior_contains_best'])+
                      int(info['orange_top2_prior_contains_best']))/2),
                  'evaluation/is_pretrained_model':float('pretrained' in info['evaluator'].lower()),
                })
        else:
            observations=None;actions=None;search_metrics=None
        if not sequence_mode:
            responses=int(self.cfg.get('opponent_responses',4))
            opponents=(self.search_budget.opponent_pool() if self.cfg.get('adaptive_search',True)
                       else max(12,min(64,int(self.cfg.get('opponent_candidates',12)))))
            responses=min(responses,opponents)
            ticks=int(self.cfg.get('search_horizon_ticks',16))
            blue=SearchContext(self.rs,our_team=0,team_candidates=budget,opponent_pool=opponents,
                               opponent_responses=responses,ticks=ticks)
            orange=SearchContext(self.rs,our_team=1,team_candidates=budget,opponent_pool=opponents,
                                 opponent_responses=responses,ticks=ticks)
            start_search=time.perf_counter()
            blue_result=blue.search(state,replay_ref=ref,seed=int(self.rng.integers(2**30)))
            orange_result=orange.search(state,replay_ref=ref,seed=int(self.rng.integers(2**30)))
            # Coupled rollout: each team counteracts the OTHER chosen team plan.
            future=blue.rollout(state,blue_result.team_plan,orange_result.team_plan)
            elapsed=max(1e-6,time.perf_counter()-start_search)
            rollouts=blue_result.num_rollouts+orange_result.num_rollouts
            terminated=should_terminate(future['ball'],future['cars'],*ref,mask=state['mask'])
            reward=0. if terminated else replay_score(future['ball'],future['cars'],*ref,mask=state['mask'])
            mode=int(state['mode']);plans=list(blue_result.team_plan)+list(orange_result.team_plan)
            observations=np.stack([make_observation(state,i) for i in range(2*mode)])
            actions=np.asarray([ACTION_TABLE[tuple(a)] for a in plans],dtype=np.int64)
        # Best behavior relative to reference is state-only supervision, not replay buttons.
        self.policy.train()
        obs=self.torch.tensor(observations,device=self.device,dtype=self.torch.float32)
        labels=self.torch.tensor(actions,device=self.device,dtype=self.torch.long)
        loss=self.torch.nn.functional.cross_entropy(self.policy(obs),labels)
        # Hard early deviation: zero replay reward, END THIS iteration without
        # teaching a control action from an off-trajectory counterfactual.
        # Otherwise use a smaller weight for poor but still valid trajectories.
        weight=0.0 if terminated else min(1.0,max(0.25,reward/3.0))
        if not terminated:
            loss=loss*weight
            self.opt.zero_grad(set_to_none=True);loss.backward()
            self.torch.nn.utils.clip_grad_norm_(self.policy.parameters(),1.0)
            self.opt.step();self.step+=1
            if strategy=='opponent_first' and self.chunk_prior is not None:
                # Full chunk targets, unlike flat single-action distillation.
                initial_obs=np.stack([make_observation(state,i)
                    for i in range(2*int(state['mode']))])
                prior_loss=self.chunk_prior.train_from_search(initial_obs,
                    np.asarray(result.plans,dtype=np.int64))
                search_metrics['policy/chunk_prior_train_loss']=float(prior_loss)
                search_metrics['policy/chunk_prior_steps']=float(self.chunk_prior.steps)
        # Do not increase search difficulty merely because tactical counter-
        # attacks deviate from a human replay. Promotion needs match benchmarks.
        if strategy!='opponent_first':
            self.search_budget.observe(not terminated,elapsed,rollouts)
        mean=float(search_metrics['search/robust_score']) if sequence_mode else (blue_result.robust_score+orange_result.robust_score)/2
        self.best_mean=max(self.best_mean,mean)
        metrics={'tracking/reward':reward,'tracking/survival_fraction':0.0 if terminated else 1.0,
                 'tracking/early_termination_rate':1.0 if terminated else 0.0,
                 'policy/distillation_loss':float(loss.detach().item()) if not terminated else 0.}
        if sequence_mode:
            metrics.update(search_metrics)
        else:
            metrics.update({'search/robust_score':mean,'search/rollouts':rollouts,
                    'performance/search_rollouts_per_sec':rollouts/elapsed,
                    'performance/search_seconds':elapsed,
                    'curriculum/search_candidates':budget,'curriculum/search_opponent_pool':opponents,
                    'curriculum/search_stage':self.search_budget.stage,
                    'curriculum/search_early_stop':int(terminated),
                    'curriculum/search_aerial_focused':int(focus)})
        # Never expose randomly initialized weights as a trained controller.
        # A catastrophic mismatch can end an iteration without an optimizer step.
        if self.step == 0:
            if self.logger:self.logger.log(metrics,0)
            return metrics
        # Save the original controller intact before switching its teacher.
        if (self._checkpoint_strategy and self._checkpoint_strategy!=strategy
            and self.path.is_file()):
            previous=self.path.parent/f'v4_pre_{strategy}_controller.pt'
            if not previous.exists():
                safe=previous.with_suffix('.tmp');shutil.copyfile(self.path,safe);safe.replace(previous)
            self._checkpoint_strategy=strategy
        # Preserve old checkpoints (validation-based promotion needs independent matches).
        tmp=self.path.with_suffix('.tmp')
        self.torch.save({'model':self.policy.state_dict(),'optimizer':self.opt.state_dict(),
                         'step':self.step,'best_mean':self.best_mean,
                         'search_budget':self.search_budget.state_dict(),
                         'type':'SEARCH_DISTILLED_ACTION_POLICY_unvalidated',
                         'obs_dim':OBS_DIM,'action_table':ACTIONS,'cfg':self.cfg},tmp)
        tmp.replace(self.path)
        # Preserve bounded historical playable-policy versions so a later
        # regression cannot silently erase every earlier controller. These
        # are NOT called 'best': only independent match evaluation can do that.
        every=max(1,int(self.cfg.get('policy_snapshot_every',10)))
        if self.step % every == 0:
            history=self.path.parent/'v4_action_policy_history'
            history.mkdir(exist_ok=True)
            dest=history/f'step_{self.step:010d}.pt'
            temp=dest.with_suffix('.tmp')
            shutil.copyfile(self.path,temp)
            temp.replace(dest)
            retain=max(1,int(self.cfg.get('policy_snapshot_keep',10)))
            for old in sorted(history.glob('step_*.pt'))[:-retain]:
                old.unlink()
        if self.logger:self.logger.log(metrics,self.step)
        return metrics


def sample_replay(paths,rng):
    if not paths:return None
    p=paths[int(rng.integers(len(paths)))]
    with np.load(p,allow_pickle=False) as file:
        return {key:file[key] for key in file.files}
