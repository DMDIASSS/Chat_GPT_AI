"""Bounded offline pretraining workload ramp and no-update batch throughput probe.

IMPORTANT: optimizer updates/s and examples/s here are not Rocket League
simulator physics steps/s. Pose-validation improvements are NOT gameplay skill.
"""
from __future__ import annotations
from dataclasses import dataclass, asdict
import math
import time


@dataclass
class AdaptiveSchedule:
    min_steps: int = 10
    max_steps: int = 200
    initial_val_loss: float | None = None
    best_val_loss: float | None = None
    stage: int = 0
    stable_evals: int = 0
    evaluations: int = 0
    min_improvement: float = 0.05
    evals_per_stage: int = 3
    # 0.95 ^ stage gives a measurable held-out improvement threshold each stage.

    def __post_init__(self):
        if not 1 <= self.min_steps <= self.max_steps <= 10000:
            raise ValueError('Expected 1 <= min_steps <= max_steps <= 10000')
        if not 1 <= self.evals_per_stage <= 1000:
            raise ValueError('Invalid evaluations-per-stage')
        if not 0 < self.min_improvement < 1:
            raise ValueError('Invalid improvement threshold')

    @classmethod
    def from_config(cls, cfg, state=None):
        fields = {
            'min_steps': int(cfg.get('adaptive_min_steps', 10)),
            'max_steps': int(cfg.get('adaptive_max_steps', 200)),
            'min_improvement': float(cfg.get('adaptive_min_improvement', 0.05)),
            'evals_per_stage': int(cfg.get('adaptive_evals_per_stage', 3)),
        }
        obj = cls(**fields)
        if state:
            for field in ('initial_val_loss', 'best_val_loss', 'stage', 'stable_evals', 'evaluations'):
                if field in state:
                    setattr(obj, field, state[field])
        return obj

    def current_steps(self):
        # Gradually ramp: 10, 15, 22, 33, 49, 74, 111, 167, 200.
        return min(self.max_steps, max(self.min_steps, round(self.min_steps * (1.5 ** self.stage))))

    def observe(self, val_loss, regression=False):
        """Only held-out *pose* loss can release stages; a regression never can."""
        self.evaluations += 1
        if (regression or val_loss is None or not math.isfinite(float(val_loss))
                or float(val_loss) <= 0):
            self.stable_evals = 0
            return self.current_steps()
        val_loss = float(val_loss)
        if self.initial_val_loss is None:
            self.initial_val_loss = val_loss
            self.best_val_loss = val_loss
            self.stable_evals = 0
            return self.current_steps()
        self.best_val_loss = min(self.best_val_loss, val_loss)
        # Need meaningful relative gain AND repeated stable validation, not one lucky batch.
        target = self.initial_val_loss * (1.0 - self.min_improvement) ** (self.stage + 1)
        if self.best_val_loss <= target and val_loss <= self.best_val_loss * 1.02:
            self.stable_evals += 1
            if self.stable_evals >= self.evals_per_stage:
                self.stage += 1
                self.stable_evals = 0
        else:
            self.stable_evals = 0
        return self.current_steps()

    def state_dict(self):
        return asdict(self)


def benchmark_batches(model, sampler, loss_fn, device, candidates, trials=3):
    """Measure forward+backward *without optimizer step*; does not modify weights.

    Synchronize CUDA for valid wall-time measurements. Skip OOM candidates.
    `samples_per_second` measures supervised examples, NOT game tick SPS.
    """
    import torch
    results = []
    if sampler is None:
        return results
    candidates = sorted({int(x) for x in candidates if 1 <= int(x) <= 512})
    for batch in candidates:
        durations = []
        failed = False
        for trial in range(max(2, trials)):
            try:
                obs, target, _, _ = sampler.batch(batch, device)
                model.train()
                model.zero_grad(set_to_none=True)
                if device.type == 'cuda':
                    torch.cuda.synchronize(device)
                t0 = time.perf_counter()
                b, c = model(*obs)
                loss = loss_fn(b, c, *target, obs[-1])
                loss.backward()
                if device.type == 'cuda':
                    torch.cuda.synchronize(device)
                dt = time.perf_counter() - t0
                if trial >= 1:
                    durations.append(max(dt, 1e-9))
            except (RuntimeError, MemoryError) as exc:
                # Invalid kernels/other runtime errors must not be silently relabelled OOM.
                if isinstance(exc, MemoryError) or 'out of memory' in str(exc).lower():
                    failed = True
                    if device.type == 'cuda':
                        torch.cuda.empty_cache()
                    break
                raise
        model.zero_grad(set_to_none=True)
        if not failed and durations:
            avg = sum(durations) / len(durations)
            results.append({'batch': batch, 'updates_per_sec': 1.0 / avg,
                            'samples_per_sec': batch / avg})
    return results


def select_batch(results, default, capacity_fraction=0.97):
    """Pick highest measured samples/s; ties favor smaller batches."""
    if not results:
        return default
    feasible = [r for r in results if r['samples_per_sec'] > 0]
    if not feasible:
        return default
    return min(feasible, key=lambda r: (-r['samples_per_sec'], r['batch']))['batch']
