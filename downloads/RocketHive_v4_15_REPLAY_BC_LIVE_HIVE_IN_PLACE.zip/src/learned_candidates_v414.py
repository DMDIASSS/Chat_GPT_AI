"""Causal, trained-policy candidate proposals for RocketHive's RocketSim search.

Replaces random sequence padding with deterministic beam proposals from the
CURRENT driving network and physically meaningful feasibility checks.  No
future replay poses or recorded controller inputs enter the proposer.

Each controlled car has its own 12..64 proposals, and the search receives at
most the same configured number of JOINT plans per team. This is a bounded
shortlist, NOT a claim that the globally optimal play is among the candidates.
"""
from __future__ import annotations

from dataclasses import dataclass
import math
import numpy as np

from .physics_search import ACTIONS, rotation_axes


@dataclass(frozen=True)
class Proposal:
    actions: tuple[int, ...]
    log_prior: float


def _car_flags(state, player):
    flags = np.asarray(state.get('flags', []), dtype=float)
    if flags.ndim == 2 and player < len(flags) and flags.shape[1] >= 4:
        return flags[player]
    return np.zeros(10, dtype=float)


def _grounded(state, player):
    car=np.asarray(state['cars'][player],float)
    flags=_car_flags(state,player)
    if flags[0]>.5:return True
    # Older replay conversions may have all-zero unknown flags.
    if not np.any(flags) and car[2]<135:return True
    return False


def action_is_feasible(state, player, action_id, sequence=(), ticks=8):
    """Conservative capability mask; the simulator remains the final arbiter.

    Jump-release edges, available flip and initial boost reserves are used.
    Do not substitute another player's hitbox or invent an aerial control state.
    """
    if not 0 <= action_id < len(ACTIONS): return False
    car=np.asarray(state['cars'][player],dtype=float)
    if len(car)<14 or not np.isfinite(car).all():return False
    flags=_car_flags(state,player)
    grounded=_grounded(state,player)
    move=ACTIONS[action_id]
    previous=ACTIONS[sequence[-1]] if sequence else None
    if bool(move[5]):
        if previous is not None and bool(previous[5]):return False
        if not grounded and (flags[2]>.5 or flags[3]>.5):return False
        # An airborne car which hasn't jumped can still have a usable flip
        # (e.g. drove off wall); let RocketSim make that final determination.
    if bool(move[6]):
        spent=sum(bool(ACTIONS[a][6]) for a in sequence)*ticks*33.3/12000.
        if float(car[13])-spent<=0.004:return False
    # Ground-only handbrake is pointless while fully airborne.
    if bool(move[7]) and not grounded:return False
    # Avoid wasting strong air rotational controls while flat on the ground.
    # They become legal immediately following a jump or from wall contact.
    if grounded and not sequence and not bool(move[5]) and action_id in range(11,21):
        if car[2]<140:return False
    return True


def _geometry_bias(state, player):
    """Small *current-state* prior for cold-start and physics plausibility.

    This is not a hand-built goal evaluator. It only improves proposal ranking
    when the learned network has limited training. It never examines replay
    future poses. Scaling is deliberately weak against learned logits.
    """
    car=np.asarray(state['cars'][player],dtype=float)
    ball=np.asarray(state['ball'],dtype=float)
    rel=ball[:3]-car[:3]
    length=max(1.,float(np.linalg.norm(rel)))
    try:
        fw,right,up=rotation_axes(car[3:7]);fw=np.asarray(fw);right=np.asarray(right)
    except (ValueError,TypeError):
        fw=np.array([0.,1.,0.]);right=np.array([1.,0.,0.])
    forward=float(np.dot(fw,rel)/length)
    rightward=float(np.dot(right,rel)/length)
    high=rel[2]>180 or not _grounded(state,player)
    result=np.zeros(len(ACTIONS),dtype=float)
    for i,a in enumerate(ACTIONS):
        if a[0]>0:result[i]+=.20*max(-.7,forward)
        if a[0]<0:result[i]+=.12*max(0.,-forward)
        if abs(a[1])>.1:result[i]+=.20*float(a[1])*rightward
        if bool(a[6]):result[i]+=.10*max(0.,forward)
        if bool(a[5]) and high:result[i]+=.25
        if i in range(11,21) and high:result[i]+=.06
    return result


def _sequence_bias(previous, current, segment, state, player):
    if previous is None:return 0.
    a=ACTIONS[previous];b=ACTIONS[current]
    score=0.
    # Continuous throttle/steering is realistic; avoid frantic oscillation.
    if a[0]==b[0] and a[1]==b[1]:score+=0.11
    if a[1]*b[1]<0:score-=.19
    if a[2]*b[2]<0:score-=.15
    # A jump edge followed by release is a normal takeoff/dodge prerequisite.
    if a[5] and not b[5]:score+=.16
    if a[6] and b[6] and float(state['cars'][player][13])<.07:score-=.14
    return score


class LearnedCandidateProposer:
    """Use trained action logits + deterministic constrained beam search.

    The policy has the SAME observation builder and ACTIONS as RLBot/RLViser.
    No randomness is used, even for untrained networks. 'Exploration' means
    deterministic diverse plausible candidates, not noise-filled input.
    """
    def __init__(self,policy,observation_builder,segments=3,ticks_per_segment=8,
                 diversity=0.65,prior_temperature=1.0):
        if not 1<=int(segments)<=8:raise ValueError('Invalid segments')
        if not 0<float(prior_temperature)<=10:raise ValueError('Invalid temperature')
        self.policy=policy
        self.observation_builder=observation_builder
        self.segments=int(segments)
        self.ticks=int(ticks_per_segment)
        self.diversity=float(diversity)
        self.temperature=float(prior_temperature)
        self.last_stats={}

    def logits_for(self,state):
        import torch
        obs=np.stack([self.observation_builder(state,i)
                      for i in range(len(state['cars']))]).astype(np.float32)
        was_training=bool(self.policy.training)
        try:
            self.policy.eval()
            device=next(self.policy.parameters()).device
            with torch.no_grad():
                result=self.policy(torch.as_tensor(obs,device=device))
            scores=np.asarray(result.detach().cpu().numpy(),dtype=float)
        finally:
            self.policy.train(was_training)
        if scores.shape!=(len(state['cars']),len(ACTIONS)) or not np.isfinite(scores).all():
            raise ValueError('Policy returned wrong/nonfinite action logits')
        scores=np.clip(scores/self.temperature,-80,80)
        scores=scores-scores.max(axis=1,keepdims=True)
        scores=scores-np.log(np.exp(scores).sum(axis=1,keepdims=True))
        return scores

    def propose(self,state,player,count,log_probs=None):
        if not 12<=int(count)<=64:raise ValueError('Proposals must be in [12,64]')
        if log_probs is None:log_probs=self.logits_for(state)
        row=np.asarray(log_probs[player],dtype=float)
        if row.shape!=(len(ACTIONS),) or not np.isfinite(row).all():
            raise ValueError('Policy logits must be finite and cover every action')
        prior=row+_geometry_bias(state,player)
        # Top-K from the neural policy. Keep a wide enough beam to retain
        # alternatives, not only small variations of the top action.
        beam=[((),0.)]
        width=max(128,min(1024,count*12))
        for segment in range(self.segments):
            next_beam=[]
            for seq,value in beam:
                for action in range(len(ACTIONS)):
                    if not action_is_feasible(state,player,action,seq,self.ticks):continue
                    # The first action gets the biggest weight because later
                    # policy calls will replan from REAL subsequent states.
                    temporal_weight=1. if segment==0 else .8
                    s=value+temporal_weight*float(prior[action])
                    s+=_sequence_bias(seq[-1] if seq else None,action,segment,state,player)
                    next_beam.append((seq+(action,),s))
            if not next_beam:raise ValueError('No physically feasible sequences')
            next_beam.sort(key=lambda x:(-x[1],x[0]))
            beam=next_beam[:width]
        # Select a strong but diverse shortlist by maximizing a neural prior
        # while suppressing near-identical sequences. This is deterministic.
        selected=[];remaining=list(beam)
        while remaining and len(selected)<count:
            def key(entry):
                seq,score=entry
                similar=max((sum(a==b for a,b in zip(seq,prior_seq))/self.segments
                             for prior_seq,_ in selected),default=0.)
                first_dup=sum(seq[0]==prev[0] for prev,_ in selected)
                return (score-self.diversity*similar-0.13*first_dup,score,tuple(-a for a in seq))
            winner=max(remaining,key=key)
            remaining.remove(winner);selected.append(winner)
        if len(selected)<count:
            # Widen by deterministically enumerating additional ranked legal
            # sequences only if beam pruning underfilled the shortlist.
            raise ValueError('Cannot form enough distinct feasible candidates')
        proposals=[Proposal(tuple(seq),float(score)) for seq,score in selected]
        self.last_stats[player]={
            'count':len(proposals), 'unique_first_actions':len(set(p.actions[0] for p in proposals)),
            'best_log_prior':proposals[0].log_prior,
            'source':'trained_policy_beam' if getattr(self,'updates',0)>0 else 'cold_start_policy_beam',
        }
        return proposals

    def propose_all(self,state,count):
        logits=self.logits_for(state) # one GPU/CPU batch for all players
        return [self.propose(state,i,count,logits) for i in range(len(state['cars']))]
