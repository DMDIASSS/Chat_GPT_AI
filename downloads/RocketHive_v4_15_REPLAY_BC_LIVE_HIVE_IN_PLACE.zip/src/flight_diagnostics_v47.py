"""Flight diagnostics deliberately distinguish demonstration, controller and replay.

Only *actual* RocketSim state/control samples count toward flight statistics.
No synthetic aerial success is inferred from pose-prediction loss.
"""
from __future__ import annotations
from dataclasses import dataclass, asdict
from pathlib import Path
import json
import math


@dataclass
class FlightStats:
    ticks: int = 0
    jump_ticks: int = 0
    airborne_ticks: int = 0
    boost_airborne_ticks: int = 0
    aerial_control_ticks: int = 0
    max_car_height_uu: float = 0.
    wall_height_ticks: int = 0

    def observe(self, states, controls):
        """Call AFTER the sim stepped, with the controls that were actually used."""
        self.ticks += 1
        for state, control in zip(states, controls):
            z = float(state.pos.z)
            if not math.isfinite(z):
                continue
            self.max_car_height_uu = max(self.max_car_height_uu, z)
            grounded = bool(getattr(state, 'is_on_ground', z < 45))
            airborne = not grounded
            self.jump_ticks += bool(getattr(control, 'jump', False))
            if airborne:
                self.airborne_ticks += 1
                self.boost_airborne_ticks += bool(getattr(control, 'boost', False))
                self.aerial_control_ticks += any(abs(float(getattr(control, axis, 0))) > 0.05
                                                 for axis in ('pitch', 'yaw', 'roll'))
            # High and wheel-contact means likely on a wall/ceiling (not guaranteed).
            if z > 260 and grounded:
                self.wall_height_ticks += 1

    def save(self, path, controller_type, checkpoint=None):
        p = Path(path)
        p.parent.mkdir(parents=True, exist_ok=True)
        info = {'source': controller_type, 'checkpoint': str(checkpoint) if checkpoint else None,
                'note': 'Observed in RocketSim; high z alone does not verify aerial skill or wall control',
                **asdict(self)}
        tmp=p.with_suffix('.tmp')
        tmp.write_text(json.dumps(info, indent=2), encoding='utf-8')
        tmp.replace(p)
        return info


def classify_flight(stats):
    if stats.jump_ticks == 0:
        return 'NO_JUMP_COMMANDS: controller did not request jumps'
    if stats.max_car_height_uu < 130:
        return 'NO_MEANINGFUL_HEIGHT: jumps may fail or launch setup may be invalid'
    if stats.boost_airborne_ticks == 0:
        return 'NO_AIRBOOST: airborne boost has not been observed'
    if stats.aerial_control_ticks == 0:
        return 'NO_AIR_STEERING: no pitch/yaw/roll observed in flight'
    return 'FLIGHT_COMMANDS_OBSERVED: does not prove the bot can hit aerial balls'
