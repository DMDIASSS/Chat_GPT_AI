"""Trainable, explicitly non-pretrained Blue/Orange next-goal evaluator.

Replay labels use Replicar goal events. Positive: next goal in same segment
inside horizon. Negative: a full horizon is observed without a goal, or a goal
is observed after horizon. Censored replay tails are excluded from negatives.
Train/validation must be split by entire replay, never frame. No human inputs.
"""
from __future__ import annotations
import hashlib
import math
from pathlib import Path
import numpy as np
from .search_teacher import OBS_DIM, make_observation, replay_state


def build_value_model():
    import torch
    from torch import nn
    return nn.Sequential(nn.Linear(OBS_DIM,160),nn.LayerNorm(160),nn.SiLU(),
                         nn.Linear(160,160),nn.SiLU(),nn.Linear(160,6))


def next_goal_labels(replay, horizons=(3.,10.)):
    """Return [frames, horizons] 0=no goal, 1=blue, 2=orange; -1=censored."""
    times=np.asarray(replay['time'],dtype=float)
    seg=np.asarray(replay.get('segment',np.zeros(len(times))),dtype=int)
    valid=np.asarray(replay['valid'],dtype=bool)
    goals=np.asarray(replay.get('goal_rows',[]),dtype=int)
    teams=np.asarray(replay.get('goal_teams',[]),dtype=int)
    if len(goals)!=len(teams):raise ValueError('Mismatched goal event arrays')
    if not np.all(np.diff(times)>0):raise ValueError('Replay times must increase')
    if np.any((goals<0)|(goals>=len(times))) or np.any((teams<0)|(teams>1)):
        raise ValueError('Malformed goal events')
    output=np.full((len(times),len(horizons)),-1,dtype=np.int64)
    last_by_segment={}
    for s in np.unique(seg):
        rows=np.flatnonzero((seg==s)&valid)
        if len(rows):last_by_segment[int(s)]=float(times[rows[-1]])
    for i in range(len(times)):
        if not valid[i] or not np.isfinite(times[i]):continue
        relevant=(goals>i)&(seg[goals]==seg[i])
        future=goals[relevant];future_teams=teams[relevant]
        g=int(future[0]) if len(future) else -1
        t=float(times[g]-times[i]) if g>=0 else float('inf')
        for col,h in enumerate(horizons):
            if g>=0 and t<=h:
                output[i,col]=int(future_teams[0])+1
            elif last_by_segment.get(int(seg[i]),times[i])-times[i]>=h:
                # A complete, observed horizon without a goal.
                output[i,col]=0
            elif g>=0 and t>h:
                # Future goal confirms no earlier goal, even with an early clip end.
                output[i,col]=0
    return output


def examples_from_replay(replay, max_frames=128, seed=42):
    labels=next_goal_labels(replay)
    valid=np.flatnonzero((labels>=0).all(axis=1))
    if len(valid)==0:return np.empty((0,OBS_DIM),np.float32),np.empty((0,2),np.int64)
    rng=np.random.default_rng(seed)
    # Stratify positives so sparse-goal data doesn't collapse into 'none'.
    positive=valid[np.any(labels[valid]>0,axis=1)]
    negative=valid[np.all(labels[valid]==0,axis=1)]
    pos_count=min(len(positive),max_frames//2)
    neg_count=min(len(negative),max_frames-pos_count)
    selected=np.concatenate((rng.choice(positive,size=pos_count,replace=False),
                             rng.choice(negative,size=neg_count,replace=False)))
    rng.shuffle(selected)
    obs=[];ys=[]
    for i in selected:
        try:
            state=replay_state(replay,int(i))
            obs.append(make_observation(state,0));ys.append(labels[i])
        except (ValueError,IndexError,KeyError):continue
    if not obs:return np.empty((0,OBS_DIM),np.float32),np.empty((0,2),np.int64)
    return np.asarray(obs,dtype=np.float32),np.asarray(ys,dtype=np.int64)


def load_replay_examples(folder,max_replays=600,frames_per_replay=128,seed=123):
    paths=sorted(Path(folder).glob('*.npz'))[:max_replays]
    xs=[];ys=[];used=0;errors=[]
    for p in paths:
        try:
            with np.load(p,allow_pickle=False) as f:
                if 'goal_rows' not in f or 'goal_teams' not in f:
                    raise ValueError('Replay has no goal-event metadata')
                # Do not treat missing goal arrays as synthetic negative outcomes.
                example={k:f[k] for k in ('time','segment','valid','goal_rows','goal_teams',
                           'cars','ball','mode','hitboxes') if k in f.files}
                if 'car_flags' in f.files:example['car_flags']=f['car_flags']
            # Stable seed per replay so validation is reproducible.
            digest=int(hashlib.sha256(p.name.encode()).hexdigest()[:8],16)
            x,y=examples_from_replay(example,frames_per_replay,seed^digest)
            if len(y):xs.append(x);ys.append(y);used+=1
        except (KeyError,OSError,ValueError,IndexError,TypeError) as exc:
            errors.append((p.name,str(exc)))
    if not xs:return np.empty((0,OBS_DIM),np.float32),np.empty((0,2),np.int64),used,errors
    return np.concatenate(xs),np.concatenate(ys),used,errors


class GoalValueEvaluator:
    """Blue-positive neural value: blended 3s/10s next-goal advantage, NOT win odds."""
    source='replay_trained_next_goal_3s_10s'
    def __init__(self,path='models/v414_goal_value_best.pt',device='cpu'):
        import torch
        self.torch=torch;self.device=torch.device(device)
        ck=torch.load(path,map_location='cpu',weights_only=False)
        if ck.get('type')!='REPLAY_GOAL_VALUE_V414' or ck.get('obs_dim')!=OBS_DIM:
            raise ValueError('Wrong value-head checkpoint architecture')
        if ck.get('horizons') != [3.0,10.0] or ck.get('trained_steps',0)<=0:
            raise ValueError('Value-head checkpoint missing training evidence')
        self.model=build_value_model().to(self.device)
        self.model.load_state_dict(ck['model']);self.model.eval()
        self.checkpoint=str(Path(path).resolve());self.validation_loss=ck.get('best_val_loss')
    def score(self,state):
        import torch
        x=make_observation(state,0)
        with torch.inference_mode():
            logits=self.model(torch.as_tensor(x[None,:],dtype=torch.float32,device=self.device))[0]
            p3=torch.softmax(logits[:3],dim=-1)
            p10=torch.softmax(logits[3:],dim=-1)
            score=0.60*(p3[1]-p3[2])+0.40*(p10[1]-p10[2])
            value=float(score.item())
        if not math.isfinite(value):raise ValueError('Nonfinite goal-value output')
        return max(-1.,min(1.,value))


def fit_value_model(train, val,steps=800,batch_size=128,lr=3e-4,device='cpu',
                    output='models/v414_goal_value_best.pt',seed=47):
    import torch
    if len(train[1])<32 or len(val[1])<16:
        raise ValueError('Insufficient replay-labelled training/validation examples')
    if (np.count_nonzero(np.any(train[1]>0,axis=1))<8 or
        np.count_nonzero(np.any(val[1]>0,axis=1))<4):
        raise ValueError('Insufficient verified goal events in training/validation data. '
                         'Do not train a degenerate all-no-goal evaluator.')
    torch.manual_seed(seed)
    rng=np.random.default_rng(seed)
    net=build_value_model().to(device)
    opt=torch.optim.AdamW(net.parameters(),lr=lr)
    x=torch.as_tensor(train[0],dtype=torch.float32,device=device)
    y=torch.as_tensor(train[1],dtype=torch.long,device=device)
    vx=torch.as_tensor(val[0],dtype=torch.float32,device=device)
    vy=torch.as_tensor(val[1],dtype=torch.long,device=device)
    path=Path(output);path.parent.mkdir(parents=True,exist_ok=True)
    if path.exists():
        ck=torch.load(path,map_location=device,weights_only=False)
        if ck.get('type')!='REPLAY_GOAL_VALUE_V414':
            raise ValueError('Existing value checkpoint is incompatible. Not overwriting.')
        net.load_state_dict(ck['model'])
        if ck.get('optimizer') is not None:opt.load_state_dict(ck['optimizer'])
        completed=int(ck.get('trained_steps',0));best=float(ck.get('best_val_loss',float('inf')))
    else:completed=0;best=float('inf')
    report=[]
    for iteration in range(steps):
        index=torch.as_tensor(rng.integers(len(x),size=min(batch_size,len(x))),device=device)
        net.train();logits=net(x[index]);target=y[index]
        loss=(torch.nn.functional.cross_entropy(logits[:,:3],target[:,0])+ 
              torch.nn.functional.cross_entropy(logits[:,3:],target[:,1]))/2
        if not torch.isfinite(loss):raise RuntimeError('Nonfinite value training loss')
        opt.zero_grad(set_to_none=True);loss.backward()
        torch.nn.utils.clip_grad_norm_(net.parameters(),1.)
        opt.step();completed+=1
        if (iteration+1)%min(100,steps)==0 or iteration==steps-1:
            net.eval()
            with torch.no_grad():
                # Bounded validation batches to limit CPU/GPU peak memory.
                vals=[]
                for i in range(0,len(vx),1024):
                    z=net(vx[i:i+1024]);lab=vy[i:i+1024]
                    vals.append(((torch.nn.functional.cross_entropy(z[:,:3],lab[:,0],reduction='sum')+
                                   torch.nn.functional.cross_entropy(z[:,3:],lab[:,1],reduction='sum'))/2).item())
                vloss=float(sum(vals)/len(vx))
            report.append({'step':completed,'train_loss':float(loss.item()),'val_loss':vloss})
            if vloss<best:
                best=vloss
                ck={'model':net.state_dict(),'optimizer':opt.state_dict(),
                    'type':'REPLAY_GOAL_VALUE_V414','obs_dim':OBS_DIM,
                    'horizons':[3.0,10.0],'trained_steps':completed,
                    'best_val_loss':best,'source':'Replicar goal events from training replays',
                    'model_kind':'next_goal_probability_not_match_win'}
                temp=path.with_suffix('.tmp');torch.save(ck,temp);temp.replace(path)
    return {'steps_total':completed,'best_val_loss':best,'evaluations':report,
            'checkpoint':str(path)}
