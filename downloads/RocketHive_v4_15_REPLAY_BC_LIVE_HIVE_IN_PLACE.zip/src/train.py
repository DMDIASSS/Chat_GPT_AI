"""Train future-pose model with no human action labels and a weak goal-state evaluator.

The CSV goal-event generator uses a strict visible ball goal-line crossing heuristic.
Any resulting value model is labelled PROXY, not a validated chess-engine equivalent.
"""
import json
from pathlib import Path
import random
import time
import numpy as np
import torch
import torch.nn.functional as F
from .models import JointForecaster,StateEvaluator,pose_loss,tensors_from_replay

class ReplaySampler:
    def __init__(self,base,subset,fps,horizon_s,seed, event_probability=0.0):
        self.paths=sorted((Path(base)/subset).glob('*.npz'))
        self.rng=np.random.default_rng(seed)
        self.fps=fps;self.horizon=max(1,round(horizon_s*fps))
        self.memory={};self.order=[];self.available=[]
        self.event_probability=float(event_probability)
        if not 0 <= self.event_probability <= 1:
            raise ValueError('event_probability must be in [0,1]')
        self.focus_indices={};self.focus_counts={};self.focus_selections=0
        for path in self.paths:
            with np.load(path) as r:
                valid=r['valid'];time=r['time']
                # Avoid learning across kickoff, gaps, and missing observations.
                # Reject clips containing *any* invalid intermediate state. Endpoint-only
                # checks accidentally train across missing frames with fabricated values.
                if len(valid) <= self.horizon: continue
                bad = (~np.asarray(valid, dtype=bool)).astype(np.int64)
                invalid_prefix = np.r_[0, np.cumsum(bad)]
                starts = np.flatnonzero(invalid_prefix[self.horizon+1:] ==
                                        invalid_prefix[:-(self.horizon+1)])
                starts=starts[abs((time[starts+self.horizon]-time[starts]) - self.horizon/fps)<0.11]
                if 'segment' in r.files:
                    seg=r['segment']
                    starts=starts[seg[starts]==seg[starts+self.horizon]]
                if len(starts)>0:
                    self.available.append((path,starts))
                    if self.event_probability > 0 and subset == 'train':
                        from .replay_sampling_v44 import event_starts
                        # Read only event metadata and position arrays; no actions.
                        events, counts = event_starts(r, starts, self.horizon)
                        self.focus_indices[str(path)] = events
                        for name, count in counts.items():
                            self.focus_counts[name] = self.focus_counts.get(name,0)+count
    def load(self,p):
        k=str(p)
        if k not in self.memory:
            with np.load(p) as z:self.memory[k]={x:z[x] for x in z.files}
            self.order.append(k)
            if len(self.order)>3:self.memory.pop(self.order.pop(0),None)
        return self.memory[k]
    def batch(self,n,device):
        if not self.available:raise ValueError('No accepted valid replay clips in '+str(self.paths))
        p,idx=self.available[self.rng.integers(len(self.available))]
        r=self.load(p);take=self.rng.choice(idx,size=n,replace=True)
        if self.event_probability > 0 and str(p) in self.focus_indices:
            focus=self.focus_indices[str(p)]
            if len(focus):
                mask=self.rng.random(n)<self.event_probability
                if np.any(mask):
                    take[mask]=self.rng.choice(focus,size=int(mask.sum()),replace=True)
                    self.focus_selections+=int(mask.sum())
        inputs=tensors_from_replay(r,take,device)
        targets=tensors_from_replay(r,take+self.horizon,device)
        return inputs,targets[:2],r,take


def goal_crossings(ball):
    """Very conservative heuristic—not equivalent to parsing actual scoring events.
    Returns time indices of first entrance into a goal volume. Orange scores at -Y.
    """
    p=ball[:,:3]
    inside=(np.abs(p[:,1])>5050)&(np.abs(p[:,0])<880)&(p[:,2]<630)
    first=np.flatnonzero(inside & ~np.r_[False,inside[:-1]])
    # filter duplicates within several seconds, kickoff jumps etc.
    out=[]
    for f in first:
        if out and f-out[-1][0]<90:continue
        out.append((int(f),1 if p[f,1]>0 else 2))  # blue attacks +Y; orange -Y
    return out


def goal_labels(ball,frames,horizon,goal_rows=None,goal_teams=None):
    """0 none, 1 blue scores (+Y), 2 orange scores (-Y)."""
    # Prefer actual Replicar goal events, never infer scoring from ball crossings when available.
    if goal_rows is not None and goal_teams is not None:
        goals=[(int(f),int(t)+1) for f,t in zip(goal_rows,goal_teams)]
    else:
        goals=goal_crossings(ball)
    y=np.zeros(len(frames),dtype='int64')
    for i,f in enumerate(frames):
        future=[(gf,side) for gf,side in goals if f<gf<=f+horizon]
        if future:y[i]=future[0][1]
    return y,goals


def train(base='data',output='models',cfg=None):
    cfg=cfg or {}
    seed=int(cfg.get('seed',42));np.random.seed(seed);random.seed(seed);torch.manual_seed(seed)
    torch.set_num_threads(min(10,torch.get_num_threads()))
    device=torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    print('Training device:',device,flush=True)
    d=int(cfg.get('model_dim',96));n=int(cfg.get('batch_size',96));lr=float(cfg.get('learning_rate',3e-4))
    fps=float(cfg.get('fps',15));look=float(cfg.get('forecast_seconds',0.5333))
    tr=ReplaySampler(base,'train',fps,look,seed)
    va=ReplaySampler(base,'val',fps,look,seed+1)
    if not tr.available:
        raise RuntimeError('No training samples. Read data/parse_report.json and replays/hitboxes.csv.')
    out=Path(output);out.mkdir(parents=True,exist_ok=True)
    model=JointForecaster(d).to(device)
    opt=torch.optim.AdamW(model.parameters(),lr=lr,weight_decay=1e-4)
    steps=int(cfg.get('train_steps',1200))
    save_every=int(cfg.get('save_every',200))
    t0=time.monotonic();log=[]
    for step in range(1,steps+1):
        model.train()
        inputs,targets,_,_=tr.batch(n,device)
        pb,pc=model(*inputs);loss=pose_loss(pb,pc,targets[0],targets[1],inputs[-1])
        opt.zero_grad(set_to_none=True);loss.backward()
        torch.nn.utils.clip_grad_norm_(model.parameters(),1.0);opt.step()
        if step%50==0 or step==1 or step==steps:
            val=None
            if va.available:
                model.eval()
                with torch.no_grad():
                    a,t,_,_=va.batch(n,device)
                    b,c=model(*a);val=float(pose_loss(b,c,t[0],t[1],a[-1]).item())
            rec={'step':step,'train_loss':float(loss.item()),'val_loss':val,'elapsed_s':round(time.monotonic()-t0,2)}
            log.append(rec);print('pose',rec,flush=True)
        if step%save_every==0 or step==steps:
            torch.save({'state_dict':model.state_dict(),'model_dim':d,'fps':fps,'horizon_s':look,
                        'type':'replay_pose_forecaster_NOT_controller','config':cfg},out/'pose_forecaster.pt')
            (out/'pose_training_log.json').write_text(json.dumps(log,indent=2),encoding='utf-8')
    print('Saved',out/'pose_forecaster.pt')
    # Train evaluator only if heuristic goal crossings occur in replays.
    goals_found=0
    for p,_ in tr.available:
        r=tr.load(p);goals_found+=len(r['goal_rows']) if 'goal_rows' in r else len(goal_crossings(r['ball']))
    if goals_found==0:
        print('No goal crossings detected; skipping evaluator to avoid fake labels.')
        return
    value=StateEvaluator(d).to(device);vopt=torch.optim.AdamW(value.parameters(),lr=lr)
    logs=[];nval=int(cfg.get('value_steps',500))
    horizon=int(fps*10)
    for step in range(1,nval+1):
        # Replay-level sampling; 50% of batches target frames near crossings if possible.
        _,_,r,_=tr.batch(1,device)
        positions=np.flatnonzero(r['valid'])
        y_all,goals=goal_labels(r['ball'],np.arange(len(r['ball'])),horizon,
                               r.get('goal_rows'),r.get('goal_teams'))
        positive=positions[y_all[positions]!=0]
        normal=positions[y_all[positions]==0]
        if len(positive) and len(normal):
            takes=np.r_[tr.rng.choice(positive,size=n//2),tr.rng.choice(normal,size=n-n//2)]
        else:takes=tr.rng.choice(positions,size=n)
        b,c,t,h,m=tensors_from_replay(r,takes,device)
        labels=torch.as_tensor(y_all[takes],device=device,dtype=torch.long)
        logits=value(b,c,t,h,m)
        loss=F.cross_entropy(logits,labels)
        vopt.zero_grad(set_to_none=True);loss.backward()
        torch.nn.utils.clip_grad_norm_(value.parameters(),1.0);vopt.step()
        if step%50==0 or step==1 or step==nval:
            rec={'step':step,'train_proxy_goal_loss':float(loss.item()),'positive_goal_events_seen':goals_found}
            logs.append(rec);print('value',rec,flush=True)
    torch.save({'state_dict':value.state_dict(),'model_dim':d,'type':'HEURISTIC_GOAL_EVALUATOR_not_calibrated',
                'label_source':'actual replicar goal events when present; otherwise conservative heuristic' },out/'goal_evaluator_PROXY.pt')
    (out/'value_training_log.json').write_text(json.dumps(logs,indent=2),encoding='utf-8')
    print('Saved evaluator with PROXY label: validate before using as win-probability.')
