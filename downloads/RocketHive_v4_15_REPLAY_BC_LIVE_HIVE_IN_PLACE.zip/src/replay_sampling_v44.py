"""Event-aware sampling WITHOUT taking future controller inputs as labels.

Events are offline clip-selection annotations only: never put future labels in
observations. Starts must have complete, valid trajectory windows in one kickoff
segment. Random mixture ensures ordinary play remains represented.
"""
from __future__ import annotations
import numpy as np


def event_starts(replay, allowed_starts, horizon, radius=15):
    allowed = np.asarray(allowed_starts, dtype=np.int64)
    if not len(allowed):
        return np.empty(0, dtype=np.int64), {}
    n = len(replay['time'])
    classes = {}
    if 'flip_reset_rows' in replay:
        classes['flip_reset'] = np.asarray(replay['flip_reset_rows'], dtype=np.int64)
    if 'goal_rows' in replay:
        classes['goal'] = np.asarray(replay['goal_rows'], dtype=np.int64)
    cars = np.asarray(replay['cars'])
    # Ground truth car positions are used ONLY to select interesting clips.
    valid = np.asarray(replay['valid'], dtype=bool)
    heights = np.max(cars[:, :, 2], axis=1)
    classes['aerial'] = np.flatnonzero(valid & (heights > 400))
    walls = ((np.abs(cars[:, :, 0]) > 3500) |
             (np.abs(cars[:, :, 1]) > 4400)) & (cars[:, :, 2] > 160)
    classes['wall'] = np.flatnonzero(valid & np.any(walls, axis=1))
    flagged = {}
    # A clip qualifies if an event lies within/just after its window.
    for name, frames in classes.items():
        frames = frames[(frames >= 0) & (frames < n)]
        if not len(frames):
            continue
        ranges = np.zeros(n + 1, dtype=np.int32)
        for frame in frames:
            left = max(0, int(frame) - horizon - radius)
            right = min(n, int(frame) + 1)
            ranges[left] += 1
            ranges[right] -= 1
        near = np.cumsum(ranges[:-1]) > 0
        chosen = allowed[near[allowed]]
        if len(chosen):
            flagged[name] = chosen
    if not flagged:
        return np.empty(0, dtype=np.int64), {}
    # Keep category counts (not replicated near-frame samples) visible.
    combined = np.unique(np.concatenate(list(flagged.values())))
    return combined, {name: len(x) for name, x in flagged.items()}
