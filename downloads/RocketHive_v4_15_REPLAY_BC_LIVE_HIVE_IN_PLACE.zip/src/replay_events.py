"""Causal contact/flip-availability signals from Replicar states.

These are **conservative proxies**, not authoritative flip reset labels. The
real physics engine's wheel-touch / dodge-availability flags take precedence.
"""
import numpy as np

def wheel_surface_proxy(car, ball=None):
    """Simple state-only flags for curriculum and event sampling.

    `car` = [xyz, quaternion, vel, angvel, boost]. It cannot reliably
    identify 3-wheel contact; only world height is known. No reward is paid
    for a flip reset unless the simulator confirms it.
    """
    x,y,z=np.asarray(car)[:3]
    return {'airborne_likely':float(z)>160,
            'near_side_wall': abs(float(x))>3880 or abs(float(y))>4900,
            'near_ceiling':float(z)>1940,
            'near_ball': ball is not None and
                         np.linalg.norm(np.asarray(car)[:3]-np.asarray(ball)[:3])<220}

def classify_flip_state(wheels_contact, jump_available=None, dodge_available=None, reset_event=None):
    """No unsupported '3 wheels = reset' assumption.

    Flip resets require appropriate contact/normal and engine dodge flags;
    touching any 3 wheels, including against another car, is not proof.
    """
    if reset_event is True:return 'reset_confirmed'
    if dodge_available is True:return 'flip_available'
    if dodge_available is False:return 'flip_spent'
    if wheels_contact is not None and int(wheels_contact)>=3:return 'contact_unverified'
    return 'unknown'
