"""Per-car RocketSim driving report: explain stalls without guessing from video.

Metrics are collected from PHYSICAL car states and actual controls, not the
replay-forecast model. The JSON includes downsampled time-series, allowing a
human to inspect what happened during the 'boost then stopped' observation.
"""
from __future__ import annotations
from dataclasses import dataclass, field
import json
import math
from pathlib import Path


CONTROL_AXES=('throttle','steer','pitch','yaw','roll','jump','boost','handbrake')


def _as_float(obj, name, default=0.):
    value=getattr(obj,name,default)
    try:return float(value)
    except (ValueError,TypeError):return float(default)


def _xyz(p):
    return tuple(_as_float(p,axis) for axis in ('x','y','z'))


def _distance(a,b):
    return math.sqrt(sum((x-y)**2 for x,y in zip(a,b)))


def _controls(c):
    return tuple(round(_as_float(c,n),2) if n not in ('jump','boost','handbrake')
                 else int(bool(getattr(c,n,False))) for n in CONTROL_AXES)


@dataclass
class _Car:
    frames:int=0
    boost_commands:int=0
    empty_boost_commands:int=0
    jump_commands:int=0
    throttle_commands:int=0
    air_control_commands:int=0
    airborne_frames:int=0
    low_speed_frames:int=0
    ball_near_frames:int=0
    current_low_speed:int=0
    longest_low_speed:int=0
    same_actions:int=0
    longest_same_actions:int=0
    action_changes:int=0
    last_action:tuple|None=None
    initial_boost:float|None=None
    final_boost:float=0.
    boost_collected:float=0.
    boost_spent:float=0.
    max_height:float=0.
    max_speed:float=0.
    distance_travelled:float=0.
    last_pos:tuple|None=None
    samples:list=field(default_factory=list)
    action_counts:dict=field(default_factory=dict)


class BehaviorReport:
    def __init__(self,n_cars,rate=120,sample_every=8):
        if not 1<=n_cars<=6:raise ValueError('n_cars must be 1..6')
        if rate<=0 or sample_every<=0:raise ValueError('invalid timing')
        self.players=[_Car() for _ in range(n_cars)]
        self.rate=float(rate);self.every=int(sample_every)
        self.ticks=0;self.ball_distance=0.;self.ball_first=None;self.ball_last=None
        self.ball_samples=[]
        self.max_ball_speed=0.
        self.kickoff_resets=0

    def mark_kickoff(self):
        self.kickoff_resets+=1
        for p in self.players:
            p.last_pos=None
            p.current_low_speed=0
            p.same_actions=0
            p.last_action=None

    def observe(self, states, controls, ball_state):
        if len(states)!=len(self.players) or len(controls)!=len(self.players):
            raise ValueError('Must record all players at the same tick')
        self.ticks+=1
        ball_pos=_xyz(ball_state.pos)
        ball_vel=_xyz(ball_state.vel)
        ball_speed=math.sqrt(sum(v*v for v in ball_vel))
        self.max_ball_speed=max(self.max_ball_speed,ball_speed)
        if self.ball_first is None:self.ball_first=ball_pos
        if self.ball_last is not None:self.ball_distance+=_distance(ball_pos,self.ball_last)
        self.ball_last=ball_pos
        if self.ticks%self.every==0 and len(self.ball_samples)<3600:
            rotation=getattr(ball_state,'rot_mat',None)
            forward=_xyz(rotation.forward) if rotation is not None else (0.,0.,0.)
            self.ball_samples.append({'t_s':round(self.ticks/self.rate,3),
                                      'pos':[round(x,1) for x in ball_pos],
                                      'vel':[round(x,1) for x in ball_vel],
                                      'angular_vel':[round(x,2) for x in _xyz(getattr(ball_state,'ang_vel',None))],
                                      'forward':[round(x,3) for x in forward]})
        for i,(s,c) in enumerate(zip(states,controls)):
            p=self.players[i];p.frames+=1
            pos=_xyz(s.pos);vel=_xyz(s.vel)
            speed=math.sqrt(sum(v*v for v in vel))
            boost=max(0.,_as_float(s,'boost',0.))
            is_on_ground=bool(getattr(s,'is_on_ground',pos[2]<45))
            ctrl=_controls(c)
            p.action_counts[ctrl]=p.action_counts.get(ctrl,0)+1
            if p.initial_boost is None:p.initial_boost=boost
            p.max_height=max(p.max_height,pos[2]);p.max_speed=max(p.max_speed,speed)
            p.boost_commands+=ctrl[6]
            p.empty_boost_commands+=bool(ctrl[6] and boost<=.5)
            p.jump_commands+=ctrl[5]
            p.throttle_commands+=abs(ctrl[0])>.1
            p.air_control_commands+=(not is_on_ground and any(abs(ctrl[j])>.1 for j in (2,3,4)))
            p.airborne_frames+=not is_on_ground
            p.low_speed_frames+=speed<120
            p.ball_near_frames+=_distance(pos,ball_pos)<240
            if speed<120:
                p.current_low_speed+=1
                p.longest_low_speed=max(p.longest_low_speed,p.current_low_speed)
            else:p.current_low_speed=0
            if p.last_action==ctrl:
                p.same_actions+=1
            else:
                if p.last_action is not None:p.action_changes+=1
                p.same_actions=1
                p.last_action=ctrl
            p.longest_same_actions=max(p.longest_same_actions,p.same_actions)
            if p.last_pos is not None:
                p.distance_travelled+=_distance(pos,p.last_pos)
                # Compare actual deltas only: pickup estimates cannot distinguish
                # all internal boost sources or tiny physics rounding differences.
                delta=boost-p.final_boost
                if delta>1:p.boost_collected+=delta
                elif delta<-.02:p.boost_spent-=delta
            p.final_boost=boost;p.last_pos=pos
            if self.ticks%self.every==0 and len(p.samples)<3600:
                rotation=getattr(s,'rot_mat',None)
                forward=_xyz(rotation.forward) if rotation is not None else (0.,0.,0.)
                p.samples.append({'t_s':round(self.ticks/self.rate,3),
                                  'pos':[round(x,1) for x in pos],
                                  'vel':[round(x,1) for x in vel],
                                  'angular_vel':[round(x,2) for x in _xyz(getattr(s,'ang_vel',None))],
                                  'forward':[round(x,3) for x in forward],
                                  'speed':round(speed,1),'boost':round(boost,2),
                                  'dist_ball':round(_distance(pos,ball_pos),1),
                                  'grounded':is_on_ground,'controls':list(ctrl)})

    @staticmethod
    def _diagnosis(p,rate):
        notes=[]
        if p.frames<1:return ['NO_DATA: no physics frames recorded']
        if p.boost_commands>0 and p.empty_boost_commands/p.boost_commands>.45:
            notes.append('BOOST_WASTED: boost is commanded while tank is empty')
        if p.final_boost<=1 and p.boost_commands>rate*.25:
            notes.append('BOOST_EXHAUSTED: boost was spent and not replenished')
        if p.longest_low_speed/rate>2:
            notes.append('STALL: speed stayed under 120 uu/s for >2 seconds')
        if p.longest_same_actions/rate>2:
            notes.append('REPEATED_ACTION: same control for >2 seconds')
        if p.action_counts and max(p.action_counts.values())/p.frames>.9 and p.frames>rate*3:
            notes.append('ACTION_COLLAPSE: one control dominates over 90% of ticks')
        if p.throttle_commands/max(1,p.frames)<.08 and p.airborne_frames/max(1,p.frames)<.2:
            notes.append('NO_DRIVE_INPUT: throttle is almost never commanded on the ground')
        if p.jump_commands==0:
            notes.append('NO_JUMP: policy never issued jump')
        if p.airborne_frames>rate and p.air_control_commands<rate*.1:
            notes.append('NO_AIR_STEERING: airborne without pitch/yaw/roll')
        if p.ball_near_frames==0:
            notes.append('NO_BALL_APPROACH: never within 240 uu of ball')
        if not notes:notes.append('NO_OBVIOUS_STALL: inspect per-tick samples')
        return notes

    def summary(self, label='trained controller',checkpoint=None):
        return {'schema':'RocketHive_behavior_v4.12','controller':str(label),
                'checkpoint':str(checkpoint) if checkpoint else None,
                'duration_s':round(self.ticks/self.rate,3),
                'physics_ticks':self.ticks, 'kickoff_resets':self.kickoff_resets,
                'ball_travel_uu':round(self.ball_distance,1),
                'max_ball_speed_uu_s':round(self.max_ball_speed,1),
                'ball_samples':self.ball_samples,
                'cars':[
                    {'car_index':i,'team':'blue' if i<len(self.players)//2 else 'orange',
                     'initial_boost':round(p.initial_boost or 0,2),
                     'final_boost':round(p.final_boost,2),
                     'boost_spent_observed':round(p.boost_spent,2),
                     'boost_replenished_observed':round(p.boost_collected,2),
                     'boost_command_pct':round(p.boost_commands/max(1,p.frames)*100,2),
                     'empty_boost_command_pct':round(p.empty_boost_commands/max(1,p.boost_commands)*100,2),
                     'jump_command_ticks':p.jump_commands,
                     'throttle_command_pct':round(p.throttle_commands/max(1,p.frames)*100,2),
                     'air_control_command_ticks':p.air_control_commands,
                     'airborne_s':round(p.airborne_frames/self.rate,2),
                     'longest_low_speed_s':round(p.longest_low_speed/self.rate,2),
                     'longest_identical_action_s':round(p.longest_same_actions/self.rate,2),
                     'action_changes':p.action_changes,
                     'unique_control_combinations':len(p.action_counts),
                     'most_common_action_pct':round(max(p.action_counts.values(),default=0)/max(1,p.frames)*100,2),
                     'max_height_uu':round(p.max_height,1),
                     'max_speed_uu_s':round(p.max_speed,1),
                     'travel_uu':round(p.distance_travelled,1),
                     'ball_near_s':round(p.ball_near_frames/self.rate,2),
                     'diagnosis':self._diagnosis(p,self.rate),
                     'samples':p.samples} for i,p in enumerate(self.players)]}

    def save(self,path,label='trained controller',checkpoint=None):
        dest=Path(path);dest.parent.mkdir(parents=True,exist_ok=True)
        data=self.summary(label,checkpoint)
        tmp=dest.with_suffix(dest.suffix+'.tmp')
        tmp.write_text(json.dumps(data,indent=2,allow_nan=False),encoding='utf-8')
        tmp.replace(dest)
        readable=dest.with_suffix('.txt')
        lines=[f'RocketHive physical-behavior report ({data["duration_s"]} s): {label}',
               f'Checkpoint: {checkpoint or "none"}',
               f'Ball travelled: {data["ball_travel_uu"]} uu']
        for c in data['cars']:
            lines.extend((f'Car {c["car_index"]} ({c["team"]}): boost {c["initial_boost"]:.1f} '
                          f'-> {c["final_boost"]:.1f}, max height {c["max_height_uu"]:.0f} uu, '
                          f'max speed {c["max_speed_uu_s"]:.0f} uu/s',
                          '  '+ ' | '.join(c['diagnosis'])))
        readable.write_text('\n'.join(lines)+'\n',encoding='utf-8')
        return data
