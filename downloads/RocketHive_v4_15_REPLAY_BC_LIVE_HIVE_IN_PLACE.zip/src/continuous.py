"""Indefinite, resumable **offline trajectory/value pretraining** for RocketHive.

This does not by itself train an action-driving RocketChad3 policy. It prepares
state models and training signals without requiring replay controller labels.
"""
from __future__ import annotations
import argparse
import json
import os
from pathlib import Path
import random
import time
import hashlib
import shutil
from datetime import datetime, timezone
import numpy as np
from .checkpoint_v44 import save_atomic, load_latest_valid
from .validation_v44 import FixedValidation
from .best_pose_v46 import (assess_saved_pose_models, champion_record,
                           save_selected_champion, save_json_atomic, manual_signature)
from .system_guard_v44 import enough_space,free_gib
from .telemetry_v44 import append_jsonl

from .ballchasing_sync import BallchasingSync
from .download_worker import DownloadWorker
from .skill_metrics import SkillMetricNames
from .adaptive_training import AdaptiveSchedule, benchmark_batches, select_batch


def report_line(path,values):
    append_jsonl(path,values)


class Logger:
    def __init__(self,project='RocketHive-v4',entity=None,token=None,skill_metrics=None):
        from .wandb_resume_v45 import resolve_binding, RunBindingError
        self.skill_metrics=SkillMetricNames(skill_metrics)
        self.skill_metrics.save_legend('reports/skill_metric_legend.json')
        self.run=None
        if token:
            try:
                import wandb
            except ImportError:
                print('[wandb] not installed; use .venv\\Scripts\\python -m pip install wandb. '
                      'Local JSONL metrics are still available.',flush=True)
            else:
                # Existing encrypted token store supplies the token. No key is written
                # to the project, checkpoint, or saved W&B run binding.
                os.environ['WANDB_API_KEY']=token
                try:
                    binding=resolve_binding(wandb,project,entity)
                    # 'must' ensures an invalid/missing run NEVER produces a fifth run.
                    # Leave existing run config untouched: resuming logging must not
                    # reconfigure or reset the first experiment.
                    self.run=wandb.init(project=binding['project'],entity=binding['entity'],
                                        id=binding['run_id'],resume='must')
                    if str(self.run.id)!=binding['run_id']:
                        raise RunBindingError('W&B returned a different run ID than requested')
                    print('[wandb] resumed existing run:',
                          binding['display_name'] or binding['run_id'],
                          '(id='+binding['run_id']+')',flush=True)
                except Exception as exc:
                    # Safe behavior: continue LOCAL training, keep local telemetry,
                    # never call wandb.init without an established existing run ID.
                    if self.run:
                        try:self.run.finish()
                        except Exception:pass
                    self.run=None
                    print('[wandb] existing-run resume unavailable:',type(exc).__name__,str(exc),flush=True)
                    print('[wandb] local metrics continue. To fix, run BIND_WANDB_RUN.bat '
                          'with the URL for likely-sea-1; no new W&B run created.',flush=True)

    def log(self,info,step):
        report_line('reports/v4_metrics.jsonl',dict(step=step,**info))
        if self.run:
            vals=self.skill_metrics.rename_values(info)
            if any(k.startswith('pose/') for k in info):
                vals[self.skill_metrics.annotated('performance/pose_updates_total')]=float(step)
            if any(k.startswith('policy/') or k.startswith('search/') for k in info):
                vals[self.skill_metrics.annotated('performance/search_updates_total')]=float(step)
            # W&B owns the event step counter when resuming an EXISTING run.
            # The pose model's optimizer step is recorded as an independent metric.
            try:
                self.run.log(vals)
            except Exception as exc:
                # Remote telemetry must not prevent checkpoints and local training.
                print('[wandb] logging failed; disabling remote logging for this session:',
                      type(exc).__name__,str(exc),flush=True)
                try:self.run.finish()
                except Exception:pass
                self.run=None
                print('[wandb] local reports/v4_metrics.jsonl still records every update.',flush=True)

    def close(self):
        if self.run:self.run.finish()


def save_status(step,best,device,info):
    """Small, atomic, secret-free status file for a separate viewer."""
    path=Path('reports/v4_status.json')
    path.parent.mkdir(parents=True,exist_ok=True)
    info={'updated_utc':datetime.now(timezone.utc).isoformat(), 'pose_step':int(step),
          'best_pose_validation_loss':best if best<float('inf') else None,
          'device':str(device), 'metrics':info,
          'note':'Pose prediction throughput is not Rocket League game SPS.'}
    tmp=path.with_suffix('.new')
    tmp.write_text(json.dumps(info,indent=2),encoding='utf-8');tmp.replace(path)


class ContinuousPoseLearner:
    def __init__(self,cfg,device=None,logger=None):
        import torch
        from .models import JointForecaster
        seed=int(cfg.get('seed',42))
        random.seed(seed);np.random.seed(seed);torch.manual_seed(seed)
        torch.set_num_threads(min(4,max(1,os.cpu_count() or 1)))
        self.cfg=cfg;self.torch=torch
        self.device=torch.device(device or ('cuda' if torch.cuda.is_available() else 'cpu'))
        self.model=JointForecaster(int(cfg.get('model_dim',96))).to(self.device)
        self.opt=torch.optim.AdamW(self.model.parameters(),lr=float(cfg.get('learning_rate',3e-4)),weight_decay=1e-4)
        self.logger=logger or Logger()
        self.path=Path('models/v4_pose_resume.pt')
        self.best_path=Path('models/v4_pose_best.pt')
        self.champion_path=Path('models/v4_pose_champion.pt')
        self.champion_step=None
        self._champion_scan_marker=None
        self.path.parent.mkdir(exist_ok=True,parents=True)
        self.step=0;self.best=float('inf');self.sampler=None;self.validation=None
        self.fixed_validation=None;self.cohort_id=None;self.best_cohort_id=None
        self.validation_issue=None
        self.schedule=AdaptiveSchedule.from_config(cfg)
        self.batch_size=int(cfg.get('batch_size',48));self.batch_tuned=False
        has_existing_checkpoint=any(p.exists() for p in (
            self.path, self.path.with_name(self.path.stem+'_previous'+self.path.suffix),
            self.best_path, self.best_path.with_name(self.best_path.stem+'_previous'+self.best_path.suffix),
            self.champion_path, self.champion_path.with_name(self.champion_path.stem+'_previous'+self.champion_path.suffix)))
        ck, recovered, errors=load_latest_valid(torch,self.path,self.best_path,
                     map_location=self.device,expected_type='replay_pose_forecaster_NOT_controller')
        if ck is None and (self.champion_path.exists() or
                           self.champion_path.with_name(self.champion_path.stem+'_previous'+self.champion_path.suffix).exists()):
            alternate, from_path, alt_errors=load_latest_valid(torch,self.champion_path,
                           map_location=self.device,expected_type='replay_pose_forecaster_NOT_controller')
            errors.extend(alt_errors)
            if alternate is not None:ck,recovered=alternate,from_path
        if ck is None and has_existing_checkpoint:
            raise RuntimeError('All existing pose checkpoints are unreadable or incompatible. '
                               'Training stopped WITHOUT overwriting them. Restore a backup.')
        if errors:
            print('[checkpoint] invalid checkpoint(s):', ', '.join(errors),flush=True)
        if ck is not None:
            try:
                self.model.load_state_dict(ck['model']);self.opt.load_state_dict(ck['optimizer'])
            except (KeyError,ValueError,RuntimeError) as exc:
                raise RuntimeError('Checkpoint architecture mismatch; do not overwrite existing models. '
                                   'Review model_dim, files, and README_V4_4.') from exc
            self.step=int(ck.get('step',0));self.best=float(ck.get('best',float('inf')))
            self.best_cohort_id=ck.get('validation_cohort_id')
            self.schedule=AdaptiveSchedule.from_config(cfg,ck.get('adaptive_schedule'))
            self.batch_size=int(ck.get('adaptive_batch_size',self.batch_size))
            self.batch_tuned=bool(ck.get('adaptive_batch_tuned',False))
            print('[resume] restored step',self.step,'from',recovered,flush=True)
            if recovered!=self.path:
                print('[checkpoint] RECOVERY SOURCE:',recovered,
                      'will be saved to latest on the next checkpoint',flush=True)
        print('[training] pose model device:',self.device,flush=True)

    def refresh_replays(self):
        from .train import ReplaySampler
        cfg=self.cfg
        args=('data',float(cfg.get('fps',15)),float(cfg.get('forecast_seconds',0.5333)))
        tr=ReplaySampler(args[0],'train',args[1],args[2],int(cfg.get('seed',42))+self.step,
                         event_probability=float(cfg.get('event_focus_probability',0.25)))
        va=ReplaySampler(args[0],'val',args[1],args[2],int(cfg.get('seed',42))+999)
        self.sampler=tr if tr.available else None
        self.validation=va if va.available else None
        self.validation_issue=None
        if not self.validation:
            self.fixed_validation=None
            self.validation_issue='No valid held-out validation replays in data/val'
        else:
            self.fixed_validation=FixedValidation(va,
                max_replays=int(cfg.get('validation_max_replays',24)),
                frames_per_replay=int(cfg.get('validation_frames_per_replay',16)))
            cohort_file=self.fixed_validation.manifest
            if self.fixed_validation.missing or self.fixed_validation.changed:
                missing=list(self.fixed_validation.missing)
                changed=list(self.fixed_validation.changed)
                # A legacy v1 manifest can become stale when the v4.7 parser
                # rewrites data files. Archive the old manifest FIRST and then
                # evaluate ALL recoverable models on a fresh, fixed cohort.
                # Never silently shrink validation when files have disappeared.
                if (changed and not missing and
                        bool(cfg.get('validation_auto_rebaseline',True))):
                    archive=cohort_file.parent/'validation_cohort_history'
                    archive.mkdir(exist_ok=True,parents=True)
                    raw=cohort_file.read_bytes()
                    digest=hashlib.sha256(raw).hexdigest()[:16]
                    backup=archive/f'cohort_before_rebaseline_{digest}.json'
                    if not backup.exists():
                        shutil.copy2(cohort_file, backup)
                    cohort_file.unlink()
                    self.fixed_validation=FixedValidation(va,manifest=cohort_file,
                        max_replays=int(cfg.get('validation_max_replays',24)),
                        frames_per_replay=int(cfg.get('validation_frames_per_replay',16)))
                    save_json_atomic('reports/v48_validation_rebaseline.json',{
                        'reason':'previous fixed cohort modified after replay conversion',
                        'old_cohort_backup':str(backup),'changed':changed,
                        'new_cohort_manifest':str(cohort_file),
                        'note':'The prior best remains stored; local checkpoints are re-scored on the new cohort.'})
                    print('[validation] repaired stale cohort; previous cohort backed up at',
                          backup, '; saved models will be re-scored on NEW cohort.',flush=True)
                else:
                    self.validation_issue=('Locked cohort has %d missing, %d changed replay(s). '
                        'No model updates until validation is repaired. '
                        'See data/v4_validation_cohort.json.' % (len(missing),len(changed)))
            if cohort_file.exists():
                self.cohort_id=hashlib.sha256(cohort_file.read_bytes()).hexdigest()
            if not self.validation_issue and self.fixed_validation.count:
                marker=(self.cohort_id, manual_signature())
                if marker != self._champion_scan_marker:
                    self.rebaseline_best()
                    self._champion_scan_marker=marker
            elif not self.validation_issue:
                self.validation_issue='Validation has zero valid fixed examples'
            if self.validation_issue:
                print('[validation] PAUSED:',self.validation_issue,flush=True)
                self.fixed_validation=None
                self._champion_scan_marker=None
        return len(tr.available),len(va.available)

    def rebaseline_best(self):
        """Select the strongest locally saved forecaster on ONE fixed cohort.

        W&B run metrics are deliberately NOT used as checkpoint weights or as
        comparable scores from earlier, potentially different validation sets.
        The latest optimizer step remains monotonic even if an older champion
        snapshot's model/optimizer pair is selected for further learning.
        """
        if not self.fixed_validation or not self.fixed_validation.count:
            return
        from .models import JointForecaster, pose_loss
        make=lambda:JointForecaster(int(self.cfg.get('model_dim',96)))
        winner,report=assess_saved_pose_models(
            self.torch,self.fixed_validation,make,pose_loss,self.device,
            self.cohort_id,max_imported=int(self.cfg.get('champion_max_imported',24)))
        save_json_atomic('reports/v4_champion_candidates.json',report)
        save_json_atomic('reports/v4_champion_selection.json',report)
        failed=[c for c in report['candidates'] if not c['ok']]
        if failed:
            print('[champion] excluded',len(failed),'corrupt/incompatible local candidate(s); '
                  'see reports/v4_champion_selection.json',flush=True)
        if winner is None:
            if report['candidates']:
                raise RuntimeError('No valid comparable pose checkpoint. Existing files protected; '
                                   'repair or remove ONLY unusable imports before continuing.')
            # Brand new training installation, nothing yet to compare.
            self.best=float('inf')
            self.best_cohort_id=self.cohort_id
            return
        record=champion_record(winner['checkpoint'],winner['score'],self.cohort_id,
                               winner['path'].as_posix(),current_step=self.step)
        save_selected_champion(self.torch,record)
        self.best=winner['score']
        self.best_cohort_id=self.cohort_id
        self.champion_step=winner['step']
        print('[champion] best LOCAL pose model:',winner['path'],
              'fixed validation loss',round(self.best,7),'at step',winner['step'],flush=True)
        if self.cfg.get('auto_resume_champion',True):
            # Do not substitute an older champion unless a consistent held-out
            # set actually measures it as better than currently loaded weights.
            current_score=self.fixed_validation.evaluate(self.model,pose_loss,self.device)
            margin=max(0.,float(self.cfg.get('champion_resume_min_loss_gap',0.0001)))
            if current_score>self.best+margin:
                self.model.load_state_dict(winner['checkpoint']['model'])
                self.opt.load_state_dict(winner['checkpoint']['optimizer'])
                print('[champion] resumed strongest tested model/optimizer from',winner['path'],
                      '(held-out gain %.6f); global optimizer step remains %d' %
                      (current_score-self.best,self.step),flush=True)

    def tune_batch_once(self):
        if self.batch_tuned or not self.sampler or not self.cfg.get('auto_batch_probe',True):
            return
        from .models import pose_loss
        raw=self.cfg.get('auto_batch_candidates',[24,48,64,96])
        results=benchmark_batches(self.model,self.sampler,pose_loss,self.device,raw)
        self.batch_size=select_batch(results,self.batch_size)
        self.batch_tuned=True
        self.logger.log({'performance/probe_best_samples_per_sec':max((r['samples_per_sec'] for r in results),default=0),
                         'performance/batch_size':self.batch_size}, self.step)
        print('[performance] offline pose batch probe (NOT game SPS):',results,
              'chosen batch',self.batch_size,flush=True)

    def evaluate(self,rounds=4):
        from .models import pose_loss
        if not self.fixed_validation or not self.fixed_validation.count:return None
        # No RNG: identical holdout replay/frame examples every time.
        return self.fixed_validation.evaluate(self.model,pose_loss,self.device,
                                               batch_size=int(self.cfg.get('validation_batch_size',32)))

    def checkpoint(self,metric,save_best=False):
        torch=self.torch
        data={'model':self.model.state_dict(),'optimizer':self.opt.state_dict(),'step':self.step,
              'best':self.best,'type':'replay_pose_forecaster_NOT_controller','cfg':self.cfg,
              'validation_cohort_id':self.cohort_id,
              'adaptive_schedule':self.schedule.state_dict(),
              'adaptive_batch_size':self.batch_size,'adaptive_batch_tuned':self.batch_tuned,
              'validated_loss':metric if save_best else None}
        save_atomic(torch,self.path,data,preserve_previous=True)
        if metric is not None and save_best:
            record=champion_record(data,metric,self.cohort_id,
                                   f'local-training-step-{self.step}',current_step=self.step)
            save_selected_champion(torch,record)
            self.champion_step=self.step
            save_json_atomic('reports/v4_champion_selection.json',{
                'version':1,'purpose':'Offline pose-forecast selection, NOT gameplay skill',
                'validation_cohort_id':self.cohort_id,'best_loss':float(metric),
                'winner':f'local-training-step-{self.step}',
                'source_step':self.step,
                'note':'New lowest loss measured on the same fixed validation cohort.'})

    def train_chunk(self,steps=50):
        from .models import pose_loss
        if not self.sampler:return 0
        if not self.fixed_validation or not self.fixed_validation.count:
            raise RuntimeError('Refusing to train without a valid fixed validation cohort. '
                               'An invalid validation result must not be logged as -1.')
        batch=self.batch_size;train_loss=0.
        t0=time.perf_counter()
        try:
            for _ in range(steps):
                obs,target,_,_=self.sampler.batch(batch,self.device)
                self.model.train();b,c=self.model(*obs)
                loss=pose_loss(b,c,*target,obs[-1])
                if not bool(self.torch.isfinite(loss).item()):
                    raise ValueError('Nonfinite pose-training loss: protecting existing best checkpoint')
                self.opt.zero_grad(set_to_none=True)
                loss.backward();self.torch.nn.utils.clip_grad_norm_(self.model.parameters(),1.0)
                self.opt.step();self.step+=1;train_loss+=float(loss.detach().item())
        except KeyboardInterrupt:
            # Preserve partial work, but never mark it as a new best without evaluation.
            self.checkpoint(None,save_best=False)
            raise
        elapsed=max(time.perf_counter()-t0,1e-9)
        val=self.evaluate()
        regression=False
        tolerance=float(self.cfg.get('regression_tolerance',0.15))
        if val is not None and self.best < float('inf') and val>self.best*(1+tolerance):
            regression=True
            # This rollback is for OFFLINE state-forecast validation only.
            good,good_path,errors=load_latest_valid(self.torch,self.champion_path,self.best_path,
                map_location=self.device,expected_type='replay_pose_forecaster_NOT_controller')
            if good is None:
                raise RuntimeError('Regression detected, but no valid best checkpoint for rollback. '
                                   'Aborting without promoting the regressed model.')
            if errors:print('[rollback] repaired from',good_path,'after',errors,flush=True)
            self.model.load_state_dict(good['model'])
            self.opt.load_state_dict(good['optimizer'])
            for group in self.opt.param_groups:group['lr']*=0.8
        new_best=val is not None and not regression and val<self.best
        if new_best:self.best=val
        self.schedule.observe(val,regression)
        self.checkpoint(val if not regression else None,save_best=new_best)
        info={'pose/train_loss':train_loss/steps,'pose/val_loss':val,
              'pose/best_val_loss':self.best if self.best<float('inf') else None,
              'pose/champion_val_loss':self.best if self.best<float('inf') else None,
              'pose/champion_source_step':self.champion_step,
              'validation/valid':1 if val is not None else 0,
              'pose/regression_rollback':int(regression),
              'performance/pose_updates_per_sec':steps/elapsed,
              'performance/pose_samples_per_sec':steps*batch/elapsed,
              'performance/batch_size':batch,
              'curriculum/pose_stage':self.schedule.stage,
              'curriculum/next_updates_per_chunk':self.schedule.current_steps(),
              'pose/train_replays':len(self.sampler.available),
              'curriculum/event_focused_samples':getattr(self.sampler,'focus_selections',0),
              'validation/fixed_examples':self.fixed_validation.count if self.fixed_validation else 0,
              'pose/val_replays':len(self.validation.available) if self.validation else 0}
        self.logger.log(info,self.step)
        print('[train]',self.step,info,flush=True)
        save_status(self.step,self.best,self.device,info)
        return steps


def run(cfg,ballchasing_token=None,wandb_token=None,stop=None):
    stop=stop or (lambda:False)
    logger=Logger(project=str(cfg.get('wandb_project','RocketHive-v4')),
                  entity=cfg.get('wandb_entity'),token=wandb_token,
                  skill_metrics=cfg.get('wandb_skill_metrics'))
    learner=ContinuousPoseLearner(cfg,logger=logger)
    fetcher=BallchasingSync(ballchasing_token) if ballchasing_token else None
    from .replicar_dataset import parse_folder
    downloader=None
    search_teacher=None
    search_unavailable=False
    search_chunk=0
    match_report_mtime=None
    try:
        # Parse existing (possibly previously downloaded) replays first.
        try:
            parse_folder('replays','data',cfg)
        except Exception as ex:
            print('[parse] unavailable:',type(ex).__name__,str(ex),flush=True)
        try:
            from .data_health_v44 import audit,write_audit
            data_report=audit('data')
            write_audit(data_report)
            print('[data audit]',data_report['train_files'],'train,',
                  data_report['val_files'],'val,',len(data_report['errors']),'errors,',
                  len(data_report['split_source_collisions']),'split leaks',flush=True)
            if not data_report['ok']:
                print('[data audit] WARNING: check reports/v4_data_audit.json; training is paused '
                      'if train/val source overlap exists.',flush=True)
                if data_report['split_source_collisions']:
                    raise RuntimeError('Train/validation replay leakage detected. '
                                       'Resolve split duplicates before training.')
        except ImportError:
            pass
        train_count, val_count = learner.refresh_replays()
        print(f'[training] parsed datasets ready: {train_count} training replay(s), '
              f'{val_count} validation replay(s). Starting offline optimization.', flush=True)
        if fetcher:
            downloader = DownloadWorker(fetcher,
                max_new=int(cfg.get('max_download_per_pass',12)),
                max_pages=3,
                idle_seconds=float(cfg.get('download_idle_seconds',1800)),
                min_disk_free_gib=float(cfg.get('min_disk_free_gib',2.0))).start()
            print('[download] SSL discovery started in background; it will not block training.',flush=True)
        while not stop():
            match_meta=Path('models/best_playing_controller.evaluation.json')
            if match_meta.exists():
                stamp=match_meta.stat().st_mtime_ns
                if stamp!=match_report_mtime:
                    match_report_mtime=stamp
                    try:
                        match_result=json.loads(match_meta.read_text(encoding='utf-8'))
                        if match_result.get('total',0)>0:
                            logger.log({'evaluation/win_rate':match_result['win_fraction'],
                                        'evaluation/head_to_head_lower_bound':match_result['wilson_lower'],
                                        'evaluation/match_count':match_result['total']},learner.step)
                    except (KeyError,ValueError,OSError) as exc:
                        print('[match stats] invalid external report:',exc,flush=True)
            if not enough_space('.', cfg.get('min_disk_free_gib',2.0)):
                print('[training] disk free %.2f GiB: pausing to protect checkpoints. '
                      'Free space and training will resume automatically.' % free_gib('.'),flush=True)
                time.sleep(30)
                continue
            if downloader:
                downloaded_now=downloader.drain()
                if downloaded_now:
                    logger.log({'replays/downloaded_total':fetcher.state['downloaded'],
                                'replays/downloaded_pass':downloaded_now}, learner.step)
                    try:
                        parse_folder('replays','data',cfg)
                        learner.refresh_replays()
                    except Exception as ex:
                        print('[parse] new replay conversion error:',type(ex).__name__,str(ex),flush=True)
            if learner.sampler and learner.fixed_validation is None:
                print('[validation] training PAUSED, not emitting fake -1 loss:',
                      learner.validation_issue or 'No fixed validation',flush=True)
                report_line('reports/v48_validation_status.jsonl',{
                    'step':learner.step,'valid':False,
                    'reason':learner.validation_issue or 'No fixed validation'})
                time.sleep(30)
                learner.refresh_replays()
                continue
            if learner.sampler:
                learner.tune_batch_once()
                learner.train_chunk(learner.schedule.current_steps() if cfg.get('adaptive_training',True)
                                    else int(cfg.get('steps_per_chunk',50)))
                search_chunk+=1
                if (cfg.get('enable_search_teacher',True) and not search_unavailable and
                    search_chunk%max(1,int(cfg.get('search_teacher_every_chunks',4)))==0):
                    print('[search_teacher] starting physics-search controller update. '
                          'First checkpoint is written only after a real optimizer update.',flush=True)
                    try:
                        from .search_teacher import PhysicsSearchTeacher, sample_replay
                        if search_teacher is None:
                            search_teacher=PhysicsSearchTeacher(cfg,logger=logger)
                            print('[search_teacher] RocketSim loaded; examining replay starts',flush=True)
                        paths=[path for path,_ in learner.sampler.available]
                        for _ in range(max(1,min(4,int(cfg.get('worlds',2))))):
                            replay=sample_replay(paths,search_teacher.rng)
                            if replay is None:break
                            metrics=search_teacher.train_replay(replay)
                            if metrics:print('[search_teacher]',metrics,flush=True)
                            else:print('[search_teacher] no matching replay start in selected replay; '
                                       'controller has NOT updated',flush=True)
                    except (ImportError,RuntimeError,FileNotFoundError,AttributeError,ValueError) as ex:
                        # A single unsupported replay hitbox or invalid frame must
                        # not disable physics search for every future replay.
                        # Only an unavailable simulator at initialization is global.
                        if search_teacher is None:
                            print('[search_teacher] initialization unavailable:',
                                  type(ex).__name__,str(ex),flush=True)
                            search_unavailable=True
                        else:
                            print('[search_teacher] skipped failed replay search; will retry '
                                  'with another replay:',type(ex).__name__,str(ex),flush=True)
                # Discover new externally converted files between chunks.
                if learner.step%max(50,int(cfg.get('rescan_every',500)))<int(cfg.get('steps_per_chunk',50)):
                    learner.refresh_replays()
            else:
                print('[training] no parsed train split; looking for more replays.',flush=True)
                time.sleep(15)
    except KeyboardInterrupt:
        print('[training] manually stopped; resume checkpoint preserved.',flush=True)
    finally:
        if search_teacher is not None:
            search_teacher.close()
        if downloader:
            downloader.stop()
        logger.close()


def main():
    a=argparse.ArgumentParser(description='Indefinite offline replay pretrainer; Ctrl+C stops')
    a.add_argument('--config',default='config_v4.json')
    a.add_argument('--no-popup',action='store_true')
    opt=a.parse_args()
    cfg=json.loads(Path(opt.config).read_text(encoding='utf-8'))
    ball=os.environ.get('BALLCHASING_TOKEN','')
    wandb=os.environ.get('WANDB_API_KEY','')
    from tools.credentials_popup import resolve_tokens
    ball,wandb=resolve_tokens(ball,wandb,no_popup=opt.no_popup)
    run(cfg,ball,wandb)

if __name__=='__main__':main()
