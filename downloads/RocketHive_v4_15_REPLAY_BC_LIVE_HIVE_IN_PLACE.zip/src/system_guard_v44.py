"""Pause destructive growth before filling a user's drive. No auto-deletion."""
from __future__ import annotations
import shutil
from pathlib import Path


def free_gib(path='.', usage=shutil.disk_usage):
    path = Path(path)
    while not path.exists() and path != path.parent:
        path = path.parent
    return usage(path).free / 1024**3


def enough_space(path='.', reserve_gib=2.0, usage=shutil.disk_usage):
    reserve = float(reserve_gib)
    if reserve < 0 or reserve > 10_000:
        raise ValueError('min_disk_free_gib must be between 0 and 10000')
    return free_gib(path, usage) >= reserve
