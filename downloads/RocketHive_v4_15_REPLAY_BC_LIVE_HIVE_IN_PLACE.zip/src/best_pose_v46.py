"""Compare *local, trusted* pose checkpoints on one immutable validation cohort.

A W&B run is telemetry, not a model. Never reconstruct model weights from a
historical W&B chart. Existing archived checkpoints may be placed manually in
models/pose_candidates. This module does NOT download/execute remote models.

Only pose forecasters are evaluated here. Playing-policy champions are guarded
separately by the real-match evaluation gate in policy_gate_v44.py.
"""
from __future__ import annotations

from datetime import datetime, timezone
import json
import math
import os
import pickle
from pathlib import Path

from .checkpoint_v44 import save_atomic

POSE_TYPE = 'replay_pose_forecaster_NOT_controller'


def candidate_paths(models_dir='models', max_imported=24):
    root = Path(models_dir)
    names = ('v4_pose_resume.pt', 'v4_pose_resume_previous.pt',
             'v4_pose_best.pt', 'v4_pose_best_previous.pt',
             'v4_pose_champion.pt', 'v4_pose_champion_previous.pt')
    direct = [root / n for n in names if (root / n).is_file()]
    manual = root / 'pose_candidates'
    if manual.is_dir():
        files = [p for p in sorted(manual.glob('*.pt')) if p.is_file() and not p.is_symlink()]
        direct.extend(files[:max(0, int(max_imported))])
    # No symlinks or recursive traversal, only expected files.
    return [p for p in direct if not p.is_symlink()]


def manual_signature(models_dir='models'):
    """Detect newly imported checkpoint candidates without rescoring every chunk."""
    manual = Path(models_dir) / 'pose_candidates'
    if not manual.is_dir():
        return ()
    out = []
    for p in sorted(manual.glob('*.pt')):
        try:
            if not p.is_file() or p.is_symlink():continue
            stat = p.stat()
            out.append((p.name, stat.st_size, stat.st_mtime_ns))
        except OSError:
            # A file may be replaced by the user during an active run.
            continue
    return tuple(out)


def _load_local(torch, path):
    # Only tensor/primitive data may be loaded, including from manually imported
    # local checkpoints. Legacy pickle-only checkpoints are rejected here.
    ck = torch.load(path, map_location='cpu', weights_only=True)
    if not isinstance(ck, dict) or ck.get('type') != POSE_TYPE:
        raise ValueError('not a RocketHive pose checkpoint')
    if not isinstance(ck.get('model'), dict) or not isinstance(ck.get('optimizer'), dict):
        raise ValueError('checkpoint missing model/optimizer')
    return ck


def assess_saved_pose_models(torch, validation, model_factory, loss_fn, device,
                             cohort_id, models_dir='models', max_imported=24):
    """Return (winner, report). Scores are comparable ONLY within this cohort.

    Winner contains original checkpoint bytes as loaded in-memory; caller
    decides whether to promote. A bad candidate never stops other candidates.
    If ALL candidates are invalid, caller must fail closed, not overwrite them.
    """
    if not cohort_id or validation is None or not validation.count:
        raise ValueError('A complete fixed validation cohort is required')
    if validation.missing or validation.changed:
        raise ValueError('Validation cohort changed; no automatic model promotion')
    winner = None
    rows = []
    for path in candidate_paths(models_dir, max_imported):
        row = {'file': path.as_posix()}
        try:
            ck = _load_local(torch, path)
            model = model_factory().to(device)
            model.load_state_dict(ck['model'], strict=True)
            score = validation.evaluate(model, loss_fn, device)
            if score is None or not math.isfinite(float(score)):
                raise ValueError('non-finite validation score')
            score = float(score)
            row.update(ok=True, loss=score, step=int(ck.get('step', 0)),
                       old_cohort=ck.get('validation_cohort_id'))
            # Stable tie-breaking favors the higher step, then path order.
            if winner is None or (score, -row['step']) < (winner['score'], -winner['step']):
                winner = {'path': path, 'score': score, 'step': row['step'], 'checkpoint': ck}
        except (OSError, RuntimeError, ValueError, TypeError, KeyError, EOFError, IndexError,
                AttributeError, ImportError, pickle.UnpicklingError) as exc:
            row.update(ok=False, reason=f'{type(exc).__name__}: {exc}'[:240])
        finally:
            if 'model' in locals():
                del model
        rows.append(row)
    return winner, {
        'version': 1,
        'purpose': 'Offline pose-forecast selection, NOT game-playing skill',
        'evaluated_utc': datetime.now(timezone.utc).isoformat(),
        'validation_cohort_id': cohort_id,
        'fixed_examples': int(validation.count),
        'winner': winner['path'].as_posix() if winner else None,
        'best_loss': winner['score'] if winner else None,
        'candidates': rows,
        'note': 'Scores from different W&B runs are NOT directly comparable unless recalculated on this exact cohort.',
    }


def save_json_atomic(path, data):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    temp = path.with_name(path.name + '.new')
    try:
        with temp.open('w', encoding='utf-8') as f:
            json.dump(data, f, indent=2, ensure_ascii=False)
            f.write('\n')
            f.flush()
            os.fsync(f.fileno())
        temp.replace(path)
    finally:
        temp.unlink(missing_ok=True)


def champion_record(ck, score, cohort_id, source, *, current_step=None):
    """Create a checkpoint ready to save without touching original file."""
    data = dict(ck)
    data['best'] = float(score)
    data['validated_loss'] = float(score)
    data['validation_cohort_id'] = cohort_id
    data['champion_origin'] = str(source)
    data['champion_source_step'] = int(ck.get('step', 0))
    # Keep optimizer history with the original model. The global step counter
    # is updated separately on resume to keep W&B/learning progress monotonic.
    if current_step is not None:
        data['selected_at_optimizer_step'] = int(current_step)
    return data


def _already_same_selection(torch, path, data):
    """Avoid rotating a useful recovery copy on every identical restart."""
    if not path.is_file():
        return False
    try:
        old = _load_local(torch, path)
        if (old.get('validation_cohort_id') != data.get('validation_cohort_id')
            or old.get('step') != data.get('step')
            or old.get('best') != data.get('best')):
            return False
        old_weights, new_weights = old['model'], data['model']
        return (old_weights.keys() == new_weights.keys() and
                all(torch.equal(old_weights[key].cpu(), new_weights[key].cpu())
                    for key in old_weights))
    except (OSError, ValueError, RuntimeError, TypeError, EOFError, pickle.UnpicklingError):
        return False


def save_selected_champion(torch, data, *, models_dir='models', write_best=True):
    """Atomically preserve champion and best, rotating only when they differ."""
    root = Path(models_dir)
    for path in (root / 'v4_pose_champion.pt', root / 'v4_pose_best.pt'):
        if path.name == 'v4_pose_best.pt' and not write_best:
            continue
        if not _already_same_selection(torch, path, data):
            save_atomic(torch, path, data, preserve_previous=True)
