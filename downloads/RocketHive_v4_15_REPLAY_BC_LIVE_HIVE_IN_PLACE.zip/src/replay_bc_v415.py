"""Replay-only RVQ chunk imitation and discounted next-goal value.

The four learned residual codebooks (64 entries each) are NOT pretrained.
No search actions, simulated self-play labels, or live opponent commands enter
training. Inferred Replicar controls are labelled as reconstructed, not recorded.
"""
from pathlib import Path
import math
import numpy as np
import torch
from torch import nn
from .search_teacher import OBS_DIM,make_observation

CHUNK=32;LEVELS=4;CODES=64

class ChunkCodec(nn.Module):
    def __init__(self):
        super().__init__();self.encoder=nn.Sequential(nn.Linear(256,256),nn.SiLU(),nn.Linear(256,64))
        self.books=nn.Parameter(torch.randn(4,64,64)*.02)
        self.decoder=nn.Sequential(nn.Linear(64,256),nn.SiLU(),nn.Linear(256,256))
    def encode(self,actions):
        z=self.encoder(actions.flatten(1));residual=z;quant=torch.zeros_like(z);ids=[];loss=z.sum()*0
        for k in range(4):
            distance=(residual[:,None,:]-self.books[k][None,:,:]).square().mean(-1);idx=distance.argmin(-1);e=self.books[k][idx]
            loss=loss+(e-residual.detach()).square().mean()+.25*(residual-e.detach()).square().mean()
            quant=quant+e;residual=residual-e.detach();ids.append(idx)
        return z+(quant-z).detach(),torch.stack(ids,1),loss
    def decode(self,ids):
        z=sum(self.books[k][ids[:,k]] for k in range(4));return self.decoder(z).reshape(-1,32,8)
    def forward(self,x):
        z,ids,loss=self.encode(x);return self.decoder(z).reshape(-1,32,8),ids,loss
    def initialize(self,x):
        with torch.no_grad():
            residual=self.encoder(x.flatten(1))
            for k in range(4):
                idx=torch.arange(64,device=x.device)%len(x);self.books[k].copy_(residual[idx])
                nearest=(residual[:,None]-self.books[k][None]).square().mean(-1).argmin(-1)
                residual=residual-self.books[k][nearest]

def reconstruction_loss(raw,target):
    axes=(torch.tanh(raw[:,:,:5])-target[:,:,:5]).square().mean()
    buttons=torch.nn.functional.binary_cross_entropy_with_logits(raw[:,:,5:],target[:,:,5:],reduction='none')
    return axes+(buttons*raw.new_tensor([4.,2.,1.5])).mean()

def controls(raw,offset=None):
    axes=torch.tanh(raw[:,:,:5])
    if offset is not None:axes=(axes+.1*torch.tanh(offset)).clamp(-1,1)
    return torch.cat((axes,(raw[:,:,5:]>0).float()),-1)

class ReplayPolicy(nn.Module):
    def __init__(self):
        super().__init__();self.trunk=nn.Sequential(nn.Linear(OBS_DIM,192),nn.LayerNorm(192),nn.SiLU(),nn.Linear(192,192),nn.SiLU())
        self.embed=nn.Embedding(65,32);self.cell=nn.GRUCell(224,192);self.code=nn.Linear(192,64)
        self.offset=nn.Linear(192,32*5);self.value=nn.Linear(192,1)
    def code_logits(self,x,prefix):
        rep=self.trunk(x);h=rep
        for k in range(prefix.shape[1]+1):
            prev=prefix[:,k-1] if k else torch.full((len(x),),64,dtype=torch.long,device=x.device)
            h=self.cell(torch.cat((rep,self.embed(prev)),-1),h)
        return self.code(h)
    def teacher_logits(self,x,ids):return torch.stack([self.code_logits(x,ids[:,:k]) for k in range(4)],1)
    def heads(self,x):
        h=self.trunk(x);return self.offset(h).reshape(-1,32,5),torch.tanh(self.value(h)).flatten()

class ReplayBrain:
    def __init__(self,path='models/v415_replay_brain.pt'):
        self.path=str(Path(path).resolve());ck=torch.load(path,map_location='cpu',weights_only=True)
        if ck.get('type')!='REPLAY_RVQ_BC_V415' or ck.get('obs_dim')!=OBS_DIM or ck.get('policy_steps',0)<1 or ck.get('codec_steps',0)<1:raise ValueError('Not a trained replay RVQ/value checkpoint')
        
        if not ck.get('health_ready',False):raise ValueError('Replay brain failed code-diversity/jump reconstruction checks; inspect reports/v415_bc_metrics.jsonl before deployment')
        self.net=ReplayPolicy().eval();self.codec=ChunkCodec().eval();self.net.load_state_dict(ck['policy']);self.codec.load_state_dict(ck['codec'])
        self.source='reconstructed_replay_RVQ_BC_value';self.validation=ck.get('validation',{})
    @torch.inference_mode()
    def modal(self,states):
        obs=np.stack([make_observation(s,i) for s in states for i in range(len(s['cars']))]);x=torch.as_tensor(obs,dtype=torch.float32)
        rep=self.net.trunk(x);h=rep;previous=torch.full((len(x),),64,dtype=torch.long);ids=[]
        for _ in range(4):
            h=self.net.cell(torch.cat((rep,self.net.embed(previous)),-1),h);previous=self.net.code(h).argmax(-1);ids.append(previous)
        ids=torch.stack(ids,1);offset=self.net.offset(rep).reshape(-1,32,5)
        out=controls(self.codec.decode(ids),offset).numpy();n=len(states[0]['cars'])
        return out.reshape(len(states),n,32,8)
    @torch.inference_mode()
    def propose_team(self,state,team,count):
        """Deterministic ranked autoregressive codes, diverse first-code paths."""
        mode=int(state['mode']);all_plans=[]
        for player in range(team*mode,(team+1)*mode):
            x=torch.as_tensor(make_observation(state,player)[None],dtype=torch.float32)
            rep=self.net.trunk(x);h=rep;previous=torch.full((1,),64,dtype=torch.long);beam=torch.empty((1,0),dtype=torch.long);scores=torch.zeros(1)
            for level in range(4):
                h=self.net.cell(torch.cat((rep.expand(len(h),-1),self.net.embed(previous)),-1),h)
                logp=torch.log_softmax(self.net.code(h),-1)
                flat=(scores[:,None]+logp).flatten();limit=min(count*2,len(flat));picked=flat.topk(limit).indices
                parent=picked//64;previous=picked%64;beam=torch.cat((beam[parent],previous[:,None]),1);scores=flat[picked];h=h[parent]
            ids=beam[:count];offset=self.net.offset(rep).reshape(-1,32,5).expand(len(ids),-1,-1)
            all_plans.append(controls(self.codec.decode(ids),offset).numpy())
        result=[np.stack([all_plans[j][(k+3*j)%count if k else 0] for j in range(mode)]) for k in range(count)]
        result[0]=self.modal([state])[0][team*mode:(team+1)*mode]
        return result
    @torch.inference_mode()
    def team_values(self,states,team):
        mode=int(states[0]['mode']);x=torch.as_tensor(np.stack([make_observation(s,team*mode+j) for s in states for j in range(mode)]),dtype=torch.float32)
        return self.net.heads(x)[1].reshape(len(states),mode).mean(-1).numpy()
