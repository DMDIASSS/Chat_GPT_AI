"""OS-level advisory lock: one action-policy trainer per RocketHive directory.

Different from a PID-file sentinel: a crash automatically releases the lock.
Keep the lock outside the project folder, including its backup ZIPs.
"""
import hashlib
import os
from pathlib import Path
import tempfile


class ControllerProcessLock:
    def __init__(self,checkpoint):
        identifier=hashlib.sha256(str(Path(checkpoint).resolve()).encode('utf-8')).hexdigest()[:22]
        self.path=Path(tempfile.gettempdir())/('rockethive-action-'+identifier+'.lock')
        self.stream=self.path.open('a+b')
        self.stream.seek(0,2)
        if self.stream.tell()==0:
            self.stream.write(b'0');self.stream.flush()
        self.stream.seek(0)
        self.held=False
        try:
            if os.name=='nt':
                import msvcrt
                msvcrt.locking(self.stream.fileno(),msvcrt.LK_NBLCK,1)
            else:
                import fcntl
                fcntl.flock(self.stream.fileno(),fcntl.LOCK_EX | fcntl.LOCK_NB)
            self.held=True
        except OSError as exc:
            self.stream.close()
            raise RuntimeError('Another RocketHive action controller trainer is active. '
                               'Stop START_V4.bat before launching TRAIN_ACTION_CONTROLLER.bat '
                               '(or vice versa).') from exc

    def close(self):
        if self.held:
            try:
                self.stream.seek(0)
                if os.name=='nt':
                    import msvcrt
                    msvcrt.locking(self.stream.fileno(),msvcrt.LK_UNLCK,1)
                else:
                    import fcntl
                    fcntl.flock(self.stream.fileno(),fcntl.LOCK_UN)
            finally:
                self.held=False
                self.stream.close()

    def __del__(self):
        if self.held:
            try:self.close()
            except Exception:pass
