"""Safe binding of an existing W&B run across RocketHive restarts.

The run *display name* is not its ID.  Resolve ``likely-sea-1`` through the
authenticated public API once, persist only non-secret identifiers, and always
use ``resume='must'``.  On failed discovery we deliberately disable remote
logging rather than create another run.
"""
from __future__ import annotations

import json
import os
from pathlib import Path
import re
from urllib.parse import urlsplit

DEFAULT_TARGET_NAME = 'likely-sea-1'
BINDING_FILE = Path('reports/wandb_run_binding.json')
_RUN_ID = re.compile(r'^[A-Za-z0-9_-]{4,64}$')
_ENTITY_PROJECT = re.compile(r'^[A-Za-z0-9_.-]{1,128}$')


class RunBindingError(RuntimeError):
    pass


def _validate(binding):
    if not isinstance(binding, dict):
        raise RunBindingError('Invalid W&B binding: expected JSON object')
    result = {key: str(binding.get(key, '')) for key in ('entity', 'project', 'run_id', 'display_name')}
    if not _RUN_ID.fullmatch(result['run_id']):
        raise RunBindingError('Missing or invalid W&B run_id')
    for field in ('entity', 'project'):
        if not _ENTITY_PROJECT.fullmatch(result[field]):
            raise RunBindingError(f'Invalid W&B {field}')
    return result


def load_binding(path=BINDING_FILE):
    path = Path(path)
    if not path.is_file():
        return None
    try:
        return _validate(json.loads(path.read_text(encoding='utf-8')))
    except (OSError, ValueError, TypeError, RunBindingError) as ex:
        raise RunBindingError(f'Cannot read {path}: {ex}') from ex


def save_binding(binding, path=BINDING_FILE):
    """Atomically write the non-secret run ID (never W&B API tokens)."""
    binding = _validate(binding)
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_name(path.name + '.new')
    try:
        with open(tmp, 'w', encoding='utf-8') as f:
            json.dump(binding, f, indent=2)
            f.write('\n')
            f.flush()
            os.fsync(f.fileno())
        os.replace(tmp, path)
    finally:
        if tmp.exists():
            tmp.unlink()
    return binding


def binding_from_url(url, expected_project=None):
    parsed = urlsplit(url.strip())
    if parsed.scheme != 'https' or parsed.hostname not in ('wandb.ai', 'www.wandb.ai'):
        raise RunBindingError('Paste an HTTPS W&B run URL, e.g. https://wandb.ai/USER/PROJECT/runs/RUN_ID')
    chunks = [c for c in parsed.path.strip('/').split('/') if c]
    if len(chunks) != 4 or chunks[2] != 'runs':
        raise RunBindingError('The URL must point to a single run: /ENTITY/PROJECT/runs/RUN_ID')
    bound = _validate({'entity': chunks[0], 'project': chunks[1],
                       'run_id': chunks[3], 'display_name': DEFAULT_TARGET_NAME})
    if expected_project and bound['project'] != expected_project:
        raise RunBindingError(f'URL project {bound["project"]!r} does not match configured '
                              f'project {expected_project!r}. Check the URL and config_v4.json.')
    return bound


def discover_named_run(wandb_module, project, entity=None, name=DEFAULT_TARGET_NAME):
    """Find exactly one existing display name; never create new runs."""
    api = wandb_module.Api(timeout=15)
    resolved_entity = entity or api.default_entity
    if not resolved_entity:
        raise RunBindingError('No W&B default entity. Set wandb_entity in config_v4.json '
                              'or use BIND_WANDB_RUN.bat with the run URL.')
    matches = [r for r in api.runs(f'{resolved_entity}/{project}',
                                  filters={'display_name': name}, per_page=50)
               if getattr(r, 'name', None) == name]
    if len(matches) != 1:
        raise RunBindingError(f'Expected exactly one {name!r} in '
                              f'{resolved_entity}/{project}, found {len(matches)}. '
                              'Use BIND_WANDB_RUN.bat with the exact URL.')
    return _validate({'entity': resolved_entity, 'project': project,
                      'run_id': matches[0].id, 'display_name': name})


def resolve_binding(wandb_module, project, entity=None, target_name=DEFAULT_TARGET_NAME,
                    path=BINDING_FILE):
    existing = load_binding(path)
    if existing is not None:
        if existing['project'] != project or (entity and existing['entity'] != entity):
            raise RunBindingError('Saved W&B run belongs to a different project/entity. '
                                  'Use BIND_WANDB_RUN.bat to bind the intended run.')
        return existing
    discovered = discover_named_run(wandb_module, project, entity, target_name)
    return save_binding(discovered, path)
