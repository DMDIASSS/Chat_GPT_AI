"""Explicit head-to-head evidence gate for promoting an action-controller snapshot.

This does NOT run matches. Results must come from independently run matches
(e.g., local RLBot/RocketSim tournament script) and are still only as trustworthy
as their source. It refuses to derive 'best bot' from pose loss or search reward.
"""
from __future__ import annotations
from collections import Counter
import hashlib
import json
from math import sqrt
from pathlib import Path
import shutil

VALID_RESULTS=('win','loss','draw')
VALID_SIDES=('blue','orange')


def sha256(path):
    digest=hashlib.sha256()
    with Path(path).open('rb') as f:
        for chunk in iter(lambda:f.read(1024*1024),b''):
            digest.update(chunk)
    return digest.hexdigest()


def wilson_interval(wins, total, z=1.96):
    """Conservative binomial CI counting draws as non-wins for the lower bound."""
    if total < 1:return (0.0,1.0)
    p=wins/total
    den=1+z*z/total
    middle=(p+z*z/(2*total))/den
    rad=z*sqrt(p*(1-p)/total+z*z/(4*total*total))/den
    return max(0.,middle-rad),min(1.,middle+rad)


def evaluate_match_log(path,candidate_hash,incumbent_hash,min_matches=24,min_per_side=6):
    if candidate_hash==incumbent_hash:
        raise ValueError('Candidate and incumbent are byte-for-byte identical')
    seen=set();results=Counter();sides=Counter()
    ignored=0
    file=Path(path)
    if not file.is_file():
        return {'ok':False,'reason':'No external match report file','total':0,'wins':0,
                'losses':0,'draws':0,'win_fraction':0.,'wilson_lower':0.,'side_counts':{}}
    for lineno,line in enumerate(file.read_text(encoding='utf-8').splitlines(),1):
        if not line.strip():continue
        try: row=json.loads(line)
        except json.JSONDecodeError as exc:
            raise ValueError(f'Invalid match-log JSON at line {lineno}') from exc
        if row.get('candidate_sha256')!=candidate_hash or row.get('incumbent_sha256')!=incumbent_hash:
            ignored+=1
            continue
        identifier=str(row.get('match_id','')).strip()
        side=row.get('candidate_side')
        result=row.get('result')
        if not identifier or side not in VALID_SIDES or result not in VALID_RESULTS:
            raise ValueError(f'Invalid match record at line {lineno}')
        if identifier in seen:
            raise ValueError(f'Duplicate match id in evaluation: {identifier}')
        seen.add(identifier);sides[side]+=1;results[result]+=1
    n=sum(results.values())
    lo,hi=wilson_interval(results['win'],n)
    ready=(n>=int(min_matches) and
           min(sides['blue'],sides['orange'])>=int(min_per_side) and lo>0.50)
    reason=('Pass: conservative 95% Wilson lower confidence bound > 50%'
            if ready else 'Needs more side-balanced games or stronger results')
    return {'ok':ready,'reason':reason,'total':n,'wins':results['win'],
            'losses':results['loss'],'draws':results['draw'],
            'win_fraction':(results['win']+.5*results['draw'])/n if n else 0.,
            'wilson_lower':lo,'wilson_upper':hi,
            'side_counts':dict(sides),'ignored_other_model_pairs':ignored,
            'note':'These results are supplied externally, not verified by RocketHive.'}


def promote_from_report(candidate,champion,results_path, *, min_matches=24,
                        min_per_side=6,commit=False,initialize=False):
    candidate=Path(candidate);champion=Path(champion)
    if not candidate.is_file():raise FileNotFoundError(candidate)
    import torch
    ck=torch.load(candidate,map_location='cpu',weights_only=False)
    if ck.get('type') != 'SEARCH_DISTILLED_ACTION_POLICY_unvalidated':
        raise ValueError('Candidate is not a search-distilled action-controller checkpoint')
    candidate_hash=sha256(candidate)
    if not champion.exists():
        if not initialize:
            raise FileNotFoundError('No champion exists. Seed one using --initialize; this is NOT proof of skill.')
        decision={'ok':True,'reason':'Unvalidated baseline initialization', 'total':0,
                  'candidate_sha256':candidate_hash,'incumbent_sha256':None,
                  'verified_gameplay':False}
    else:
        incumbent_hash=sha256(champion)
        decision=evaluate_match_log(results_path,candidate_hash,incumbent_hash,
                                    min_matches,min_per_side)
        decision['candidate_sha256']=candidate_hash
        decision['incumbent_sha256']=incumbent_hash
        decision['verified_gameplay']=False  # No match runner/source attestation here.
    if commit and decision['ok']:
        champion.parent.mkdir(parents=True,exist_ok=True)
        # Protect the previous champion even after a successful promotion.
        if champion.exists():
            backup=champion.with_name(champion.stem+'_previous'+champion.suffix)
            backup_tmp=backup.with_name(backup.name+'.tmp')
            try:shutil.copyfile(champion,backup_tmp);backup_tmp.replace(backup)
            finally:backup_tmp.unlink(missing_ok=True)
        tmp=champion.with_name(champion.name+'.new')
        try:shutil.copyfile(candidate,tmp);tmp.replace(champion)
        finally:tmp.unlink(missing_ok=True)
        meta=champion.with_suffix('.evaluation.json')
        tmpmeta=meta.with_name(meta.name+'.new')
        try:tmpmeta.write_text(json.dumps(decision,indent=2),encoding='utf-8');tmpmeta.replace(meta)
        finally:tmpmeta.unlink(missing_ok=True)
    return decision
