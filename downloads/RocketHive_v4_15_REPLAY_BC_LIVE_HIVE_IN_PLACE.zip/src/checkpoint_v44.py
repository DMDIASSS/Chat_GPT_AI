"""Atomic checkpoint replacement with a previous-generation recovery copy.

Only locally produced, trusted torch checkpoints should be loaded: torch.load
may execute pickle data for legacy optimizer formats. No remote downloads are
loaded as checkpoints.
"""
from __future__ import annotations
from pathlib import Path
import shutil
import pickle


def save_atomic(torch, path, data, preserve_previous=True):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    temp = path.with_name(path.name + '.new')
    try:
        torch.save(data, temp)
        if preserve_previous and path.is_file():
            # Never replace a good recovery copy with a corrupted latest file.
            try:
                existing = torch.load(path,map_location='cpu',weights_only=False)
                healthy = isinstance(existing,dict) and 'model' in existing and 'optimizer' in existing
            except (RuntimeError,OSError,EOFError,KeyError,TypeError,ValueError,
                    pickle.UnpicklingError):
                healthy = False
            if healthy:
                prior = path.with_name(path.stem + '_previous' + path.suffix)
                tmp_prior = prior.with_name(prior.name + '.new')
                try:
                    shutil.copyfile(path, tmp_prior)
                    tmp_prior.replace(prior)
                finally:
                    tmp_prior.unlink(missing_ok=True)
        temp.replace(path)
    finally:
        temp.unlink(missing_ok=True)


def load_latest_valid(torch, main, best=None, map_location='cpu', expected_type=None):
    main = Path(main)
    previous = main.with_name(main.stem + '_previous' + main.suffix)
    candidates = [main, previous]
    if best is not None:
        candidates.append(Path(best))
    errors = []
    for path in candidates:
        if not path.exists():
            continue
        try:
            ck = torch.load(path, map_location=map_location, weights_only=False)
            if not isinstance(ck, dict) or 'model' not in ck or 'optimizer' not in ck:
                raise ValueError('missing model/optimizer')
            if expected_type is not None and ck.get('type') != expected_type:
                raise ValueError('checkpoint model type mismatch')
            return ck, path, errors
        except (ValueError, RuntimeError, OSError, EOFError, KeyError, TypeError, pickle.UnpicklingError) as exc:
            errors.append(f'{path.name}: {type(exc).__name__}')
    return None, None, errors
