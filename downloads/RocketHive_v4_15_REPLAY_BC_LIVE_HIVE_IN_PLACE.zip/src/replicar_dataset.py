"""Replicar v2 -> RocketHive trajectory dataset.

Replicar's own MIT-licensed converter provides reconstructed Soccar physics states.
We USE ONLY STATES as prediction targets; inferred controller inputs are NOT labels.
Default 8-tick output = 15 Hz, with replays split by file, not frame.

The catalog check intentionally detects Replicar's documented Octane fallback for
unmapped body IDs: a reported OCTANE alone is not proof of a verified Octane body.
"""
from __future__ import annotations

import csv
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import urllib.request

import numpy as np
from .dataset import dataset_split
from .hitboxes import allowed, GROUPS, load_overrides

CATALOG_URL = 'https://raw.githubusercontent.com/Rolv-Arild/replicar/master/data/body_hitboxes.tsv'


def read_catalog(root: Path):
    """Load the exact upstream ID -> preset catalog. No fuzzy cosmetic matching."""
    path = root/'third_party'/'replicar_body_hitboxes.tsv'
    if not path.is_file():
        path.parent.mkdir(parents=True, exist_ok=True)
        try:
            with urllib.request.urlopen(CATALOG_URL, timeout=15) as response:
                data=response.read(2_000_000)
            path.write_bytes(data)
            print('Downloaded the upstream Replicar body-hitbox catalog:', path, flush=True)
        except Exception as exc:
            print('WARNING: cannot download hitbox catalog:', exc, flush=True)
            print('Body IDs will require manual verification. Place the official TSV at',path, flush=True)
            return {}
    output={}
    with path.open('r',encoding='utf-8-sig',newline='') as f:
        for row in csv.DictReader(f,delimiter='\t'):
            try: product_id=int(row['id'])
            except (ValueError,TypeError,KeyError):continue
            output[product_id]={'hitbox':str(row.get('hitbox','')).strip().lower(),
                                'name':str(row.get('name','')).strip()}
    if not output:raise RuntimeError(f'Empty/malformed Replicar body catalog: {path}')
    return output


def verified_players(header, source, overrides, catalog):
    """Order players by team then source index; check raw product ID against catalog."""
    by_team={0:[],1:[]}
    for p in header.get('players',[]):
        team=int(p['team'])
        if team not in by_team:raise ValueError('Not two Soccar teams')
        by_team[team].append(p)
    if len(by_team[0])!=len(by_team[1]) or len(by_team[0]) not in (1,2,3):
        raise ValueError('Not standard balanced 1v1/2v2/3v3')
    selected=[]
    for t in (0,1):
        for slot,p in enumerate(sorted(by_team[t],key=lambda x:int(x['index']))):
            raw_box=str(p.get('hitbox') or '').strip().lower()
            ident=p.get('body_product_id')
            known=catalog.get(int(ident)) if ident is not None and str(ident).isdigit() else None
            # 'unmapped' can have an Octane SIM fallback. Never trust that as actual hitbox!
            verified=known and known['hitbox'] in GROUPS and known['hitbox']==raw_box
            box=raw_box if verified else 'unknown'
            team='blue' if t==0 else 'orange'
            box=overrides.get((source,team,slot),box)
            selected.append({'team':team,'slot':slot,'index':int(p['index']),
                             'name':str(p.get('name') or f'{team}-{slot}'),
                             'body':(known or {}).get('name') or f'product_id={ident}',
                             'product_id':ident,'hitbox':box,'catalog_verified':bool(verified)})
    return selected


def get_goal_events(f, a):
    """Actual goal event labels, not the prior guess from goal-line crossing."""
    try: records=f.records('events').to_pylist()
    except (KeyError,ValueError): return np.zeros(0,np.int64),np.zeros(0,np.int8)
    frames=np.asarray(a['frame'])
    rows=[];teams=[]
    for event in records:
        if str(event.get('kind','')).lower()!='goal':continue
        side=event.get('scoring_team')
        if side is None:continue
        try:side=int(side)
        except (ValueError,TypeError):continue
        if side not in (0,1):continue
        where=np.flatnonzero(frames==event.get('frame'))
        if len(where):
            rows.append(int(where[-1]));teams.append(side)
    return np.asarray(rows,np.int64),np.asarray(teams,np.int8)


def get_flip_reset_events(f, a, players):
    try:events=f.records('events').to_pylist()
    except (KeyError,ValueError,AttributeError):events=[]
    frame=np.asarray(a.get('frame',np.arange(len(a['ball_position']))))
    lookup={p['index']:i for i,p in enumerate(players)}
    rows=[];persons=[]
    for ev in events:
        if str(ev.get('kind','')).lower()!='flip_reset':continue
        try:who=int(ev.get('player'))
        except (TypeError,ValueError):continue
        if who not in lookup:continue
        matched=np.flatnonzero(frame==ev.get('frame'))
        if len(matched):rows.append(int(matched[-1]));persons.append(lookup[who])
    return np.asarray(rows,np.int64),np.asarray(persons,np.int8)


def normalize_arrays(f, players, fps=15.):
    """Convert a ReplicarFile (or duck-typed mock) to original RocketHive npz fields."""
    a=f.arrays();N=len(a['ball_position'])
    columns=['ball_position','ball_rotation','ball_velocity','ball_angular_velocity',
             'car_position','car_rotation','car_velocity','car_angular_velocity','car_boost']
    absent=[c for c in columns if c not in a]
    if absent:raise ValueError(f'Missing required replicar state columns: {absent}')
    get=lambda key:np.asarray(a[key],dtype=np.float32)
    ball=np.concatenate([get(k) for k in columns[:4]],axis=-1)
    if ball.shape!=(N,13):raise ValueError(f'Unexpected ball shape: {ball.shape}')
    cars=np.zeros((N,6,14),np.float32)
    teams=np.full((6,),-1,np.int8)
    boxes=np.array(['padding']*6,dtype='<U16')
    valid=np.isfinite(ball).all(axis=-1)
    for i,p in enumerate(players):
        j=p['index']
        body=np.concatenate([get('car_position')[:,j],get('car_rotation')[:,j],
                             get('car_velocity')[:,j],get('car_angular_velocity')[:,j]],axis=-1)
        boost=get('car_boost')[:,j:j+1] / 100.0
        if body.shape!=(N,13):raise ValueError('Unexpected car feature shape')
        packed=np.concatenate([body,boost],axis=-1)
        frame_ok=np.isfinite(packed).all(axis=-1)
        if 'car_status' in a:
            status=np.asarray(a['car_status'])[:,j].astype(str)
            frame_ok &= status=='active'
        valid &= frame_ok
        cars[:,i,:]=np.nan_to_num(packed,nan=0.,posinf=0.,neginf=0.)
        teams[i]=0 if p['team']=='blue' else 1
        boxes[i]=p['hitbox']
    valid &= np.linalg.norm(ball[:,3:7],axis=-1)>0.5
    for i in range(len(players)):
        valid &= np.linalg.norm(cars[:,i,3:7],axis=-1)>0.5
    # Canonical replay_time; segments keep kickoff boundaries separate in training.
    time=np.asarray(a['replay_time'],dtype=np.float64)
    segment=np.asarray(a.get('segment',np.zeros(N)),dtype=np.float64)
    valid &= np.isfinite(time)&np.isfinite(segment)
    valid &= np.r_[True,np.diff(time)>0]
    # Out-of-play rows can be absent or invalid; never manufacture zeros as targets.
    mask=teams!=-1
    # Replay-only contact/dodge metadata. These are causal observations when
    # obtained from the LIVE simulator; parsed versions are offline labels.
    flag_names=('is_on_ground','has_jumped','has_double_jumped','has_flipped',
                'is_flipping','is_jumping','wheel_0_contact','wheel_1_contact',
                'wheel_2_contact','wheel_3_contact')
    flags=np.zeros((N,6,len(flag_names)),dtype=np.int8)
    flag_present=np.zeros(len(flag_names),dtype=np.int8)
    for fi,name in enumerate(flag_names):
        key='car_'+name
        if key not in a:continue
        arr=np.asarray(a[key])
        if arr.ndim!=2:continue
        flag_present[fi]=1
        for i,p in enumerate(players):
            if p['index']<arr.shape[1]:
                flags[:,i,fi]=np.asarray(arr[:,p['index']]==True,dtype=np.int8)
    goals,goal_teams=get_goal_events(f,a)
    flip_rows,flip_players=get_flip_reset_events(f,a,players)
    return dict(time=time,segment=np.nan_to_num(segment,nan=-1).astype(np.int32),ball=np.nan_to_num(ball),
                cars=cars,valid=valid,team=teams,mask=mask,hitboxes=boxes,
                mode=sum(x['team']=='blue' for x in players),fps=float(fps),
                goal_rows=goals,goal_teams=goal_teams,
                car_flags=flags,car_flag_names=np.asarray(flag_names),
                car_flags_present=flag_present,flip_reset_rows=flip_rows,
                flip_reset_players=flip_players)


def find_meshes(root: Path):
    candidates=[os.environ.get('REPLICAR_MESHES',''),
                str(root/'third_party'/'collision_meshes'),
                str(root/'collision_meshes')]
    for candidate in candidates:
        if candidate and list((Path(candidate)/'soccar').glob('*.cmf')):
            return str(Path(candidate).resolve())
    return None


def convert_missing(raw, parquet_dir, root, tick_step, jobs):
    """Use Replicar Python native extra when possible, or existing CLI; never forge states."""
    import replicar
    if not raw:return
    # Normalize both sides of relative_to(): Windows can otherwise reject
    # 'replays\\file.replay' against 'E:\\project\\replays'.
    root=Path(root).resolve()
    replay_root=(root/'replays').resolve()
    parquet_dir=Path(parquet_dir).resolve()
    manifest_path=parquet_dir/'manifest.json'
    if manifest_path.exists():
        try: manifest=json.loads(manifest_path.read_text(encoding='utf-8'))
        except (ValueError,OSError):manifest={}
    else:manifest={}
    needed=[]
    for p in raw:
        replay_path=Path(p).resolve()
        relative=replay_path.relative_to(replay_root).as_posix()
        key=hashlib.sha256(relative.encode()).hexdigest()[:16]
        manifest[key]=relative
        if not (parquet_dir/(key+'.parquet')).is_file():needed.append((replay_path,key))
    manifest_path.write_text(json.dumps(manifest,indent=2),encoding='utf-8')
    if not needed:return
    meshes=find_meshes(root)
    if not meshes:
        raise RuntimeError('Replicar needs soccar collision meshes from your Rocket League install. '
                           'Set REPLICAR_MESHES to the folder containing soccar/*.cmf, '
                           'or put them in third_party/collision_meshes/soccar/. '
                           'Alternatively copy existing Replicar .parquet files into replicar_parquet/.')
    try:import replicar_native
    except ImportError:replicar_native=None
    if replicar_native:
        import replicar  # converter API lives here; avoid UnboundLocalError during conversion
    exe=shutil.which('replicar')
    if not replicar_native and not exe:
        exe_local=root/'third_party'/'replicar'/'target'/'release'/('replicar.exe' if os.name=='nt' else 'replicar')
        if exe_local.is_file():exe=str(exe_local)
    if not replicar_native and not exe:
        raise RuntimeError('Replicar native converter not installed. Try: python -m pip install "replicar[convert]" '
                           'or build its CLI with Rust: cargo build --release -p replicar-cli. '
                           'Reader-only Replicar cannot convert .replay files.')
    for i,(p,h) in enumerate(needed,1):
        out=parquet_dir/(h+'.parquet')
        print(f'[replicar {i}/{len(needed)}] {p.name}',flush=True)
        if replicar_native:
            replicar.convert(p,out,tick_step=tick_step,meshes=meshes)
        else:
            cmd=[str(exe),'convert',str(p),'-o',str(out),'--tick-step',str(tick_step),'--meshes',meshes]
            subprocess.run(cmd,check=True)


def parse_folder(replays='replays',out='data',cfg=None):
    import replicar
    cfg=cfg or {}
    root=Path('.').resolve()
    r=Path(replays).resolve()
    o=Path(out).resolve()
    o.mkdir(exist_ok=True,parents=True)
    parquet_dir=root/'replicar_parquet';parquet_dir.mkdir(exist_ok=True)
    raw=sorted(r.rglob('*.replay')) if r.exists() else []
    # User may have converted with external Replicar. Do not require meshes then.
    if raw:convert_missing(raw,parquet_dir,root,int(cfg.get('replicar_tick_step',8)),int(cfg.get('replicar_jobs',4)))
    paths=sorted(set(parquet_dir.rglob('*.parquet')) | set(r.rglob('*.parquet')))
    paths=[p for p in paths if p.name !='index.parquet']
    if not paths:raise RuntimeError('No Replicar .parquet files. Place .replay files in replays/ and supply meshes, '
                                   'or place preconverted .parquet files in replicar_parquet/.')
    catalog=read_catalog(root); overrides=load_overrides(r/'hitboxes.csv')
    manifest_path=parquet_dir/'manifest.json'
    try:manifest=json.loads(manifest_path.read_text(encoding='utf-8')) if manifest_path.exists() else {}
    except (ValueError,OSError):manifest={}
    report=[];unknown=[];acc=0
    cache_file=o/'v4_parse_cache.json'
    try:cache=json.loads(cache_file.read_text(encoding='utf-8'))
    except (OSError,ValueError):cache={}
    catalog_file=root/'third_party'/'replicar_body_hitboxes.tsv'
    rev_file=r/'hitboxes.csv'
    config_tag=hashlib.sha256((str(cfg.get('hitbox_filter'))+
        str(catalog_file.stat().st_mtime_ns if catalog_file.exists() else 'none')+
        str(rev_file.stat().st_mtime_ns if rev_file.exists() else 'none')).encode()).hexdigest()[:12]
    for i,p in enumerate(paths,1):
        # Convert hash names back to the human readable replay path for CSV reviews.
        source=manifest.get(p.stem,p.name)
        info={'replay':source,'status':'error','reason':''}
        sig=f'{p.stat().st_size}:{p.stat().st_mtime_ns}:{config_tag}'
        cached=cache.get(str(p))
        if cached and cached.get('signature')==sig and cached['info'].get('status')=='accepted' and \
           Path(cached['info'].get('path','')).is_file():
            info=dict(cached['info']);report.append(info);acc+=1
            print(f'[{i}/{len(paths)}] cached accepted: {source}',flush=True)
            continue
        try:
            f=replicar.read(p)
            hdr=f.header
            # Only standard Soccar is supported by upstream Replicar v2 converter.
            players=verified_players(hdr,source,overrides,catalog)
            info['players']=players
            if any(x['hitbox']=='unknown' for x in players):
                info.update(status='review',reason='unknown/unmapped body. Verify hitbox in replays/hitboxes.csv')
                for q in players:
                    if q['hitbox']=='unknown':unknown.append({'replay':source,'team':q['team'],'slot':q['slot'],
                                                              'body':q['body'],'hitbox':''})
            elif not allowed(players,cfg.get('hitbox_filter','octane_duo_or_all')):
                info.update(status='rejected',reason='Octane-team requirement not satisfied')
            else:
                data=normalize_arrays(f,players,float(cfg.get('fps',15.)))
                if data['valid'].sum()<32:raise ValueError('Fewer than 32 fully active/finite rows')
                h=hashlib.sha256(source.encode()).hexdigest()[:16]
                dest=o/dataset_split(source)/(h+'.npz');dest.parent.mkdir(exist_ok=True,parents=True)
                np.savez_compressed(dest,**data,source=source,parquet_source=str(p))
                acc+=1
                info.update(status='accepted',reason='Replicar v2 states; catalog verified',path=str(dest),
                            frames=len(data['time']),valid_frames=int(data['valid'].sum()),
                            goal_events=int(len(data['goal_rows'])))
        except Exception as exc:info.update(status='error',reason=f'{type(exc).__name__}: {exc}')
        report.append(info)
        if info['status']=='accepted':cache[str(p)]={'signature':sig,'info':info}
        print(f'[{i}/{len(paths)}] {info["status"]}: {source}: {info["reason"]}',flush=True)
    review=r/'hitboxes.csv';existing=[]
    if review.exists():
        with review.open(newline='',encoding='utf-8-sig') as f:existing=list(csv.DictReader(f))
    seen={(x.get('replay'),x.get('team'),str(x.get('slot'))) for x in existing}
    existing.extend(x for x in unknown if (x['replay'],x['team'],str(x['slot'])) not in seen)
    # Never rewrite the review CSV unless its content actually changes. Its
    # mtime feeds the parse-cache key; rewriting it on every launch used to
    # reconvert every NPZ, invalidating the fixed-validation manifest.
    if existing and (not review.exists() or any((x['replay'],x['team'],str(x['slot'])) not in seen for x in unknown)):
        with review.open('w',newline='',encoding='utf-8') as f:
            w=csv.DictWriter(f,fieldnames=['replay','team','slot','body','hitbox']);w.writeheader();w.writerows(existing)
    cache_file.write_text(json.dumps(cache,indent=2,ensure_ascii=False),encoding='utf-8')
    (o/'parse_report.json').write_text(json.dumps(report,indent=2,ensure_ascii=False),encoding='utf-8')
    print(f'Accepted {acc}/{len(paths)} Replicar v2 replays; see {o}/parse_report.json')
    return acc
