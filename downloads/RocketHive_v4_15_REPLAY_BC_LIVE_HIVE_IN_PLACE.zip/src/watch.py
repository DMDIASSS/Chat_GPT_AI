"""Backwards-compatible CLI: now delegates to native RLViser, NEVER a browser."""
from tools.watch_rlviser import main


if __name__ == '__main__':
    raise SystemExit(main())
