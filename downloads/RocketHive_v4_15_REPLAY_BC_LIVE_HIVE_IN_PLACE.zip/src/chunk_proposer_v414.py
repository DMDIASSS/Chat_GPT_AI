"""Small autoregressive action-chunk proposer with a separate checkpoint.

Unlike independent action-table logits, the k-th action prediction conditions on
THE PREVIOUS ACTIONS IN THE CHUNK. The training target is a selected sequence
from RocketSim counterfactual search, not recorded human controls. No random
padding, fake VQ-BeT claims, or modification to the v4 action-policy format.

A full residual-VQ VQ-BeT codebook is a separate research integration. This
small network is a compatible first step and fits a low-memory laptop.
"""
from __future__ import annotations
from dataclasses import dataclass
from pathlib import Path
import numpy as np

from .search_teacher import OBS_DIM
from .physics_search import ACTIONS
from .learned_candidates_v414 import (Proposal,action_is_feasible,_geometry_bias,
                                       _sequence_bias)


def build_chunk_network(hidden=128):
    import torch
    from torch import nn
    n=len(ACTIONS)
    class ChunkNet(nn.Module):
        def __init__(self):
            super().__init__()
            self.state=nn.Sequential(nn.Linear(OBS_DIM,hidden),nn.LayerNorm(hidden),nn.SiLU(),
                                     nn.Linear(hidden,hidden),nn.SiLU())
            self.previous=nn.Embedding(n+1,24)
            self.cell=nn.GRUCell(hidden+24,hidden)
            self.output=nn.Linear(hidden,n)
            self.bos=n
        def next_logits(self,obs,prefix):
            # obs: [N,OBS_DIM], prefix: [N,k] index matrix, k=0..7
            h=self.state(obs)
            for k in range(prefix.shape[1]+1):
                prev=(prefix[:,k-1] if k else obs.new_full((len(obs),),self.bos,dtype=torch.long))
                h=self.cell(torch.cat([self.state(obs),self.previous(prev)],dim=-1),h)
            return self.output(h)
        def forward(self,obs,actions):
            # Teacher-forced logit for each move in the complete sequence.
            hidden_state=self.state(obs);representation=hidden_state
            logits=[]
            for k in range(actions.shape[1]):
                previous=actions[:,k-1] if k else actions.new_full((len(obs),),self.bos)
                hidden_state=self.cell(torch.cat([representation,self.previous(previous)],-1),hidden_state)
                logits.append(self.output(hidden_state))
            return torch.stack(logits,1)
    return ChunkNet()


class ChunkPrior:
    """Reused across search iterations; checkpoint protects trainable sequence prior."""
    def __init__(self, path='models/v414_chunk_prior.pt',device='cpu',lr=2e-4):
        import torch
        self.torch=torch;self.device=torch.device(device)
        self.net=build_chunk_network().to(self.device)
        self.opt=torch.optim.AdamW(self.net.parameters(),lr=lr)
        self.path=Path(path);self.path.parent.mkdir(parents=True,exist_ok=True)
        self.steps=0
        if self.path.exists():
            ck=torch.load(self.path,map_location=self.device,weights_only=False)
            if ck.get('type')!='ROCKETHIVE_AUTOREGRESSIVE_CHUNK_V414' or ck.get('obs_dim')!=OBS_DIM:
                raise ValueError('Incompatible chunk-prior checkpoint; never overwrite it')
            self.net.load_state_dict(ck['model']);self.opt.load_state_dict(ck['optimizer'])
            self.steps=int(ck.get('steps',0))
    def train_from_search(self,obs,sequences):
        torch=self.torch
        x=torch.as_tensor(np.asarray(obs,dtype=np.float32),device=self.device)
        y=torch.as_tensor(np.asarray(sequences,dtype=np.int64),device=self.device)
        if x.ndim!=2 or x.shape[1]!=OBS_DIM or y.ndim!=2 or len(x)!=len(y) or y.shape[1]<1:
            raise ValueError('Chunk training input shapes invalid')
        if torch.any((y<0)|(y>=len(ACTIONS))):raise ValueError('Chunk labels are not known controls')
        self.net.train()
        logits=self.net(x,y)
        # Make jump/boost transitions a bit more salient, otherwise a common
        # throttle action can dominate a tiny multimodal dataset.
        categorical=torch.nn.functional.cross_entropy(logits.flatten(0,1),y.flatten(),reduction='none')
        jumps=torch.as_tensor(np.array([bool(a[5]) for a in ACTIONS]),device=self.device)
        boosts=torch.as_tensor(np.array([bool(a[6]) for a in ACTIONS]),device=self.device)
        weights=1.+0.45*jumps[y.flatten()].float()+0.12*boosts[y.flatten()].float()
        loss=(categorical*weights).mean()
        if not torch.isfinite(loss):raise RuntimeError('Nonfinite sequence-prior loss')
        self.opt.zero_grad(set_to_none=True);loss.backward()
        torch.nn.utils.clip_grad_norm_(self.net.parameters(),1.)
        self.opt.step();self.steps+=1
        temp=self.path.with_suffix('.tmp')
        torch.save({'type':'ROCKETHIVE_AUTOREGRESSIVE_CHUNK_V414',
                    'obs_dim':OBS_DIM,'model':self.net.state_dict(),
                    'optimizer':self.opt.state_dict(),'steps':self.steps},temp)
        temp.replace(self.path)
        return float(loss.detach().cpu().item())


class ChunkCandidateProposer:
    """Batch-autoregressive beam shortlist with explicit feasible-action masking."""
    def __init__(self,prior,observation_builder,segments=3,ticks_per_segment=8,
                 diversity=.65,beam_cap=256):
        self.prior=prior;self.observation_builder=observation_builder
        self.segments=int(segments);self.ticks=int(ticks_per_segment)
        self.diversity=float(diversity);self.beam_cap=int(beam_cap)
        self.last_stats={}
        if not 1<=self.segments<=8:raise ValueError('segments must be 1..8')
    def propose(self,state,player,count):
        torch=self.prior.torch
        if not 12<=count<=64:raise ValueError('candidates must be 12..64')
        obs=np.asarray(self.observation_builder(state,player),np.float32)
        beam=[((),0.)];bias=_geometry_bias(state,player)
        was_training=bool(self.prior.net.training)
        self.prior.net.eval()
        try:
            for step in range(self.segments):
                # One network call for ALL retained prefixes, not a call per
                # candidate. This is important for CPU inference latency.
                prefixes=np.asarray([p for p,_ in beam],dtype=np.int64).reshape(len(beam),step)
                x=np.repeat(obs[None,:],len(beam),axis=0)
                with torch.inference_mode():
                    z=self.prior.net.next_logits(torch.as_tensor(x,device=self.prior.device),
                         torch.as_tensor(prefixes,device=self.prior.device))
                    logp=torch.log_softmax(z,dim=1).cpu().numpy()
                possibilities=[]
                for i,(seq,score) in enumerate(beam):
                    for action in range(len(ACTIONS)):
                        if not action_is_feasible(state,player,action,seq,self.ticks):continue
                        bonus=_sequence_bias(seq[-1] if seq else None,action,step,state,player)
                        possibilities.append((seq+(action,),score+float(logp[i,action])+0.08*float(bias[action])+bonus))
                if not possibilities:raise ValueError('No physically feasible chunk proposals')
                possibilities.sort(key=lambda pair:(-pair[1],pair[0]))
                beam=possibilities[:max(count*3,min(self.beam_cap,len(possibilities)))]
        finally:
            self.prior.net.train(was_training)
        chosen=[];remaining=list(beam)
        while len(chosen)<count:
            if not remaining:raise ValueError('Not enough distinct feasible chunks')
            def ranking(p):
                seq,score=p
                if not chosen:return (score,score,tuple(-a for a in seq))
                match=max(sum(a==b for a,b in zip(seq,prev))/self.segments for prev,_ in chosen)
                return (score-self.diversity*match,score,tuple(-a for a in seq))
            picked=max(remaining,key=ranking)
            remaining.remove(picked);chosen.append(picked)
        self.last_stats[player]={
            'count':len(chosen),'unique_first_actions':len(set(a[0][0] for a in chosen)),
            'best_log_prior':float(chosen[0][1]),'source':'autoregressive_chunk_prior',
            'sequence_prior_steps':self.prior.steps}
        return [Proposal(tuple(seq),float(score)) for seq,score in chosen]

    def propose_all(self,state,count):
        return [self.propose(state,i,count) for i in range(len(state['cars']))]
