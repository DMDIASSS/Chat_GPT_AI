"""Persistent, fixed replay-level validation cohort for repeatable pose comparisons.

Never generate validation examples from train replays.  The exact replay files
and frame indices remain fixed across restarts and are not silently replaced
by newly downloaded (easier/harder) replays.  A missing/changed replay is
excluded and reported. Delete the manifest deliberately to rebuild a cohort.
"""
from __future__ import annotations
import json
import hashlib
from pathlib import Path
import numpy as np


class FixedValidation:
    def __init__(self, sampler, manifest='data/v4_validation_cohort.json', max_replays=24,
                 frames_per_replay=16):
        self.sampler = sampler
        self.manifest = Path(manifest)
        self.max_replays = max(1, int(max_replays))
        self.frames_per_replay = max(1, int(frames_per_replay))
        self.entries = []
        self.missing = []
        self.changed = []
        self.upgraded = False
        if self.manifest.exists():
            stored = json.loads(self.manifest.read_text(encoding='utf-8'))
            if stored.get('version') not in (1, 2) or not isinstance(stored.get('entries'), list):
                raise ValueError('Unknown validation cohort format; inspect and rebuild deliberately')
            self._load(stored['entries'], version=stored['version'])
            if stored['version']==1 and not (self.missing or self.changed):
                # One-time upgrade. Record byte digests so harmless timestamp
                # changes won't invalidate the cohort again.
                self._write_manifest(self._records_from_entries())
                self.upgraded = True
        else:
            records = self._new_entries()
            if records:
                self._write_manifest(records)
            self._load(records, version=2)

    @staticmethod
    def _sha256(path):
        digest=hashlib.sha256()
        with Path(path).open('rb') as src:
            for block in iter(lambda:src.read(1024*1024), b''):
                digest.update(block)
        return digest.hexdigest()

    def _write_manifest(self, records):
        self.manifest.parent.mkdir(parents=True, exist_ok=True)
        tmp=self.manifest.with_suffix('.tmp')
        tmp.write_text(json.dumps({'version':2,'entries':records},indent=2),encoding='utf-8')
        tmp.replace(self.manifest)

    def _records_from_entries(self):
        rows=[]
        for path,frames in self.entries:
            stat=path.stat()
            rows.append({'name':path.name,'bytes':stat.st_size,
                         'sha256':self._sha256(path),'frames':[int(x) for x in frames]})
        return rows

    def _new_entries(self):
        by_mode = {1: [], 2: [], 3: []}
        for path, starts in self.sampler.available:
            try:
                with np.load(path, allow_pickle=False) as z:
                    mode = int(z['mode'])
            except (OSError, ValueError, KeyError):
                continue
            if mode in by_mode:
                by_mode[mode].append((path, starts))
        selected = []
        # Round-robin across 1v1/2v2/3v3, rather than fill with one mode.
        while len(selected) < self.max_replays and any(by_mode.values()):
            for mode in (1, 2, 3):
                if by_mode[mode] and len(selected) < self.max_replays:
                    selected.append(by_mode[mode].pop(0))
        entries = []
        for p, starts in selected:
            st = p.stat()
            take = starts[np.linspace(0, len(starts)-1,
                                       num=min(self.frames_per_replay, len(starts)), dtype=int)]
            entries.append({'name': p.name, 'bytes': st.st_size, 'sha256': self._sha256(p),
                            'frames': [int(x) for x in take]})
        return entries

    def _load(self, records, version=2):
        available = {path.name: (path, set(int(x) for x in starts))
                     for path, starts in self.sampler.available}
        for row in records:
            if not isinstance(row, dict) or not isinstance(row.get('name'), str):
                raise ValueError('Invalid validation manifest entry')
            name = row['name']
            if name not in available:
                self.missing.append(name)
                continue
            path, valid = available[name]
            st = path.stat()
            frames = row.get('frames')
            bad_metadata=(st.st_size != row.get('bytes') or
                          (st.st_mtime_ns != row.get('mtime_ns') if version==1
                           else self._sha256(path) != row.get('sha256')))
            if (bad_metadata or not isinstance(frames, list) or any(i not in valid for i in frames)):
                self.changed.append(name)
                continue
            self.entries.append((path, np.asarray(frames, dtype=np.int64)))

    @property
    def count(self):
        return sum(len(frames) for _, frames in self.entries)

    def evaluate(self, model, loss_fn, device, batch_size=32):
        """Example-weighted average, with no RNG mutation and no parameter updates."""
        from .models import tensors_from_replay
        import torch
        total = 0.
        count = 0
        model.eval()
        with torch.inference_mode():
            for path, frames in self.entries:
                r = self.sampler.load(path)
                for start in range(0, len(frames), batch_size):
                    idx = frames[start:start+batch_size]
                    obs = tensors_from_replay(r, idx, device)
                    future = tensors_from_replay(r, idx+self.sampler.horizon, device)
                    predicted = model(*obs)
                    loss = loss_fn(*predicted, *future[:2], obs[-1])
                    if not bool(torch.isfinite(loss).item()):
                        raise ValueError('Nonfinite fixed validation loss')
                    total += float(loss.item())*len(idx)
                    count += len(idx)
        return total/count if count else None
