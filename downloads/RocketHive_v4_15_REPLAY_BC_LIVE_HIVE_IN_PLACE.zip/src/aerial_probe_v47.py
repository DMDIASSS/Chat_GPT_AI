"""An independent, untrained flight-control smoke-test pilot.

This is NOT an RL model, not imitation of human replay controls, and must never
be reported as the trained controller. Tests jump/boost/pitch in a real sim.
"""
from dataclasses import dataclass


def clamp(v):
    return max(-1., min(1., float(v)))


@dataclass
class ProbePhase:
    ticks: int = 0


class AerialProbe:
    def __init__(self):
        self.phases = {}

    def controls(self, rs, cars, ball):
        result=[]
        for car in cars:
            phase=self.phases.setdefault(car.id,ProbePhase())
            state=car.get_state()
            # One held jump from the ground, then release, then early boost and
            # pitch up, finally control the airborne heading. Designed to
            # diagnose whether RocketSim controls move a car vertically.
            k=phase.ticks
            phase.ticks+=1
            if k<3:
                c=rs.CarControls(throttle=1.,steer=0.,pitch=-0.8,yaw=0.,roll=0.,
                                 jump=True,boost=False,handbrake=False)
            elif k<4:
                c=rs.CarControls(throttle=1.,steer=0.,pitch=-0.7,yaw=0.,roll=0.,
                                 jump=False,boost=False,handbrake=False)
            elif k<16:
                # HOLD boost only while above ground. A pure vertical proof,
                # intentionally ignoring replay targets and scoring.
                direction=state.rot_mat.forward
                c=rs.CarControls(throttle=1.,steer=0.,pitch=0.0 if k>=10 else -0.8,
                                 yaw=0.,roll=0.,jump=False,boost=True,handbrake=False)
            else:
                c=rs.CarControls(throttle=1.,steer=0.,pitch=0.,yaw=0.,roll=0.,
                                 jump=False,boost=False,handbrake=False)
            result.append(c)
        return result
