"""Background Ballchasing downloader for continuous offline replay training.

Only the worker touches BallchasingSync; the main thread receives item counts
and parses on its own schedule. No token is written into the event queue.
"""
from __future__ import annotations
import queue
import threading
from .ballchasing_sync import RateLimited
from .system_guard_v44 import enough_space,free_gib


class DownloadWorker:
    def __init__(self, fetcher, max_new=12, max_pages=3, idle_seconds=1800, min_disk_free_gib=2.0):
        self.fetcher = fetcher
        self.max_new = max_new
        self.max_pages = max_pages
        self.idle_seconds = max(1.0, float(idle_seconds))
        self.min_disk_free_gib = float(min_disk_free_gib)
        self.events = queue.SimpleQueue()
        self.stop_requested = threading.Event()
        self.thread = threading.Thread(target=self._loop, name='BallchasingSSL', daemon=True)

    def start(self):
        self.thread.start()
        return self

    def drain(self):
        found = 0
        while True:
            try:
                found += self.events.get_nowait()
            except queue.Empty:
                return found

    def _loop(self):
        while not self.stop_requested.is_set():
            try:
                if not enough_space(getattr(self.fetcher, 'directory', '.'), self.min_disk_free_gib):
                    print('[download] low disk space (%.2f GiB free); pausing downloads; '
                          'never deleting replays.' % free_gib(getattr(self.fetcher, 'directory', '.')), flush=True)
                    self.stop_requested.wait(self.idle_seconds)
                    continue
                new = self.fetcher.sync_once(max_new=self.max_new, max_pages=self.max_pages)
                if new:
                    self.events.put(new)
                    print(f'[download] received {new} replay(s); continuing training in parallel', flush=True)
                wait = 15.0 if new else self.idle_seconds
            except RateLimited as exc:
                self.fetcher.state['backoff'] = min(3600, max(120, exc.seconds * 2))
                self.fetcher._save()
                wait = max(1.0, float(exc.seconds))
                print(f'[download] rate limited; will automatically resume in {wait:.0f}s. '
                      'Offline training continues.', flush=True)
            except (ValueError, OSError) as exc:
                wait = self.idle_seconds
                print(f'[download] skipped this pass ({type(exc).__name__}): {exc}. '
                      'Offline training continues.', flush=True)
            except Exception as exc:
                wait = self.idle_seconds
                print(f'[download] unexpected {type(exc).__name__}: {exc}. '
                      'Offline training continues; inspect downloader.', flush=True)
            self.stop_requested.wait(wait)

    def stop(self):
        self.stop_requested.set()
        if self.thread.is_alive():
            self.thread.join(timeout=1.0)
