"""Use a search-distilled action policy to drive all cars in RocketSim.

This is not a tested RLBot v5 deployment adapter. Search distillation must
produce a checkpoint and the same observation/action formats must be used.
"""
from __future__ import annotations
from pathlib import Path
import numpy as np
from .physics_search import ACTIONS,car_features,ball_features,action_controls
from .search_teacher import build_policy,make_observation,OBS_DIM


FLAG_FIELDS=('is_on_ground','has_jumped','has_double_jumped','has_flipped',
             'is_flipping','is_jumping','wheel_0_contact','wheel_1_contact',
             'wheel_2_contact','wheel_3_contact')


def live_state_flags(car):
    """Prefer simulator flags over zero-filling all replay-trained inputs.

    Unknown fields remain zero. Native bindings differ: this is a best-effort
    parity improvement, not exact timer/suspension-state reconstruction.
    """
    state=car.get_state()
    flags=[]
    for name in FLAG_FIELDS:
        value=getattr(state,name,None)
        if value is None:
            value=getattr(car,name,False)
        flags.append(float(bool(value)))
    return flags


class SearchPolicyController:
    def __init__(self, checkpoint='models/v4_action_policy_search_teacher.pt', device='cpu'):
        import torch
        p=Path(checkpoint).expanduser()
        if not p.is_absolute() and not p.is_file():
            # Recover when a caller changes cwd to launch the RLViser binary.
            root_candidate=Path(__file__).resolve().parents[1] / p
            if root_candidate.is_file():
                p=root_candidate
        if not p.is_file():
            raise FileNotFoundError(
                f'Action controller checkpoint not found: {p}. '
                'Run VERIFY_PHYSICS_SEARCH.bat and TRAIN_ACTION_CONTROLLER.bat; '
                'the pose champion is not a driving policy.')
        self.torch=torch;self.device=torch.device(device)
        ck=torch.load(p,map_location='cpu',weights_only=False)
        if ck.get('type')!='SEARCH_DISTILLED_ACTION_POLICY_unvalidated':
            raise ValueError('Not a RocketHive search-distilled controller checkpoint')
        if int(ck.get('step',0))<=0:
            raise ValueError('Controller checkpoint has zero optimizer updates (untrained). Run TRAIN_ACTION_CONTROLLER.bat')
        if int(ck['obs_dim'])!=OBS_DIM or list(map(tuple,ck['action_table'])) != list(map(tuple,ACTIONS)):
            raise ValueError('Observation/action tables do not match the training checkpoint')
        self.model=build_policy().to(self.device)
        self.model.load_state_dict(ck['model']);self.model.eval()
        self.checkpoint=str(p.resolve())
        self.checkpoint_step=int(ck.get('step',-1))
        print(f'[controller] search action policy loaded: {self.checkpoint} | step={self.checkpoint_step} | UNVALIDATED playing skill',flush=True)

    def action_indices(self, state):
        cars=np.asarray(state['cars'])
        batch=np.stack([make_observation(state,i) for i in range(len(cars))])
        with self.torch.no_grad():
            o=self.torch.tensor(batch,device=self.device,dtype=self.torch.float32)
            return self.model(o).argmax(-1).tolist()

    def controls(self,rs,cars,ball,hitboxes=None):
        n=len(cars);mode=n//2
        if n not in (2,4,6):raise ValueError('Expected exactly 2,4,6 cars')
        box=np.asarray(hitboxes if hitboxes is not None else ['octane']*n)
        state={'mode':mode,'cars':np.stack([car_features(car.get_state()) for car in cars]),
               'ball':ball_features(ball), 'hitboxes':box,
               'flags':np.asarray([live_state_flags(car) for car in cars],dtype=np.float32)}
        actions=self.action_indices(state)
        return [action_controls(rs,ACTIONS[a]) for a in actions]
