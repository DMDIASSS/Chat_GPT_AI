"""Hitbox matching. We never infer Octane from absent data.

Official car-body -> hitbox list: https://www.epicgames.com/help/c-37599050/a20257614
Metadata may not contain body cosmetics; a supplied CSV overrides missing labels.
"""
import csv
import json
import re
from pathlib import Path

OCTANE = {'octane','octane zsr','fennec','fennec zr-f','backfire','dingo','gizmo','grog','jackal','marauder','proteus','scarab','takumi','takumi rx-t','triton','twinzer','zippy','vulcan','road hog','road hog xl','outlaw','honda civic type r','bmw 1 series','volkswagen golf gti','mudcat','harbinger','shokunin'}
DOMINUS = {'dominus','dominus gt','89 batmobile','aftershock','hotshot','imperator dt5','werewolf','ronin','lamborghini huracan sto','porsche 911 turbo'}
BREAKOUT = {'breakout','breakout type-s','cyclone','animus gp','komodo','emperor','ace'}
HYBRID = {'endo','nimbus','venom','x-devil','esper','insidio','jäger','jager','tygris','tesla cybertruck'}
MERC = {'merc','battle bus','nomad','behemoth'}
PLANK = {'16 batmobile','mantis','paladin','sentinel','centio','artemis','twin mill iii'}
GROUPS = {'octane': OCTANE, 'dominus': DOMINUS, 'breakout': BREAKOUT, 'hybrid': HYBRID, 'merc': MERC, 'plank': PLANK, 'psyclops': {'psyclops'}}


def classify(name):
    if not isinstance(name, str) or not name.strip(): return 'unknown'
    s = re.sub(r'[_\-]+', ' ', name.lower().strip())
    s = re.sub(r'\s+', ' ', s)
    # Exact/variant matching; do not match arbitrary substring like "octane decal".
    for group, known in GROUPS.items():
        if s in known: return group
    return 'unknown'


def load_overrides(path):
    d={}
    if not Path(path).exists(): return d
    with open(path, newline='', encoding='utf-8-sig') as f:
        for row in csv.DictReader(f):
            name = (row.get('replay') or '').strip()
            team = (row.get('team') or '').strip().lower()
            slot = (row.get('slot') or '').strip()
            hit = (row.get('hitbox') or '').strip().lower()
            car = (row.get('body') or '').strip()
            if hit not in GROUPS: hit = classify(car)
            if name and team in ('blue','orange') and slot.isdigit() and hit in GROUPS:
                d[(name,team,int(slot))] = hit
    return d


def classify_players(meta, replay_name, overrides=None):
    overrides = overrides or {}
    m = meta.get('replay_meta', meta)
    players=[]
    for tkey, tname in [('team_zero','blue'),('team_one','orange')]:
        for slot, p in enumerate(m.get(tkey,[]) or []):
            if not isinstance(p,dict): p={'name':str(p)}
            # Only fields that explicitly identify the car body, never player name/team.
            body = next((p[k] for k in ['body_name','car_body_name','car_body','car_name','body']
                         if k in p and isinstance(p[k],str)), '')
            explicit = str(p.get('hitbox_type') or p.get('hitbox') or '').strip().lower()
            if explicit not in GROUPS: explicit = classify(body)
            label=overrides.get((replay_name,tname,slot),explicit)
            players.append({'team':tname,'slot':slot,'name':p.get('name',f'{tname}-{slot}'), 'body':body, 'hitbox':label})
    return players


def allowed(players, mode='octane_team_or_all'):
    blue=[p['hitbox'] for p in players if p['team']=='blue']
    orange=[p['hitbox'] for p in players if p['team']=='orange']
    if len(blue)!=len(orange) or len(blue) not in (1,2,3): return False
    if 'unknown' in blue+orange: return False
    if mode=='all_verified': return True
    if mode=='all_octane': return all(h=='octane' for h in blue+orange)
    if mode in ('octane_team_or_all','octane_duo_or_all'):
        if len(blue)==1: return any(h=='octane' for h in blue+orange)
        return (all(h=='octane' for h in blue+orange) or
                blue.count('octane')>=2 or orange.count('octane')>=2)
    raise ValueError('Invalid hitbox filter: '+str(mode))
