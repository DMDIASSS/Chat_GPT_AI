"""Opponent-aware game-state evaluation.

The optional ONNX evaluator is deliberately strict. A 114-float array is NOT a
valid Goal Predictor input merely because it has the right shape: the original
3v3 network requires the *exact* order, normalization, boost-pad status and
player-respawn fields from its training pipeline. No guessed features.

The built-in physics proxy is NOT trained and does not output win probabilities.
It lets opponent-first search run while a verified pretrained bridge is absent.
"""
from __future__ import annotations
from dataclasses import dataclass
import hashlib
import importlib.util
import json
import math
from pathlib import Path
import numpy as np


class EvaluationUnavailable(RuntimeError):
    pass


def clamp(value, low=-1., high=1.):
    return max(low, min(high, float(value)))


class PhysicsProxy:
    """Lightweight *untrained* positional value, Blue positive, Orange negative.

    This is NOT a calibrated probability, a match win estimate or a pretrained
    network. It is an emergency search baseline; prioritize real model support.
    """
    source='physics_proxy_UNTRAINED'
    def score(self,state):
        ball=np.asarray(state['ball'],dtype=float)
        if ball.shape[0]<10 or not np.isfinite(ball).all():
            raise EvaluationUnavailable('Nonfinite/malformed ball state')
        y=float(ball[1]);vy=float(ball[8]);x=float(ball[0])
        # Approximate attack direction: Blue attacks the +y goal.
        pos=clamp((y+0.28*vy)/5120)
        goal_alignment=1-.5*min(1.,abs(x)/4096)
        value=0.70*pos*goal_alignment+0.20*clamp(vy/3500)
        cars=np.asarray(state['cars'],dtype=float)
        mode=int(state.get('mode',len(cars)//2))
        if mode>0 and len(cars)>=2*mode:
            distances=np.linalg.norm(cars[:2*mode,:3]-ball[:3],axis=1)
            blue=float(np.min(distances[:mode]));orange=float(np.min(distances[mode:]))
            value+=0.10*clamp((orange-blue)/2500)
        return clamp(value)


class VerifiedONNXEvaluator:
    """ONNX inference with a user-supplied VERIFIED upstream feature mapper.

    The manifest references a local mapping module exposing `to_features(state)`
    that reconstructs the upstream model's exact feature preprocessing. Only
    use after validating it against original inference on held-out states.
    No downloads, arbitrary plugins, or model execution are attempted until
    the user explicitly selects this manifest. Modules execute Python code,
    so only point at files you trust and control.
    """
    def __init__(self,manifest_path):
        p=Path(manifest_path).resolve()
        if not p.is_file():raise EvaluationUnavailable('Evaluator manifest missing: '+str(p))
        m=json.loads(p.read_text(encoding='utf-8'))
        if m.get('verified_feature_mapping') is not True:
            raise EvaluationUnavailable('Feature mapping must be explicitly verified against upstream tests')
        if m.get('output_labels') != ['none','blue','orange']:
            raise EvaluationUnavailable('Unknown output semantics; require [none,blue,orange]')
        if m.get('input_dim') != 114 or m.get('modes') != [3]:
            raise EvaluationUnavailable('This verified Goal Predictor format supports 3v3 and 114 features only')
        model=(p.parent/m['model_path']).resolve()
        script=(p.parent/m['adapter_path']).resolve()
        if not model.is_file() or not script.is_file():
            raise EvaluationUnavailable('Expected pretrained model and verified adapter files are missing')
        digest=hashlib.sha256(model.read_bytes()).hexdigest()
        if digest.lower()!=str(m.get('sha256','')).lower():
            raise EvaluationUnavailable('Pretrained ONNX checksum does not match manifest')
        try:
            import onnxruntime as ort
        except ImportError as exc:
            raise EvaluationUnavailable('Install onnxruntime into the existing venv') from exc
        spec=importlib.util.spec_from_file_location('_rockethive_verified_evaluator_adapter',str(script))
        if spec is None or spec.loader is None:raise EvaluationUnavailable('Invalid feature-adapter module')
        module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
        if not callable(getattr(module,'to_features',None)):
            raise EvaluationUnavailable('Feature adapter must expose to_features(state)')
        self.to_features=module.to_features
        self.session=ort.InferenceSession(str(model),providers=['CPUExecutionProvider'])
        inputs=self.session.get_inputs();outputs=self.session.get_outputs()
        if len(inputs)!=1 or len(outputs)<1:
            raise EvaluationUnavailable('Unexpected ONNX I/O signature')
        if len(inputs[0].shape)!=2 or inputs[0].shape[-1]!=114:
            raise EvaluationUnavailable('ONNX input shape is not [batch,114]')
        if len(outputs[0].shape)!=2 or outputs[0].shape[-1]!=3:
            raise EvaluationUnavailable('ONNX output shape is not [batch,3]')
        self.input_name=inputs[0].name;self.output_name=outputs[0].name
        self.source='verified_goal_predictor_ONNX_3v3'
    def score(self,state):
        if int(state['mode'])!=3:
            raise EvaluationUnavailable('The pretrained model cannot score non-3v3 states')
        features=np.asarray(self.to_features(state),dtype=np.float32)
        if features.shape != (114,):
            raise EvaluationUnavailable('Adapter must produce 114 features in exact upstream order')
        # Model may legitimately expect NaNs for demolished players; the
        # upstream adapter is responsible for those semantics.
        out=np.asarray(self.session.run([self.output_name],{self.input_name:features[None,:]})[0],float)
        if out.shape!=(1,3) or not np.isfinite(out).all():
            raise EvaluationUnavailable('Pretrained model returned invalid outputs')
        p=out[0]
        # It may emit logits or already-normalized probabilities. Preserve
        # normalized probability vectors; otherwise apply stable softmax.
        if np.min(p)<0 or np.max(p)>1 or abs(float(p.sum())-1)>0.01:
            e=np.exp(p-np.max(p));p=e/e.sum()
        return clamp(float(p[1]-p[2]))


def make_evaluator(cfg):
    source=str(cfg.get('game_evaluator','physics_proxy')).strip().lower()
    if source=='physics_proxy':return PhysicsProxy()
    if source in ('replay_goal_value','learned_goal_value'):
        from .goal_value_v414 import GoalValueEvaluator
        try:return GoalValueEvaluator(cfg.get('evaluator_checkpoint','models/v414_goal_value_best.pt'))
        except (FileNotFoundError,ValueError,KeyError) as exc:
            raise EvaluationUnavailable('Goal-value checkpoint unavailable/incompatible. Run TRAIN_GAME_EVALUATOR.bat first.') from exc
    if source=='auto':
        from pathlib import Path
        target=cfg.get('evaluator_checkpoint','models/v414_goal_value_best.pt')
        if Path(target).is_file():
            from .goal_value_v414 import GoalValueEvaluator
            return GoalValueEvaluator(target)
        raise EvaluationUnavailable('No trained Blue/Orange evaluator yet. Run TRAIN_GAME_EVALUATOR.bat; or explicitly select physics_proxy_UNTRAINED for diagnostics.')
    if source in ('verified_onnx','pretrained'):
        return VerifiedONNXEvaluator(cfg.get('evaluator_manifest','models/evaluator/manifest.json'))
    raise EvaluationUnavailable('Unknown evaluator '+source)
