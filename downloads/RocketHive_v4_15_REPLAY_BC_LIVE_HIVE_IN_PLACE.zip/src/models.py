"""Replay-only pose forecaster + goal evaluator.

These predict future *states*, not controller actions; they cannot be plugged
into an RLBot car without an additional physics/action training stage.
"""
import torch
from torch import nn
import torch.nn.functional as F

HITBOXES=('octane','dominus','plank','breakout','hybrid','merc','psyclops','unknown','padding')


def scales(device):
    return torch.tensor([4096,5120,2050,1,1,1,1,2300,2300,2300,6,6,6,1],device=device,dtype=torch.float32)


def normalize_ball(b):
    return b/ scales(b.device)[:13]


def normalize_cars(c):
    return c/scales(c.device)


class JointForecaster(nn.Module):
    """Predicts ball + six car poses at a future timestamp, jointly.

    One shared model handles 1v1, 2v2, 3v3 with padding.
    """
    def __init__(self,d=96,layers=2):
        super().__init__()
        self.ball_in=nn.Linear(13,d)
        self.car_in=nn.Linear(14,d)
        self.teams=nn.Embedding(3,d)
        self.boxes=nn.Embedding(len(HITBOXES),d)
        enc=nn.TransformerEncoderLayer(d,4,d*4,batch_first=True,norm_first=True,dropout=0.0)
        self.enc=nn.TransformerEncoder(enc,layers,enable_nested_tensor=False)
        self.car_out=nn.Linear(d,14)
        self.ball_out=nn.Linear(d,13)
    def forward(self,ball,cars,teams,boxes,mask):
        ball_n=normalize_ball(ball)
        car_n=normalize_cars(cars)
        token=torch.cat([self.ball_in(ball_n)[:,None,:],self.car_in(car_n)+
                         self.teams((teams+1).clamp(0,2).long())+self.boxes(boxes.long())],dim=1)
        pad=torch.cat([torch.zeros(mask.size(0),1,device=mask.device,dtype=torch.bool),~mask],dim=1)
        h=self.enc(token,src_key_padding_mask=pad)
        bc=self.ball_out(h[:,0])
        pc=self.car_out(h[:,1:])
        # Predict *differences* from initial state, so even untrained models start near now.
        bp=torch.cat([ball[:,:3]+bc[:,:3]*900,
                      F.normalize(ball[:,3:7]+bc[:,3:7]*0.25,p=2,dim=-1),
                      ball[:,7:13]+bc[:,7:13]*900],-1)
        cp=torch.cat([cars[:,:,:3]+pc[:,:,:3]*900,
                      F.normalize(cars[:,:,3:7]+pc[:,:,3:7]*0.25,p=2,dim=-1),
                      cars[:,:,7:13]+pc[:,:,7:13]*900,
                      (cars[:,:,13:14]+pc[:,:,13:14]*0.12).clamp(0,1)],-1)
        return bp,cp


class StateEvaluator(nn.Module):
    """Heuristic near-term scored-by-blue/orange/none estimator from current state."""
    def __init__(self,d=96):
        super().__init__()
        self.ball_in=nn.Linear(13,d)
        self.car_in=nn.Linear(14,d)
        self.teams=nn.Embedding(3,d)
        self.boxes=nn.Embedding(len(HITBOXES),d)
        layer=nn.TransformerEncoderLayer(d,4,d*4,batch_first=True,norm_first=True,dropout=0.0)
        self.enc=nn.TransformerEncoder(layer,2,enable_nested_tensor=False)
        self.out=nn.Sequential(nn.Linear(d,d),nn.GELU(),nn.Linear(d,3))
    def forward(self,ball,cars,teams,boxes,mask):
        t=torch.cat([self.ball_in(normalize_ball(ball))[:,None,:],
                     self.car_in(normalize_cars(cars))+
                     self.teams((teams+1).clamp(0,2).long())+
                     self.boxes(boxes.long())],dim=1)
        pad=torch.cat([torch.zeros(mask.size(0),1,device=mask.device,dtype=torch.bool),~mask],dim=1)
        return self.out(self.enc(t,src_key_padding_mask=pad)[:,0])


def pose_loss(pred_ball,pred_cars,target_ball,target_cars,mask):
    m=mask.float();den=m.sum().clamp_min(1)
    pos=((pred_cars[:,:,:3]-target_cars[:,:,:3]).square().sum(-1)/500**2*m).sum()/den
    vel=((pred_cars[:,:,7:10]-target_cars[:,:,7:10]).square().sum(-1)/1500**2*m).sum()/den
    p=F.normalize(pred_cars[:,:,3:7],dim=-1)
    q=F.normalize(target_cars[:,:,3:7],dim=-1)
    # q and -q are the SAME 3D orientation (double cover): dot^2 handles both.
    rot=((1-(p*q).sum(-1).square().clamp(max=1))*m).sum()/den
    bpos=(pred_ball[:,:3]-target_ball[:,:3]).square().sum(-1).mean()/700**2
    brot=1-(F.normalize(pred_ball[:,3:7],dim=-1)*
            F.normalize(target_ball[:,3:7],dim=-1)).sum(-1).square().clamp(max=1).mean()
    # Keep units balanced so the model cannot ignore boost, spin, or ball speed.
    spin = (((pred_cars[:,:,10:13]-target_cars[:,:,10:13]).square().sum(-1)/6**2)*m).sum()/den
    boost = (((pred_cars[:,:,13]-target_cars[:,:,13]).square())*m).sum()/den
    bvel = (pred_ball[:,7:10]-target_ball[:,7:10]).square().sum(-1).mean()/3000**2
    bspin = (pred_ball[:,10:13]-target_ball[:,10:13]).square().sum(-1).mean()/6**2
    return pos+0.3*vel+0.6*rot+0.15*spin+0.2*boost+0.4*bpos+0.15*bvel+0.02*brot+0.02*bspin


def tensors_from_replay(r,idx,device):
    # For a single replay, select frames by direct indices.
    n=len(idx)
    b=torch.as_tensor(r['ball'][idx],device=device,dtype=torch.float32)
    c=torch.as_tensor(r['cars'][idx],device=device,dtype=torch.float32)
    team=torch.as_tensor(r['team'],device=device,dtype=torch.long).expand(n,-1)
    box_ids=[HITBOXES.index(str(x)) if str(x) in HITBOXES else HITBOXES.index('unknown') for x in r['hitboxes']]
    box=torch.tensor(box_ids,device=device,dtype=torch.long).expand(n,-1)
    mask=torch.as_tensor(r['mask'],device=device,dtype=torch.bool).expand(n,-1)
    return b,c,team,box,mask
