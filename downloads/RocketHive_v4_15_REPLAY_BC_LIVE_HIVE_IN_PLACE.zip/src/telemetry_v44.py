"""Bounded local metric history; hosted W&B remains independent."""
from __future__ import annotations
import json
from pathlib import Path


def append_jsonl(path, values, max_bytes=32*1024*1024, keep=8):
    p=Path(path);p.parent.mkdir(parents=True, exist_ok=True)
    text=json.dumps(values, ensure_ascii=False, allow_nan=False)+'\n'
    if p.exists() and max_bytes>0 and p.stat().st_size+len(text.encode('utf-8')) > max_bytes:
        # Older numbered logs beyond `keep` are deleted; model and replay
        # files are never rotated here. W&B history is independent.
        p.with_name(p.name+f'.{keep}').unlink(missing_ok=True)
        for i in range(keep-1,0,-1):
            current=p.with_name(p.name+f'.{i}')
            target=p.with_name(p.name+f'.{i+1}')
            if current.exists():current.replace(target)
        p.replace(p.with_name(p.name+'.1'))
    with p.open('a',encoding='utf-8') as f:f.write(text)
