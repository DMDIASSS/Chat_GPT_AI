"""Rate-limited, resumable ballchasing.com public-replay downloader.

Credentials live only in process memory. No passwords are embedded in configs,
logs or ZIPs. API ranking compatibility is checked; we never silently relax SSL.
"""
from __future__ import annotations
import argparse
import email.utils
import json
import os
from pathlib import Path
import re
import time
from urllib.error import HTTPError, URLError
from urllib.parse import urlencode, urlparse, urlunparse
from urllib.request import Request, urlopen

API = 'https://ballchasing.com/api/replays'
WEBSITE = 'https://ballchasing.com/'
PLAYLISTS = ('ranked-duels', 'ranked-doubles', 'ranked-standard')  # website ids 10,11,13
REPLAY_ID = re.compile(r'^[0-9a-fA-F-]{12,80}$')

class UnsupportedRankFilter(Exception):
    """API docs may not accept website's numeric SSL rank=22."""


class RateLimited(Exception):
    def __init__(self, seconds):
        self.seconds = seconds
        super().__init__(f'HTTP 429; retry after {seconds:.0f}s')


def retry_seconds(headers, default=120.):
    v = headers.get('Retry-After') if headers else None
    if v:
        try: return max(1., min(7200., float(v)))
        except ValueError:
            try:
                from datetime import datetime, timezone
                dt=email.utils.parsedate_to_datetime(v)
                return max(1., min(7200., (dt-datetime.now(timezone.utc)).total_seconds()))
            except (TypeError, ValueError, OverflowError): pass
    return float(default)


def safe_url(url):
    """Prevent the supplied pagination URL from exfiltrating an API token."""
    p=urlparse(url)
    if p.scheme!='https' or p.hostname not in ('ballchasing.com','www.ballchasing.com') or \
       p.username or p.password or p.port or p.path!='/api/replays':
        raise ValueError('Unsafe next-page URL from API: '+url[:200])
    return url


def listing_url(rank='22'):
    """Rank 22 in site URL. API docs omit SSL; try literal 22 first.

    If the API does not accept numeric filters, it fails explicitly rather
    than substituting Grand Champion and contaminating the SSL dataset.
    """
    fields=[('playlist', s) for s in PLAYLISTS]
    fields += [('min-rank',rank),('max-rank',rank),('count','200'),('sort-by','upload-date'),('sort-dir','desc')]
    return API+'?'+urlencode(fields)


class BallchasingSync:
    def __init__(self, token, directory='replays/ballchasing_ssl', state_path='data/ballchasing_sync.json',
                 request_interval=1.2, timeout=35, transport=None, clock=None, sleep=None):
        if not token or not token.strip(): raise ValueError('Ballchasing API token required')
        self.token=token.strip()
        self.directory=Path(directory)
        self.state_path=Path(state_path)
        self.request_interval=max(1., float(request_interval))  # free-tier binary endpoint: 1/s
        self.timeout=timeout
        self.transport=transport or self._request
        self.website_transport=self._public_request
        self.clock=clock or time.monotonic
        self.sleep=sleep or time.sleep
        self.previous_call=None
        self.state=self._load()
        self.directory.mkdir(parents=True,exist_ok=True)

    def _load(self):
        if self.state_path.exists():
            try:
                x=json.loads(self.state_path.read_text(encoding='utf-8'))
                return {'next':x.get('next'), 'last_cycle':x.get('last_cycle',0),
                        'website_page':max(1,int(x.get('website_page',1))),
                        'listing_mode':x.get('listing_mode','api'),
                        'downloaded':int(x.get('downloaded',0)),'backoff':float(x.get('backoff',120))}
            except (ValueError,TypeError):pass
        return {'next':None,'last_cycle':0,'website_page':1,'listing_mode':'api',
                'downloaded':0,'backoff':120.}

    def _save(self):
        self.state_path.parent.mkdir(parents=True,exist_ok=True)
        tmp=self.state_path.with_suffix('.tmp')
        tmp.write_text(json.dumps(self.state,indent=2),encoding='utf-8')
        tmp.replace(self.state_path)

    def _request(self,url):
        req=Request(url,headers={'Authorization':self.token,'User-Agent':'RocketHive-v4/1.0',
                                 'Accept':'application/octet-stream, application/json'})
        with urlopen(req,timeout=self.timeout) as r:
            return r.read(), r.headers

    def _public_request(self,url):
        # Public website listing for the EXACT user's rank=22 URL, only when
        # the API rejects the website's numeric rank. NEVER send the API token.
        req=Request(url,headers={'User-Agent':'RocketHive-v4/1.0','Accept':'text/html'})
        with urlopen(req,timeout=self.timeout) as r:return r.read(),r.headers

    def public_listing(self, page=1):
        """Discover only SSL replay cards from the exact website filters.

        We do not treat "Supersonic Legend" somewhere in the page (e.g. the
        filter dropdown) as proof that EVERY linked replay is SSL. Each card
        must explicitly identify its own rank and playlist.
        """
        params=[('playlist','10'),('playlist','11'),('playlist','13'),
                ('min-rank','22'),('max-rank','22')]
        if page>1:params.append(('page',str(page)))
        url=WEBSITE+'?'+urlencode(params)
        try:raw,_=self.website_transport(url)
        except HTTPError as exc:
            if exc.code==429:raise RateLimited(retry_seconds(exc.headers,self.state['backoff'])) from None
            raise
        body=raw.decode('utf-8',errors='replace')
        anchors=list(re.finditer(r"href=[\"'](?:https://(?:www\.)?ballchasing\.com)?/replay/([0-9a-fA-F-]{36})",body,re.I))
        ids=[];seen=set()
        for i,match in enumerate(anchors):
            rid=match.group(1)
            if rid in seen or not REPLAY_ID.fullmatch(rid):continue
            stop=anchors[i+1].start() if i+1<len(anchors) else len(body)
            card=body[match.end():stop]
            ssl=re.search(r"(?:alt|title|aria-label|data-original-title)\s*=\s*[\"'][^\"']*Supersonic Legend\s*\(Game average rank\)[^\"']*[\"']",card,re.I)
            playlist=re.search(r'Ranked\s+(?:Duels|Doubles|Standard)(?:\s|<|&)',card,re.I)
            if ssl and playlist:
                seen.add(rid);ids.append(rid)
        if not ids:
            raise ValueError('No individually verified SSL replay cards on website page; '
                             'markup, badges, or pagination might have changed. '
                             'Refusing unverified downloads.')
        return [{'id':rid,'visibility':'public','website_card_verified':True} for rid in ids]

    def fetch(self,url):
        # Only known API host and endpoints are allowed to receive the token.
        p=urlparse(url)
        if p.scheme!='https' or p.hostname not in ('ballchasing.com','www.ballchasing.com') or \
           p.username or p.password or p.port or not p.path.startswith('/api/replays'):
            raise ValueError('Unsafe API URL')
        if self.previous_call is not None:
            delay=self.request_interval-(self.clock()-self.previous_call)
            if delay>0:self.sleep(delay)
        self.previous_call=self.clock()
        try:return self.transport(url)
        except HTTPError as exc:
            if exc.code==429:
                raise RateLimited(retry_seconds(exc.headers,self.state['backoff'])) from None
            if exc.code>=500:
                raise RateLimited(min(3600,self.state['backoff'])) from None
            if exc.code==400 and 'min-rank=' in url:
                raise UnsupportedRankFilter('Ballchasing API rejected rank=22; using public SSL website listing') from None
            raise
        except (URLError,TimeoutError):
            raise RateLimited(min(3600,self.state['backoff'])) from None

    def sync_once(self, max_new=50, max_pages=10):
        """One bounded pass, with persisted pagination. No network without a token.
        Returns new replay count; can be repeatedly called from continuous trainer.
        """
        new=0
        page=0
        while page<max_pages and new<max_new:
            from_website=self.state.get('listing_mode')=='website'
            if from_website:
                result={'list':self.public_listing(self.state.get('website_page',1)),'next':None}
            else:
                url=safe_url(self.state['next']) if self.state['next'] else listing_url()
                try:
                    raw,_=self.fetch(url)
                except UnsupportedRankFilter as exc:
                    print('[ballchasing]',exc,flush=True)
                    self.state['listing_mode']='website';self.state['next']=None
                    self._save()
                    result={'list':self.public_listing(self.state['website_page']),'next':None}
                    from_website=True
                else:result=json.loads(raw)
            if not isinstance(result.get('list'),list): raise ValueError('Invalid replay listing response')
            # Persist cursor only AFTER all entries from that page have completed,
            # so interruption never loses an un-downloaded replay.
            for rec in result['list']:
                rid=str(rec.get('id',''))
                if not REPLAY_ID.fullmatch(rid):continue
                path=self.directory/(rid+'.replay')
                if path.exists() and path.stat().st_size>256:continue
                # Must be public and match the selected playlist. The API itself
                # performs the exact rank filter; do not infer rank from metadata.
                if rec.get('visibility') not in (None,'public'):continue
                if rec.get('playlist_id') not in (None,*PLAYLISTS):continue
                try:blob,_=self.fetch(API+'/'+rid+'/file')
                except HTTPError as exc:
                    if exc.code in (403,404,410):
                        print(f'[ballchasing] replay {rid} inaccessible ({exc.code}); skipping',flush=True)
                        continue
                    raise
                if len(blob)<256 or blob[:1]==b'{':raise ValueError('Downloaded data does not look like a replay: '+rid)
                temp=path.with_suffix('.partial')
                temp.write_bytes(blob);temp.replace(path)
                self.state['downloaded']+=1
                self._save()
                new+=1
                if new>=max_new:
                    # Start same page again next pass, existing files are skipped.
                    break
            else:
                next_url=result.get('next')
                if from_website:
                    # Website fallback pagination is best-effort; on an empty/new
                    # cycle the next invocation can retry recent uploads.
                    self.state['website_page']+=1
                    if self.state['website_page']>1000:
                        self.state['website_page']=1
                        self.state['last_cycle']=time.time()
                else:
                    self.state['next']=safe_url(next_url) if next_url else None
                    self.state['last_cycle']=time.time() if not next_url else self.state['last_cycle']
                self._save();page+=1
                if not next_url and not from_website:break
                continue
            break
        self.state['backoff']=120.
        # A scan with 0 new downloads must not reset the website page cursor;
        # that would starve the older pages indefinitely.
        self._save()
        return new

    def run(self, max_new_per_pass=50, idle_seconds=1800., stop=None, on_new=None):
        stop=stop or (lambda:False)
        while not stop():
            try:
                n=self.sync_once(max_new_per_pass)
                if n and on_new:on_new(n)
                if n==0:self.sleep(idle_seconds)
            except RateLimited as ex:
                self.state['backoff']=min(3600,max(ex.seconds*2,self.state['backoff']*2))
                self._save()
                print(f'[ballchasing] rate limited; pausing {ex.seconds:.0f}s',flush=True)
                self.sleep(ex.seconds)


def main():
    a=argparse.ArgumentParser()
    a.add_argument('--max-new',type=int,default=50)
    a.add_argument('--watch',action='store_true')
    opt=a.parse_args()
    token=os.environ.get('BALLCHASING_TOKEN','')
    if not token:raise SystemExit('Set BALLCHASING_TOKEN in this process, or use START_V4.bat (popup).')
    s=BallchasingSync(token)
    try:
        if opt.watch:s.run(opt.max_new)
        else:print('Downloaded:',s.sync_once(opt.max_new))
    except KeyboardInterrupt:pass

if __name__=='__main__':main()
