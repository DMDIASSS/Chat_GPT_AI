"""Model export: .pt is weights, TorchScript, ONNX; .toml is metadata/config.

No export here creates valid RLBot driving inputs from replay pose forecasts.
"""
import json
from pathlib import Path
import torch
from .models import JointForecaster,StateEvaluator

def export():
    out=Path('models')
    p=out/'pose_forecaster.pt'
    if not p.exists():raise FileNotFoundError('Train first: '+str(p))
    ck=torch.load(p,map_location='cpu',weights_only=True)
    m=JointForecaster(int(ck['model_dim']));m.load_state_dict(ck['state_dict']);m.eval()
    dummy=(torch.zeros(1,13),torch.zeros(1,6,14),torch.tensor([[0,0,0,1,1,1]]),
           torch.zeros(1,6,dtype=torch.long),torch.tensor([[True]*6]))
    # valid quaternion to normalize
    dummy[0][:,3]=1;dummy[1][:,:,3]=1
    # Keep the attention implementation stable between trace and validation.
    # PyTorch's inference fastpath may otherwise swap graph operators across runs.
    torch.backends.mha.set_fastpath_enabled(False)
    with torch.no_grad():
        traced=torch.jit.trace(m,dummy,strict=False,check_trace=False)
    traced.save(str(out/'pose_forecaster_torchscript.pt'))
    with torch.no_grad():
        a,b=m(*dummy);c,d=traced(*dummy)
        assert torch.allclose(a,c,atol=2e-3,rtol=1e-4) and torch.allclose(b,d,atol=2e-3,rtol=1e-4), 'TorchScript disagrees with PyTorch'
    try:
        import onnx
        torch.onnx.export(m,dummy,str(out/'pose_forecaster.onnx'),opset_version=17,
                          dynamo=False,input_names=['ball','cars','team','hitbox','mask'],
                          output_names=['future_ball','future_cars'],
                          dynamic_axes={x:{0:'batch'} for x in ('ball','cars','team','hitbox','mask','future_ball','future_cars')})
        print('Exported ONNX.')
    except Exception as ex:
        print('Optional ONNX export skipped:',ex)
        print('To enable: .venv\\Scripts\\python.exe -m pip install onnx')
    value_p=out/'goal_evaluator_PROXY.pt'
    if value_p.exists():
        vck=torch.load(value_p,map_location='cpu',weights_only=True)
        v=StateEvaluator(int(vck['model_dim']));v.load_state_dict(vck['state_dict']);v.eval()
        with torch.no_grad():
            torch.jit.trace(v,dummy,strict=False,check_trace=False).save(str(out/'goal_evaluator_PROXY_torchscript.pt'))
    manifest={'model_type':'future_state_forecast_not_controller','fps':ck['fps'],
              'horizon_s':ck['horizon_s'],'rlbot4_action_policy':False,
              'rlbot5_action_policy':False,'arena':'Soccar',
              'notes':'Do not use this checkpoint as a driving controller. A physics-control RL stage is required.'}
    (out/'model_manifest.json').write_text(json.dumps(manifest,indent=2),encoding='utf-8')
    (out/'model_info.toml').write_text('''# Metadata/config only: TOML is NOT trained neural-network weights.
[model]
kind = "replay_pose_forecaster_not_controller"
weights = "pose_forecaster.pt"
torchscript = "pose_forecaster_torchscript.pt"
platform = "offline_pose_prediction"
rlbot_v4_drivable = false
rlbot_v5_drivable = false
arena = "Soccar"
''',encoding='utf-8')
    print('Model weights and metadata in',out.resolve())
if __name__=='__main__':export()
