"""Strict 120 Hz reconstructed-input labels; never upsample 15 Hz poses into buttons."""
from pathlib import Path
import hashlib,json
import numpy as np
from .replicar_dataset import normalize_arrays,verified_players,read_catalog
from .hitboxes import load_overrides
from .search_teacher import replay_state,make_observation
from .dataset import dataset_split

def chunk_examples(f,players,limit=256):
    a=f.arrays();data=normalize_arrays(f,players,120.)
    ticks=np.asarray(a.get('sim_tick',[]));n=len(data['time'])
    if len(ticks)!=n or n<33:raise ValueError('Need sim_tick and at least 33 rows of native 120 Hz controls')
    delta=np.diff(ticks)
    if np.count_nonzero(delta==1)<.9*len(delta):raise ValueError('File is not 120 Hz. Reconvert raw replays with --tick-step 1; 15 Hz inputs are not interpolated.')
    keys=['car_controls_'+s for s in ('throttle','steer','pitch','yaw','roll','jump','boost','handbrake')]
    if any(k not in a for k in keys):raise ValueError('Replicar reconstructed controls are absent; pose-only data is not an action dataset')
    candidates=np.arange(0,n-32,8);rng=np.random.default_rng(415);rng.shuffle(candidates)
    xs=[];ys=[];values=[];known=[];sources=[]
    goals=np.asarray(data['goal_rows']);teams=np.asarray(data['goal_teams'])
    for start in candidates:
        if not data['valid'][start:start+33].all() or not (data['segment'][start:start+33]==data['segment'][start]).all() or not (delta[start:start+32]==1).all():continue
        state=replay_state(data,int(start));future=goals[(goals>start)&(data['segment'][goals]==data['segment'][start])]
        for slot,p in enumerate(players):
            control=np.stack([np.asarray(a[k])[start:start+32,p['index']] for k in keys],1).astype(np.float32)
            if not np.isfinite(control).all() or (abs(control[:,:5])>1.001).any() or not np.isin(control[:,5:],[0,1]).all():continue
            if len(future):
                row=int(future[0]);goal_team=int(teams[np.flatnonzero(goals==row)[0]]);v=(1 if goal_team==(0 if slot<len(players)//2 else 1) else -1)*np.exp(-(data['time'][row]-data['time'][start])/5.);is_known=True
            else:v=0.;is_known=False # censored tails are not fake no-goal outcomes
            xs.append(make_observation(state,slot));ys.append(control);values.append(v);known.append(is_known);sources.append(int(start))
            if len(xs)>=limit:return dict(obs=np.asarray(xs,np.float32),actions=np.asarray(ys,np.float32),value=np.asarray(values,np.float32),value_known=np.asarray(known,bool),rows=np.asarray(sources))
    if not xs:raise ValueError('No valid complete tick-level input chunks')
    return dict(obs=np.asarray(xs,np.float32),actions=np.asarray(ys,np.float32),value=np.asarray(values,np.float32),value_known=np.asarray(known,bool),rows=np.asarray(sources))

def build(root='.',limit=256,max_files=300):
    import replicar
    root=Path(root).resolve();catalog=read_catalog(root);overrides=load_overrides(root/'replays/hitboxes.csv');out=root/'data/v415_chunks';report=[]
    files=sorted(set((root/'replicar_120hz').rglob('*.parquet'))|set((root/'replicar_parquet').rglob('*.parquet')))[:max_files]
    for p in files:
        row=dict(file=str(p))
        try:
            digest=hashlib.sha256(p.read_bytes()).hexdigest();split=dataset_split(digest)
            target=out/split/(digest+'.npz');target.parent.mkdir(parents=True,exist_ok=True)
            if target.is_file():row.update(status='cached',split=split);report.append(row);continue
            f=replicar.read(p);players=verified_players(f.header,p.name,overrides,catalog)
            if any(q['hitbox']=='unknown' for q in players):raise ValueError('Unverified car hitbox; review existing hitboxes CSV')
            data=chunk_examples(f,players,limit);temp=target.with_suffix('.tmp.npz')
            np.savez_compressed(temp,**data,source_sha256=digest,label_source='Replicar inferred controls, not recorded human buttons');temp.replace(target)
            row.update(status='accepted',split=split,chunks=len(data['obs']),known_values=int(data['value_known'].sum()))
        except (ValueError,KeyError,OSError,IndexError) as e:row.update(status='rejected',reason=str(e))
        report.append(row);print('[replay chunks]',row,flush=True)
    (root/'reports').mkdir(exist_ok=True);(root/'reports/v415_chunk_import.json').write_text(json.dumps(report,indent=2))
    if not files:raise ValueError('No Parquet replays. Use CONVERT_REPLAYS_120HZ.bat or put tick-step=1 Parquets in replicar_120hz/')
    return report
