"""Physics-replay tracking reward components for later PPO integration.

These routines are complete pure-numpy functions, but wiring them into
RocketChad3/RocketGPU must respect its batched CUDA callback interface.
Do NOT apply their 'target' states directly as car position commands.
"""
import numpy as np


def quaternion_error(q1,q2):
    q1=np.asarray(q1,dtype=float);q2=np.asarray(q2,dtype=float)
    a=q1/np.maximum(np.linalg.norm(q1,axis=-1,keepdims=True),1e-9)
    b=q2/np.maximum(np.linalg.norm(q2,axis=-1,keepdims=True),1e-9)
    return 1.0-np.clip(np.sum(a*b,axis=-1)**2,0,1)


def interpolate_pose(times,poses,t):
    """Interpolate 14-d player pose by real timestamps, including shortest quaternion."""
    times=np.asarray(times);poses=np.asarray(poses)
    if t<=times[0]:return poses[0].copy()
    if t>=times[-1]:return poses[-1].copy()
    upper=int(np.searchsorted(times,t,side='right'));low=upper-1
    f=(float(t)-float(times[low]))/float(times[upper]-times[low]);p=poses[low]*(1-f)+poses[upper]*f
    a=poses[low,3:7];b=poses[upper,3:7]
    if np.dot(a,b)<0:b=-b
    q=(1-f)*a+f*b;q=q/max(np.linalg.norm(q),1e-8)
    p[3:7]=q
    return p


def track_reward(current,target,position_scale=500,velocity_scale=1000):
    """Dense reward requires same-time reference, called for each active car."""
    c=np.asarray(current);ref=np.asarray(target)
    dist=np.linalg.norm(c[:3]-ref[:3])
    vel=np.linalg.norm(c[7:10]-ref[7:10])
    ang=float(quaternion_error(c[3:7],ref[3:7]))
    return float(np.exp(-dist/position_scale)+0.5*(1-ang)+0.3*np.exp(-vel/velocity_scale))


def deviation_terminal(current,target,max_pos_error=1200,max_angle_error=0.95):
    """Per-player deviation test, caller decides any-vs-all group termination."""
    return (np.linalg.norm(np.asarray(current)[:3]-np.asarray(target)[:3])>max_pos_error or
            quaternion_error(np.asarray(current)[3:7],np.asarray(target)[3:7])>max_angle_error)
