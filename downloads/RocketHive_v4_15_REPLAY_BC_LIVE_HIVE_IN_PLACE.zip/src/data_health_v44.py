"""Read-only NPZ dataset audit with replay-level leakage detection."""
from __future__ import annotations
from collections import Counter
import json
from pathlib import Path
import numpy as np


def audit(base='data', max_files=None):
    base = Path(base)
    result = {'train_files':0,'val_files':0,'modes':{},'hitboxes':{},
              'valid_frames':0,'invalid_frames':0,'goal_events':0,
              'flip_reset_events':0,'errors':[],'warnings':[],
              'split_source_collisions':[]}
    modes, boxes = Counter(), Counter()
    sources = {'train':set(),'val':set()}
    for split in ('train','val'):
        paths = sorted((base/split).glob('*.npz'))
        if max_files is not None: paths=paths[:int(max_files)]
        result[split+'_files'] = len(paths)
        for path in paths:
            try:
                with np.load(path,allow_pickle=False) as r:
                    required={'time','ball','cars','valid','hitboxes','team','mask','mode'}
                    if not required.issubset(r.files):
                        raise ValueError('Missing fields: '+str(sorted(required.difference(r.files))))
                    n=len(r['time']); ball=r['ball']; cars=r['cars']; valid=r['valid']
                    if ball.shape!=(n,13) or cars.shape!=(n,6,14) or valid.shape!=(n,):
                        raise ValueError('Wrong ball/car/valid shapes')
                    if not np.all(np.isfinite(ball[valid])) or not np.all(np.isfinite(cars[valid])):
                        raise ValueError('Nonfinite valid states')
                    if (np.diff(r['time'])<=0).any():
                        result['warnings'].append(path.name+': nonmonotonic timestamps')
                    num=int(valid.sum())
                    result['valid_frames']+=num
                    result['invalid_frames']+=n-num
                    mode=int(r['mode'])
                    if mode not in (1,2,3):raise ValueError('Invalid player count')
                    modes[str(mode)+'v'+str(mode)]+=1
                    for h in r['hitboxes'][:2*mode]:boxes[str(h)]+=1
                    result['goal_events']+=len(r['goal_rows']) if 'goal_rows' in r.files else 0
                    result['flip_reset_events']+=len(r['flip_reset_rows']) if 'flip_reset_rows' in r.files else 0
                    source=str(r['source'].item()) if 'source' in r.files else path.name
                    if source in sources[split]:
                        result['warnings'].append('Duplicate replay within '+split+': '+source)
                    sources[split].add(source)
            except (ValueError,KeyError,OSError,EOFError) as exc:
                result['errors'].append(path.name+': '+str(exc)[:180])
    result['modes']=dict(modes)
    result['hitboxes']=dict(boxes)
    result['split_source_collisions']=sorted(sources['train'] & sources['val'])
    if result['split_source_collisions']:
        result['warnings'].append('Train/validation leakage: matching replay sources found')
    result['ok']=not result['errors'] and not result['split_source_collisions']
    return result


def write_audit(report, path='reports/v4_data_audit.json'):
    p=Path(path);p.parent.mkdir(parents=True,exist_ok=True)
    tmp=p.with_suffix('.new')
    tmp.write_text(json.dumps(report,indent=2),encoding='utf-8')
    tmp.replace(p)
    return p
