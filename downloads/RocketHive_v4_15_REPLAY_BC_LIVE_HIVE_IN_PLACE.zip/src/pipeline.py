import argparse
from pathlib import Path
import json
from .dataset import parse_folder as parse_subtr_folder
from .replicar_dataset import parse_folder as parse_replicar_folder
from .train import train

def main():
    p=argparse.ArgumentParser()
    p.add_argument('--config',default='config.json');p.add_argument('--skip-parse',action='store_true')
    a=p.parse_args();cfg=json.loads(Path(a.config).read_text(encoding='utf-8'))
    if cfg.get('arena')!='soccar':raise ValueError('Only standard Soccar is supported')
    Path('reports').mkdir(exist_ok=True)
    if not a.skip_parse:
        if cfg.get('replay_backend') == 'replicar_v2':
            accepted=parse_replicar_folder('replays','data',cfg)
        elif cfg.get('replay_backend') == 'subtr_actor_legacy':
            accepted=parse_subtr_folder('replays','data',cfg['fps'],cfg['hitbox_filter'],
                                       cfg.get('allow_unknown_map',False))
        else:
            raise ValueError('Unknown replay_backend. Use replicar_v2 or subtr_actor_legacy.')
        if not accepted:raise RuntimeError('No accepted replay; see data/parse_report.json and README')
    train('data','models',cfg)
    print('Saved models are trajectory predictors, NOT playable RLBot action policies.')
    print('Next: EXPORT_MODELS.bat, WATCH_REPLAY.bat, optional WATCH_RLVISER.bat')
if __name__=='__main__':main()
