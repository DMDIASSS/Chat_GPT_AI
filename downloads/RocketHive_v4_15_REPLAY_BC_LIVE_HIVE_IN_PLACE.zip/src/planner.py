"""Joint adversarial search skeleton. Requires a real simulator to select car controls.

Users supply all three callbacks. No unphysical pose teleportation is used here.
"""
from dataclasses import dataclass
from typing import Any,Callable

@dataclass
class PlanResult:
    team_plan:Any
    robust_score:float
    average_score:float
    worst_score:float
    num_rollouts:int


def joint_minimax_search(state,team_plan_sampler,opponent_reply_sampler,simulate,evaluate,
                         team_candidates=16,opponent_responses=4,risk=0.6):
    """Sample coordinated full-team plans and plausible opponent joint replies.

    simulate(state, plan, reply) MUST simulate real car controls with physics;
    evaluate(next_state) returns scalar for *our* team. Neither is stubbed.
    risk=1 -> conservative worst-response; 0 -> mean response.
    """
    if team_candidates<1 or opponent_responses<1:raise ValueError('candidate counts must be positive')
    if not 0<=risk<=1:raise ValueError('risk must be in [0,1]')
    best=None;calls=0
    for _ in range(team_candidates):
        plan=team_plan_sampler(state)   # one plan includes ALL controlled teammates
        scores=[]
        for _ in range(opponent_responses):
            reply=opponent_reply_sampler(state,plan)
            future=simulate(state,plan,reply)
            scores.append(float(evaluate(future)));calls+=1
        worst=min(scores);avg=sum(scores)/len(scores)
        robust=risk*worst+(1-risk)*avg
        if best is None or robust>best.robust_score:
            best=PlanResult(plan,robust,avg,worst,calls)
    best.num_rollouts=calls
    return best
