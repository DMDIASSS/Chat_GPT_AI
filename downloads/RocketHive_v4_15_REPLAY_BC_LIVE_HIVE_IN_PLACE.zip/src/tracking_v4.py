"""Time-aligned multi-entity replay tracking for *physics-generated* rollouts.

No replay buttons or post-hoc reconstructed inputs are given to the policy.
Normalizes position, velocity, angular velocity, quaternion attitude and ball
spin; terminates hard deviations to prevent reward from off-trajectory clips.
"""
from dataclasses import dataclass
import numpy as np
from .tracking import quaternion_error,interpolate_pose

@dataclass
class TrackingWeights:
    car_pos:float=1.0
    car_vel:float=0.35
    car_angle:float=0.4
    car_spin:float=0.15
    car_boost:float=0.18
    ball_pos:float=0.6
    ball_vel:float=0.25
    ball_spin:float=0.1
    ball_angle:float=0.05


def entity_similarity(x,y,is_ball=False):
    x=np.asarray(x,dtype=float);y=np.asarray(y,dtype=float)
    if len(x)<13 or len(y)<13:raise ValueError('Need pose, angular velocity and quaternion')
    p=np.exp(-np.linalg.norm(x[:3]-y[:3])/(700 if is_ball else 450))
    v=np.exp(-np.linalg.norm(x[7:10]-y[7:10])/(2200 if is_ball else 1200))
    theta=1.-float(quaternion_error(x[3:7],y[3:7]))
    w=np.exp(-np.linalg.norm(x[10:13]-y[10:13])/5.)
    return p,v,theta,w


def replay_score(cur_ball,cur_cars,ref_ball,ref_cars,weights=None,mask=None):
    weights=weights or TrackingWeights()
    cb=np.asarray(cur_ball);rc=np.asarray(ref_cars)
    cc=np.asarray(cur_cars);rb=np.asarray(ref_ball)
    if cc.shape!=rc.shape:raise ValueError('Every teammate/opponent must be aligned')
    if mask is None:mask=np.ones(len(cc),dtype=bool)
    b=entity_similarity(cb,rb,True)
    score=weights.ball_pos*b[0]+weights.ball_vel*b[1]+weights.ball_angle*b[2]+weights.ball_spin*b[3]
    selected=[entity_similarity(cc[i],rc[i]) for i in range(len(cc)) if mask[i]]
    if selected:
        terms=np.asarray(selected).mean(axis=0)
        score+=weights.car_pos*terms[0]+weights.car_vel*terms[1]+weights.car_angle*terms[2]+weights.car_spin*terms[3]
        # 14th element is normalized boost (0..1). Previously ignored by the
        # short-horizon search teacher despite being stored in the replay.
        if cc.shape[1] >= 14 and rc.shape[1] >= 14:
            boost_match=np.exp(-np.abs(cc[np.asarray(mask),13]-rc[np.asarray(mask),13])/0.20)
            score+=weights.car_boost*float(np.mean(boost_match))
    return float(score)


def should_terminate(cur_ball,cur_cars,ref_ball,ref_cars,mask=None,
                     max_car_error=1200,max_ball_error=1500,max_angle_error=0.98):
    if np.linalg.norm(np.asarray(cur_ball)[:3]-np.asarray(ref_ball)[:3])>max_ball_error:return True
    if mask is None:mask=np.ones(len(cur_cars),bool)
    for i in np.flatnonzero(mask):
        if np.linalg.norm(cur_cars[i,:3]-ref_cars[i,:3])>max_car_error:return True
        if quaternion_error(cur_cars[i,3:7],ref_cars[i,3:7])>max_angle_error:return True
    return False


class TimeAlignedEpisode:
    """Absolute replay timestamps; the entire joint clip ends at first deviation."""
    def __init__(self,data,start_frame,end_frame,weights=None,
                 max_car_error=1200,max_ball_error=1500):
        self.data=data;self.start=int(start_frame);self.end=int(end_frame)
        self.weights=weights or TrackingWeights()
        self.max_car_error=max_car_error;self.max_ball_error=max_ball_error
        valid=np.asarray(data['valid'][self.start:self.end+1],bool)
        if not valid.all():raise ValueError('Clip contains non-active/invalid frames')
        seg=np.asarray(data['segment'][self.start:self.end+1]) if 'segment' in data else None
        if seg is not None and (seg!=seg[0]).any():raise ValueError('Clip crosses kickoff')
        self.t0=float(data['time'][self.start]);self.t1=float(data['time'][self.end]);self.done=False

    def reference(self,elapsed):
        t=self.t0+float(elapsed)
        times=np.asarray(self.data['time'][self.start:self.end+1])
        ball=interpolate_pose(times,np.asarray(self.data['ball'][self.start:self.end+1]),t)
        cars=np.asarray([interpolate_pose(times,self.data['cars'][self.start:self.end+1,i],t)
                         for i in range(self.data['cars'].shape[1])])
        return ball,cars

    def step(self,elapsed,ball,cars):
        if self.done:return 0.,True
        if self.t0+elapsed>=self.t1:
            self.done=True
            return 0.,True
        b,c=self.reference(elapsed)
        m=np.asarray(self.data['mask'],bool)
        terminated=should_terminate(ball,cars,b,c,m,self.max_car_error,self.max_ball_error)
        if terminated:
            self.done=True
            return -0.25,True
        return replay_score(ball,cars,b,c,self.weights,m),False
