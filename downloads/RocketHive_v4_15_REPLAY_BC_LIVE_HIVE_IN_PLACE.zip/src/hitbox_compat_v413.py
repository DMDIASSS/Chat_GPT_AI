"""Diagnose real car-hitbox support and filter incompatible replay clips.

This module does not alter model weights, replay data, or model checkpoints.
The only automatic response to an unsupported preset is to omit that replay
from *this* action-teacher run, while preserving the original file on disk.
"""
from __future__ import annotations

from collections import Counter
from datetime import datetime, timezone
import json
from pathlib import Path
import numpy as np

from .physics_search import HITBOX_PRESETS, UnsupportedHitboxError, configure_car


def probe_hitboxes(rs, create_arena):
    """Exercise the actual add_car binding for each independently named preset.

    Checking hasattr(rs, 'DOMINUS') alone is insufficient: a native binding
    might export that symbol but reject it in add_car().
    """
    supported = []
    unsupported = {}
    if not hasattr(rs, 'Team') or not hasattr(rs.Team, 'BLUE'):
        raise RuntimeError('RocketSim Team.BLUE is unavailable')
    for hitbox in HITBOX_PRESETS:
        arena = create_arena(rs)
        try:
            configure_car(arena, rs, rs.Team.BLUE, hitbox)
        except UnsupportedHitboxError as exc:
            unsupported[hitbox] = str(exc)
        else:
            supported.append(hitbox)
    return supported, unsupported


def filter_replays(paths, supported):
    """Filter entire clips if even one active car has unsupported physics.

    This is safer than replacing a single Dominus with Octane. It also avoids
    retrying a known-incompatible replay in an indefinite training loop.
    """
    supported = set(supported)
    accepted = []
    omitted = []
    for p in paths:
        p = Path(p)
        try:
            with np.load(p, allow_pickle=False) as data:
                if 'hitboxes' not in data.files or 'mode' not in data.files:
                    raise ValueError('missing hitboxes or game mode')
                n = 2 * int(np.asarray(data['mode']).item())
                hitboxes = np.asarray(data['hitboxes']).astype(str).ravel()
                if n not in (2, 4, 6) or len(hitboxes) < n:
                    raise ValueError('invalid number of active hitboxes')
                missing = sorted(set(hitboxes[:n]) - supported)
                if missing:
                    omitted.append((p.name, 'unsupported native hitbox: ' + ', '.join(missing)))
                else:
                    accepted.append(p)
        except (OSError, ValueError, KeyError, TypeError) as exc:
            omitted.append((p.name, f'bad replay metadata: {type(exc).__name__}: {exc}'))
    return accepted, omitted


def save_report(path, rs, supported, unsupported, usable, omitted):
    """Write diagnostics without API tokens or sensitive environment variables."""
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    summary = {
        'created_utc': datetime.now(timezone.utc).isoformat(),
        'binding_file': str(getattr(rs, '__file__', 'unknown')),
        'supported_hitboxes': list(supported),
        'unsupported_hitboxes': dict(unsupported),
        'usable_replay_count': len(usable),
        'excluded_replay_count': len(omitted),
        'excluded_reason_counts': dict(Counter(reason for _, reason in omitted)),
        'excluded_replays': [{'file': name, 'reason': reason} for name, reason in omitted],
        'fallback_hitbox_substitutions': 0,
    }
    tmp = path.with_suffix(path.suffix + '.tmp')
    tmp.write_text(json.dumps(summary, indent=2), encoding='utf-8')
    tmp.replace(path)
    return summary
