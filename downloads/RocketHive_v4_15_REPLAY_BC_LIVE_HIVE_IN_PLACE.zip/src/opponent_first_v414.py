"""Two-ply opponent-first, maximin sequence search for all players.

First sample each opponent car's 12..64 multi-action candidates in the same
physics world. Rank joint opponent combinations against several ACTIVE ally
probes; keep the strongest threats. THEN search our joint actions against all
retained threats. Train Blue and Orange from their own perspectives.

A short horizon never certifies 'best' in full Rocket League. Opponents are
selected as worst cases from the *sampled pool*, not magically optimal play.
"""
from __future__ import annotations
from dataclasses import dataclass
import math
import time
from typing import Sequence
import numpy as np

from .sequence_search_v412 import (SequenceSearch, SequenceResult, motion_candidates,
    trajectory_rating, parsed_motion_stages, motion_class)
from .evaluation_v414 import make_evaluator


@dataclass
class TeamSearch:
    team:int
    allied_plan:tuple
    enemy_threats:tuple
    enemy_rankings:tuple
    robust_value:float
    mean_value:float
    search_rollouts:int
    runner_up:tuple|None=None
    runner_up_value:float|None=None
    selected_pool_index:int|None=None
    top2_prior_regret:float|None=None
    top2_prior_contains_best:bool|None=None


class OpponentFirstSearch(SequenceSearch):
    """Bounded game-theoretic best reply to an opponent shortlist."""
    def __init__(self,simulator,candidates=12,segments=3,ticks_per_segment=8,
                 opponent_responses=4, ally_probes=3, evaluator=None,
                 replay_weight=0.02, seed=0, proposer=None, adversarial_refinement=1):
        super().__init__(simulator,candidates,segments,ticks_per_segment,1,seed)
        if not 1<=opponent_responses<=min(16,candidates):raise ValueError('Invalid opponent response count')
        if not 2<=ally_probes<=min(6,candidates):raise ValueError('Need >=2 non-idle ally probes')
        if not 0<=replay_weight<=0.10:raise ValueError('Replay term must be small')
        self.opponent_responses=int(opponent_responses)
        self.ally_probes=int(ally_probes)
        self.evaluator=evaluator if evaluator is not None else make_evaluator({'game_evaluator':'physics_proxy'})
        self.replay_weight=float(replay_weight)
        self.proposer=proposer
        self.adversarial_refinement=max(0,min(2,int(adversarial_refinement)))
        self._proposal_stats={}

    def _joint_pool(self,initial_state,references,team,individual_pools=None):
        """At most 12..64 joint plans PER TEAM, never a Cartesian product."""
        mode=int(initial_state['mode']);count=self.candidates
        players=list(range(team*mode,(team+1)*mode))
        pools=[]
        for player in players:
            if individual_pools is not None:
                pool=[tuple(proposal.actions) for proposal in individual_pools[player]]
                self._proposal_stats[player]={
                    'candidate_count':len(pool),
                    'first_action_diversity':len(set(p[0] for p in pool)),
                    'source':type(self.proposer).__name__,
                }
            else:
                pool,_=motion_candidates(self.rng,initial_state,player,references,count,self.segments)
                self._proposal_stats[player]={'candidate_count':len(pool),
                    'first_action_diversity':len(set(p[0] for p in pool)),
                    'source':'legacy_replay_motion'}
            if len(pool)<count:
                raise ValueError('Not enough candidates for player '+str(player))
            pools.append(pool)
        # Use co-prime strides to cover individual players' high-ranking plans
        # without multiplying 64^6 possible combinations. First joint plan
        # always uses each player's top proposal.
        joint=[]
        for k in range(count):
            parts=[]
            for j,pool in enumerate(pools):
                if j==0:idx=k
                else:
                    stride=2*j+1
                    while math.gcd(stride,count)!=1:stride+=2
                    idx=(k*stride)%count
                parts.append(pool[idx])
            joint.append(tuple(parts))
        return joint

    @staticmethod
    def _assemble(mode,team,ally,enemy):
        """Global car order is Blue then Orange regardless of viewpoint."""
        if len(ally)!=mode or len(enemy)!=mode:raise ValueError('Incomplete team plan')
        return tuple(ally+enemy) if team==0 else tuple(enemy+ally)

    def _value(self,states,references,team):
        # score() is from Blue's perspective; the sign changes for Orange.
        adv=float(self.evaluator.score(states[-1]))
        if not math.isfinite(adv) or abs(adv)>1.00001:
            raise ValueError('Evaluator must return finite Blue-advantage value in [-1,1]')
        utility=adv if team==0 else -adv
        if references is not None and self.replay_weight:
            # Small mechanics term only when replay reference is supplied.
            # NEVER train by feeding future replay states to the live policy.
            similarity=trajectory_rating(states,references)
            utility+=self.replay_weight*max(-3.,min(4.,similarity))
        return utility

    def search_one_team(self,state,references,team,pools=None):
        mode=int(state['mode']);rollouts=0
        if pools is None:pools=(self._joint_pool(state,references,0),self._joint_pool(state,references,1))
        ally_pool=pools[team];enemy_pool=pools[1-team]
        # Important: opponent candidate ranking does NOT assume our cars are
        # stationary. Use multiple active, dissimilar ally probes.
        distinct=[i for i in [1,self.candidates//2,self.candidates-1,2,self.candidates//3]
                  if 0<=i<self.candidates]
        indices=[]
        for idx in distinct:
            if idx not in indices:indices.append(idx)
            if len(indices)==self.ally_probes:break
        if len(indices)<self.ally_probes:
            for idx in range(self.candidates):
                if idx not in indices:indices.append(idx)
                if len(indices)>=self.ally_probes:break
        probes=[ally_pool[i] for i in indices]
        rankings=[]
        for enemy_id,enemy in enumerate(enemy_pool):
            utilities=[]
            for ally in probes:
                world=self._assemble(mode,team,ally,enemy)
                outcome=self.rollout(state,world)
                utilities.append(self._value(outcome,None,team))
                rollouts+=1
            # Low utility for us is GOOD for the enemy. Min over ACTIVE probes
            # keeps both aggressive and opportunistic enemy threats.
            danger=0.75*min(utilities)+0.25*float(np.mean(utilities))
            rankings.append((danger,enemy_id))
        rankings.sort(key=lambda t:(t[0],t[1]))
        threat_indices=[idx for _,idx in rankings[:self.opponent_responses]]
        # First opponents are ranked against actively moving ally probes.
        # Only after that does the allied planner choose its response.
        outcome_cache={}
        def utility(ally_id,enemy_id):
            nonlocal rollouts
            pair=(ally_id,enemy_id)
            if pair not in outcome_cache:
                world=self._assemble(mode,team,ally_pool[ally_id],enemy_pool[enemy_id])
                state_list=self.rollout(state,world)
                outcome_cache[pair]=self._value(state_list,references,team)
                rollouts+=1
            return outcome_cache[pair]
        def rank_responses(threat_ids):
            scores=[]
            for ally_id in range(len(ally_pool)):
                values=[utility(ally_id,enemy_id) for enemy_id in threat_ids]
                scores.append((min(values),float(np.mean(values)),ally_id))
            scores.sort(key=lambda entry:(-entry[0],-entry[1],entry[2]))
            return scores
        scores=rank_responses(threat_indices)
        # Optional bounded double-oracle check: if our top response has a
        # worse counter among the full feasible enemy shortlist, add it and
        # re-optimize. This also catches enemies whose threat is specifically
        # strong against OUR choice rather than against generic ally probes.
        for _ in range(self.adversarial_refinement):
            chosen=scores[0][2]
            counters=sorted((utility(chosen,ei),ei) for ei in range(len(enemy_pool)))
            worst_value,worst_id=counters[0]
            if worst_id in threat_indices:break
            threat_indices.append(worst_id)
            scores=rank_responses(threat_indices)
        best=scores[0];runner=scores[1] if len(scores)>1 else None
        prior_top2=max(sc[0] for sc in scores if sc[2]<2)
        # This compares proposer-ranked top two JOINT plans with the search's
        # best found plan among the current 12..64, NOT global optimal play.
        regret=max(0.,float(best[0]-prior_top2))
        recall=bool(best[2]<2)
        return TeamSearch(team,tuple(ally_pool[best[2]]),tuple(threat_indices),
                          tuple((float(s),int(i)) for s,i in rankings),
                          best[0],best[1],rollouts,
                          runner_up=tuple(ally_pool[runner[2]]) if runner else None,
                          runner_up_value=runner[0] if runner else None,
                          selected_pool_index=best[2],
                          top2_prior_regret=regret,
                          top2_prior_contains_best=recall)

    def search(self,initial_state,references):
        if len(references)!=self.segments:raise ValueError('Expected a replay target for each segment')
        t0=time.perf_counter();n=len(initial_state['cars']);mode=int(initial_state['mode'])
        if n!=2*mode:raise ValueError('Expected blue cars first, orange second')
        individual_pools=(self.proposer.propose_all(initial_state,self.candidates)
                          if self.proposer is not None else None)
        pools=(self._joint_pool(initial_state,references,0,individual_pools),
               self._joint_pool(initial_state,references,1,individual_pools))
        # Both teams run opponent-first decision trees from their OWN viewpoint.
        blue=self.search_one_team(initial_state,references,0,pools)
        orange=self.search_one_team(initial_state,references,1,pools)
        plans=tuple(blue.allied_plan+orange.allied_plan)
        states=tuple(self.rollout(initial_state,plans))
        # For tactical play, divergence from a human replay is NOT a training
        # terminal: a successful counterattack may necessarily deviate.
        # Keep pose similarity as an auxiliary diagnostic only.
        individual=tuple(float(trajectory_rating(states,references,i)) for i in range(n))
        utility=float(self.evaluator.score(states[-1]))
        classes=tuple(motion_class(initial_state['cars'][i],references[-1]['cars'][i]) for i in range(n))
        stages=tuple(parsed_motion_stages(initial_state,i,references) for i in range(n))
        result=SequenceResult(plans,states,blue.search_rollouts+orange.search_rollouts+1,
                              individual,0.5*(utility+1),False,classes,
                              time.perf_counter()-t0,references[-1],stages)
        # Attached dynamic fields for existing v4.12 result compatibility.
        result.opponent_first_info={
            'evaluator':str(self.evaluator.source),
            'blue_advantage':utility,
            'blue_robust_value':blue.robust_value,
            'blue_second_best_value':blue.runner_up_value,
            'orange_robust_value':orange.robust_value,
            'orange_second_best_value':orange.runner_up_value,
            'blue_mean_value':blue.mean_value,
            'orange_mean_value':orange.mean_value,
            'opponent_responses':self.opponent_responses,
            'ally_probes':self.ally_probes,
            'candidate_count':self.candidates,
            'blue_enemy_threat_ids':list(blue.enemy_threats),
            'orange_enemy_threat_ids':list(orange.enemy_threats),
            'blue_opponent_ranking':list(blue.enemy_rankings),
            'orange_opponent_ranking':list(orange.enemy_rankings),
            'search_method':'neural_proposals_opponent_first_refined_maximin',
            'candidate_source':(type(self.proposer).__name__ if self.proposer is not None else 'legacy_motion'),
            'candidate_stats':self._proposal_stats,
            'blue_top2_prior_regret':blue.top2_prior_regret,
            'orange_top2_prior_regret':orange.top2_prior_regret,
            'blue_top2_prior_contains_best':blue.top2_prior_contains_best,
            'orange_top2_prior_contains_best':orange.top2_prior_contains_best,
            'blue_selected_candidate':blue.selected_pool_index,
            'orange_selected_candidate':orange.selected_pool_index,
            'blue_second_best_plan':blue.runner_up,
            'orange_second_best_plan':orange.runner_up,
            'adversarial_refinement':self.adversarial_refinement,
        }
        return result
