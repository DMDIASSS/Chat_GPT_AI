"""Strict subtr-actor decoder: stable split by replay; six padded car tokens.

Only trained on fresh reconstructed state, NOT human controller input. All car
hitboxes are explicit; ambiguous ones must be reviewed in replays/hitboxes.csv.
Current frame features: rigidbody [position3, quaternion4, velocity3, ang_vel3].
"""
import csv
import hashlib
import json
from pathlib import Path
import numpy as np
from .hitboxes import allowed,classify_players,load_overrides,GROUPS

GLOBAL_ADDERS=['BallRigidBodyQuaternionVelocities','CurrentTime']
PLAYER_ADDERS=['PlayerRigidBodyQuaternionVelocities','PlayerBoost']


def dataset_split(name):
    i=int(hashlib.sha256(name.casefold().encode()).hexdigest()[:12],16)%10
    return 'train' if i<8 else 'val' if i==8 else 'test'


def parse_metadata_players(meta):
    m=meta.get('replay_meta', meta)
    return m.get('team_zero',[]) or [],m.get('team_one',[]) or []


def classify_soccar(meta,allow_unknown=False):
    # Reject clearly non-soccar modes; don't infer the mode from player count alone.
    m=meta.get('replay_meta',meta)
    fields=[]
    for k in ('game_mode','game_type','playlist','playlist_name','mode','map','map_name','arena','arena_name'):
        v=m.get(k,meta.get(k)) if isinstance(m,dict) else meta.get(k)
        if v is not None: fields.append(str(v).lower())
    joined=' '.join(fields)
    bad=('hoops','dropshot','drop shot','snow day','snowday','rumble','gridiron','heatseeker','knockout','beach ball','spike rush','spikerush')
    if any(x in joined for x in bad):return False,'non-soccar metadata: '+joined
    if any(x in joined for x in ('soccar','standard','duel','doubles','standard 3v3','ranked duel','ranked doubles','ranked standard')):
        return True,'recognized standard mode'
    # Map names are not mode identifiers, but common standard soccer maps are informative.
    if any(x in joined for x in ('dfh stadium','mannfield','champions field','beckwith park','urban central','utopia coliseum','farmstead','forbidden temple','salty shores','deadeye canyon','aquadome','sovereign heights')):
        return True,'standard soccar stadium name; confirm replay mutators'
    return bool(allow_unknown),'soccar status not supplied by parser'


def unpack_quaternion_blocks(meta,mat,players_count):
    head=meta.get('column_headers') or {}
    gh=list(head.get('global_headers') or [])
    ph=list(head.get('player_headers') or [])
    # Need quaternion+velocities, not 7-feature no-velocity quaternion variant.
    if len(gh)!=14 or len(ph)!=14:
        raise ValueError(f'Unsupported feature layout (global={len(gh)} player={len(ph)}); '+
                         'requires QuaternionVelocities + CurrentTime / PlayerBoost. Inspect column_headers.')
    if mat.ndim!=2 or mat.shape[1]!=14+14*players_count:
        raise ValueError(f'Feature size mismatch: got {mat.shape}; expected 14+14*{players_count}')
    if not all(np.isfinite(mat[:,13])):raise ValueError('Nonfinite frame time')
    time=mat[:,13].astype('float64')
    if len(time)<25 or np.diff(time).min()<=0:
        # subtr-actor may repeat or reset CurrentTime on kickoff; don't silently time-warp.
        raise ValueError('Non-increasing replay timestamps; inspect/resegment this replay')
    ball=mat[:,:13].astype('float32')
    cars=np.zeros((len(mat),6,14),dtype='float32')
    for i in range(players_count):
        cars[:,i,:13]=mat[:,14+i*14:14+i*14+13]
        cars[:,i,13]=np.clip(mat[:,14+i*14+13]/255,0,1)
    # Quaternions can have opposite signs for the same rotation; normalize at use time.
    valid=(np.isfinite(ball).all(axis=1) & np.isfinite(cars[:,:players_count]).all(axis=(1,2)))
    for arr in (ball[:,3:7],cars[:,:players_count,3:7].reshape(-1,4)):
        if len(arr):
            norm=np.linalg.norm(arr,axis=-1)
            if arr.ndim==2 and len(arr)==len(ball):valid &= norm>0.1
    return time,ball,cars,valid,{'global_headers':gh,'player_headers':ph}


def parse_folder(replays='replays',out='data',fps=15.0,filter_mode='octane_duo_or_all',allow_unknown_map=False,limit=0):
    try: import subtr_actor
    except ImportError as e:raise RuntimeError('Install subtr-actor-py') from e
    root,out=Path(replays),Path(out);out.mkdir(parents=True,exist_ok=True)
    paths=sorted(root.rglob('*.replay'))
    if limit:paths=paths[:limit]
    if not paths:
        raise RuntimeError(f'No .replay files found inside {root.resolve()}. Copy your replays into that folder.')
    overrides=load_overrides(root/'hitboxes.csv')
    report=[];unknown=[]
    for n,p in enumerate(paths,1):
        rel=p.relative_to(root).as_posix()
        info={'replay':rel,'status':'error','reason':''}
        try:
            # Quick metadata read before frame reconstruction.
            raw=subtr_actor.get_replay_meta(str(p),global_feature_adders=GLOBAL_ADDERS,player_feature_adders=PLAYER_ADDERS)
            blue,orange=parse_metadata_players(raw)
            if len(blue)!=len(orange) or len(blue) not in (1,2,3):
                raise ValueError('Not a balanced 1v1 / 2v2 / 3v3 replay')
            ok,why=classify_soccar(raw,allow_unknown_map)
            if not ok:
                info.update(status='review',reason=why)
            else:
                players=classify_players(raw,rel,overrides)
                info['players']=players
                if any(x['hitbox']=='unknown' for x in players):
                    info.update(status='review',reason='unknown body/hitbox; fill replays/hitboxes.csv')
                    for x in players:
                        if x['hitbox']=='unknown':unknown.append({'replay':rel,'team':x['team'],'slot':x['slot'],'body':x['body'],'hitbox':''})
                elif not allowed(players,filter_mode):
                    info.update(status='rejected',reason='Octane team criteria not satisfied')
                else:
                    meta,mat=subtr_actor.get_ndarray_with_info_from_replay_filepath(
                        str(p),global_feature_adders=GLOBAL_ADDERS,player_feature_adders=PLAYER_ADDERS,
                        fps=float(fps),dtype='float32')
                    time,ball,cars,valid,headers=unpack_quaternion_blocks(meta,np.asarray(mat),len(players))
                    if valid.sum()<32:raise ValueError('Fewer than 32 valid frames')
                    # Canonical order: blue cars, orange cars, followed by padding.
                    team=np.array([0]*len(blue)+[1]*len(orange)+[-1]*(6-len(players)),dtype='int8')
                    mask=team!=-1
                    boxes=np.array([x['hitbox'] for x in players]+['padding']*(6-len(players)))
                    h=hashlib.sha256(rel.encode()).hexdigest()[:16]
                    dest=out/dataset_split(rel)/(h+'.npz');dest.parent.mkdir(parents=True,exist_ok=True)
                    np.savez_compressed(dest,time=time,ball=ball,cars=cars,valid=valid,team=team,mask=mask,
                                        hitboxes=boxes,source=rel,mode=len(blue),fps=float(fps))
                    info.update(status='accepted',path=str(dest),frames=len(time),valid_frames=int(valid.sum()),reason=why)
                    (out/'schema.json').write_text(json.dumps(headers,indent=2),encoding='utf-8')
        except Exception as exc:
            info.update(status='error',reason=f'{type(exc).__name__}: {exc}')
        report.append(info)
        print(f'[{n}/{len(paths)}] {info["status"]:9} {rel}  {info.get("reason","")}',flush=True)
    path=root/'hitboxes.csv'
    existing=[]
    if path.exists():
        with path.open(newline='',encoding='utf-8-sig') as f:existing=list(csv.DictReader(f))
    seen={(x.get('replay'),x.get('team'),str(x.get('slot'))) for x in existing}
    existing.extend(x for x in unknown if (x['replay'],x['team'],str(x['slot'])) not in seen)
    if existing:
        with path.open('w',newline='',encoding='utf-8') as f:
            writer=csv.DictWriter(f,fieldnames=['replay','team','slot','body','hitbox'])
            writer.writeheader();writer.writerows(existing)
    (out/'parse_report.json').write_text(json.dumps(report,indent=2,ensure_ascii=False),encoding='utf-8')
    acc=sum(x['status']=='accepted' for x in report)
    print(f'Accepted {acc}/{len(paths)}. Please review {root / "hitboxes.csv"} for unknown bodies.')
    return acc
