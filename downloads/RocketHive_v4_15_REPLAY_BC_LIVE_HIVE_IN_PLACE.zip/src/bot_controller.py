"""Deterministic, physics-driven RocketSim baseline. This is NOT the replay-trained network.

Receives only the current simulation state; outputs legal controller inputs.
Blue attacks +Y, orange attacks -Y. This is an inspectable starter policy, not an SSL bot.
"""
from dataclasses import dataclass
import math


def clip(x, lo, hi):
    return max(lo, min(hi, float(x)))


@dataclass(frozen=True)
class Controls:
    throttle: float = 0.0
    steer: float = 0.0
    boost: bool = False
    handbrake: bool = False
    jump: bool = False
    pitch: float = 0.0
    yaw: float = 0.0
    roll: float = 0.0


def destination(me, ball, attack_y, defending=False):
    """Ground target from current ball position/velocity, no future information leakage."""
    x, y = float(ball.pos.x), float(ball.pos.y)
    bvx, bvy = clip(ball.vel.x, -2300, 2300), clip(ball.vel.y, -2300, 2300)
    dx, dy = x - me.pos.x, y - me.pos.y
    lead = clip(math.hypot(dx, dy) / 2700, 0.10, 0.65)
    bx, by = clip(x + bvx * lead, -3750, 3750), clip(y + bvy * lead, -4750, 4750)
    if defending:
        # Shadow the play from the goal side. Do not chase our striker.
        return (clip(bx * 0.65, -3000, 3000),
                clip(by - 1250 * attack_y, -4400, 4400))
    # Approach slightly behind the ball relative to the enemy goal.
    goal_x, goal_y = (0.0, 5100.0 * attack_y)
    vx, vy = goal_x - bx, goal_y - by
    length = max(1.0, math.hypot(vx, vy))
    offset = clip(math.hypot(dx, dy) * 0.17, 90, 420)
    return (clip(bx - vx / length * offset, -3900, 3900),
            clip(by - vy / length * offset, -4850, 4850))


def drive(me, ball, attack_y, defending=False):
    """Use the true car orientation to steer, with speed-aware drift and boost."""
    target = destination(me, ball, attack_y, defending)
    dx, dy = target[0] - me.pos.x, target[1] - me.pos.y
    dist = math.hypot(dx, dy)
    forward = me.rot_mat.forward
    heading = math.atan2(float(forward.y), float(forward.x))
    desired = math.atan2(dy, dx)
    error = math.atan2(math.sin(desired - heading), math.cos(desired - heading))
    speed = math.hypot(float(me.vel.x), float(me.vel.y))
    # Rocket League positive steer rotates car counter-clockwise on the ground.
    steer = clip(error * 3.2, -1, 1)
    # Slow down around the ball and reverse if the target is behind and close.
    reverse = abs(error) > 2.25 and dist < 650
    throttle = -0.7 if reverse else (0.28 if dist < 150 and speed > 750 else 1.0)
    handbrake = not reverse and abs(error) > 1.10 and speed > 550
    boost = (not defending and not reverse and dist > 1200 and
             abs(error) < 0.22 and speed < 2200 and float(me.boost) > 5)
    # Tiny hops for low aerial touches; no indiscriminate flip spam.
    ball_xy = math.hypot(float(ball.pos.x - me.pos.x), float(ball.pos.y - me.pos.y))
    jump = (not defending and ball_xy < 210 and 220 < float(ball.pos.z) < 390 and
            abs(error) < 0.38 and bool(me.is_on_ground) and speed > 400)
    if not bool(me.is_on_ground) and me.pos.z > 210:
        # Gentle leveling so the bot doesn't tumble uncontrollably on landing.
        up = me.rot_mat.up
        return Controls(throttle=1.0, pitch=clip(float(forward.z) * -2, -1, 1),
                        roll=clip(float(up.y) * 2, -1, 1), yaw=steer * 0.2)
    return Controls(throttle=throttle, steer=steer, handbrake=handbrake, boost=boost, jump=jump)


def decide(cars, ball, team_index, me_index):
    """Simple coordinated roles: nearest team car challenges, teammates shadow."""
    me = cars[me_index]
    allied = [i for i, c in enumerate(cars) if int(c.team) == team_index]
    nearest = min(allied, key=lambda i: (cars[i].get_state().pos.x - ball.pos.x)**2 +
                  (cars[i].get_state().pos.y - ball.pos.y)**2)
    return drive(me.get_state(), ball, 1 if team_index == 0 else -1, defending=me_index != nearest)
