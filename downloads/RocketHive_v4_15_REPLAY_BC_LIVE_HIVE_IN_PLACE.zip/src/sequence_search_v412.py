"""Multi-player, multi-step physics teacher for parsed replay MOTION (not inputs).

A candidate is a sequence of 8-tick control blocks. Every car (including team
mates and opponents) receives its own independently selected candidate while
all cars and the ball are simulated in the same RocketSim arena. Candidates are
scored against *time-aligned* replay poses after each block. The future replay
may guide this OFFLINE teacher but must never enter the deployed policy's obs.

The candidate list is made of control primitives inferred from observable
motion classes (rising, airborne, turning, boost use), not recovered button
presses. It intentionally contains jump-release and boost-coast sequences.
"""
from __future__ import annotations
from dataclasses import dataclass
import math
import random
import time
from typing import Mapping
import numpy as np

from .physics_search import ACTIONS, replay_arena, action_controls, car_features, ball_features
from .tracking import quaternion_error, interpolate_pose

FLAG_FIELDS = ('is_on_ground', 'has_jumped', 'has_double_jumped', 'has_flipped',
               'is_flipping', 'is_jumping', 'wheel_0_contact', 'wheel_1_contact',
               'wheel_2_contact', 'wheel_3_contact')


def motion_class(start, target):
    """Motion descriptions from parsed states, **not** recorded controller inputs."""
    start, target = np.asarray(start), np.asarray(target)
    if start[2]>140 and (abs(start[0])>3300 or abs(start[1])>4350):
        return 'wall'
    if target[2] - start[2] > 100 or (target[2] > 220 and target[9] > 150):
        return 'takeoff'
    if target[2] > 230 or start[2] > 230:
        return 'airborne'
    if target[13] < start[13] - 0.05:
        return 'boosting'
    if abs(float(np.dot(start[3:7], target[3:7]))) < .95:
        return 'turning'
    return 'ground'


def replay_targets(data: Mapping, start_frame: int, segments: int, ticks_per_segment: int):
    """Return segment-end reference states or None for gaps/invalid/kickoffs.

    Samples every interval in seconds at 120 Hz, interpolating replay poses.
    The frame at the end of the interval must be within the SAME valid segment;
    no future information leaks into the deployed policy.
    """
    times=np.asarray(data['time'],dtype=float)
    valid=np.asarray(data['valid'],dtype=bool)
    seg=np.asarray(data['segment']) if 'segment' in data else np.zeros(len(times),int)
    if (segments<1 or ticks_per_segment<1 or start_frame<0 or
        start_frame>=len(times) or not valid[start_frame]):return None
    selected=[]
    start=float(times[start_frame]);fps=float(np.asarray(data.get('fps',15.)).item())
    if not (0<fps<1000):return None
    for k in range(1,segments+1):
        timestamp=start+k*ticks_per_segment/120.
        right=int(np.searchsorted(times,timestamp,side='left'))
        if right>=len(times):return None
        left=max(start_frame,right-1)
        if (right<=start_frame or not np.all(valid[start_frame:right+1]) or
            not np.all(seg[start_frame:right+1]==seg[start_frame]) or
            times[right]-timestamp>1/fps+.013):return None
        # Full replay segment interpolation is safe because all preceding
        # frames are valid. It does not cross a kickoff or invalid frame.
        ts=times[left:right+1]
        b=interpolate_pose(ts,np.asarray(data['ball'][left:right+1]),timestamp)
        mode=int(np.asarray(data['mode']).item());n=2*mode
        cars=np.stack([interpolate_pose(ts,np.asarray(data['cars'][left:right+1,i]),timestamp)
                       for i in range(n)])
        selected.append(dict(ball=b,cars=cars,time=timestamp))
    return selected


def parsed_motion_stages(state,car_index,references):
    """Extract motion-intent tags from replay poses at each target timestamp.

    No controller inputs are read or inferred; these are kinematic categories
    used to build diverse legal physics-control candidates.
    """
    previous=np.asarray(state['cars'][car_index])
    stages=[]
    for ref in references:
        target=np.asarray(ref['cars'][car_index])
        stages.append(motion_class(previous,target))
        previous=target
    return tuple(stages)


def motion_candidates(rng, state, car_index, reference, count, segments):
    """12..64 unique action-index sequences for THIS car, selected independently.

    Planning is open-loop for a short horizon only. The POLICY remains closed
    loop: it chooses a fresh action every eight physics ticks during play.
    """
    if not 12<=count<=64:raise ValueError('Each player needs 12..64 candidates')
    if segments<1:raise ValueError('segments must be positive')
    car=np.asarray(state['cars'][car_index]);target=np.asarray(reference[-1]['cars'][car_index])
    kind=motion_class(car,target)
    primitives=[
        (0,0,0), (5,5,0), (5,0,0), (1,1,0), (2,2,0), (7,7,0), (8,8,0),
        (6,6,0), (9,0,13), (10,0,13), (10,0,14), (9,0,11),
        (9,0,12), (21,0,10), (21,0,9), (0,10,13), (0,9,11),
        (13,13,0), (14,14,0), (11,11,0), (12,12,0), (15,15,0),
        (16,16,0), (17,17,0), (18,18,0), (19,0,14), (20,0,13),
        (0,1,2), (0,2,1), (5,1,0), (5,2,0), (1,5,0), (2,5,0),
    ]
    if kind in ('takeoff','airborne','wall'):
        order=list(range(8,27))+list(range(0,8))+list(range(27,len(primitives)))
    elif kind=='boosting':
        order=[1,2,3,4,28,29,30,31]+list(range(8,27))+[0,5,6,7]
    elif kind=='turning':
        order=[3,4,5,6,27,28,29,30,31,1,2,0]+list(range(8,27))
    else:
        order=list(range(8))+list(range(27,len(primitives)))+list(range(8,27))
    pool=[];seen=set()
    def add(candidate):
        seq=tuple(int(a) for a in candidate[:segments])
        if len(seq)<segments:seq+=tuple([seq[-1]]*(segments-len(seq)))
        if seq not in seen:
            pool.append(seq);seen.add(seq)
    # Always include non-boost and non-jump alternatives even in aerial clips.
    add([0]*segments)
    add([5]*segments)
    # Construct NEW blended sequences from the successive motion segments that
    # Replicar exposes. We infer only the *kinematic class*, never player buttons.
    stages=parsed_motion_stages(state,car_index,reference)
    stage_controls={
        'ground':(0,5,1,2,6,7,8),
        'boosting':(5,3,4,1,2,0),
        'turning':(1,2,7,8,11,12,5),
        'takeoff':(9,10,21,0,11,12),
        'airborne':(11,12,13,14,15,16,17,18,0,5),
        'wall':(0,5,9,10,11,12,13,14),
    }
    for shift in range(min(8,count)):
        series=[]
        for j,stage in enumerate(stages):
            choices=stage_controls[stage]
            move=choices[(shift+j)%len(choices)]
            # Do not continuously hold the jump button: the release edge is
            # important for dodges/second jumps. A candidate's future physics
            # still decides whether that manoeuvre is actually possible.
            if j and ACTIONS[series[-1]][5] and ACTIONS[move][5]:move=0
            series.append(move)
        add(series)
        if len(pool)>=count:break
    for idx in order:
        add(primitives[idx])
        if len(pool)>=count:break
    # Higher stages can use additional mixed-control trajectories, but don't
    # overwrite the physics with reference poses and never use replay buttons.
    attempts=0
    while len(pool)<count and attempts<count*100:
        attempts+=1
        options=(0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,21)
        trial=[rng.choice(options) for _ in range(segments)]
        # Include legal jump-release transition rather than holding jump.
        if segments>=2 and trial[0] in (9,10,21):trial[1]=0
        add(trial)
    if len(pool)<count:raise RuntimeError('Insufficient candidate sequence diversity')
    return pool[:count],kind


def _similarity(now, target, ball=False):
    a=np.asarray(now,dtype=float);b=np.asarray(target,dtype=float)
    pos=float(np.linalg.norm(a[:3]-b[:3]));vel=float(np.linalg.norm(a[7:10]-b[7:10]));
    orientation=float(1.-quaternion_error(a[3:7],b[3:7]));spin=float(np.linalg.norm(a[10:13]-b[10:13]))
    # Rocket League's ball is spherical: spin matters more to collisions than
    # its intrinsic orientation, but orientation is still tracked as requested.
    value=( (1.05 if ball else 1.30)*math.exp(-pos/(650 if ball else 400))+
           (0.36 if ball else 0.38)*math.exp(-vel/(2000 if ball else 1100))+
           (0.09 if ball else 0.50)*orientation+
           (0.23 if ball else 0.20)*math.exp(-spin/4.5))
    if not ball:
        value+=.20*math.exp(-abs(float(a[13]-b[13]))/.20)
    return value,pos,vel


def trajectory_rating(states, references, player=None):
    """Higher is better; use own car + common ball during coordinate search."""
    if len(states)!=len(references):raise ValueError('State/reference lengths differ')
    scores=[];max_car=0.;max_ball=0.
    for s,ref in zip(states,references):
        bs,bd,_=_similarity(s['ball'],ref['ball'],True)
        max_ball=max(max_ball,bd)
        if player is None:
            local=[_similarity(a,b) for a,b in zip(s['cars'],ref['cars'])]
            car_score=float(np.mean([x[0] for x in local]))
            max_car=max(max_car,max(x[1] for x in local))
            scores.append(bs*.65+car_score)
        else:
            car_score,dist,_=_similarity(s['cars'][player],ref['cars'][player])
            max_car=max(max_car,dist)
            # Opposing players still affect the same ball through real physics.
            scores.append(bs*.65+car_score)
    # Early clips are more reliable than late clips due to approximate
    # suspension/jump/boost-pad reconstruction. Penalize large divergence.
    loss=float(np.mean(scores))
    loss-=min(4.,max(0.,max_car-900.)/600.)
    loss-=min(4.,max(0.,max_ball-1200.)/600.)
    return loss


def trajectory_diverged(states, references, max_car=1200., max_ball=1500.):
    for s,r in zip(states,references):
        if np.linalg.norm(s['ball'][:3]-r['ball'][:3])>max_ball:return True
        for a,b in zip(s['cars'],r['cars']):
            if np.linalg.norm(a[:3]-b[:3])>max_car:return True
            if quaternion_error(a[3:7],b[3:7])>.98:return True
    return False


@dataclass
class SequenceResult:
    plans:tuple  # one action-index sequence per car, blue then orange
    states:tuple  # every segment-end physical world
    rollouts:int
    individual_scores:tuple
    reward:float
    terminated:bool
    classes:tuple
    elapsed:float
    reference_last:dict|None=None
    stage_classes:tuple|None=None


class SequenceSearch:
    def __init__(self, simulator, candidates=12, segments=3, ticks_per_segment=8,
                 sweeps=1, seed=0):
        if not 12<=int(candidates)<=64:raise ValueError('candidates must be 12..64')
        if not 1<=int(segments)<=8:raise ValueError('segments must be 1..8')
        if not 1<=int(ticks_per_segment)<=30:raise ValueError('ticks_per_segment must be 1..30')
        if not 1<=int(sweeps)<=3:raise ValueError('sweeps must be 1..3')
        self.simulator=simulator;self.candidates=int(candidates)
        self.segments=int(segments);self.ticks=int(ticks_per_segment)
        self.sweeps=int(sweeps);self.rng=random.Random(seed)

    def rollout(self,state,plans):
        """Actual RocketSim rollout with all 2/4/6 car controls simultaneously."""
        rs=self.simulator
        arena,cars=replay_arena(rs,state)
        if len(plans)!=len(cars):raise ValueError('Every car needs an action sequence')
        observations=[]
        for k in range(self.segments):
            for car,seq in zip(cars,plans):
                car.set_controls(action_controls(rs,ACTIONS[seq[k]]))
            arena.step(self.ticks)
            def flags(car):
                s=car.get_state()
                return [float(bool(getattr(s,field,getattr(car,field,False))))
                        for field in FLAG_FIELDS]
            observations.append({'ball':ball_features(arena.ball.get_state()),
                                 'cars':np.stack([car_features(car.get_state()) for car in cars]),
                                 'flags':np.asarray([flags(car) for car in cars],dtype=np.float32),
                                 'hitboxes':state['hitboxes'], 'mask':state.get('mask'),
                                 'mode':state['mode'],'team':state.get('team')})
        return observations

    def search(self, initial_state, references):
        if len(references)!=self.segments:raise ValueError('Need one future pose per segment')
        t0=time.perf_counter();n=len(initial_state['cars'])
        # Joint occupancy matters: an opponent can intercept the ball, and a
        # teammate can block an aerial. Do not optimize independent ghost cars.
        plans=[[0]*self.segments for _ in range(n)]
        pools=[];classes=[];stage_classes=[]
        for i in range(n):
            pool,kind=motion_candidates(self.rng,initial_state,i,references,self.candidates,self.segments)
            pools.append(pool);classes.append(kind)
            stage_classes.append(parsed_motion_stages(initial_state,i,references))
        rollouts=0
        # Coordinate descent: optimize every player, including opponents, then
        # condition later players on earlier players' best physical responses.
        for _ in range(self.sweeps):
            for player in range(n):
                best=float('-inf');best_plan=None
                for plan in pools[player]:
                    trial=[tuple(p) for p in plans];trial[player]=plan
                    states=self.rollout(initial_state,trial)
                    score=trajectory_rating(states,references,player)
                    rollouts+=1
                    if score>best:
                        best=score;best_plan=plan
                plans[player]=list(best_plan)
        final_states=self.rollout(initial_state,plans);rollouts+=1
        individual=tuple(float(trajectory_rating(final_states,references,i)) for i in range(n))
        combined=float(trajectory_rating(final_states,references))
        terminated=bool(trajectory_diverged(final_states,references))
        return SequenceResult(tuple(tuple(seq) for seq in plans),tuple(final_states),rollouts,
                              individual,0. if terminated else combined,terminated,
                              tuple(classes),time.perf_counter()-t0, references[-1],tuple(stage_classes))


def compact_result(result):
    """Readable report comparing chosen multi-step moves to actual replay pose."""
    players=[]
    for i,(kind,plan) in enumerate(zip(result.classes,result.plans)):
        item={'index':i,'motion_type':kind,'actions':list(plan),
              'motion_stages':list(result.stage_classes[i]) if result.stage_classes else [],
              'trajectory_score':round(float(result.individual_scores[i]),4)}
        if result.reference_last is not None:
            now=result.states[-1]['cars'][i]
            target=result.reference_last['cars'][i]
            item['final_errors']={
                'position_uu':round(float(np.linalg.norm(now[:3]-target[:3])),2),
                'velocity_uu_s':round(float(np.linalg.norm(now[7:10]-target[7:10])),2),
                'orientation_error_0_to_1':round(float(quaternion_error(now[3:7],target[3:7])),5),
                'angular_velocity_rad_s':round(float(np.linalg.norm(now[10:13]-target[10:13])),3),
                'boost_percent':round(float(abs(now[13]-target[13])*100),2),
            }
        players.append(item)
    summary={'candidate_rollouts':result.rollouts,
             'search_seconds':round(result.elapsed,4),
             'replay_reward':result.reward,'deviation_terminal':result.terminated,
             'players':players}
    if result.reference_last is not None:
        ball=result.states[-1]['ball']
        target=result.reference_last['ball']
        summary['ball_final_errors']={
            'position_uu':round(float(np.linalg.norm(ball[:3]-target[:3])),2),
            'velocity_uu_s':round(float(np.linalg.norm(ball[7:10]-target[7:10])),2),
            'orientation_error_0_to_1':round(float(quaternion_error(ball[3:7],target[3:7])),5),
            'spin_rad_s':round(float(np.linalg.norm(ball[10:13]-target[10:13])),3),
        }
    return summary
