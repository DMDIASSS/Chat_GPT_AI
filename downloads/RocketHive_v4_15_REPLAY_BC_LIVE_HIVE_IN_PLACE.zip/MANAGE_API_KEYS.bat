@echo off
setlocal
cd /d "%~dp0"
if not exist ".venv\Scripts\python.exe" (
  echo Missing .venv\Scripts\python.exe
  pause
  exit /b 2
)
".venv\Scripts\python.exe" -m tools.credentials_popup --manage
if errorlevel 1 pause
