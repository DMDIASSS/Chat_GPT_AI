@echo off
setlocal
cd /d "%~dp0"
if not exist ".venv\Scripts\python.exe" (
  echo [ERROR] Existing RocketHive .venv was not found.
  pause
  exit /b 2
)
echo Training the PHYSICS-SEARCH ACTION CONTROLLER separately from the pose model.
echo This is not PPO, and it does not need your API tokens.
echo It uses real RocketSim; Ctrl+C stops without deleting trained weights.
".venv\Scripts\python.exe" -m tools.train_action_controller_v48 --config config_v4.json
if errorlevel 1 (
  echo Search failed. Scroll up to the first [controller] ERROR and copy that message.
  pause
  exit /b 1
)
pause
