@echo off
setlocal
cd /d "%~dp0"
if not exist ".venv\Scripts\python.exe" (
 echo Run START_TRAIN.bat first, or create the Python environment.
 pause
 exit /b 1
)
".venv\Scripts\python.exe" -m src.pipeline --config config.json || goto :error
pause
exit /b 0
:error
pause
exit /b 1
