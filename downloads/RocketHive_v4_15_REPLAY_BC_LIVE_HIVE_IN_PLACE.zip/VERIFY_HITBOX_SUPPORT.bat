@echo off
cd /d "%~dp0"
echo Checking native RocketSim car hitboxes without modifying model weights...
if exist ".venv\Scripts\python.exe" (
    ".venv\Scripts\python.exe" -m tools.check_hitbox_support_v413
) else (
    python -m tools.check_hitbox_support_v413
)
if errorlevel 1 (
  echo Check failed or no compatible replays remain. See the report above.
) else (
  echo Ready to run TRAIN_ACTION_CONTROLLER.bat.
)
pause
