@echo off
setlocal
cd /d "%~dp0"
if not exist ".venv\Scripts\python.exe" (
    echo Your old Python virtual environment was not found at .venv\Scripts\python.exe.
    echo No new environment or libraries have been installed.
    echo Restore your original .venv folder, then try again.
    goto :error
)
set "PY=.venv\Scripts\python.exe"
echo [1/3] Checking EXISTING Python libraries. No pip install.
"%PY%" -c "import RocketSim, rlviser_py" 2>nul
if errorlevel 1 (
    echo This environment does not have both RocketSim and rlviser-py installed.
    echo Only if needed, install the missing viewer packages once with:
    echo .venv\Scripts\python.exe -m pip install "rocketsim>=2.2.1" rlviser-py
    goto :error
)
echo [2/3] Finding native RLViser desktop executable (downloads only if missing)...
"%PY%" tools\install_rlviser.py || goto :error
echo [3/3] Starting LIVE 2v2 RocketSim bots in native RLViser...
"%PY%" -m tools.watch_bot_rlviser --team-size 2 --seconds 120
if errorlevel 1 goto :error
pause
exit /b 0
:error
echo.
echo Launch could not complete. Your installed packages were NOT changed.
echo See README_UPDATE_EXISTING_FOLDER.txt for help.
pause
exit /b 1
