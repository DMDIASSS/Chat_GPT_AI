@echo off
setlocal
cd /d "%~dp0"
if not exist ".venv\Scripts\python.exe" (echo Missing your existing virtual environment&pause&exit /b 1)
".venv\Scripts\python.exe" tools\enable_v47_defaults.py
if errorlevel 1 (pause&exit /b 1)
echo Configuration updated.
pause
