@echo off
cd /d "%~dp0"
if exist ".venv\Scripts\python.exe" (set "PY=.venv\Scripts\python.exe") else (set "PY=python")
echo Read-only native RocketSim opponent-first search benchmark.
%PY% -m tools.benchmark_opponent_search_v414
pause
