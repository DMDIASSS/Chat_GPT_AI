@echo off
setlocal
cd /d "%~dp0"
if not exist ".venv\Scripts\python.exe" (
  echo [ERROR] Existing RocketHive .venv was not found.
  pause
  exit /b 2
)
".venv\Scripts\python.exe" -m tools.diagnose_validation_v48
pause
