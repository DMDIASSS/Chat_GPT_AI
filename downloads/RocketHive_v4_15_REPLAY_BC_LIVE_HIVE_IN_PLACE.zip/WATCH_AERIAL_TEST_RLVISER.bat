@echo off
setlocal
cd /d "%~dp0"
if not exist ".venv\Scripts\python.exe" (echo Missing .venv&pause&exit /b 1)
".venv\Scripts\python.exe" tools\install_rlviser.py || goto :fail
".venv\Scripts\python.exe" -m tools.watch_bot_rlviser --aerial-probe --team-size 1 --seconds 8
if errorlevel 1 goto :fail
echo Report: reports\v47_flight_report.json
pause
exit /b 0
:fail
pause
exit /b 1
