@echo off
setlocal
cd /d "%~dp0"
if not exist ".venv\Scripts\python.exe" (echo Missing your existing .venv&pause&exit /b 1)
".venv\Scripts\python.exe" -m tools.check_flight_v47 --seconds 30 --team-size 2
if errorlevel 1 (echo Cannot measure controller flight yet.&pause&exit /b 1)
echo Read reports\v47_trained_flight_report.json
pause
