@echo off
setlocal
cd /d "%~dp0"
if not exist ".venv\Scripts\python.exe" (
  echo [ERROR] RocketHive .venv is missing.
  pause
  exit /b 2
)
".venv\Scripts\python.exe" -m tools.enable_v412_defaults
if errorlevel 1 (pause & exit /b 1)
echo Updated settings. Run TRAIN_ACTION_CONTROLLER.bat to train physics sequences.
pause
