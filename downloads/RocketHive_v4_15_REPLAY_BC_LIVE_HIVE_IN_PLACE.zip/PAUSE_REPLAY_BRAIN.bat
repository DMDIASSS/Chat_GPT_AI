@echo off
cd /d "%~dp0"
type nul > STOP_REPLAY_BC
echo Safe stop requested for replay BC only.
pause
