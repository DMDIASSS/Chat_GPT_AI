@echo off
cd /d "%~dp0"
if not exist ".venv\Scripts\python.exe" (
 echo Run START_TRAIN.bat to create your Python environment first.
 pause
 exit /b 1
)
.venv\Scripts\python.exe tools\setup_fast_gpu.py
pause
