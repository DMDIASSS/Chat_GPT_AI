"""Replay sequences, on-physics player rollouts and explainable stall reports."""
from __future__ import annotations
from pathlib import Path
from tempfile import TemporaryDirectory
from unittest.mock import patch
from types import SimpleNamespace as NS
import os
import unittest
import numpy as np

from src.sequence_search_v412 import (SequenceSearch,motion_candidates,motion_class,
    replay_targets,trajectory_rating,trajectory_diverged,compact_result)
from src.behavior_report_v412 import BehaviorReport
from tests.test_native_rlviser import RS,Vec
from tests.test_search_teacher import replay
from tools import native_rlviser
from tools.enable_v412_defaults import update


class ReplaySequenceTests(unittest.TestCase):
    def test_trajectory_3d_orientation_speed_boost_and_ball_spin(self):
        data=replay(n=13,mode=1)
        for i in range(13):
            data['cars'][i,0,2]=i*50.
            data['cars'][i,0,9]=i*100.
            data['cars'][i,0,13]=1.-i/15
            data['ball'][i,2]=100+i*40
            data['ball'][i,12]=i*.25
        target=replay_targets(data,0,3,8)
        self.assertEqual(len(target),3)
        self.assertAlmostEqual(target[0]['cars'][0,2],50.)
        self.assertAlmostEqual(target[1]['cars'][0,9],200.)
        self.assertAlmostEqual(target[2]['ball'][12],.75)
        self.assertAlmostEqual(target[0]['cars'][0,13],1-1/15.)
        self.assertIsNone(replay_targets(data,11,3,8))
        data['valid'][2]=False
        self.assertIsNone(replay_targets(data,0,3,8))
        data['valid'][2]=True; data['segment'][2:]=1
        self.assertIsNone(replay_targets(data,0,3,8))

    def test_each_player_has_12_to_64_unique_multistep_proposals(self):
        import random
        data=replay(mode=3)
        data['hitboxes'][:6]='octane'
        ref=[dict(cars=data['cars'][1,:6].copy(),ball=data['ball'][1])]*3
        ref[0]['cars'][0,2]=250
        state={'cars':data['cars'][0,:6].copy(),'mode':3}
        for count in (12,24,64):
            for player in range(6):
                candidates,kind=motion_candidates(random.Random(42),state,player,ref,count,3)
                self.assertEqual(len(candidates),count)
                self.assertEqual(len(set(candidates)),count)
                self.assertTrue(all(len(row)==3 for row in candidates))
                self.assertIn((0,0,0),candidates)
        self.assertEqual(motion_class(state['cars'][0],ref[0]['cars'][0]),'takeoff')
        self.assertTrue(any(p[0] in (9,10,21) and p[1]==0
                            for p in motion_candidates(random.Random(1),state,0,ref,24,3)[0]))

    def test_exact_physics_states_rank_better_than_far_ball_car(self):
        b=np.zeros(13,dtype=np.float32);b[6]=1
        c=np.zeros((2,14),dtype=np.float32);c[:,6]=1;c[:,13]=.5
        ref={'ball':b.copy(),'cars':c.copy()}
        excellent={'ball':b.copy(),'cars':c.copy()}
        poor={'ball':b.copy(),'cars':c.copy()}
        poor['cars'][1,2]=900
        poor['cars'][1,13]=0
        poor['ball'][2]=700
        poor['ball'][10]=10
        self.assertGreater(trajectory_rating([excellent],[ref]),
                           trajectory_rating([poor],[ref]))
        self.assertFalse(trajectory_diverged([excellent],[ref]))
        poor['cars'][1,2]=1500
        self.assertTrue(trajectory_diverged([poor],[ref]))

    def test_really_constructs_all_car_rocketsim_worlds(self):
        data=replay(mode=2,n=9)
        data['hitboxes'][:4]='octane'
        initial={'mode':2,'cars':data['cars'][0,:4].copy(),
                 'ball':data['ball'][0].copy(),
                 'flags':np.zeros((4,10),dtype=np.float32),
                 'hitboxes':data['hitboxes'][:4],'mask':np.ones(4,bool),'team':np.array([0,0,1,1])}
        ref=replay_targets(data,0,3,8)
        with patch.object(native_rlviser,'find_meshes',return_value=Path('/fake/meshes')):
            engine=SequenceSearch(RS,candidates=12,segments=3,ticks_per_segment=8,seed=3)
            outcome=engine.search(initial,ref)
        self.assertEqual(outcome.rollouts,4*12+1)
        self.assertEqual(len(outcome.plans),4)
        self.assertEqual(len(outcome.states),3)
        self.assertEqual(outcome.states[-1]['cars'].shape,(4,14))
        self.assertEqual(len(compact_result(outcome)['players']),4)

    def test_parsed_motion_stages_can_change_mid_sequence(self):
        from src.sequence_search_v412 import parsed_motion_stages
        s=np.zeros((2,14),dtype=np.float32);s[:,6]=1;s[:,2]=17
        initial={'cars':s,'mode':1}
        t1=s.copy();t1[0,2]=180
        t2=t1.copy();t2[0,2]=300
        t3=t2.copy();t3[0,2]=310
        refs=[{'cars':t,'ball':np.zeros(13)} for t in (t1,t2,t3)]
        stages=parsed_motion_stages(initial,0,refs)
        self.assertEqual(stages,('takeoff','takeoff','airborne'))
        import random
        plans,_=motion_candidates(random.Random(1),initial,0,refs,12,3)
        self.assertTrue(any(plan[0] in (9,10,21) for plan in plans))

    def test_replay_errors_include_ball_spin_and_car_boost(self):
        from src.sequence_search_v412 import SequenceResult
        b=np.zeros(13,dtype=np.float32);b[6]=1
        c=np.zeros((2,14),dtype=np.float32);c[:,6]=1
        r={'ball':b.copy(),'cars':c.copy()}
        s={'ball':b.copy(),'cars':c.copy()}
        s['ball'][2]=66
        s['ball'][10]=5
        s['cars'][0,13]=.9
        result=SequenceResult(((0,0,0),(5,0,0)),(s,),25,(1.,1.),1.5,False,
                              ('ground','boosting'),.12,reference_last=r)
        report=compact_result(result)
        self.assertEqual(report['ball_final_errors']['position_uu'],66)
        self.assertEqual(report['ball_final_errors']['spin_rad_s'],5)
        self.assertEqual(report['players'][0]['final_errors']['boost_percent'],90)

    def test_settings_snapshot_existing_controller_only_once(self):
        import json
        with TemporaryDirectory() as d:
            folder=Path(d);model=folder/'models/v4_action_policy_search_teacher.pt'
            model.parent.mkdir(parents=True)
            model.write_bytes(b'original-weight-file')
            cfg=folder/'config_v4.json'
            cfg.write_text(json.dumps({'seed':5}))
            update(cfg)
            snap=folder/'models/v4_action_policy_pre_sequences_v412.pt'
            self.assertEqual(snap.read_bytes(),b'original-weight-file')
            model.write_bytes(b'new-weight-file')
            update(cfg)
            self.assertEqual(snap.read_bytes(),b'original-weight-file')

    def test_each_player_gets_separate_optimum(self):
        data=replay(mode=1,n=10)
        initial={'mode':1,'cars':data['cars'][0,:2].copy(),'ball':data['ball'][0].copy()}
        ref=[{'ball':data['ball'][0].copy(),'cars':initial['cars'].copy()} for _ in range(3)]
        # Fake physics: each player's first action changes that player's x.
        # One replay target wants movement, the other wants to remain still.
        for frame in ref:
            frame['cars'][0,0]=20
            frame['cars'][1,0]=0
        engine=SequenceSearch(object(),12,3,8,seed=0)
        def sim(state,plans):
            s=[]
            for t in range(3):
                cars=state['cars'].copy()
                cars[0,0]+=20 if plans[0][t]!=0 else 0
                cars[1,0]+=20 if plans[1][t]!=0 else 0
                s.append({'ball':state['ball'].copy(),'cars':cars})
            return s
        engine.rollout=sim
        out=engine.search(initial,ref)
        self.assertNotEqual(out.plans[0],out.plans[1])
        self.assertEqual(out.rollouts,25)
        self.assertEqual(len(out.individual_scores),2)


class ReportTests(unittest.TestCase):
    def test_detects_empty_boost_stall_and_repeated_controls(self):
        stats=BehaviorReport(2,rate=120,sample_every=8)
        ctrl=NS(throttle=0,steer=0,pitch=0,yaw=0,roll=0,jump=False,boost=True,handbrake=False)
        ball=NS(pos=Vec(0,0,100),vel=Vec())
        for t in range(361):
            states=[NS(pos=Vec(1000,0,17),vel=Vec(),boost=max(0,65-t*.5),is_on_ground=True),
                    NS(pos=Vec(-1000,0,17),vel=Vec(),boost=0,is_on_ground=True)]
            stats.observe(states,[ctrl,ctrl],ball)
        with TemporaryDirectory() as tmp:
            file=Path(tmp)/'behavior.json'
            result=stats.save(file,'test')
            self.assertTrue(file.is_file())
            self.assertTrue(file.with_suffix('.txt').is_file())
            self.assertGreater(result['cars'][0]['empty_boost_command_pct'],50)
            self.assertTrue(any('ACTION_COLLAPSE' in x for x in result['cars'][0]['diagnosis']))
            self.assertTrue(any('BOOST_EXHAUSTED' in x for x in result['cars'][0]['diagnosis']))
            self.assertTrue(any('STALL' in x for x in result['cars'][0]['diagnosis']))
            self.assertEqual(result['cars'][1]['jump_command_ticks'],0)
            self.assertGreater(len(result['cars'][1]['samples']),10)

    def test_settings_preserve_old_metric_preferences(self):
        with TemporaryDirectory() as d:
            p=Path(d)/'config_v4.json'
            p.write_text('{"wandb_skill_metrics":{"pose/val_loss":[9,"low"]},"seed":77}')
            changes=update(p)
            self.assertIn('search_strategy',changes)
            import json
            cfg=json.loads(p.read_text())
            self.assertEqual(cfg['wandb_skill_metrics']['pose/val_loss'],[9,'low'])
            self.assertEqual(cfg['search_strategy'],'replay_sequences')
            self.assertEqual(update(p),[])
            self.assertEqual(cfg['seed'],77)
            self.assertTrue((p.parent/'config_v4.json.pre_v412.bak').exists())

    def test_training_multisegment_policy_checkpoint_compatible(self):
        from src.search_teacher import PhysicsSearchTeacher
        from src.sequence_search_v412 import SequenceResult
        import torch
        data=replay(mode=1,n=16)
        data['hitboxes'][:2]='octane'
        class DummySequenceSearch:
            def __init__(self,*args,**kwargs):self.seg=kwargs['segments']
            def search(self,state,references):
                states=[state.copy() for _ in range(self.seg)]
                # each frame label nontrivial, but within original 22-action table
                return SequenceResult(((9,0,13),(0,1,5)),tuple(states),25,
                                      (2.1,2.2),3.2,False,('takeoff','ground'),.01)
        with TemporaryDirectory() as d:
            old=Path.cwd();os.chdir(d)
            try:
                with patch('src.sequence_search_v412.SequenceSearch',DummySequenceSearch):
                    worker=PhysicsSearchTeacher({'seed':1,'search_strategy':'replay_sequences',
                                                 'sequence_segments':3,'sequence_ticks':8},simulator=object())
                    metrics=worker.train_replay(data)
                    self.assertEqual(metrics['policy/distilled_examples'],6)
                    self.assertEqual(metrics['search/rollouts'],25)
                    self.assertEqual(worker.step,1)
                    self.assertTrue(worker.path.is_file())
                    saved=torch.load(worker.path,weights_only=False,map_location='cpu')
                    self.assertEqual(saved['step'],1)
                    worker.close()
            finally:os.chdir(old)


if __name__=='__main__':unittest.main()
