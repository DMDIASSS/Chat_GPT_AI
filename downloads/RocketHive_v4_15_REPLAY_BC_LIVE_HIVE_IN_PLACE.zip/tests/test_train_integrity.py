"""Dataset clip hygiene: never learn to forecast across invalid intermediate states."""
import tempfile
import unittest
from pathlib import Path
import numpy as np
from src.train import ReplaySampler


class TrainIntegrity(unittest.TestCase):
    def test_invalid_middle_frame_prevents_pair(self):
        with tempfile.TemporaryDirectory() as temp:
            root=Path(temp)/'train'
            root.mkdir()
            good=np.ones(30,dtype=bool)
            good[10]=False
            np.savez(root/'clip.npz',valid=good,time=np.arange(30)/15.,segment=np.zeros(30))
            s=ReplaySampler(temp,'train',15,4/15,42)
            starts=s.available[0][1]
            self.assertFalse(any(6 <= k <= 10 for k in starts))
            self.assertIn(5,starts)
            self.assertIn(11,starts)

if __name__=='__main__': unittest.main()
