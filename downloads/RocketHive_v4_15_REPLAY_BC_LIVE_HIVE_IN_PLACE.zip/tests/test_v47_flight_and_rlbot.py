import math
import os
import tempfile
import unittest
import zipfile
from pathlib import Path
from types import SimpleNamespace as NS
from unittest.mock import patch
import numpy as np

from src.physics_search import ACTIONS, replay_conditioned_pool
from src.tracking_v4 import replay_score
from src.flight_diagnostics_v47 import FlightStats,classify_flight
from src.aerial_probe_v47 import AerialProbe
from rlbot_v4.RocketHiveBot.packet_adapter import (q_from_rlbot_rot,packet_state,identify_hitbox,pose)
from tools.export_rlbot_v47 import export


def v(x=0,y=0,z=0): return NS(x=x,y=y,z=z)
def phy(pitch=0,yaw=0,roll=0):
    return NS(location=v(0,0,17),velocity=v(250,100,0),angular_velocity=v(),
              rotation=NS(pitch=pitch,yaw=yaw,roll=roll))


class FlightTests(unittest.TestCase):
    def test_pose_includes_vertical_velocity_and_orientation(self):
        p=phy(pitch=.5,yaw=.2,roll=.3)
        p.location.z=555
        p.velocity.z=321
        a=pose(p,55)
        self.assertEqual(len(a),14)
        self.assertEqual(a[2],555)
        self.assertEqual(a[9],321)
        self.assertAlmostEqual(a[13],.55)
        self.assertAlmostEqual(float(np.linalg.norm(a[3:7])),1.0,places=5)

    def test_pitch_quaternion_is_nose_up(self):
        from src.physics_search import rotation_axes
        f,r,u=rotation_axes(q_from_rlbot_rot(math.pi/6,0,0))
        self.assertAlmostEqual(f[2],.5,places=4)
        self.assertAlmostEqual(f[0],math.sqrt(3)/2,places=4)
        f,r,u=rotation_axes(q_from_rlbot_rot(0,math.pi/2,0))
        self.assertAlmostEqual(f[1],1.0,places=5)

    def test_explicit_boost_loss(self):
        ball=np.zeros(13,dtype=float);ball[6]=1
        cars=np.zeros((2,14),dtype=float);cars[:,6]=1;cars[:,13]=.75
        ref=cars.copy();ref[:,13]=0.1
        self.assertGreater(replay_score(ball,cars,ball,cars), replay_score(ball,cars,ball,ref))
        ref=cars.copy();ref[:,2]=300
        self.assertGreater(replay_score(ball,cars,ball,cars), replay_score(ball,cars,ball,ref))

    def test_targeted_search_proposes_jumps_and_airs(self):
        import random
        state={'mode':1,'cars':np.zeros((2,14),dtype=float), 'flags':np.zeros((2,10),dtype=float)}
        state['flags'][:,0]=1
        target=state['cars'].copy();target[:,2]=300
        plans=replay_conditioned_pool(random.Random(4),state,0,12,(np.zeros(13),target))
        self.assertEqual(len(plans),12)
        self.assertTrue(any(plan[0][5] for plan in plans[:8]))
        # The raw action table is untouched: existing trained controllers load.
        self.assertEqual(len(ACTIONS),22)

    def test_flight_metrics_only_observed_physics(self):
        s=FlightStats()
        state=NS(pos=v(z=400),is_on_ground=False)
        control=NS(jump=True,boost=True,pitch=-.8,yaw=0,roll=0)
        s.observe([state],[control]); self.assertEqual(s.airborne_ticks,1)
        self.assertIn('FLIGHT_COMMANDS_OBSERVED', classify_flight(s))
        with tempfile.TemporaryDirectory() as d:
            saved=s.save(Path(d)/'stats.json','untrained probe')
            self.assertEqual(saved['max_car_height_uu'],400)

    def test_probe_sends_jump_then_airboost(self):
        from tests.test_native_rlviser import RS,Car
        car=Car(1,0)
        probe=AerialProbe()
        seq=[probe.controls(RS,[car],None)[0] for i in range(17)]
        self.assertTrue(seq[0].jump)
        self.assertTrue(seq[2].jump)
        self.assertFalse(seq[3].jump)
        self.assertTrue(seq[5].boost)
        self.assertFalse(seq[-1].boost)

    def test_hitbox_identification_strict(self):
        self.assertEqual(identify_hitbox(NS(length=118.01,width=84.2,height=36.16)),'octane')
        self.assertEqual(identify_hitbox(NS(length=127.93,width=83.28,height=31.3)),'dominus')
        with self.assertRaises(ValueError):identify_hitbox(None)
        with self.assertRaises(ValueError):identify_hitbox(NS(length=100,width=100,height=100))

    def test_v4_state_has_cars_both_teams(self):
        cars=[NS(team=t, physics=phy(),boost=100,hitbox=NS(length=118.01,width=84.2,height=36.16),
                 has_wheel_contact=True,jumped=False,double_jumped=False) for t in [1,0,1,0]]
        pkt=NS(game_cars=cars,num_cars=4,game_ball=NS(physics=phy()))
        state,idx=packet_state(pkt,1)
        self.assertEqual(idx,0)
        self.assertEqual(state['cars'].shape,(4,14))
        self.assertEqual(state['mode'],2)
        self.assertEqual(list(state['hitboxes']),['octane']*4)
        self.assertEqual(state['flags'].shape,(4,10))
        # Odd team sizes and unknown hitboxes fail, not silently guessed.
        pkt.num_cars=3
        with self.assertRaises(ValueError):packet_state(pkt,1)

    def test_export_rejects_pose_forecaster_and_omits_keys(self):
        import torch
        from src.search_teacher import build_policy,OBS_DIM
        with tempfile.TemporaryDirectory() as d:
            d=Path(d)
            ck=d/'controller.pt'
            torch.save({'type':'replay_pose_forecaster_NOT_controller'},ck)
            with self.assertRaises(ValueError):export(d/'out.zip',ck)
            torch.save({'type':'SEARCH_DISTILLED_ACTION_POLICY_unvalidated','obs_dim':OBS_DIM,
                        'action_table':ACTIONS,'model':build_policy().state_dict(),
                        'step':2},ck)
            result=export(d/'out.zip',ck)
            self.assertTrue(result.exists())
            with zipfile.ZipFile(result) as z:
                names=z.namelist()
                self.assertIn('RocketHiveBot/RocketHive.cfg',names)
                self.assertIn('RocketHiveBot/models/v4_action_policy_search_teacher.pt',names)
                self.assertFalse(any('credentials' in a or 'wandb' in a.lower() and 'resume' not in a.lower() for a in names))
                self.assertFalse(any(a.endswith('.npz') or a.endswith('v4_pose_best.pt') for a in names))

if __name__=='__main__':unittest.main()

class MoreV47Tests(unittest.TestCase):
    def test_missing_flags_still_includes_ground_launch(self):
        from src.physics_search import replay_conditioned_pool
        import random
        state={'mode':1,'cars':np.zeros((2,14)), 'flags':np.zeros((2,10))}
        state['cars'][:,2]=17.5
        target=state['cars'].copy();target[:,2]=320
        pool=replay_conditioned_pool(random.Random(1),state,0,12,(np.zeros(13),target))
        self.assertTrue(any(a[0][5] for a in pool))

    def test_search_teacher_tracks_aerial_samples(self):
        from tests.test_search_teacher import replay
        from src.search_teacher import PhysicsSearchTeacher
        import torch
        from types import SimpleNamespace
        from unittest.mock import patch
        r=replay()
        r['cars'][:,0,2]=650
        class MockContext:
            def __init__(self,rs,our_team,**kwargs):self.team=our_team
            def search(self,state,**kwargs):
                return SimpleNamespace(team_plan=(ACTIONS[10],ACTIONS[10]),robust_score=1.,num_rollouts=12)
            def rollout(self,state,blue,orange):return state
        with tempfile.TemporaryDirectory() as d:
            before=Path.cwd();os.chdir(d)
            try:
                with patch('src.search_teacher.SearchContext',MockContext):
                    worker=PhysicsSearchTeacher({'seed':4,'aerial_teacher_prob':1.},simulator=object())
                    metrics=worker.train_replay(r)
                self.assertEqual(metrics['curriculum/search_aerial_focused'],1)
            finally:os.chdir(before)

    def test_model_inference_on_packet_observation(self):
        import torch
        from src.search_teacher import build_policy,OBS_DIM
        from src.policy_inference import SearchPolicyController
        cars=[NS(team=t, physics=phy(),boost=70,hitbox=NS(length=118.01,width=84.2,height=36.16),
                 has_wheel_contact=True,jumped=False,double_jumped=False) for t in [0,1]]
        pkt=NS(game_cars=cars,num_cars=2,game_ball=NS(physics=phy()))
        state,idx=packet_state(pkt,0)
        with tempfile.TemporaryDirectory() as d:
            ck=Path(d)/'action.pt'
            torch.save({'type':'SEARCH_DISTILLED_ACTION_POLICY_unvalidated',
                        'obs_dim':OBS_DIM,'action_table':ACTIONS,'model':build_policy().state_dict(), 'step':9},ck)
            controller=SearchPolicyController(checkpoint=ck)
            self.assertEqual(controller.checkpoint_step,9)
            indexes=controller.action_indices(state)
            self.assertEqual(len(indexes),2)
            self.assertTrue(all(0<=i<len(ACTIONS) for i in indexes))
