"""True-on-disk pose checkpoint and regression behavior; fake replay tensors only."""
import os
from pathlib import Path
from tempfile import TemporaryDirectory
import unittest
from unittest.mock import patch
import torch
from src.continuous import ContinuousPoseLearner
from src.adaptive_training import benchmark_batches
from src.models import JointForecaster, pose_loss


class FakeSampler:
    available=[1]
    def batch(self,n,device):
        ball=torch.zeros(n,13,device=device)
        ball[:,6]=1
        cars=torch.zeros(n,6,14,device=device)
        cars[:,:,6]=1
        teams=torch.zeros(n,6,device=device,dtype=torch.long)
        boxes=torch.zeros(n,6,device=device,dtype=torch.long)
        mask=torch.zeros(n,6,device=device,dtype=torch.bool)
        mask[:,:2]=True
        return (ball,cars,teams,boxes,mask),(ball,cars),None,None


class QuietLogger:
    def log(self,*args):pass


class CheckpointTests(unittest.TestCase):
    def test_best_separate_and_recovery_survives_restart(self):
        with TemporaryDirectory() as d:
            old=Path.cwd();os.chdir(d)
            try:
                cfg={'model_dim':16,'batch_size':2,'adaptive_min_steps':1,'adaptive_max_steps':4,'auto_batch_probe':False}
                l=ContinuousPoseLearner(cfg,device='cpu',logger=QuietLogger())
                l.sampler=FakeSampler();l.validation=l.sampler
                from types import SimpleNamespace
                l.fixed_validation=SimpleNamespace(count=1)
                l.evaluate=lambda rounds=4:1.0
                l.train_chunk(steps=1)
                p=Path('models/v4_pose_best.pt')
                assert p.exists()
                data=torch.load(p,map_location='cpu',weights_only=False)
                assert data['best']==1.0
                l.evaluate=lambda rounds=4:2.0
                l.train_chunk(steps=1)
                data2=torch.load(p,map_location='cpu',weights_only=False)
                assert data2['best']==1.0
                resumed=ContinuousPoseLearner(cfg,device='cpu',logger=QuietLogger())
                assert resumed.step==2
                assert resumed.best==1.0
                assert resumed.schedule.evaluations==2
            finally:os.chdir(old)

    def test_benchmark_does_not_modify_model(self):
        m=JointForecaster(16)
        before={k:v.clone() for k,v in m.state_dict().items()}
        results=benchmark_batches(m,FakeSampler(),pose_loss,torch.device('cpu'),[2,4],trials=2)
        assert {x['batch'] for x in results}=={2,4}
        assert all(torch.equal(m.state_dict()[k],v) for k,v in before.items())


if __name__=='__main__':unittest.main()
