import unittest
from types import SimpleNamespace
from tempfile import TemporaryDirectory
from pathlib import Path
from unittest.mock import patch
import os
import numpy as np
from src.search_teacher import OBS_DIM,make_observation,replay_state,teacher_indices,PhysicsSearchTeacher
from src.physics_search import ACTIONS


def replay(n=15, mode=2):
    ball=np.zeros((n,13),np.float32);ball[:,6]=1
    cars=np.zeros((n,6,14),np.float32);cars[:,:,6]=1
    return dict(ball=ball,cars=cars,time=np.arange(n)/15,segment=np.zeros(n,int),
                valid=np.ones(n,bool),mode=np.array(mode),fps=np.array(15.),
                hitboxes=np.array(['octane','dominus','merc','breakout','padding','padding']))


class SearchTeacherTests(unittest.TestCase):
    def test_observations_for_every_player(self):
        a=replay()
        s=replay_state(a,3)
        self.assertEqual(s['cars'].shape,(4,14))
        for i in range(4):
            self.assertEqual(make_observation(s,i).shape,(OBS_DIM,))
        self.assertNotEqual(make_observation(s,0)[-2],make_observation(s,3)[-2])
        self.assertEqual(len(teacher_indices(a)),13)
        a['segment'][4:]=1
        self.assertNotIn((2,4),teacher_indices(a))

    def test_all_four_cars_get_teacher_targets(self):
        class MockContext:
            seen=[]
            def __init__(self,rs,our_team,**kwargs):self.our_team=our_team
            def search(self,state,**kwargs):
                self.seen.append((self.our_team,len(state['cars'])))
                return SimpleNamespace(team_plan=tuple([ACTIONS[self.our_team+1]]*2),
                                       robust_score=1.5,num_rollouts=48)
            def rollout(self,state,blue,orange):
                self.seen.append(('rollout',len(blue),len(orange)))
                return state
        import torch
        with TemporaryDirectory() as d:
            before=Path.cwd();os.chdir(d)
            try:
                with patch('src.search_teacher.SearchContext',MockContext):
                    worker=PhysicsSearchTeacher({'seed':1},simulator=object())
                    metrics=worker.train_replay(replay())
                    self.assertTrue((Path('models')/'v4_action_policy_search_teacher.pt').exists())
                    self.assertEqual(metrics['search/rollouts'],96)
                    self.assertEqual(MockContext.seen[-1],('rollout',2,2))
            finally:os.chdir(before)

if __name__=='__main__':unittest.main()
