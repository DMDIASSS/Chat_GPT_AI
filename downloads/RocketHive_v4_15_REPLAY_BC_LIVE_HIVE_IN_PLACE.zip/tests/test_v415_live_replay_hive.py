import json,math,socket,tempfile,time
from pathlib import Path
from unittest.mock import patch
import numpy as np
import pytest
from src.live_hive_v415 import HiveSettings,candidate_pool,control_tuple,safe_drive
from src.hive_runtime_v415 import TeamClient,atomic_json,public_state,TeamLock

def state(mode=1):
    cars=np.zeros((2*mode,14),np.float32);cars[:,6]=1;cars[:,13]=.6;cars[:,2]=17;cars[:mode,1]=-1500;cars[mode:,1]=1500
    ball=np.zeros(13,np.float32);ball[6]=1;ball[2]=93
    return dict(cars=cars,ball=ball,flags=np.zeros((2*mode,10)),mode=mode,hitboxes=np.asarray(['octane']*(2*mode)))

def test_neutral_brake_turn_and_both_sides_are_available():
    s=state();s['ball'][0]=1000
    assert abs(safe_drive(s,0)[1])>.1
    s['cars'][0,:3]=[1000,-130,17];s['cars'][0,7:10]=[1600,0,0]
    assert safe_drive(s,0,'attack')[0]<0
    for i in (0,1):
        plans=candidate_pool(s,i,64,32,1)
        assert len(plans)==64 and len(set(plans))==64
        assert any(all(abs(x)<1e-8 for x in p[0]) for p in plans)
        assert all(len(p)==32 for p in plans)

def test_team_namespace_and_causal_input_strip():
    with tempfile.TemporaryDirectory() as d:
        a=TeamClient(0,'match',base=d);b=TeamClient(1,'match',base=d)
        assert a.root!=b.root
        s=state();s['opponent_actual_plan']='forbidden';assert 'opponent_actual_plan' not in public_state(s)
        with patch.object(a,'_spawn'):
            a.controls(s,10,'roster')
        q=json.loads((a.root/'request.json').read_text());assert q['team']==0 and 'opponent_actual_plan' not in q['state']

def test_expired_plan_and_clock_reset_never_hold_forward():
    with tempfile.TemporaryDirectory() as d:
        c=TeamClient(0,'match',base=d);s=state();now=time.monotonic()
        plan=dict(team=0,posted=now-10,state_time=10,roster='roster',controls=[[[1,0,0,0,0,0,0,0]]*32],controller='TEST')
        atomic_json(c.root/'plan.json',plan)
        with patch.object(c,'_spawn'):
            c.controls(s,20,'roster');assert c.status.startswith('GEOMETRIC_FALLBACK')
            plan.update(posted=time.monotonic(),state_time=0);atomic_json(c.root/'plan.json',plan)
            c.controls(s,0,'roster');assert c.status.startswith('GEOMETRIC_FALLBACK')

def test_team_lock_has_single_owner():
    with tempfile.TemporaryDirectory() as d:
        a=TeamLock(Path(d)/'lock');b=TeamLock(Path(d)/'lock');assert a.acquire();assert not b.acquire();a.close();assert b.acquire();b.close()

def test_rvq_codec_and_autoregressive_policy_train_with_tick_buttons():
    import torch
    from src.replay_bc_v415 import ChunkCodec,ReplayPolicy,reconstruction_loss,controls
    from src.search_teacher import OBS_DIM
    torch.set_num_threads(1);torch.manual_seed(2)
    y=torch.rand(16,32,8)*2-1;y[:,:,5:]=(y[:,:,5:]>0).float();codec=ChunkCodec();codec.initialize(y)
    raw,ids,ql=codec(y);assert ids.shape==(16,4) and ids.max()<64
    loss=reconstruction_loss(raw,y)+ql;loss.backward();assert codec.books.grad is not None
    net=ReplayPolicy();x=torch.randn(16,OBS_DIM);z=net.teacher_logits(x,ids);assert z.shape==(16,4,64)
    ce=torch.nn.functional.cross_entropy(z.flatten(0,1),ids.flatten());ce.backward();assert net.embed.weight.grad is not None
    command=controls(raw);assert command.shape==(16,32,8) and torch.isin(command[:,:,5:],torch.tensor([0.,1.])).all()

def test_legacy_action_table_and_existing_observation_contract_preserved():
    from src.physics_search import ACTIONS
    from src.search_teacher import OBS_DIM,make_observation
    assert len(ACTIONS)==22 and make_observation(state(),0).shape==(OBS_DIM,)

def test_replay_reader_rejects_15hz_and_missing_inputs():
    from src.replay_chunks_v415 import chunk_examples
    # Test at the actual schema boundary without fabricating inferred controls.
    with patch('src.replay_chunks_v415.normalize_arrays',return_value={'time':np.arange(40)/15}):
        f=type('File',(),{'arrays':lambda self:{'sim_tick':np.arange(40)*8}})()
        with pytest.raises(ValueError,match='120 Hz'):chunk_examples(f,[])

def test_viewer_uses_upstream_100_boost_units_and_steer_key():
    from tools.rocketsimvis_v415 import packet
    from tests.test_native_rlviser import Arena,RS,Car
    ar=Arena(0);ar._cars=[Car(1,0)]
    s=ar._cars[0].state;s.last_controls=type('A',(),dict(throttle=1,steer=.3,pitch=0,yaw=0,roll=0,boost=False,jump=False,handbrake=False))();s.is_demoed=False;s.has_flipped=False;s.has_double_jumped=False
    j=packet(ar);assert j['cars'][0]['boost_amount']==100 and j['cars'][0]['controls']['steer']==.3

def test_120hz_reconstructed_button_timing_and_goal_labels_survive_import():
    import pyarrow as pa
    from src.replay_chunks_v415 import chunk_examples
    n=128;arrays={'sim_tick':np.arange(n),'frame':np.arange(n),'replay_time':np.arange(n)/120,'segment':np.zeros(n),'car_boost':np.ones((n,2))*70,'car_status':np.full((n,2),'active')}
    for prefix in ('ball','car'):
        shape=(n,3) if prefix=='ball' else (n,2,3)
        arrays[prefix+'_position']=np.zeros(shape);arrays[prefix+'_position'][...,2]=93 if prefix=='ball' else 17
        arrays[prefix+'_velocity']=np.zeros(shape);arrays[prefix+'_angular_velocity']=np.zeros(shape)
        rot=np.zeros(shape[:-1]+(4,));rot[...,3]=1;arrays[prefix+'_rotation']=rot
    for name in ('throttle','steer','pitch','yaw','roll','jump','boost','handbrake'):
        arrays['car_controls_'+name]=np.zeros((n,2))
    arrays['car_controls_jump'][::8]=1
    class File:
        def arrays(self):return arrays
        def records(self,kind):return pa.Table.from_pylist([dict(kind='goal',frame=100,scoring_team=0)])
    players=[dict(index=0,team='blue',hitbox='octane'),dict(index=1,team='orange',hitbox='octane')]
    chunks=chunk_examples(File(),players,32)
    assert chunks['actions'].shape[1:]==(32,8)
    assert chunks['actions'][:,:,5].sum()>0 and (chunks['actions'][:,:,5]==0).any()
    assert chunks['value_known'].any() and (chunks['value']>0).any() and (chunks['value']<0).any()

def test_native_hive_agent_returns_steer_brake_and_does_not_latch_on_rewind():
    import importlib.util,sys,types
    from types import SimpleNamespace as NS
    from tests.test_v47_flight_and_rlbot import phy
    fake=types.ModuleType('rlbot.agents.base_agent');fake.BaseAgent=type('BaseAgent',(),{});fake.SimpleControllerState=type('Controller',(),{})
    with patch.dict(sys.modules,{'rlbot':types.ModuleType('rlbot'),'rlbot.agents':types.ModuleType('rlbot.agents'),'rlbot.agents.base_agent':fake}):
        path=Path(__file__).resolve().parents[1]/'rlbot_hive/RocketHiveBot/agent.py'
        spec=importlib.util.spec_from_file_location('_hive_agent_test',path);module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
        bot=module.RocketHiveBot();bot.index=0;bot.team=0
        bot.hive=NS(status='TEST',controls=lambda *_:[(-1,.8,0,0,0,False,False,False)],close=lambda:None);bot.last_status=None
        cars=[NS(team=t,name=str(t),physics=phy(),boost=50,has_wheel_contact=True,hitbox=NS(length=118.01,width=84.2,height=36.16)) for t in (0,1)]
        packet=NS(num_cars=2,game_cars=cars,game_ball=NS(physics=phy()),game_info=NS(seconds_elapsed=100))
        assert bot.get_output(packet).throttle==-1
        packet.game_info.seconds_elapsed=0;assert bot.get_output(packet).steer==.8

def test_replay_brain_rejects_merely_updated_unhealthy_checkpoint():
    import torch
    from src.replay_bc_v415 import ReplayBrain
    from src.search_teacher import OBS_DIM
    with tempfile.TemporaryDirectory() as d:
        p=Path(d)/'bad.pt';torch.save(dict(type='REPLAY_RVQ_BC_V415',obs_dim=OBS_DIM,codec_steps=400,policy_steps=400,health_ready=False),p)
        with pytest.raises(ValueError,match='failed'):ReplayBrain(p)
