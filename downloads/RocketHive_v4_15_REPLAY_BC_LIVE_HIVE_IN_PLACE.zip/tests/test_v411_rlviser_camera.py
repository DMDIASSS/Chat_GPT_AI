"""Unit regression for native RLViser persistence + viewer truthfulness."""
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch
from tools import native_rlviser
from tools.rlviser_camera_v411 import (configure_rlviser_camera,
                                        load_camera_preferences,
                                        save_camera_preferences)


class CameraSettingsTests(unittest.TestCase):
    def test_first_run_creates_settings_follow_car_and_ballcam(self):
        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp) / 'rlviser.exe'
            path.touch()
            target = configure_rlviser_camera(path)
            self.assertEqual(target.read_text(), 'ball_cam=true\ncamera_state={"TrackCar":1}\n')
            self.assertFalse((path.parent / 'settings.txt.rockethive-original.bak').exists())
            self.assertEqual(target.stat().st_size, len(target.read_bytes()))

    def test_preserves_other_settings_and_creates_one_backup(self):
        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp) / 'rlviser.exe'
            path.touch()
            settings = path.parent / 'settings.txt'
            original = 'fps_limit=144\r\nball_cam=false\r\ncamera_state="Spectator"\r\nshow_time=true\r\n'
            settings.write_bytes(original.encode())
            configure_rlviser_camera(path, car=2, ball_cam=True)
            expected = ('fps_limit=144\r\nball_cam=true\r\ncamera_state={"TrackCar":2}'
                        '\r\nshow_time=true\r\n')
            self.assertEqual(settings.read_bytes(), expected.encode())
            backup = path.parent / 'settings.txt.rockethive-original.bak'
            self.assertEqual(backup.read_bytes(), original.encode())
            configure_rlviser_camera(path, car=3, ball_cam=False)
            self.assertEqual(backup.read_bytes(), original.encode())
            self.assertIn('ball_cam=false', settings.read_text())
            self.assertIn('"TrackCar":3', settings.read_text())

    def test_idempotent_preserves_mtime_and_deduplicates_keys(self):
        with tempfile.TemporaryDirectory() as tmp:
            binary = Path(tmp) / 'rlviser.exe'
            binary.touch()
            settings = binary.parent / 'settings.txt'
            settings.write_text('ball_cam=false\nball_cam=false\ncamera_state="Spectator"\n')
            configure_rlviser_camera(binary)
            text = settings.read_text()
            self.assertEqual(text.count('ball_cam='), 1)
            self.assertEqual(text.count('camera_state='), 1)
            mtime = settings.stat().st_mtime_ns
            configure_rlviser_camera(binary)
            self.assertEqual(settings.stat().st_mtime_ns, mtime)

    def test_preferences_persist_and_invalid_values_fail(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            self.assertEqual(load_camera_preferences(root), {'car': 1, 'ball_cam': True})
            save_camera_preferences(root, 4, False)
            self.assertEqual(load_camera_preferences(root), {'car': 4, 'ball_cam': False})
            for car in (0, 9, True, '2'):
                with self.assertRaises(ValueError):
                    save_camera_preferences(root, car, True)
            for ball in ('yes', 1, None):
                with self.assertRaises(ValueError):
                    save_camera_preferences(root, 1, ball)

    def test_enter_viewer_directory_sets_camera_before_cwd_change(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            directory = root / 'third_party' / 'rlviser'
            directory.mkdir(parents=True)
            binary = directory / 'rlviser.exe'
            binary.touch()
            save_camera_preferences(root, 2, True)
            current = Path.cwd()
            try:
                with patch.object(native_rlviser, 'ROOT', root):
                    found = native_rlviser.enter_viewer_directory()
                    self.assertEqual(found, binary)
                    self.assertEqual(Path.cwd(), directory)
                    self.assertIn('camera_state={"TrackCar":2}', (directory/'settings.txt').read_text())
            finally:
                import os
                os.chdir(current)

    def test_refuses_invalid_utf8_and_missing_binary(self):
        with tempfile.TemporaryDirectory() as tmp:
            binary = Path(tmp) / 'rlviser.exe'
            with self.assertRaises(FileNotFoundError):
                configure_rlviser_camera(binary)
            binary.touch()
            settings = binary.parent / 'settings.txt'
            settings.write_bytes(b'\xff\xfe')
            with self.assertRaises(UnicodeDecodeError):
                configure_rlviser_camera(binary)
            self.assertEqual(settings.read_bytes(), b'\xff\xfe')

    def test_replay_is_not_controller_and_baseline_is_not_trained(self):
        root=Path(__file__).resolve().parents[1]
        replay=(root / 'tools/watch_rlviser.py').read_text()
        live=(root / 'tools/watch_bot_rlviser.py').read_text()
        self.assertIn('NOT live AI decisions', replay)
        self.assertIn('heuristic ground baseline', live)
        self.assertIn('search-distilled network (UNVALIDATED)', live)

if __name__ == '__main__':
    unittest.main()
