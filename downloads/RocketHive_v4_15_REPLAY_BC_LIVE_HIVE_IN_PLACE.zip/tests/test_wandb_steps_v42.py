import os
from tempfile import TemporaryDirectory
from pathlib import Path
import unittest
from src.continuous import Logger

class FakeRun:
    def __init__(self): self.logs=[]
    def log(self, info, **kwargs):
        # An existing run has a preexisting W&B step. Avoid passing a fresh
        # 0/1/2 explicit step, which can cause the SDK to drop log entries.
        assert not kwargs, kwargs
        self.logs.append(info)
    def finish(self): pass

class LoggerTests(unittest.TestCase):
    def test_pose_and_search_steps_do_not_reset_resumed_wandb_step(self):
        with TemporaryDirectory() as d:
            old=Path.cwd();os.chdir(d)
            try:
                l=Logger(token=None)
                r=FakeRun();l.run=r
                l.log({'pose/val_loss':0.2},200)
                l.log({'search/robust_score':0.1},1)
                l.log({'pose/val_loss':0.1},250)
                assert len(r.logs)==3
                assert r.logs[0]['performance/pose_updates_total(0,neutral)']==200
                assert r.logs[1]['performance/search_updates_total(0,neutral)']==1
                assert r.logs[2]['performance/pose_updates_total(0,neutral)']==250
            finally:os.chdir(old)

if __name__=='__main__':unittest.main()
