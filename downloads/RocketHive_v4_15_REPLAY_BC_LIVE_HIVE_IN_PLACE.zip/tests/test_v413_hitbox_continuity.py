"""v4.13 regression tests: binding-specific presets, no hitbox substitution,
clip filtering without data deletion, and uninterrupted training updates."""
import json
import os
import sys
from pathlib import Path
from types import SimpleNamespace
from tempfile import TemporaryDirectory
from unittest.mock import patch
import numpy as np
import pytest

from src.physics_search import configure_car, UnsupportedHitboxError
from src.hitbox_compat_v413 import probe_hitboxes, filter_replays, save_report


class Car:
    def set_state(self, state):
        pass


class Arena:
    def __init__(self):
        self.called = []

    def add_car(self, *args):
        self.called.append(args)
        return Car()


class RSTest:
    Team = SimpleNamespace(BLUE='blue')


def test_carconfig_lowercase_method_selects_real_dominus():
    obj=object()
    rs=SimpleNamespace(CarConfig=SimpleNamespace(dominus=lambda:obj))
    arena=Arena()
    configure_car(arena,rs,'blue','dominus')
    assert arena.called==[('blue',obj)]


def test_module_car_config_constant_selects_real_dominus():
    obj=object()
    rs=SimpleNamespace(CAR_CONFIG_DOMINUS=obj)
    arena=Arena()
    configure_car(arena,rs,'blue','dominus')
    assert arena.called==[('blue',obj)]


def test_module_level_dominus_constant_selects_real_dominus():
    obj=object()
    rs=SimpleNamespace(DOMINUS=obj)
    arena=Arena()
    configure_car(arena,rs,'blue','dominus')
    assert arena.called==[('blue',obj)]


def test_car_body_config_enum_selects_real_dominus():
    obj=object()
    rs=SimpleNamespace(CarBodyConfig=SimpleNamespace(DOMINUS=obj))
    arena=Arena()
    configure_car(arena,rs,'blue','dominus')
    assert arena.called==[('blue',obj)]


def test_missing_dominus_does_not_substitute_octane():
    arena=Arena()
    with pytest.raises(UnsupportedHitboxError, match='cannot set dominus'):
        configure_car(arena,SimpleNamespace(),'blue','dominus')
    assert arena.called==[]


def test_legacy_octane_default_permitted_only_for_octane():
    arena=Arena()
    configure_car(arena,SimpleNamespace(),'blue','octane')
    assert arena.called==[('blue',)]


def test_binding_rejects_native_preset_without_fallback():
    class IncompatibleArena(Arena):
        def add_car(self,*args):
            raise TypeError('expected a different native type')
    rs=SimpleNamespace(DOMINUS=1)
    with pytest.raises(UnsupportedHitboxError, match='rejected'):
        configure_car(IncompatibleArena(),rs,'blue','dominus')


def test_probe_uses_actual_add_car_and_rejects_absent_presets():
    rs=SimpleNamespace(Team=SimpleNamespace(BLUE='blue'),CAR_CONFIG_DOMINUS='dominus')
    supported,missing=probe_hitboxes(rs,lambda rs:Arena())
    assert 'dominus' in supported and 'octane' in supported
    assert 'plank' in missing and 'psyclops' in missing


def test_filter_replay_by_every_active_hitbox_preserves_source_files():
    with TemporaryDirectory() as td:
        root=Path(td)
        a=root/'a.npz'; b=root/'b.npz'; c=root/'c.npz'
        np.savez(a,mode=np.asarray(1),hitboxes=np.asarray(['octane','octane']))
        np.savez(b,mode=np.asarray(2),hitboxes=np.asarray(['octane','dominus','octane','octane']))
        np.savez(c,mode=np.asarray(1),hitboxes=np.asarray(['octane','octane']))
        before={x.name:x.read_bytes() for x in (a,b,c)}
        accepted,excluded=filter_replays([a,b,c],['octane'])
        assert accepted==[a,c]
        assert excluded==[('b.npz','unsupported native hitbox: dominus')]
        assert before=={x.name:x.read_bytes() for x in (a,b,c)}


def test_missing_metadata_is_reported_not_crash():
    with TemporaryDirectory() as td:
        p=Path(td)/'empty.npz';np.savez(p,mode=1)
        accepted,excluded=filter_replays([p],['octane'])
        assert not accepted
        assert excluded[0][0]=='empty.npz'
        assert 'missing hitboxes' in excluded[0][1]


def test_support_report_contains_no_api_secrets():
    with TemporaryDirectory() as td:
        path=Path(td)/'hitboxes.json'
        report=save_report(path,SimpleNamespace(__file__='RocketSim.pyd'),
                           ['octane'],{'dominus':'missing'},
                           [Path('one.npz')],[('two.npz','dominus unavailable')])
        assert json.loads(path.read_text())==report
        assert report['fallback_hitbox_substitutions']==0
        assert report['usable_replay_count']==1
        assert report['excluded_replay_count']==1


def test_action_trainer_skips_late_incompatible_clip_and_continues():
    from tools import train_action_controller_v48 as trainer
    class FakeRng:
        def integers(self,n):return 0
    class Worker:
        seen=[]
        def __init__(self,cfg,logger,simulator):
            self.rng=FakeRng();self.step=77;self.path=Path('models/action.pt')
            self.last_sequence_report=None
        def train_replay(self,data):
            Worker.seen.append(data['file'])
            if data['file']=='bad.npz':
                raise UnsupportedHitboxError('binding cannot simulate dominus')
            self.step+=1
            return {'tracking/survival_fraction':1,'search/rollouts':25}
        def close(self):pass
    with TemporaryDirectory() as td:
        wd=Path.cwd();os.chdir(td)
        try:
            Path('config_v4.json').write_text('{}')
            Worker.seen=[]
            with (patch.dict(sys.modules,{'RocketSim':SimpleNamespace(__file__='RocketSim.pyd')}),
                  patch('tools.native_rlviser.init_arena',return_value=object()),
                  patch.object(trainer,'candidates',return_value=([Path('bad.npz'),Path('ok.npz')],[])),
                  patch.object(trainer,'probe_hitboxes',return_value=(['octane'],{})),
                  patch.object(trainer,'filter_replays',side_effect=lambda p,s:(p,[])),
                  patch.object(trainer,'save_report',return_value={}),
                  patch.object(trainer,'sample_replay',side_effect=lambda p,r:{'file':p[0].name}),
                  patch.object(trainer,'PhysicsSearchTeacher',Worker)):
                result=trainer.main(['--iterations','2'])
            assert result==0
            assert Worker.seen==['bad.npz','ok.npz']
        finally:
            os.chdir(wd)
