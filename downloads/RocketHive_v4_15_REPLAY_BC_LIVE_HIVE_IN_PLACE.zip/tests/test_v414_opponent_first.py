"""V4.14: deterministic learned proposals, opponent-first response, honest value."""
import tempfile
from pathlib import Path
import unittest
import numpy as np

from src.goal_value_v414 import (next_goal_labels,examples_from_replay,
    fit_value_model,GoalValueEvaluator,build_value_model)
from src.evaluation_v414 import make_evaluator,EvaluationUnavailable
from src.learned_candidates_v414 import LearnedCandidateProposer,action_is_feasible
from src.opponent_first_v414 import OpponentFirstSearch
from src.search_teacher import replay_state,make_observation,build_policy
from tests.test_search_teacher import replay


def state(mode=1):
    r=replay(n=350,mode=mode)
    r['hitboxes'][:2*mode]='octane'
    r['cars'][:,:,2]=17
    r['cars'][:,:,13]=.9
    return replay_state(r,0)


class ProposalTests(unittest.TestCase):
    def test_deterministic_feasible_both_teams_counts(self):
        import torch
        torch.manual_seed(777)
        pol=build_policy()
        s=state(2)
        proposer=LearnedCandidateProposer(pol,make_observation)
        for count in [12,24,64]:
            a=proposer.propose_all(s,count)
            b=proposer.propose_all(s,count)
            self.assertEqual(len(a),4)
            for i in range(4):
                self.assertEqual([t.actions for t in a[i]],[t.actions for t in b[i]])
                self.assertEqual(len(set(p.actions for p in a[i])),count)
                for t in a[i]:
                    for k,act in enumerate(t.actions):
                        self.assertTrue(action_is_feasible(s,i,act,t.actions[:k]))
        self.assertGreaterEqual(proposer.last_stats[0]['unique_first_actions'],2)

    def test_invalid_boost_and_jump_edges(self):
        s=state(1)
        s['cars'][:,13]=0.
        self.assertFalse(action_is_feasible(s,0,5)) # boost without tank
        self.assertFalse(action_is_feasible(s,0,9,(9,))) # continuous jump held


class GameValueTests(unittest.TestCase):
    def example(self):
        r=replay(n=250,mode=1)
        r['hitboxes'][:2]='octane'
        r['cars'][:,:,13]=.7
        r['goal_rows']=np.array([100,210],np.int64)
        r['goal_teams']=np.array([0,1],np.int8)
        r['segment'][:]=0
        return r

    def test_goal_labels_censoring_and_direction(self):
        d=self.example()
        labels=next_goal_labels(d)
        self.assertEqual(labels[98,0],1)
        self.assertEqual(labels[205,1],2)
        self.assertEqual(labels[200,0],2)
        self.assertEqual(labels[0,0],0)
        self.assertEqual(labels[249,1],-1)
        x,y=examples_from_replay(d,max_frames=60)
        self.assertEqual(x.shape[1],make_observation(replay_state(d,0),0).shape[0])
        self.assertTrue(np.any(y==1) and np.any(y==2))

    def test_checkpoint_scores_and_rejects_wrong_architecture(self):
        import torch
        d=self.example();x,y=examples_from_replay(d,100)
        with tempfile.TemporaryDirectory() as tmp:
            p=Path(tmp)/'value.pt'
            result=fit_value_model((x,y),(x,y),steps=2,batch_size=12,
                                   output=p,device='cpu')
            self.assertTrue(p.exists())
            self.assertEqual(result['steps_total'],2)
            v=GoalValueEvaluator(p)
            self.assertIn(v.source,'replay_trained_next_goal_3s_10s')
            self.assertGreaterEqual(v.score(replay_state(d,0)),-1.)
            self.assertLessEqual(v.score(replay_state(d,0)),1.)
            with self.assertRaises(EvaluationUnavailable):
                make_evaluator({'game_evaluator':'replay_goal_value',
                                'evaluator_checkpoint':str(p)+'missing'})


class OpponentFirstTests(unittest.TestCase):
    def test_explicit_threats_ranked_before_friendly_and_no_afk(self):
        # Stub physics returns a meaningful team-value for the adversarial game;
        # distinct opponent candidates create different threats to a response.
        class FakeVal:
            source='deterministic_test_value'
            def score(self,s):return float(s['score'])
        class Physics(OpponentFirstSearch):
            def rollout(self,s,plans):
                blue=plans[0][0];orange=plans[1][0]
                # Blue action 1 is good unless Orange chooses counter 2.
                score={0:.2,1:.9,2:.3}.get(blue,.1)
                if orange==2 and blue==1:score=-.8
                if orange==1:score-=.3
                return [dict(s,score=score,ball=s['ball'].copy(),cars=s['cars'].copy())]*self.segments
        s=state()
        refs=[{'cars':s['cars'].copy(),'ball':s['ball'].copy()}]*3
        class Proposer:
            def propose_all(self,s,count):
                from src.learned_candidates_v414 import Proposal
                base=[(1,0,0),(2,0,0),(0,0,0)]
                return [[Proposal(base[k%3] if k<3 else (k%22,0,0),float(-k))
                         for k in range(count)] for _ in range(2)]
        engine=Physics(None,candidates=12,segments=3,opponent_responses=3,
                evaluator=FakeVal(),proposer=Proposer(),replay_weight=0.)
        result=engine.search(s,refs)
        self.assertIn('blue_enemy_threat_ids',result.opponent_first_info)
        self.assertTrue(result.opponent_first_info['blue_opponent_ranking'])
        self.assertEqual(result.opponent_first_info['candidate_source'],'Proposer')
        self.assertEqual(len(result.plans),2)
        self.assertNotEqual(result.opponent_first_info['search_method'],'random')
        self.assertGreater(result.rollouts,12)
        self.assertGreaterEqual(result.opponent_first_info['blue_top2_prior_regret'],0.)
        self.assertIsInstance(result.opponent_first_info['blue_top2_prior_contains_best'],bool)


if __name__=='__main__':unittest.main()

class TrainingWiringTests(unittest.TestCase):
    def test_controller_uses_learned_candidates_and_preserves_old_weights(self):
        import os
        from unittest.mock import patch
        from src.search_teacher import PhysicsSearchTeacher
        from src.sequence_search_v412 import SequenceResult
        import torch
        r=replay(n=18,mode=1)
        r['hitboxes'][:2]='octane'
        r['cars'][:,:,13]=.6
        class FakeEval:
            source='unit_test_goal_value'
            def score(self,s):return .22
        class FakeOpponent:
            observed=[]
            def __init__(self,rs,**kwargs):
                self.observed.append(kwargs)
                self.proposer=kwargs['proposer']
                self.segments=kwargs['segments']
            def search(self,state,refs):
                self.observed.append(self.proposer.propose_all(state,12))
                plans=((0,1,0),(1,2,0))
                states=tuple(dict(state) for _ in range(3))
                result=SequenceResult(plans,states,14,(3.5,3.6),.5,False,
                     ('ground','turning'),.025,refs[-1],(('ground',)*3,)*2)
                result.opponent_first_info={
                  'blue_advantage':.22,'blue_robust_value':.12,
                  'orange_robust_value':-.11,'blue_second_best_value':.1,
                  'orange_second_best_value':-.13,'blue_enemy_threat_ids':[3],
                  'orange_enemy_threat_ids':[4],
                  'blue_top2_prior_regret':.25,'orange_top2_prior_regret':.15,
                  'blue_top2_prior_contains_best':False,'orange_top2_prior_contains_best':True,
                  'candidate_stats':{0:{'first_action_diversity':4},
                                     1:{'first_action_diversity':5}},
                  'evaluator':'unit_test_goal_value','search_method':'unit_test'
                }
                return result
        with tempfile.TemporaryDirectory() as d:
            before=Path.cwd();os.chdir(d)
            try:
                cfg={'seed':3,'search_strategy':'opponent_first',
                     'sequence_segments':3,'sequence_ticks':8,
                     'search_candidates':12,'adaptive_search':False}
                with patch('src.opponent_first_v414.OpponentFirstSearch',FakeOpponent),\
                     patch('src.evaluation_v414.make_evaluator',return_value=FakeEval()):
                    worker=PhysicsSearchTeacher(cfg,simulator=object())
                    info=worker.train_replay(r)
                    self.assertEqual(worker.step,1)
                    self.assertEqual(worker.chunk_prior.steps,1)
                    self.assertTrue(Path('models/v414_chunk_prior.pt').exists())
                    self.assertEqual(info['evaluation/blue_advantage'],.22)
                    self.assertEqual(info['search/opponent_threats'],1)
                    self.assertAlmostEqual(info['policy/proposal_regret'],.2)
                    self.assertAlmostEqual(info['policy/top2_joint_prior_recall'],.5)
                    self.assertEqual(info['policy/distilled_examples'],6)
                    self.assertEqual(info['policy/mean_unique_first_actions'],4.5)
                    worker.close()
                    self.assertEqual(len(FakeOpponent.observed[1]),2)
            finally:os.chdir(before)


class ChunkPriorTests(unittest.TestCase):
    def test_autoregressive_chunks_no_random_and_resume(self):
        from src.chunk_proposer_v414 import ChunkPrior,ChunkCandidateProposer
        s=state(1)
        obs=np.stack([make_observation(s,i) for i in range(2)])
        targets=np.asarray([[9,0,14],[5,1,2]],dtype=np.int64)
        with tempfile.TemporaryDirectory() as root:
            path=Path(root)/'chunk.pt'
            prior=ChunkPrior(path)
            self.assertEqual(prior.steps,0)
            self.assertTrue(np.isfinite(prior.train_from_search(obs,targets)))
            self.assertEqual(prior.steps,1)
            proposals=ChunkCandidateProposer(prior,make_observation)
            a=proposals.propose_all(s,12)
            b=proposals.propose_all(s,12)
            for i in range(2):
                self.assertEqual([p.actions for p in a[i]],[p.actions for p in b[i]])
                self.assertEqual(len(set(p.actions for p in a[i])),12)
                self.assertTrue(all(len(p.actions)==3 for p in a[i]))
            loaded=ChunkPrior(path)
            self.assertEqual(loaded.steps,1)
            self.assertEqual([p.actions for p in ChunkCandidateProposer(loaded,make_observation).propose(s,0,12)],
                             [p.actions for p in a[0]])


class NativeMockRolloutTests(unittest.TestCase):
    def test_all_players_2v2_joint_world(self):
        from unittest.mock import patch
        from tests.test_native_rlviser import RS
        from tools import native_rlviser
        from src.evaluation_v414 import PhysicsProxy
        r=replay(n=15,mode=2)
        r['cars'][:,:,2]=17.
        r['cars'][:,:,13]=.7
        r['hitboxes'][:4]='octane'
        s=replay_state(r,0)
        proposer=LearnedCandidateProposer(build_policy(),make_observation)
        ref=[dict(ball=s['ball'].copy(),cars=s['cars'].copy()) for _ in range(3)]
        planner=OpponentFirstSearch(RS,candidates=12,segments=3,
                  opponent_responses=3,proposer=proposer,evaluator=PhysicsProxy())
        with patch.object(native_rlviser,'find_meshes',return_value=Path('/fake/meshes')):
            result=planner.search(s,ref)
        self.assertEqual(len(result.plans),4)
        self.assertTrue(all(len(seq)==3 for seq in result.plans))
        self.assertEqual(result.states[-1]['cars'].shape,(4,14))
        self.assertEqual(len(result.opponent_first_info['blue_opponent_ranking']),12)
        self.assertGreater(result.rollouts,12*2)


class SettingsTests(unittest.TestCase):
    def test_new_strategy_keeps_custom_importance_and_all_secret_free(self):
        import json
        from tools.enable_v414_defaults import update
        with tempfile.TemporaryDirectory() as t:
            path=Path(t)/'config_v4.json'
            path.write_text(json.dumps({'search_strategy':'replay_sequences',
             'search_candidates':24,'wandb_skill_metrics':{'pose/val_loss':[9,'low']},
             'api_key':'a deliberately fake placeholder'}))
            c=update(path)
            self.assertEqual(c['search_strategy'],'opponent_first')
            self.assertEqual(c['search_candidates'],24)
            self.assertEqual(c['wandb_skill_metrics']['pose/val_loss'],[9,'low'])
            self.assertFalse(c['adaptive_search'])
            self.assertEqual(c['game_evaluator'],'replay_goal_value')
