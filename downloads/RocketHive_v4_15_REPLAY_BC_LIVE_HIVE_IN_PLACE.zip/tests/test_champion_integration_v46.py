"""Replay-level smoke check for v4.6 startup and checkpoint after one update."""
import json
import os
from pathlib import Path
from tempfile import TemporaryDirectory
import numpy as np
from src.continuous import ContinuousPoseLearner

class NullLogger:
    def log(self,*a):pass


def _make_replay(path,source):
    n=35
    t=np.arange(n,dtype=np.float64)/15.
    ball=np.zeros((n,13),dtype=np.float32);ball[:,6]=1.;ball[:,2]=94;ball[:,0]=t*40
    cars=np.zeros((n,6,14),dtype=np.float32);cars[:,:,6]=1.;cars[:,:,13]=.5
    cars[:,0,0]=t*10
    np.savez_compressed(path,time=t,ball=ball,cars=cars,valid=np.ones(n,dtype=bool),
      team=np.array([0,1,-1,-1,-1,-1]),mask=np.array([1,1,0,0,0,0],dtype=bool),
      hitboxes=np.array(['octane','dominus','padding','padding','padding','padding']),
      mode=1,segment=np.zeros(n,dtype=np.int32),source=source,fps=15.)


def test_full_train_then_restart_selects_champion():
    with TemporaryDirectory() as d:
        cwd=os.getcwd()
        os.chdir(d)
        try:
            for split in ('train','val'):(Path('data')/split).mkdir(parents=True)
            _make_replay('data/train/a.npz','train-a')
            _make_replay('data/val/b.npz','val-b')
            cfg={'model_dim':16,'batch_size':2,'seed':42,'auto_batch_probe':False,
                 'validation_max_replays':1,'validation_frames_per_replay':4,
                 'forecast_seconds':.1333333333,'fps':15.,'auto_resume_champion':True,
                 'adaptive_min_steps':1,'adaptive_max_steps':4}
            first=ContinuousPoseLearner(cfg,device='cpu',logger=NullLogger())
            assert first.refresh_replays()==(1,1)
            first.train_chunk(1)
            assert Path('models/v4_pose_champion.pt').is_file()
            val=first.best
            restarted=ContinuousPoseLearner(cfg,device='cpu',logger=NullLogger())
            restarted.refresh_replays()
            assert restarted.step==1
            assert abs(restarted.best-val)<1e-4
            report=json.loads(Path('reports/v4_champion_candidates.json').read_text())
            assert len(report['candidates'])>=2
            assert all('loss' in x for x in report['candidates'] if x['ok'])
        finally:
            os.chdir(cwd)
