import json
import os
from pathlib import Path
import sys
import tempfile
import types
import unittest
from unittest.mock import patch

from src.wandb_resume_v45 import (
    RunBindingError, binding_from_url, discover_named_run,
    load_binding, resolve_binding, save_binding,
)
from src.continuous import Logger


class DummyRun:
    def __init__(self, id='abcdef12', name='likely-sea-1'):
        self.id=id; self.name=name; self.history=[]; self.closed=False
    def log(self, values, **kwargs):
        if kwargs:
            raise AssertionError('Resumed W&B runs must not receive reset step counters')
        self.history.append(values)
    def finish(self):
        self.closed=True


class DummyWandb(types.ModuleType):
    def __init__(self, found=True, init_fails=False):
        super().__init__('wandb')
        self.found=found; self.init_fails=init_fails; self.init_calls=[];self.api_calls=[]
        self.run=DummyRun()
    def Api(self, timeout=15):
        outer=self
        class API:
            default_entity='my-user'
            def runs(self, project, filters, per_page):
                outer.api_calls.append((project,filters,per_page))
                return [outer.run] if outer.found else []
        return API()
    def init(self, **kwargs):
        self.init_calls.append(kwargs)
        if self.init_fails:
            raise RuntimeError('no remote W&B access')
        return self.run


class WandbBindingTests(unittest.TestCase):
    def test_url_is_checked_and_bound_without_token(self):
        value=binding_from_url('https://wandb.ai/my-user/RocketHive-v4/runs/abcdef12',
                               expected_project='RocketHive-v4')
        self.assertEqual(value['run_id'],'abcdef12')
        for invalid in ('https://not-wandb.ai/a/b/runs/abcdef12',
                        'http://wandb.ai/a/b/runs/abcdef12',
                        'https://wandb.ai/a/b/overview',
                        'https://wandb.ai/a/b/runs/!@#'):
            with self.assertRaises(RunBindingError):
                binding_from_url(invalid)
        with self.assertRaises(RunBindingError):
            binding_from_url('https://wandb.ai/a/other/runs/abcdef12',
                             expected_project='RocketHive-v4')

    def test_discover_exact_first_name_and_no_ambiguous_match(self):
        wb=DummyWandb()
        got=discover_named_run(wb,'RocketHive-v4')
        self.assertEqual((got['run_id'],got['display_name']),('abcdef12','likely-sea-1'))
        self.assertEqual(wb.api_calls[0][0],'my-user/RocketHive-v4')
        self.assertEqual(wb.api_calls[0][1],{'display_name':'likely-sea-1'})
        wb.run.name='floral-dawn-4'
        with self.assertRaises(RunBindingError):
            discover_named_run(wb,'RocketHive-v4')
        wb.run.name='likely-sea-1';wb.found=False
        with self.assertRaises(RunBindingError):
            discover_named_run(wb,'RocketHive-v4')

    def test_saved_id_is_reused_offline(self):
        with tempfile.TemporaryDirectory() as d:
            p=Path(d)/'binding.json'
            wb=DummyWandb()
            original=resolve_binding(wb,'RocketHive-v4',path=p)
            self.assertTrue(p.exists())
            self.assertNotIn('api_key',p.read_text())
            wb.found=False
            repeated=resolve_binding(wb,'RocketHive-v4',path=p)
            self.assertEqual(repeated,original)
            self.assertEqual(len(wb.api_calls),1)
            with self.assertRaises(RunBindingError):
                resolve_binding(wb,'different-project',path=p)

    def test_corrupt_binding_fails_closed(self):
        with tempfile.TemporaryDirectory() as d:
            p=Path(d)/'binding.json'
            p.write_text('{garbage',encoding='utf-8')
            with self.assertRaises(RunBindingError):load_binding(p)
            with self.assertRaises(RunBindingError):resolve_binding(DummyWandb(),'RocketHive-v4',path=p)

    def test_logger_resumes_same_run_without_resetting_steps_or_config(self):
        with tempfile.TemporaryDirectory() as d:
            prior=Path.cwd();wb=DummyWandb()
            try:
                os.chdir(d)
                with patch.dict(sys.modules,{'wandb':wb}):
                    with patch.dict(os.environ,{},clear=False):
                        log=Logger(project='RocketHive-v4',token='TEST_TOKEN')
                        log.log({'pose/train_loss':0.3,'pose/best_val_loss':0.1},12400)
                        log.close()
                        self.assertEqual(wb.init_calls,[dict(project='RocketHive-v4',entity='my-user',
                                                               id='abcdef12',resume='must')])
                        self.assertIn('performance/pose_updates_total(0,neutral)',wb.run.history[0])
                        self.assertEqual(wb.run.history[0]['performance/pose_updates_total(0,neutral)'],12400.)
                        self.assertTrue(wb.run.closed)
                        self.assertTrue(Path('reports/wandb_run_binding.json').exists())
            finally:os.chdir(prior)

    def test_wandb_discovery_failure_continues_local_and_creates_no_new_run(self):
        with tempfile.TemporaryDirectory() as d:
            prior=Path.cwd();wb=DummyWandb(found=False)
            try:
                os.chdir(d)
                with patch.dict(sys.modules,{'wandb':wb}):
                    log=Logger(project='RocketHive-v4',token='TEST_TOKEN')
                    log.log({'pose/val_loss':0.12},12400)
                self.assertIsNone(log.run)
                self.assertEqual(len(wb.init_calls),0)
                self.assertTrue(Path('reports/v4_metrics.jsonl').is_file())
            finally:os.chdir(prior)

    def test_log_transport_failure_does_not_stop_training_or_local_metrics(self):
        with tempfile.TemporaryDirectory() as d:
            prior=Path.cwd();wb=DummyWandb()
            try:
                os.chdir(d)
                with patch.dict(sys.modules,{'wandb':wb}):
                    log=Logger(project='RocketHive-v4',token='TEST_TOKEN')
                    def offline(values):
                        raise OSError('simulated WAN disconnect')
                    wb.run.log=offline
                    log.log({'pose/train_loss':0.12},12400)
                    log.log({'pose/train_loss':0.11},12401)
                    self.assertIsNone(log.run)
                    rows=Path('reports/v4_metrics.jsonl').read_text().splitlines()
                    self.assertEqual(len(rows),2)
                    self.assertEqual(json.loads(rows[1])['step'],12401)
            finally:os.chdir(prior)

    def test_wandb_existing_init_failure_creates_no_fallback(self):
        with tempfile.TemporaryDirectory() as d:
            prior=Path.cwd();wb=DummyWandb(init_fails=True)
            try:
                os.chdir(d)
                with patch.dict(sys.modules,{'wandb':wb}):
                    log=Logger(project='RocketHive-v4',token='TEST_TOKEN')
                self.assertIsNone(log.run)
                self.assertEqual(len(wb.init_calls),1)
                self.assertEqual(wb.init_calls[0]['resume'],'must')
            finally:os.chdir(prior)


if __name__=='__main__':unittest.main()
