import json
from pathlib import Path
import sys
import tempfile
import types
import unittest
import numpy as np
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from src.dataset import parse_folder

class TestParserMock(unittest.TestCase):
    def test_quarantines_unknown_and_accepts_octane_duo(self):
        with tempfile.TemporaryDirectory() as tmp:
            root=Path(tmp)/'replays';out=Path(tmp)/'data';root.mkdir()
            (root/'known.replay').write_bytes(b'synthetic mock for unit test')
            meta={'replay_meta':{
                'team_zero':[{'name':'A','car_body_name':'Fennec'},{'name':'B','car_body_name':'Octane'}],
                'team_one':[{'name':'C','car_body_name':'Merc'},{'name':'D','car_body_name':'Dominus'}],
                'game_mode':'Soccar'}}
            a=np.zeros((90,14+14*4),dtype=np.float32)
            a[:,13]=np.arange(90,dtype=np.float32)/15
            a[:,3]=1
            for j in range(4):a[:,14+j*14+3]=1
            fake=types.SimpleNamespace(
                get_replay_meta=lambda *args,**kwargs:meta,
                get_ndarray_with_info_from_replay_filepath=lambda *args,**kwargs:(
                    dict(meta,column_headers={'global_headers':list(range(14)),
                                              'player_headers':list(range(14))}),a))
            old=sys.modules.get('subtr_actor');sys.modules['subtr_actor']=fake
            try:
                count=parse_folder(root,out,15,'octane_duo_or_all')
            finally:
                if old is None:sys.modules.pop('subtr_actor',None)
                else:sys.modules['subtr_actor']=old
            self.assertEqual(count,1)
            with np.load(next(out.rglob('*.npz'))) as d:
                self.assertEqual(int(d['mode']),2)
                self.assertEqual(d['cars'].shape,(90,6,14))
                self.assertEqual(d['hitboxes'].tolist()[:4],['octane','octane','merc','dominus'])
            self.assertEqual(json.loads((out/'parse_report.json').read_text())[0]['status'],'accepted')

if __name__=='__main__':unittest.main()
