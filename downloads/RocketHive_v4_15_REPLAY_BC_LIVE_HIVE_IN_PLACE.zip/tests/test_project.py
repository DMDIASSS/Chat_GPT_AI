import sys
from pathlib import Path
import unittest
import numpy as np
import torch
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from src.hitboxes import classify, allowed
from src.dataset import unpack_quaternion_blocks,classify_soccar,dataset_split
from src.models import JointForecaster,StateEvaluator,pose_loss
from src.tracking import quaternion_error,interpolate_pose,track_reward,deviation_terminal
from src.retrieve import compatible_permutations
from src.planner import joint_minimax_search
from src.train import goal_crossings,goal_labels


def example(batch=2,mode=2):
    ball=torch.zeros(batch,13)
    cars=torch.zeros(batch,6,14)
    ball[:,3]=1;cars[:,:,3]=1
    team=torch.tensor([[0]*mode+[1]*mode+[-1]*(6-2*mode)]).expand(batch,-1)
    boxes=torch.zeros(batch,6,dtype=torch.long)
    mask=team!=-1
    return ball,cars,team,boxes,mask

class TestCore(unittest.TestCase):
    def test_octane_selection(self):
        self.assertEqual(classify('Fennec'),'octane')
        self.assertEqual(classify('Merc'),'merc')
        self.assertEqual(classify('???'),'unknown')
        p=[{'hitbox':h,'team':team} for team,h in [('blue','octane'),('blue','octane'),('orange','merc'),('orange','dominus')]]
        self.assertTrue(allowed(p,'octane_duo_or_all'))
        p[1]['hitbox']='plank';self.assertFalse(allowed(p,'octane_duo_or_all'))
        p[1]['hitbox']='unknown';self.assertFalse(allowed(p,'octane_duo_or_all'))
    def test_soccar(self):
        self.assertEqual(classify_soccar({'replay_meta':{'game_mode':'Soccar'}})[0],True)
        self.assertEqual(classify_soccar({'replay_meta':{'game_mode':'Hoops'}})[0],False)
        self.assertEqual(classify_soccar({'replay_meta':{}})[0],False)
    def test_schema(self):
        mat=np.zeros((40,14+14*4),dtype=np.float32)
        mat[:,13]=np.arange(40)/15
        mat[:,3]=1
        for i in range(4):mat[:,14+i*14+3]=1
        meta={'column_headers':{'global_headers':list(range(14)),'player_headers':list(range(14))}}
        t,b,c,v,_=unpack_quaternion_blocks(meta,mat,4)
        self.assertEqual(c.shape,(40,6,14))
        self.assertTrue(v.all())
        self.assertAlmostEqual(t[1],1/15,places=5)
    def test_quaternion_sign(self):
        q=np.array([1.,0,0,0]);self.assertAlmostEqual(float(quaternion_error(q,-q)),0)
        a=np.zeros((2,14));a[:,3]=[1,-1]
        r=interpolate_pose(np.array([0.,1.]),a,0.5)
        self.assertAlmostEqual(float(abs(r[3])),1)
    def test_tracking(self):
        x=np.zeros(14);x[3]=1
        self.assertGreater(track_reward(x,x),1.7)
        y=x.copy();y[0]=2000
        self.assertTrue(deviation_terminal(y,x,1200))
    def test_model_shapes_and_loss(self):
        a=example();m=JointForecaster(d=32,layers=1)
        bp,cp=m(*a)
        self.assertEqual(bp.shape,(2,13));self.assertEqual(cp.shape,(2,6,14))
        self.assertTrue(torch.isfinite(pose_loss(bp,cp,a[0],a[1],a[4])))
        ev=StateEvaluator(d=32)
        self.assertEqual(ev(*a).shape,(2,3))
    def test_goals(self):
        ball=np.zeros((300,13));ball[:,3]=1
        ball[100:105,1]=5100
        vals=goal_crossings(ball)
        self.assertEqual(vals[0],(100,1))
        target,_=goal_labels(ball,np.array([90,101,200]),30)
        self.assertEqual(target.tolist(),[1,0,0])
    def test_hitbox_permutation(self):
        x=['octane','octane','dominus','merc']
        y=['octane','octane','merc','dominus']
        self.assertEqual(len(compatible_permutations(2,x,y)),2)
        self.assertEqual(compatible_permutations(2,x,['octane']*4),[])
    def test_joint_minimax(self):
        # Team plan A wins 8 vs greedy opponent but -3 vs tactical response;
        # B is safer with 4 against both.
        plans=iter(['A','B'])
        reply=iter(['weak','strong','weak','strong'])
        table={('A','weak'):8,('A','strong'):-3,('B','weak'):4,('B','strong'):4}
        res=joint_minimax_search(None,lambda s:next(plans),lambda s,a:next(reply),
                                 lambda s,a,b:table[(a,b)],lambda x:x,2,2)
        self.assertEqual(res.team_plan,'B');self.assertEqual(res.num_rollouts,4)
    def test_replay_split(self):
        self.assertEqual(dataset_split('same.replay'),dataset_split('same.replay'))

if __name__=='__main__':unittest.main()
