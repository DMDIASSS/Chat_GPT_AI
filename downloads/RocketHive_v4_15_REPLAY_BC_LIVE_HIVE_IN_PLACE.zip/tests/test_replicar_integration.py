import sys
import os
import tempfile
import hashlib
import json
from unittest.mock import patch
from pathlib import Path
import unittest
from types import SimpleNamespace
import numpy as np
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from src.replicar_dataset import verified_players, normalize_arrays, get_goal_events, convert_missing
from src.train import goal_labels

class FakeFile:
    def __init__(self,n=64):
        players=4
        z=np.zeros((n,players,3),np.float32)
        rot=np.zeros((n,players,4),np.float32);rot[:,:,3]=1
        bpos=np.zeros((n,3),np.float32)
        brot=np.zeros((n,4),np.float32);brot[:,3]=1
        self.a={'ball_position':bpos,'ball_rotation':brot,'ball_velocity':bpos,
                'ball_angular_velocity':bpos,'car_position':z,'car_rotation':rot,
                'car_velocity':z,'car_angular_velocity':z,'car_boost':np.full((n,players),40,dtype=np.float32),
                'car_status':np.full((n,players),'active',dtype=object),
                'replay_time':np.arange(n)/15,'segment':np.r_[np.zeros(32),np.ones(32)],
                'frame':np.arange(n,dtype=np.int32)}
        self.rows=[{'frame':45,'kind':'goal','scoring_team':0}]
    def arrays(self):return self.a
    def records(self,_):return SimpleNamespace(to_pylist=lambda:self.rows)

class ReplicarTests(unittest.TestCase):
    def test_hitboxes_do_not_trust_fallback(self):
        hdr={'players':[{'index':0,'team':0,'body_product_id':99,'hitbox':'octane'},
                        {'index':1,'team':0,'body_product_id':1,'hitbox':'octane'},
                        {'index':2,'team':1,'body_product_id':2,'hitbox':'merc'},
                        {'index':3,'team':1,'body_product_id':3,'hitbox':'dominus'}]}
        catalog={1:{'hitbox':'octane','name':'Fennec'},2:{'hitbox':'merc','name':'Merc'},
                 3:{'hitbox':'dominus','name':'Dominus'},99:{'hitbox':'unmapped','name':'Mystery'}}
        ps=verified_players(hdr,'a.parquet',{},catalog)
        self.assertEqual(ps[0]['hitbox'],'unknown')
        self.assertEqual(ps[1]['hitbox'],'octane')
        self.assertFalse(ps[0]['catalog_verified'])
        self.assertEqual(ps[2]['hitbox'],'merc')
    def test_reconstruct_rows_and_goal_labels(self):
        fake=FakeFile();ps=[]
        for i,(team,hit) in enumerate([('blue','octane'),('blue','octane'),('orange','merc'),('orange','dominus')]):
            ps.append({'index':i,'team':team,'hitbox':hit})
        d=normalize_arrays(fake,ps)
        self.assertEqual(d['cars'].shape,(64,6,14))
        self.assertEqual(d['ball'].shape,(64,13))
        self.assertTrue(d['valid'].all())
        self.assertEqual(d['goal_rows'].tolist(),[45])
        self.assertEqual(d['goal_teams'].tolist(),[0])
        self.assertAlmostEqual(float(d['cars'][0,0,-1]),.4)
        self.assertEqual(d['team'].tolist(),[0,0,1,1,-1,-1])
        y,_=goal_labels(d['ball'],np.array([30,44,46]),30,d['goal_rows'],d['goal_teams'])
        self.assertEqual(y.tolist(),[1,1,0])
    def test_relative_replay_path_manifest_on_windows_style_setup(self):
        # Regression for path.relative_to() comparing a relative replay to
        # an absolute project root (the user's Windows traceback).
        with tempfile.TemporaryDirectory() as tmp:
            root=Path(tmp).resolve()
            raw=root/'replays'/'nested'/'demo.replay'
            raw.parent.mkdir(parents=True)
            raw.write_bytes(b'dummy')
            parquet=root/'replicar_parquet'
            parquet.mkdir()
            key=hashlib.sha256('nested/demo.replay'.encode()).hexdigest()[:16]
            (parquet/(key+'.parquet')).write_bytes(b'cached')
            original=Path.cwd()
            try:
                os.chdir(root)
                with patch.dict(sys.modules, {'replicar':object()}):
                    # The input is intentionally relative while root is absolute.
                    convert_missing([Path('replays/nested/demo.replay')], parquet, root, 8, 4)
            finally:
                os.chdir(original)
            manifest=json.loads((parquet/'manifest.json').read_text())
            self.assertEqual(manifest[key], 'nested/demo.replay')

    def test_rejected_missing_columns(self):
        f=FakeFile();del f.a['car_rotation']
        ps=[{'index':i,'team':'blue' if i<2 else 'orange','hitbox':'octane'} for i in range(4)]
        with self.assertRaisesRegex(ValueError,'car_rotation'):
            normalize_arrays(f,ps)

if __name__=='__main__': unittest.main()
