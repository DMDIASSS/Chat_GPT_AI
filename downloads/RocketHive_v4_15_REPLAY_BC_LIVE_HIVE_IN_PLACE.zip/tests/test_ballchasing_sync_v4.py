import unittest
from tempfile import TemporaryDirectory
from pathlib import Path
from urllib.error import HTTPError
from src.ballchasing_sync import BallchasingSync, RateLimited, retry_seconds, listing_url

ID='67f9b649-154b-462d-9664-4659949b3965'
OTHER='6ccad216-7d3b-4ac6-b86b-daf12d1ba333'


def website_cards():
    return ('<html><select><option>Supersonic Legend</option></select>'
            '<a href="/replay/'+ID+'">Match</a> Ranked Doubles '
            '<img alt="Supersonic Legend (Game average rank)">'
            '<a href="/replay/'+OTHER+'">Other</a> Ranked Doubles '
            '<img alt="Grand Champion (Game average rank)">'
            '</html>')


class DownloaderTests(unittest.TestCase):
    def test_site_fallback_replay_specific_ssl_and_resume(self):
        with TemporaryDirectory() as d:
            calls=[];site=[]
            def api(url):
                calls.append(url)
                if '/file' in url:return (b'A'*1024, {'Content-Type':'application/octet-stream'})
                raise HTTPError(url,400,'unsupported SSL rank',{},None)
            s=BallchasingSync('secret',directory=Path(d)/'replays',state_path=Path(d)/'db.json',
                              transport=api,request_interval=1.0,clock=lambda:0.,sleep=lambda _:None)
            s.website_transport=lambda url:(site.append(url) or (website_cards().encode(),{}))
            self.assertEqual(s.sync_once(max_new=1,max_pages=1),1)
            self.assertTrue((Path(d)/'replays'/(ID+'.replay')).exists())
            self.assertFalse((Path(d)/'replays'/(OTHER+'.replay')).exists())
            self.assertEqual(s.state['listing_mode'],'website')
            self.assertEqual(s.sync_once(max_new=1,max_pages=2),0)
            self.assertEqual(s.state['website_page'],3)  # no reset-to-page-1 bug
            self.assertTrue(all('min-rank=22' in url and 'playlist=10' in url for url in site))
            self.assertTrue(all('secret' not in url for url in site))
            self.assertTrue(all('ballchasing.com/api/' in url for url in calls))

    def test_dropdown_ssl_is_not_proof_of_replay_rank(self):
        with TemporaryDirectory() as d:
            s=BallchasingSync('secret',directory=Path(d)/'replays',state_path=Path(d)/'db.json',
                              transport=lambda url:(b'{}',{}))
            s.website_transport=lambda url:(('<html>Supersonic Legend'
                '<a href="/replay/'+ID+'">Match</a> Ranked Doubles'
                '<img alt="Grand Champion (Game average rank)"></html>').encode(),{})
            with self.assertRaisesRegex(ValueError,'No individually verified SSL'):
                s.public_listing()

    def test_retry_after_and_url_rank(self):
        self.assertEqual(retry_seconds({'Retry-After':'33'}),33)
        self.assertIn('max-rank=22',listing_url())
        self.assertIn('playlist=ranked-standard',listing_url())

if __name__=='__main__':unittest.main()
