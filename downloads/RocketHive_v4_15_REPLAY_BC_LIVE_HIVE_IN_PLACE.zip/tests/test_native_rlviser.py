"""Fast desktop-viewer unit tests with fake RocketSim/UDP; no GUI required."""
import math
import tempfile
import unittest
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch
import numpy as np

from src.bot_controller import drive, destination, decide
from tools import native_rlviser as native
from tools.watch_bot_rlviser import run
from tools.watch_rlviser import update_state


class Vec:
    def __init__(self, x=0, y=0, z=0):
        self.x, self.y, self.z = x, y, z
    def as_tuple(self):
        return self.x, self.y, self.z


class RotMat:
    def __init__(self, forward=None, right=None, up=None):
        self.forward = forward or Vec(1, 0, 0)
        self.right = right or Vec(0, 1, 0)
        self.up = up or Vec(0, 0, 1)


class State:
    def __init__(self, pos=None, rot_mat=None, vel=None, ang_vel=None, boost=100):
        self.pos = pos or Vec(0, 0, 17)
        self.rot_mat = rot_mat or RotMat()
        self.vel = vel or Vec()
        self.ang_vel = ang_vel or Vec()
        self.boost = boost
        self.is_on_ground = True


class Car:
    def __init__(self, car_id, team):
        self.id, self.team = car_id, team
        self.state = State()
        self.controls = None
    def get_state(self): return self.state
    def set_state(self, state): self.state = state
    def set_controls(self, controls): self.controls = controls
    def get_config(self): return object()


class Arena:
    tick_rate = 120
    def __init__(self, _mode):
        self._cars = []
        self.ball = SimpleNamespace()
        ball_state = State(pos=Vec(0, 0, 100))
        self.ball.get_state = lambda: ball_state
        self.ball.set_state = lambda state: setattr(self.ball, 'get_state', lambda: state)
        self.steps = 0
    def add_car(self, team):
        c = Car(len(self._cars) + 1, team)
        self._cars.append(c)
        return c
    def get_cars(self): return self._cars
    def get_boost_pads(self):
        return [SimpleNamespace(get_pos=lambda: Vec(100, 100, 0),
                                get_state=lambda: SimpleNamespace(is_active=True))]
    def step(self, n):
        self.steps += n
        for c in self._cars:
            if c.controls:
                c.state.pos.x += float(c.controls.throttle)*n

class RS:
    Vec = Vec
    RotMat = RotMat
    Arena = Arena
    GameMode = SimpleNamespace(SOCCAR=0)
    Team = SimpleNamespace(BLUE=0, ORANGE=1)
    CarState = State
    BallState = State
    @staticmethod
    def CarControls(**kwargs): return SimpleNamespace(**kwargs)
    @staticmethod
    def init(path): return path


class Viewer:
    def __init__(self): self.events=[]; self.finished=False
    def set_boost_pad_locations(self, x): self.pads=x
    def render(self, *args): self.events.append(args)
    def quit(self): self.finished=True


class NativeTests(unittest.TestCase):
    def test_quaternion_orientation_transferred(self):
        yaw=math.pi/2
        rot=native.rot_from_xyzw(RS,[0,0,math.sin(yaw/2),math.cos(yaw/2)])
        self.assertAlmostEqual(rot.forward.x, 0, places=6)
        self.assertAlmostEqual(rot.forward.y, 1, places=6)
        self.assertAlmostEqual(rot.right.x, -1, places=6)
    def test_interception_and_steering(self):
        car = State(pos=Vec(0,-2300,17), rot_mat=RotMat(Vec(0,1,0),Vec(-1,0,0),Vec(0,0,1)))
        ball=State(pos=Vec(0,0,100), vel=Vec(0,0,0))
        self.assertLess(destination(car,ball,1)[1],ball.pos.y)
        act=drive(car,ball,1)
        self.assertGreater(act.throttle,0)
        self.assertAlmostEqual(act.steer,0,places=5)
        self.assertTrue(act.boost)
        car.rot_mat.forward=Vec(0,-1,0)
        self.assertFalse(drive(car,ball,1).boost)
        self.assertTrue(-1<=drive(car,ball,1).steer<=1)
    def test_live_match_has_real_controls_and_render_packets(self):
        rv=Viewer()
        with patch.object(native,'find_meshes',return_value=Path('/pretend')):
            steps=run(RS,rv,seconds=.2,team_size=2,speed=1,clock=lambda:0,sleep=lambda _:None)
        self.assertEqual(steps,24)
        self.assertEqual(len(rv.events),24)
        self.assertTrue(rv.finished)
        self.assertEqual(len(rv.events[0][-1]),4)
    def test_replay_car_orientation_vel_and_boost_sent(self):
        arena=Arena(0)
        c=arena.add_car(0)
        data={'ball':np.array([[0,0,100,0,0,0,1,100,0,0,0,0,4]],float),
              'cars':np.zeros((1,1,14),float)}
        data['cars'][0,0]=[500,0,17,0,0,0,1,220,2,0,0,0,1,.72]
        update_state(RS,arena,[c],data,0)
        self.assertEqual(c.state.boost,72)
        self.assertEqual(c.state.vel.x,220)
        self.assertEqual(c.state.pos.x,500)
        self.assertEqual(arena.ball.get_state().vel.x,100)
    def test_missing_binary_fails_instead_of_browser_fallback(self):
        with patch.dict('os.environ', {'RLVISER_EXE':'/path/not/real'}, clear=True), \
             patch.object(native,'ROOT',Path('/path/not/real')):
            self.assertIsNone(native.find_binary())
            with self.assertRaises(FileNotFoundError): native.enter_viewer_directory()

if __name__ == '__main__': unittest.main()
