"""v4.8 regression coverage: legacy cohort repair, parser cache, controller truth."""
import json
import os
import sys
import tempfile
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch
import unittest
import numpy as np
import torch

from src.validation_v44 import FixedValidation
from src.continuous import ContinuousPoseLearner
from src.search_teacher import PhysicsSearchTeacher
from src.policy_inference import SearchPolicyController
from tests.test_quality_v44 import write_replay
from tests.test_search_teacher import replay
from src.physics_search import ACTIONS
from tools.train_action_controller_v48 import candidates

class QuietLogger:
    def log(self,*args):pass

class V48Tests(unittest.TestCase):
    def test_manifest_digest_survives_timestamp_touch_but_not_content_change(self):
        from src.train import ReplaySampler
        with tempfile.TemporaryDirectory() as td:
            base=Path(td)
            (base/'val').mkdir(); p=base/'val'/'x.npz'
            write_replay(p)
            sample=lambda:ReplaySampler(base,'val',15.,.13333,3)
            cohort=base/'v4_validation_cohort.json'
            first=FixedValidation(sample(),manifest=cohort)
            self.assertEqual(json.loads(cohort.read_text())['version'],2)
            self.assertGreater(first.count,0)
            os.utime(p,None)
            next=FixedValidation(sample(),manifest=cohort)
            self.assertEqual(next.changed,[])
            with p.open('ab') as out:out.write(b'change-the-file')
            after=FixedValidation(sample(),manifest=cohort)
            self.assertEqual(after.changed,['x.npz'])

    def test_legacy_validation_mtime_mismatch_rebases_and_archives_not_deletes(self):
        with tempfile.TemporaryDirectory() as td:
            cwd=Path.cwd();os.chdir(td)
            try:
                for folder in ['data/train','data/val']:Path(folder).mkdir(parents=True)
                write_replay(Path('data/train/t.npz'),source='train')
                valfile=Path('data/val/v.npz');write_replay(valfile,source='val')
                cfg={'model_dim':16,'batch_size':2,'seed':12,'auto_batch_probe':False,
                     'validation_max_replays':1,'validation_frames_per_replay':3,
                     'forecast_seconds':.13333333,'fps':15.,'auto_resume_champion':True}
                learner=ContinuousPoseLearner(cfg,device='cpu',logger=QuietLogger())
                learner.refresh_replays();learner.train_chunk(1)
                old_best=Path('models/v4_pose_best.pt').read_bytes()
                # Simulate stale V1 cohort written before parser recooked NPZ files.
                v2=json.loads(Path('data/v4_validation_cohort.json').read_text())
                v1={'version':1,'entries':[{**entry,'mtime_ns':1} for entry in v2['entries']]}
                Path('data/v4_validation_cohort.json').write_text(json.dumps(v1))
                learner.refresh_replays()
                self.assertIsNotNone(learner.fixed_validation)
                self.assertGreater(learner.fixed_validation.count,0)
                self.assertTrue(list(Path('data/validation_cohort_history').glob('*.json')))
                self.assertTrue(Path('reports/v48_validation_rebaseline.json').is_file())
                self.assertEqual(Path('models/v4_pose_best.pt').read_bytes(),old_best)
                self.assertEqual(json.loads(Path('data/v4_validation_cohort.json').read_text())['version'],2)
            finally:os.chdir(cwd)

    def test_train_fails_closed_without_validation(self):
        with tempfile.TemporaryDirectory() as td:
            cwd=Path.cwd();os.chdir(td)
            try:
                from tests.test_best_checkpoint_v42 import FakeSampler
                worker=ContinuousPoseLearner({'model_dim':16},device='cpu',logger=QuietLogger())
                worker.sampler=FakeSampler()
                with self.assertRaisesRegex(RuntimeError,'Refusing to train'):
                    worker.train_chunk(1)
                self.assertFalse(Path('models/v4_pose_resume.pt').exists())
            finally:os.chdir(cwd)

    def test_controller_does_not_publish_random_model_on_terminal(self):
        class OffTrajectoryContext:
            def __init__(self,*a,**kw):pass
            def search(self,s,**kw):
                n=int(s['mode'])
                return SimpleNamespace(team_plan=tuple([ACTIONS[0]]*n),robust_score=-1,num_rollouts=10)
            def rollout(self,s,blue,orange):
                out=dict(s);out['ball']=s['ball'].copy()
                out['ball'][0]+=99999
                return out
        with tempfile.TemporaryDirectory() as td:
            cwd=Path.cwd();os.chdir(td)
            try:
                with patch('src.search_teacher.SearchContext',OffTrajectoryContext):
                    worker=PhysicsSearchTeacher({'seed':5},simulator=object())
                    result=worker.train_replay(replay())
                    self.assertEqual(result['tracking/survival_fraction'],0)
                    self.assertEqual(worker.step,0)
                    self.assertFalse(Path('models/v4_action_policy_search_teacher.pt').exists())
            finally:os.chdir(cwd)

    def test_zero_step_model_refused_in_viewer(self):
        from src.search_teacher import build_policy,OBS_DIM
        with tempfile.TemporaryDirectory() as td:
            path=Path(td)/'untrained.pt'
            torch.save({'type':'SEARCH_DISTILLED_ACTION_POLICY_unvalidated',
                'obs_dim':OBS_DIM,'action_table':ACTIONS,
                'model':build_policy().state_dict(),'step':0},path)
            with self.assertRaisesRegex(ValueError,'zero optimizer updates'):
                SearchPolicyController(path)

    def test_direct_action_preflight_sees_valid_replay(self):
        with tempfile.TemporaryDirectory() as td:
            folder=Path(td);write_replay(folder/'a.npz')
            good,bad=candidates(folder)
            self.assertEqual(len(good),1)
            self.assertEqual(bad,[])

if __name__=='__main__':unittest.main()

def test_only_one_action_teacher_can_write_to_checkpoint():
    import os
    from src.controller_lock_v48 import ControllerProcessLock
    with tempfile.TemporaryDirectory() as td:
        target=Path(td)/'models'/'policy.pt'
        one=ControllerProcessLock(target)
        try:
            with __import__('pytest').raises(RuntimeError,match='Another RocketHive'):
                ControllerProcessLock(target)
        finally:
            one.close()
        next=ControllerProcessLock(target)
        next.close()

def test_parser_does_not_rewrite_unchanged_hitbox_review_csv():
    import types
    from src.replicar_dataset import parse_folder
    with tempfile.TemporaryDirectory() as td:
        previous=Path.cwd();os.chdir(td)
        try:
            Path('replays').mkdir();Path('replicar_parquet').mkdir()
            Path('replicar_parquet/fake.parquet').write_bytes(b'fake-parquet')
            csv=Path('replays/hitboxes.csv')
            csv.write_text('replay,team,slot,body,hitbox\nmanual.replay,blue,0,octane,octane\n',encoding='utf-8')
            before=csv.stat().st_mtime_ns
            data={'time':np.arange(50)/15,'ball':np.zeros((50,13),np.float32),
                  'cars':np.zeros((50,6,14),np.float32),
                  'valid':np.ones(50,dtype=bool),'team':np.array([0,1,-1,-1,-1,-1]),
                  'mask':np.array([1,1,0,0,0,0],dtype=bool),'hitboxes':np.array(['octane']*6),
                  'mode':1,'segment':np.zeros(50,dtype=int),'fps':15.,'goal_rows':np.array([])}
            players=[{'hitbox':'octane','team':'blue'},{'hitbox':'octane','team':'orange'}]
            with patch.dict(sys.modules,{'replicar':types.SimpleNamespace(read=lambda p:SimpleNamespace(header={}))}):
                with patch('src.replicar_dataset.read_catalog',return_value={}):
                    with patch('src.replicar_dataset.verified_players',return_value=players):
                        with patch('src.replicar_dataset.normalize_arrays',return_value=data):
                            assert parse_folder('replays','data',{'fps':15.})==1
                            assert parse_folder('replays','data',{'fps':15.})==1
            assert csv.stat().st_mtime_ns==before
        finally:os.chdir(previous)
