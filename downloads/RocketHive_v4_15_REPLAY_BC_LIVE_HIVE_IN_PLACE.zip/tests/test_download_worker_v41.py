import threading
import unittest
from src.download_worker import DownloadWorker

class FakeSync:
    def __init__(self):
        self.state={}
        self.done=threading.Event()
        self.calls=0
    def sync_once(self, max_new, max_pages):
        self.calls+=1
        self.done.set()
        return 2

class DownloadWorkerTests(unittest.TestCase):
    def test_download_runs_off_main_thread_and_reports_event(self):
        sync=FakeSync()
        worker=DownloadWorker(sync,idle_seconds=1).start()
        try:
            self.assertTrue(sync.done.wait(timeout=2))
            # Worker may signal immediately after event; use repeated drain.
            total=0
            for _ in range(20):
                total+=worker.drain()
                if total:break
                sync.done.wait(0.01)
            self.assertEqual(total,2)
        finally:worker.stop()
        self.assertFalse(worker.thread.is_alive())

if __name__=='__main__':unittest.main()
