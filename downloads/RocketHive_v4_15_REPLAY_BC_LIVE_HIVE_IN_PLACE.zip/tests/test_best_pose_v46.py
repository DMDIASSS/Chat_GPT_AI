"""Test champion selection on the exact same fixed validation examples."""
import json
import os
from pathlib import Path
from tempfile import TemporaryDirectory
import unittest
import torch
from src.best_pose_v46 import (POSE_TYPE, assess_saved_pose_models, champion_record,
                              manual_signature, save_selected_champion)
from src.continuous import ContinuousPoseLearner
from src.models import JointForecaster
from src.checkpoint_v44 import save_atomic

class FakeValidation:
    count=8
    missing=[]
    changed=[]
    def evaluate(self, model, loss_fn, device, batch_size=32):
        return abs(float(model.ball_in.weight[0,0].item())-1.)

class SilentLogger:
    def log(self, info, step):pass

def make_ck(weight, step, claimed_best=0.):
    m=JointForecaster(16)
    with torch.no_grad():m.ball_in.weight[0,0]=weight
    opt=torch.optim.AdamW(m.parameters())
    return {'model':m.state_dict(),'optimizer':opt.state_dict(),'step':step,
            'best':claimed_best,'type':POSE_TYPE,'validation_cohort_id':'older_cohort'}

class ChampionSelectionTests(unittest.TestCase):
    def setUp(self):
        self.tmp=TemporaryDirectory();self.cwd=os.getcwd();os.chdir(self.tmp.name)
        Path('models').mkdir()
    def tearDown(self):os.chdir(self.cwd);self.tmp.cleanup()
    def select(self):
        return assess_saved_pose_models(torch,FakeValidation(),lambda:JointForecaster(16),
                                       lambda *x:0.,'cpu','same_fixed_cohort')

    def test_score_overrides_logged_best_and_optimizer_step(self):
        save_atomic(torch,'models/v4_pose_resume.pt',make_ck(.5,12400,claimed_best=0.001))
        save_atomic(torch,'models/v4_pose_best.pt',make_ck(.9,9700,claimed_best=0.9))
        Path('models/pose_candidates').mkdir()
        save_atomic(torch,'models/pose_candidates/older.pt',make_ck(1.,1148,claimed_best=10.))
        winner,report=self.select()
        self.assertEqual(winner['step'],1148)
        self.assertAlmostEqual(winner['score'],0.)
        self.assertEqual(len(report['candidates']),3)

    def test_rejects_corrupted_and_wrong_model_type(self):
        save_atomic(torch,'models/v4_pose_resume.pt',make_ck(.6,500))
        root=Path('models/pose_candidates');root.mkdir()
        (root/'corrupt.pt').write_bytes(b'garbage')
        save_atomic(torch,root/'controller.pt',dict(make_ck(1.,10),type='driving_controller'))
        winner,report=self.select()
        self.assertEqual(winner['step'],500)
        self.assertEqual(sum(x['ok'] for x in report['candidates']),1)
        self.assertEqual((root/'corrupt.pt').read_bytes(),b'garbage')

    def test_promotion_keeps_latest_and_old_best_backup(self):
        save_atomic(torch,'models/v4_pose_resume.pt',make_ck(.5,900))
        save_atomic(torch,'models/v4_pose_best.pt',make_ck(.7,800))
        winner,_=self.select()
        save_selected_champion(torch,champion_record(winner['checkpoint'],winner['score'],
                                                      'same_fixed_cohort',winner['path']))
        saved=torch.load('models/v4_pose_champion.pt',weights_only=False)
        self.assertEqual(saved['validation_cohort_id'],'same_fixed_cohort')
        self.assertEqual(saved['best'],winner['score'])
        self.assertTrue(Path('models/v4_pose_best_previous.pt').exists())
        self.assertEqual(torch.load('models/v4_pose_resume.pt',weights_only=False)['step'],900)

    def test_resume_best_weights_keeps_current_training_step(self):
        save_atomic(torch,'models/v4_pose_resume.pt',make_ck(.5,12400))
        save_atomic(torch,'models/v4_pose_best.pt',make_ck(1.,200))
        trainer=ContinuousPoseLearner({'model_dim':16,'auto_resume_champion':True},
                                      device='cpu',logger=SilentLogger())
        trainer.cohort_id='same_fixed_cohort';trainer.fixed_validation=FakeValidation()
        trainer.rebaseline_best()
        self.assertEqual(trainer.step,12400)
        self.assertAlmostEqual(float(trainer.model.ball_in.weight[0,0].item()),1.,places=6)
        self.assertAlmostEqual(trainer.best,0.)
        report=json.loads(Path('reports/v4_champion_selection.json').read_text())
        self.assertEqual(report['winner'],'models/v4_pose_best.pt')
        trainer.checkpoint(None)
        self.assertEqual(torch.load('models/v4_pose_resume.pt',weights_only=False)['step'],12400)

    def test_invalid_import_cannot_erase_models(self):
        root=Path('models/pose_candidates');root.mkdir()
        (root/'bad.pt').write_bytes(b'nope')
        trainer=ContinuousPoseLearner({'model_dim':16},device='cpu',logger=SilentLogger())
        trainer.cohort_id='same_fixed_cohort';trainer.fixed_validation=FakeValidation()
        with self.assertRaisesRegex(RuntimeError,'No valid comparable'):
            trainer.rebaseline_best()
        self.assertEqual((root/'bad.pt').read_bytes(),b'nope')
        self.assertFalse(Path('models/v4_pose_champion.pt').exists())

    def test_new_candidate_does_not_require_rescoring_every_step(self):
        self.assertEqual(manual_signature(),())
        root=Path('models/pose_candidates');root.mkdir()
        (root/'a.pt').write_bytes(b'ab')
        before=manual_signature()
        (root/'a.pt').write_bytes(b'abc')
        self.assertNotEqual(manual_signature(),before)

if __name__=='__main__':unittest.main()

# A repeated startup must not overwrite the most useful previous-generation file.
def test_repeated_startup_preserves_previous_generation(tmp_path):
    original=make_ck(.5,100)
    replaced=make_ck(1.,200)
    save_atomic(torch,tmp_path/'v4_pose_best.pt',original)
    data=champion_record(replaced,0.,'same_cohort','new-version')
    save_selected_champion(torch,data,models_dir=tmp_path)
    previous=tmp_path/'v4_pose_best_previous.pt'
    snapshot=previous.read_bytes()
    save_selected_champion(torch,data,models_dir=tmp_path)
    assert previous.read_bytes()==snapshot

def test_incompatible_architecture_is_skipped(tmp_path):
    bad=make_ck(.5,200)
    # Invalid neural-network tensor shape should never become champion.
    bad['model']['ball_in.weight']=torch.randn(5,5)
    save_atomic(torch,tmp_path/'v4_pose_best.pt',bad)
    save_atomic(torch,tmp_path/'v4_pose_resume.pt',make_ck(.9,300))
    best, report=assess_saved_pose_models(torch,FakeValidation(),lambda:JointForecaster(16),
                                          lambda *x:0.,'cpu','same',models_dir=tmp_path)
    assert best['step']==300
    assert any(not x['ok'] for x in report['candidates'])


def test_skip_promotion_when_validation_data_missing(tmp_path):
    obj=FakeValidation()
    obj.missing=['deleted-sample.npz']
    save_atomic(torch,tmp_path/'v4_pose_best.pt',make_ck(.9,200))
    try:
        assess_saved_pose_models(torch,obj,lambda:JointForecaster(16),
                                 lambda *x:0.,'cpu','same',models_dir=tmp_path)
        assert False,'should never promote without complete validation cohort'
    except ValueError as ex:
        assert 'changed' in str(ex)


def test_settings_keep_custom_wandb_metric_importance(tmp_path):
    from tools.enable_v46_defaults import migrate
    p=tmp_path/'config_v4.json'
    p.write_text(json.dumps({'wandb_skill_metrics':{'pose/champion_val_loss':[9,'low']},
                             'auto_resume_champion':False}),encoding='utf-8')
    assert migrate(p)
    data=json.loads(p.read_text())
    assert data['wandb_skill_metrics']['pose/champion_val_loss']==[9,'low']
    assert data['auto_resume_champion'] is False
    assert data['wandb_skill_metrics']['pose/champion_source_step']==[0,'neutral']
    assert migrate(p) is False
