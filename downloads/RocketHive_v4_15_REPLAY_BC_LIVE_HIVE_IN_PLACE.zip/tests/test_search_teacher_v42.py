"""Checkpoint-history retention; simulated physics is mocked, not validated."""
import unittest
from tempfile import TemporaryDirectory
from unittest.mock import patch
from pathlib import Path
import os
import numpy as np
from types import SimpleNamespace
from src.physics_search import ACTIONS
from src.search_teacher import PhysicsSearchTeacher
from tests.test_search_teacher import replay

class HistoryTests(unittest.TestCase):
    def test_bounded_policy_checkpoint_history(self):
        class MockContext:
            def __init__(self,rs,our_team,**kwargs):self.team=our_team
            def search(self,state,**kwargs):
                return SimpleNamespace(team_plan=(ACTIONS[1],ACTIONS[1]),robust_score=1.5,num_rollouts=4)
            def rollout(self,state,blue,orange):return state
        with TemporaryDirectory() as d:
            cwd=Path.cwd();os.chdir(d)
            try:
                with patch('src.search_teacher.SearchContext',MockContext):
                    worker=PhysicsSearchTeacher({'seed':1,'policy_snapshot_every':1,
                                                 'policy_snapshot_keep':2},simulator=object())
                    for i in range(4):worker.train_replay(replay())
                    history=list(Path('models/v4_action_policy_history').glob('step_*.pt'))
                    assert len(history)==2
                    assert [p.name for p in sorted(history)]==['step_0000000003.pt','step_0000000004.pt']
                    assert Path('models/v4_action_policy_search_teacher.pt').exists()
            finally:os.chdir(cwd)

if __name__=='__main__':unittest.main()
