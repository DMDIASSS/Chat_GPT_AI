"""Credential-persistence tests; Windows DPAPI itself requires a Windows host."""
import json
import os
from pathlib import Path
import sys
import tempfile
import unittest
from unittest.mock import patch

from tools import credentials_popup as creds


class StoredKeysTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.path = Path(self.temp.name) / 'credentials.dpapi'
        self.platform = patch.object(creds.sys, 'platform', 'win32')
        self.path_patch = patch.object(creds, '_secret_path', return_value=self.path)
        self.crypt_patch = patch.object(creds, '_crypt', side_effect=self.fake_crypt)
        self.platform.start()
        self.path_patch.start()
        self.crypt_patch.start()

    def tearDown(self):
        self.crypt_patch.stop()
        self.path_patch.stop()
        self.platform.stop()
        self.temp.cleanup()

    @staticmethod
    def fake_crypt(data, *, decrypt):
        if decrypt:
            if not data.startswith(b'DPAPI-TEST:'):
                raise creds.CredentialError('invalid ciphertext')
            return data[len(b'DPAPI-TEST:'):][::-1]
        return b'DPAPI-TEST:' + data[::-1]

    def test_secure_storage_does_not_write_plaintext(self):
        creds.save_tokens('BALL_PRIVATE', 'WANDB_PRIVATE')
        blob = self.path.read_bytes()
        self.assertNotIn(b'BALL_PRIVATE', blob)
        self.assertNotIn(b'WANDB_PRIVATE', blob)
        self.assertEqual(creds.load_saved_tokens(), ('BALL_PRIVATE', 'WANDB_PRIVATE'))

    def test_restart_skips_popup_and_reuses_saved_tokens(self):
        creds.save_tokens('ball-saved', 'wandb-saved')
        with patch.object(creds, 'prompt_tokens', side_effect=AssertionError('should skip')):
            self.assertEqual(creds.resolve_tokens(), ('ball-saved', 'wandb-saved'))
            self.assertEqual(creds.resolve_tokens(no_popup=True), ('ball-saved', 'wandb-saved'))

    def test_explicit_environment_tokens_override_saved_without_changing_store(self):
        creds.save_tokens('old-b', 'old-w')
        self.assertEqual(creds.resolve_tokens('new-b', ''), ('new-b', 'old-w'))
        self.assertEqual(creds.load_saved_tokens(), ('old-b', 'old-w'))

    def test_manage_can_force_edit_popup(self):
        creds.save_tokens('old-b', 'old-w')
        with patch.object(creds, 'prompt_tokens', return_value=('new-b', 'new-w')) as pop:
            self.assertEqual(creds.resolve_tokens(force_popup=True), ('new-b', 'new-w'))
            self.assertTrue(pop.call_args.kwargs['has_saved'])

    def test_removal(self):
        creds.save_tokens('abc', 'def')
        creds.clear_saved_tokens()
        self.assertFalse(self.path.exists())
        self.assertIsNone(creds.load_saved_tokens())

    def test_blank_both_clears(self):
        creds.save_tokens('abc', 'def')
        creds.save_tokens('', '')
        self.assertFalse(self.path.exists())

    def test_corrupted_data_not_returned(self):
        self.path.write_bytes(b'invalid')
        with self.assertRaises(creds.CredentialError):
            creds.load_saved_tokens()
        with patch.object(creds, 'prompt_tokens', return_value=('new-b', 'new-w')):
            self.assertEqual(creds.resolve_tokens(), ('new-b', 'new-w'))

    def test_no_popup_stays_noninteractive_with_corrupt_data(self):
        self.path.write_bytes(b'invalid')
        with patch.object(creds, 'prompt_tokens', side_effect=AssertionError('should skip')):
            self.assertEqual(creds.resolve_tokens(no_popup=True), ('', ''))

    def test_partial_credential_persistence(self):
        creds.save_tokens('only-ball', '')
        with patch.object(creds, 'prompt_tokens', side_effect=AssertionError('should skip')):
            self.assertEqual(creds.resolve_tokens(), ('only-ball', ''))

    def test_no_file_when_never_saved(self):
        with patch.object(creds, 'prompt_tokens', return_value=('b', 'w')):
            self.assertEqual(creds.resolve_tokens(), ('b', 'w'))


class NonWindowsTests(unittest.TestCase):
    def test_nonwindows_has_no_plaintext_fallback(self):
        with patch.object(creds.sys, 'platform', 'linux'), \
             patch.object(creds, '_crypt', side_effect=AssertionError('encrypt should not run')):
            self.assertIsNone(creds.load_saved_tokens())
            with self.assertRaises(creds.CredentialError):
                creds.save_tokens('secret', '')


if __name__ == '__main__':
    unittest.main()
