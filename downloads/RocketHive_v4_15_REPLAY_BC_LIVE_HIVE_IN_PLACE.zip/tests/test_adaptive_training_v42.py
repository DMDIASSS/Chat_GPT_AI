import unittest
from src.adaptive_training import AdaptiveSchedule, select_batch


class AdaptiveScheduleTests(unittest.TestCase):
    def test_steady_proficiency_ramp_and_cap(self):
        a=AdaptiveSchedule(min_steps=10,max_steps=50,evals_per_stage=2,min_improvement=.05)
        assert a.current_steps()==10
        a.observe(100)
        a.observe(90)
        assert a.current_steps()==10
        a.observe(90)
        assert a.current_steps()==15
        a.observe(80)
        a.observe(80)
        assert a.current_steps()==22
        for loss in [60,60,40,40,20,20,10,10,5,5]:a.observe(loss)
        assert a.current_steps()==50

    def test_regression_never_promotes(self):
        a=AdaptiveSchedule(evals_per_stage=2)
        a.observe(100);a.observe(90)
        a.observe(1,regression=True)
        assert a.stage==0
        a.observe(float('nan'))
        assert a.stage==0
        a.observe(90)
        assert a.stage==0  # 1 stable evaluation after reset

    def test_resume_and_batch_selection(self):
        a=AdaptiveSchedule();a.observe(3);a.observe(2)
        b=AdaptiveSchedule.from_config({'adaptive_min_steps':10,'adaptive_max_steps':200},a.state_dict())
        assert a.state_dict()==b.state_dict()
        measurements=[{'batch':24,'samples_per_sec':100},{'batch':48,'samples_per_sec':160},
                      {'batch':96,'samples_per_sec':150}]
        assert select_batch(measurements,32)==48
        assert select_batch([],32)==32


if __name__=='__main__':unittest.main()
