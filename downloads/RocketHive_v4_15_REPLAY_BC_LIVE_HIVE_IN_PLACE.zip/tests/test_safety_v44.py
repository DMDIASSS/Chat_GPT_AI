import json
import os
from pathlib import Path
import tempfile
import unittest

import torch
from src.telemetry_v44 import append_jsonl
from src.checkpoint_v44 import save_atomic
from src.continuous import ContinuousPoseLearner
from tools.monitor_v44 import summarize


class LogRotationTests(unittest.TestCase):
    def test_bounded_logs_preserve_latest(self):
        with tempfile.TemporaryDirectory() as tmp:
            p=Path(tmp)/'events.jsonl'
            for i in range(30):
                append_jsonl(p,{'iteration':i},max_bytes=50,keep=2)
            self.assertLessEqual(len(list(Path(tmp).glob('events.jsonl*'))),3)
            self.assertEqual(json.loads(p.read_text().splitlines()[-1])['iteration'],29)
            self.assertTrue((Path(tmp)/'events.jsonl.1').exists())


class AllCheckpointsUnreadableTests(unittest.TestCase):
    def test_never_overwrite_if_all_recovery_sources_corrupt(self):
        with tempfile.TemporaryDirectory() as tmp:
            previous=os.getcwd();os.chdir(tmp)
            try:
                Path('models').mkdir()
                p=Path('models/v4_pose_resume.pt')
                p.write_bytes(b'bad-data')
                before=p.read_bytes()
                with self.assertRaisesRegex(RuntimeError, 'WITHOUT overwriting'):
                    ContinuousPoseLearner({'model_dim':32},device='cpu')
                self.assertEqual(p.read_bytes(),before)
            finally:os.chdir(previous)


class StatusReaderTests(unittest.TestCase):
    def test_summary_no_secrets(self):
        with tempfile.TemporaryDirectory() as tmp:
            base=Path(tmp);(base/'reports').mkdir()
            (base/'reports'/'v4_status.json').write_text(json.dumps({
                'updated_utc':'test','pose_step':99,'device':'cpu',
                'metrics':{'performance/pose_samples_per_sec':888}}))
            report=summarize(base)
            self.assertEqual(report['pose_optimizer_steps'],99)
            self.assertEqual(report['pose_examples_per_sec'],888)
            self.assertNotIn('WANDB_API_KEY',str(report))

if __name__=='__main__':unittest.main()
