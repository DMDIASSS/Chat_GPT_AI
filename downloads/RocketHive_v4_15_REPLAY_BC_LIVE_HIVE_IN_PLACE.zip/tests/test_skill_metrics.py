import unittest
from pathlib import Path
from tempfile import TemporaryDirectory
from src.skill_metrics import SkillMetricNames, validate_spec


class SkillMetricTests(unittest.TestCase):
    def test_names_and_directions(self):
        specs=SkillMetricNames({'Loss': [6, 'low'], 'Win rate':[10,'high'], 'Downloads':[0,'high']})
        self.assertEqual(specs.annotated('Loss'), 'Loss(6,low)')
        self.assertEqual(specs.annotated('Win rate'), 'Win rate(10,high)')
        self.assertEqual(specs.annotated('Downloads'), 'Downloads(0,neutral)')
        self.assertEqual(specs.annotated('Unlisted'), 'Unlisted(0,neutral)')
        self.assertEqual(specs.rename_values({'Loss': 1.2, 'Downloads': 9, 'missing': None}),
                         {'Loss(6,low)': 1.2, 'Downloads(0,neutral)':9.0})
        with TemporaryDirectory() as d:
            path=specs.save_legend(Path(d)/'legend.json')
            self.assertIn('Loss(6,low)', path.read_text())

    def test_reject_invalid_ratings(self):
        for value in ([-1,'low'], [11,'high'], [1,'neutral'], [True,'high'], [6,'fast']):
            with self.assertRaises(ValueError):validate_spec(value)

if __name__=='__main__': unittest.main()
