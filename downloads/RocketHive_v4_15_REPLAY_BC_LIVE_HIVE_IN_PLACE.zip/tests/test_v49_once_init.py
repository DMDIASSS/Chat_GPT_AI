"""Regressions for native RocketSim process initialization / first teacher rollout."""
from pathlib import Path
from unittest.mock import patch
import unittest

from tools import native_rlviser as native
from src.physics_search import replay_arena, SearchContext, ACTIONS
from src.search_teacher import replay_state
from tests.test_native_rlviser import RS
from tests.test_search_teacher import replay


class OnceInitTests(unittest.TestCase):
    def test_preflight_then_repeated_rollout_only_initializes_once(self):
        class NativeRaisesOnSecondInit(RS):
            init_calls = 0
            @classmethod
            def init(cls, path):
                cls.init_calls += 1
                if cls.init_calls != 1:
                    raise RuntimeError('Already inited')

        data = replay(n=5, mode=1)
        data['hitboxes'][:2] = 'octane'
        state = replay_state(data, 0)
        with patch.object(native, 'find_meshes', return_value=Path('/pretend/mesh')):
            # The direct launcher does this preflight before creating any search.
            native.init_arena(NativeRaisesOnSecondInit)
            for _ in range(5):
                arena, cars = replay_arena(NativeRaisesOnSecondInit, state)
                self.assertEqual(len(cars), 2)
                self.assertIsNotNone(arena)
            search = SearchContext(NativeRaisesOnSecondInit, ticks=8)
            for _ in range(3):
                result = search.rollout(state, (ACTIONS[0],), (ACTIONS[9],))
                self.assertEqual(result['cars'].shape[0], 2)
        self.assertEqual(NativeRaisesOnSecondInit.init_calls, 1)

    def test_preinitialized_native_binding_is_accepted_and_cached(self):
        class AlreadyInitialized(RS):
            init_calls = 0
            @classmethod
            def init(cls, path):
                cls.init_calls += 1
                raise RuntimeError('Already inited')

        with patch.object(native, 'find_meshes', return_value=Path('/pretend/mesh')):
            native.init_arena(AlreadyInitialized)
            native.init_arena(AlreadyInitialized)
        self.assertEqual(AlreadyInitialized.init_calls, 1)

    def test_unexpected_init_error_is_never_swallowed_or_cached(self):
        class BrokenMeshes(RS):
            init_calls = 0
            @classmethod
            def init(cls, path):
                cls.init_calls += 1
                raise RuntimeError('mesh loading failed')

        with patch.object(native, 'find_meshes', return_value=Path('/pretend/mesh')):
            for _ in range(2):
                with self.assertRaisesRegex(RuntimeError, 'mesh loading failed'):
                    native.init_arena(BrokenMeshes)
        self.assertEqual(BrokenMeshes.init_calls, 2)

    def test_missing_meshes_cannot_be_marked_initialized(self):
        class NoMeshes(RS):
            init_calls = 0
            @classmethod
            def init(cls, path):
                cls.init_calls += 1

        with patch.object(native, 'find_meshes', return_value=None):
            with self.assertRaisesRegex(FileNotFoundError, 'Soccar collision meshes'):
                native.init_arena(NoMeshes)
        self.assertEqual(NoMeshes.init_calls, 0)
        with patch.object(native, 'find_meshes', return_value=Path('/pretend/mesh')):
            native.init_arena(NoMeshes)
        self.assertEqual(NoMeshes.init_calls, 1)


if __name__ == '__main__':
    unittest.main()

class CheckPhysicsTests(unittest.TestCase):
    def test_read_only_preflight_executes_one_real_search_rollout(self):
        import tempfile
        import numpy as np
        from tools.check_physics_search_v49 import check_simulator

        class OneTimeRS(RS):
            init_calls=0
            @classmethod
            def init(cls,path):
                cls.init_calls+=1
                if cls.init_calls>1:
                    raise RuntimeError('Already inited')

        with tempfile.TemporaryDirectory() as tmp:
            p=Path(tmp)/'a.npz'
            data=replay(n=7,mode=1)
            data['hitboxes'][:2] = 'octane'
            np.savez(p,**data)
            messages=[]
            with patch.object(native,'find_meshes',return_value=Path('/pretend/meshes')):
                result=check_simulator(OneTimeRS,train_dir=tmp,print_fn=messages.append)
            self.assertTrue(result)
            self.assertEqual(OneTimeRS.init_calls,1)
            self.assertTrue(any('rollout PASS' in m for m in messages))
