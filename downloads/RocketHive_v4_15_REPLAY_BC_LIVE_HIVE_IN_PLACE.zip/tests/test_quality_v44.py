"""v4.4 deterministic validation, event sampling, health and recovery checks."""
import json
from pathlib import Path
import tempfile
import unittest

import numpy as np
import torch
from src.train import ReplaySampler
from src.validation_v44 import FixedValidation
from src.checkpoint_v44 import save_atomic, load_latest_valid
from src.data_health_v44 import audit
from src.replay_sampling_v44 import event_starts
from src.system_guard_v44 import enough_space, free_gib
from src.policy_inference import live_state_flags


def write_replay(path, mode=2, source='synthetic', aerial=True):
    n=60
    t=np.arange(n,dtype=np.float64)/15
    ball=np.zeros((n,13),dtype=np.float32)
    ball[:,3:7]=[0,0,0,1]
    ball[:,1]=t*100
    cars=np.zeros((n,6,14),dtype=np.float32)
    cars[:,:,3:7]=[0,0,0,1]
    cars[:,0,2]=np.linspace(20,800,n) if aerial else 20
    cars[:,0,0]=3700 if aerial else 0
    cars[:,:,13]=1
    flag=np.ones((n,),dtype=bool)
    np.savez_compressed(path, time=t, ball=ball,cars=cars,valid=flag,
        team=np.asarray([0]*mode+[1]*mode+[-1]*(6-2*mode)),
        mask=np.asarray([True]*(2*mode)+[False]*(6-2*mode)),
        hitboxes=np.asarray(['octane']*(2*mode)+['padding']*(6-2*mode)),
        mode=mode, segment=np.zeros(n,dtype=np.int32),
        flip_reset_rows=np.asarray([25],dtype=np.int64),
        goal_rows=np.asarray([46],dtype=np.int64),
        source=source, fps=15.)


class ValidationTests(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory()
        self.path=Path(self.temp.name)
        (self.path/'val').mkdir()
        (self.path/'train').mkdir()
        for i,m in enumerate((1,2,3)):
            write_replay(self.path/'val'/f'{i}.npz',mode=m,source=f'V{i}')
        write_replay(self.path/'train'/'t.npz',source='TRAIN')
    def tearDown(self):self.temp.cleanup()

    def test_fixed_replays_and_frames_persist_across_restart(self):
        samples=ReplaySampler(self.path,'val',15.,.1333,1)
        manifest=self.path/'cohort.json'
        a=FixedValidation(samples,manifest,max_replays=3,frames_per_replay=6)
        first=[(p.name, frames.tolist()) for p,frames in a.entries]
        self.assertEqual(a.count,18)
        b=FixedValidation(ReplaySampler(self.path,'val',15.,.1333,9999),manifest,
                          max_replays=1,frames_per_replay=1)
        self.assertEqual(first,[(p.name,fr.tolist()) for p,fr in b.entries])
        self.assertEqual(set(x[0] for x in first),{'0.npz','1.npz','2.npz'})

    def test_validation_does_not_change_rng_or_model(self):
        samples=ReplaySampler(self.path,'val',15.,.1333,10)
        fixed=FixedValidation(samples,self.path/'anchors.json')
        class Passthrough(torch.nn.Module):
            def forward(self,ball,cars,teams,boxes,mask):return ball,cars
        model=Passthrough()
        loss_fn=lambda p,c,rb,rc,mask: (p-rb).abs().mean()+(c-rc).abs().mean()
        before=str(samples.rng.bit_generator.state)
        one=fixed.evaluate(model,loss_fn,'cpu')
        two=fixed.evaluate(model,loss_fn,'cpu')
        self.assertAlmostEqual(one,two,places=12)
        self.assertEqual(before,str(samples.rng.bit_generator.state))

    def test_changed_cohort_never_silently_accepted(self):
        sampler=ReplaySampler(self.path,'val',15.,.1333,2)
        manifest=self.path/'cohort.json'
        FixedValidation(sampler,manifest)
        with (self.path/'val'/'1.npz').open('ab') as f:f.write(b'X')
        new=FixedValidation(ReplaySampler(self.path,'val',15.,.1333,1),manifest)
        self.assertIn('1.npz',new.changed)
        self.assertNotIn('1.npz',[p.name for p,fr in new.entries])

    def test_event_focus_respects_valid_starts(self):
        tr=ReplaySampler(self.path,'train',15.,.1333,2,event_probability=1.0)
        self.assertGreater(len(tr.focus_indices[str(tr.available[0][0])]),0)
        self.assertTrue(tr.focus_counts.get('flip_reset',0)>0)
        _,_,data,takes=tr.batch(24,torch.device('cpu'))
        self.assertEqual(tr.focus_selections,24)
        starts=set(tr.available[0][1])
        self.assertTrue(all(int(t) in starts for t in takes))

    def test_data_audit_finds_split_leak(self):
        r=audit(self.path)
        self.assertTrue(r['ok'])
        self.assertEqual(r['train_files'],1)
        self.assertEqual(r['val_files'],3)
        write_replay(self.path/'val'/'extra.npz',source='TRAIN')
        leak=audit(self.path)
        self.assertFalse(leak['ok'])
        self.assertIn('TRAIN',leak['split_source_collisions'])


class Checkpoints(unittest.TestCase):
    def test_corrupt_latest_recovers_prior(self):
        with tempfile.TemporaryDirectory() as root:
            p=Path(root)/'resume.pt'
            one={'model':{'x':1},'optimizer':{},'type':'pose','step':1}
            two={'model':{'x':2},'optimizer':{},'type':'pose','step':2}
            save_atomic(torch,p,one)
            save_atomic(torch,p,two)
            p.write_bytes(b'NOT A CHECKPOINT')
            found,source,errors=load_latest_valid(torch,p,expected_type='pose')
            self.assertEqual(found['step'],1)
            self.assertEqual(source.name,'resume_previous.pt')
            self.assertEqual(len(errors),1)

    def test_best_is_not_overwritten_by_latest(self):
        with tempfile.TemporaryDirectory() as root:
            root=Path(root)
            for step in (1,2,3):
                save_atomic(torch,root/'latest.pt',dict(model={'x':step},optimizer={},type='pose'))
            save_atomic(torch,root/'best.pt',dict(model={'x':1},optimizer={},type='pose'))
            self.assertEqual(torch.load(root/'best.pt',weights_only=False)['model']['x'],1)
            self.assertEqual(torch.load(root/'latest.pt',weights_only=False)['model']['x'],3)

class SafetyTests(unittest.TestCase):
    def test_disk_low_guard_no_delete(self):
        class Usage:
            free=1024**3
        with tempfile.TemporaryDirectory() as root:
            self.assertFalse(enough_space(root,2,usage=lambda p:Usage()))
            self.assertTrue(enough_space(root,.5,usage=lambda p:Usage()))
            self.assertAlmostEqual(free_gib(root,usage=lambda p:Usage()),1.)

    def test_flags_reflect_native_state(self):
        class State:
            has_jumped=True
            has_double_jumped=False
            wheel_1_contact=True
        class Car:
            def get_state(self):return State()
        result=live_state_flags(Car())
        self.assertEqual(len(result),10)
        self.assertEqual(result[1],1.)
        self.assertEqual(result[7],1.)
        self.assertEqual(result[2],0.)

if __name__=='__main__':unittest.main()
