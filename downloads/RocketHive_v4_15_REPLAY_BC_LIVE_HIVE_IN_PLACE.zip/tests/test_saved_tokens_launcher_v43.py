"""Check the continuous runner uses saved-token resolution for normal launches."""
import json
import os
from pathlib import Path
import sys
from tempfile import TemporaryDirectory
import unittest
from unittest.mock import patch
from src import continuous


class LauncherCredentialTests(unittest.TestCase):
    def _run(self, extra_args=()):
        with TemporaryDirectory() as d:
            p = Path(d) / 'config.json'
            p.write_text(json.dumps({'wandb_project': 'a'}))
            with patch.object(sys, 'argv', ['continuous', '--config', str(p), *extra_args]), \
                 patch('tools.credentials_popup.resolve_tokens', return_value=('ball-secure', 'wandb-secure')) as resolver, \
                 patch.object(continuous, 'run') as runner, \
                 patch.dict(os.environ, {}, clear=True):
                continuous.main()
                self.assertEqual(runner.call_args.args[1:], ('ball-secure', 'wandb-secure'))
                return resolver.call_args.kwargs

    def test_regular_launch(self):
        self.assertEqual(self._run()['no_popup'], False)

    def test_no_popup_launch_still_resolves_saved_tokens(self):
        self.assertEqual(self._run(('--no-popup',))['no_popup'], True)


if __name__ == '__main__':
    unittest.main()
