import json
from pathlib import Path
import tempfile
import unittest
import torch
from src.search_schedule_v44 import SearchBudget
from src.policy_gate_v44 import sha256, wilson_interval, evaluate_match_log, promote_from_report
from tools.enable_v44_defaults import migrate


class SearchBudgetTests(unittest.TestCase):
    def test_ramps_after_stable_survival_with_bounded_rollouts(self):
        b=SearchBudget.from_config({})
        self.assertEqual(b.candidates(),12)
        self.assertEqual(b.opponent_pool(),12)
        for _ in range(12):b.observe(True,1.0,288)
        self.assertEqual(b.candidates(),16)
        for _ in range(12):b.observe(False,1.,384)
        self.assertEqual(b.candidates(),12)
        for _ in range(12*6):b.observe(True,1.,1)
        self.assertLessEqual(2*b.candidates()*b.opponent_pool(),2048)
        self.assertEqual(b.candidates(),64)
        c=SearchBudget.from_config({},b.state_dict())
        self.assertEqual(c.candidates(),64)

    def test_never_accelerates_over_time_limit(self):
        b=SearchBudget.from_config({'search_max_seconds_per_update':.05})
        for _ in range(12):b.observe(True,2.,288)
        self.assertEqual(b.candidates(),12)


class MatchGateTests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory()
        self.d=Path(self.tmp.name)
        self.base=self.d/'baseline.pt';self.candidate=self.d/'new.pt'
        torch.save({'type':'SEARCH_DISTILLED_ACTION_POLICY_unvalidated', 'model':{}, 'optimizer':{},'version':0},self.base)
        torch.save({'type':'SEARCH_DISTILLED_ACTION_POLICY_unvalidated', 'model':{}, 'optimizer':{},'version':1},self.candidate)
        self.champion=self.d/'champion.pt'
        self.log=self.d/'matches.jsonl'
    def tearDown(self):self.tmp.cleanup()

    def write_matches(self,wins=40,total=40):
        c,i=sha256(self.candidate),sha256(self.base)
        rows=[{'match_id':f'game_{n}','candidate_sha256':c,'incumbent_sha256':i,
              'candidate_side':'blue' if n%2==0 else 'orange',
              'result':'win' if n<wins else 'loss','source':'external_user_game'} for n in range(total)]
        self.log.write_text(''.join(json.dumps(x)+'\n' for x in rows))

    def test_seed_champion_only_with_explicit_initialize(self):
        with self.assertRaises(FileNotFoundError):
            promote_from_report(self.base,self.champion,self.log)
        decision=promote_from_report(self.base,self.champion,self.log,initialize=True,commit=True)
        self.assertTrue(decision['ok'])
        self.assertFalse(decision['verified_gameplay'])
        self.assertEqual(sha256(self.champion),sha256(self.base))

    def test_promote_after_side_balanced_strong_results(self):
        promote_from_report(self.base,self.champion,self.log,initialize=True,commit=True)
        self.write_matches(wins=37,total=40)
        dry=promote_from_report(self.candidate,self.champion,self.log)
        self.assertTrue(dry['ok'])
        self.assertEqual(sha256(self.champion),sha256(self.base))
        promote_from_report(self.candidate,self.champion,self.log,commit=True)
        self.assertEqual(sha256(self.champion),sha256(self.candidate))
        self.assertTrue((self.d/'champion_previous.pt').exists())
        self.assertFalse(json.loads((self.d/'champion.evaluation.json').read_text())['verified_gameplay'])

    def test_low_quality_results_cannot_promote(self):
        promote_from_report(self.base,self.champion,self.log,initialize=True,commit=True)
        self.write_matches(wins=21,total=40)
        dec=promote_from_report(self.candidate,self.champion,self.log,commit=True)
        self.assertFalse(dec['ok'])
        self.assertEqual(sha256(self.champion),sha256(self.base))

    def test_duplicates_rejected(self):
        self.write_matches()
        with self.log.open('a') as f:
            f.write(self.log.read_text().splitlines()[0]+'\n')
        with self.assertRaisesRegex(ValueError,'Duplicate'):
            evaluate_match_log(self.log,sha256(self.candidate),sha256(self.base))


class SettingsMigration(unittest.TestCase):
    def test_merge_is_non_destructive_and_idempotent(self):
        with tempfile.TemporaryDirectory() as root:
            p=Path(root)/'config_v4.json'
            p.write_text(json.dumps({'adaptive_search':False,
                  'wandb_skill_metrics':{'pose/val_loss':[10,'low']}}))
            self.assertTrue(migrate(p))
            cfg=json.loads(p.read_text())
            self.assertFalse(cfg['adaptive_search'])
            self.assertEqual(cfg['wandb_skill_metrics']['pose/val_loss'],[10,'low'])
            self.assertTrue((p.parent/'config_v4_before_v44.json').exists())
            self.assertFalse(migrate(p))

if __name__=='__main__':unittest.main()
