"""Regression: RLViser changes cwd, but a valid controller must still load."""
import os
import sys
import tempfile
import unittest
from pathlib import Path
from types import ModuleType
from unittest.mock import patch

import torch
from src.physics_search import ACTIONS
from src.search_teacher import OBS_DIM, build_policy
from tools import watch_bot_rlviser as viewer


def save_controller(path, steps=3):
    path.parent.mkdir(parents=True, exist_ok=True)
    torch.save({'type': 'SEARCH_DISTILLED_ACTION_POLICY_unvalidated',
                'step': steps, 'obs_dim': OBS_DIM, 'action_table': ACTIONS,
                'model': build_policy().state_dict()}, path)


class ViewerCheckpointTests(unittest.TestCase):
    def test_model_is_loaded_before_rlviser_changes_working_directory(self):
        with tempfile.TemporaryDirectory() as t:
            root = Path(t)
            checkpoint = root / 'models/v4_action_policy_search_teacher.pt'
            rlviser_dir = root / 'third_party/rlviser'
            rlviser_dir.mkdir(parents=True)
            save_controller(checkpoint, steps=17)
            old_dir = Path.cwd()
            observed = {}

            def change_cwd():
                # This is what enter_viewer_directory() does on Windows.
                os.chdir(rlviser_dir)
                return rlviser_dir / 'rlviser.exe'

            def fake_run(rs, rv, *args, **kw):
                observed['step'] = kw['trained_controller'].checkpoint_step
                observed['checkpoint'] = Path(kw['trained_controller'].checkpoint)
                observed['report'] = kw['report_path']
                observed['cwd'] = Path.cwd()
                return 1

            try:
                os.chdir(root)
                with patch.object(viewer, 'ROOT', root), \
                     patch.object(viewer, 'enter_viewer_directory', side_effect=change_cwd), \
                     patch.object(viewer, 'run', side_effect=fake_run), \
                     patch.dict(sys.modules, {'RocketSim': ModuleType('RocketSim'),
                                              'rlviser_py': ModuleType('rlviser_py')}), \
                     patch.object(sys, 'argv', ['watch_bot_rlviser', '--trained-policy']):
                    self.assertEqual(viewer.main(), 0)
            finally:
                os.chdir(old_dir)
            self.assertEqual(observed['step'], 17)
            self.assertEqual(observed['checkpoint'], checkpoint)
            self.assertEqual(observed['cwd'], rlviser_dir)
            self.assertEqual(observed['report'], root / 'reports/v47_flight_report.json')

    def test_no_checkpoint_fails_without_launching_rlviser(self):
        with tempfile.TemporaryDirectory() as t:
            root = Path(t)
            with patch.object(viewer, 'ROOT', root), \
                 patch.object(viewer, 'enter_viewer_directory') as launch, \
                 patch.dict(sys.modules, {'RocketSim': ModuleType('RocketSim'),
                                          'rlviser_py': ModuleType('rlviser_py')}), \
                 patch.object(sys, 'argv', ['watch_bot_rlviser', '--trained-policy']):
                with self.assertRaises(SystemExit) as result:
                    viewer.main()
            self.assertEqual(result.exception.code, 2)
            launch.assert_not_called()

    def test_zero_update_checkpoint_rejected_before_rlviser_launch(self):
        with tempfile.TemporaryDirectory() as t:
            root=Path(t)
            save_controller(root/'models/v4_action_policy_search_teacher.pt', steps=0)
            with patch.object(viewer, 'ROOT', root), \
                 patch.object(viewer, 'enter_viewer_directory') as launch, \
                 patch.dict(sys.modules, {'RocketSim': ModuleType('RocketSim'),
                                          'rlviser_py': ModuleType('rlviser_py')}), \
                 patch.object(sys, 'argv', ['watch_bot_rlviser', '--trained-policy']):
                with self.assertRaises(SystemExit) as result:
                    viewer.main()
            self.assertEqual(result.exception.code, 2)
            launch.assert_not_called()


if __name__ == '__main__':
    unittest.main()
