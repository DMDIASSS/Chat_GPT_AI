@echo off
setlocal
cd /d "%~dp0"
if not exist ".venv\Scripts\python.exe" (
 echo Use your existing RocketHive folder with .venv. No environment is replaced.
 pause
 exit /b 1
)
".venv\Scripts\python.exe" -m tools.report_hive_v415
if errorlevel 1 (
 echo Command failed. Keep the output above; existing models and data were preserved.
 pause
 exit /b 1
)
pause
