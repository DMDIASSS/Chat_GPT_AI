@echo off
setlocal
cd /d "%~dp0"
if not exist ".venv\Scripts\python.exe" (
 echo Existing RocketHive .venv not found. No changes made.
 pause
 exit /b 1
)
echo Configure DEFAULT RLViser camera for replay and live bot viewers.
echo RLViser should be closed before changing camera settings.
".venv\Scripts\python.exe" -m tools.set_rlviser_camera_v411 --interactive
if errorlevel 1 (
 echo Could not save camera preferences.
 pause
 exit /b 1
)
pause
