@echo off
setlocal
cd /d "%~dp0"
if not exist ".venv\Scripts\python.exe" (
  echo [ERROR] The existing RocketHive .venv was not found.
  pause
  exit /b 2
)
echo RocketSim initialization and one real replay-state rollout check.
echo Read-only: no trained checkpoints, replay data, or API keys are changed.
".venv\Scripts\python.exe" -m tools.check_physics_search_v49 --train-dir data/train
if errorlevel 1 (
  echo [ERROR] Physics rollout test failed. See the first error above.
  pause
  exit /b 1
)
echo Verification passed. You can now run TRAIN_ACTION_CONTROLLER.bat.
pause
