@echo off
setlocal
cd /d "%~dp0"
if not exist ".venv\Scripts\python.exe" (echo Missing RocketHive .venv & pause & exit /b 2)
echo ONE physics-sequence search + optional optimizer step. Safe to restart.
".venv\Scripts\python.exe" -m tools.train_action_controller_v48 --config config_v4.json --iterations 1
if errorlevel 1 (pause & exit /b 1)
pause
