"""Read-only held-out action audit. Codec reconstruction is not policy imitation."""
from pathlib import Path
import argparse,hashlib,json
import numpy as np

def predict_observations(brain,obs):
    import torch
    from src.replay_bc_v415 import controls
    with torch.inference_mode():
        x=torch.as_tensor(obs,dtype=torch.float32);rep=brain.net.trunk(x);h=rep
        previous=torch.full((len(x),),64,dtype=torch.long);ids=[]
        for _ in range(4):
            h=brain.net.cell(torch.cat((rep,brain.net.embed(previous)),-1),h);previous=brain.net.code(h).argmax(-1);ids.append(previous)
        raw=brain.codec.decode(torch.stack(ids,1));offset=brain.net.offset(rep).reshape(-1,32,5)
        return controls(raw,offset).numpy()

def action_metrics(pred,truth):
    result=dict(axis_mae=np.abs(pred[:,:,:5]-truth[:,:,:5]).mean((0,1)).tolist(),zero_axis_mae=np.abs(truth[:,:,:5]).mean((0,1)).tolist(),buttons={})
    for j,name in enumerate(('jump','boost','handbrake'),5):
        a=pred[:,:,j]>.5;b=truth[:,:,j]>.5;tp=int((a&b).sum());fp=int((a&~b).sum());fn=int((~a&b).sum())
        result['buttons'][name]=dict(pred_rate=float(a.mean()),truth_rate=float(b.mean()),precision=tp/max(1,tp+fp),recall=tp/max(1,tp+fn),f1=2*tp/max(1,2*tp+fp+fn))
    return result

def audit(root='.',model=None):
    import torch
    from src.replay_bc_v415 import ReplayBrain,controls
    from tools.train_replay_brain_v415 import load_data
    root=Path(root).resolve();model=Path(model or root/'models/v415_replay_brain.pt');torch.set_num_threads(1)
    brain=ReplayBrain(model);(x,y,v,known),files=load_data(root/'data/v415_chunks/val',6000)
    predicted=[];reconstructed=[];values=[]
    with torch.inference_mode():
        for start in range(0,len(x),128):
            xx=x[start:start+128];yy=torch.from_numpy(y[start:start+128]);raw,_,_=brain.codec(yy)
            reconstructed.append(controls(raw).numpy());predicted.append(predict_observations(brain,xx));values.append(brain.net.heads(torch.from_numpy(xx))[1].numpy())
    p=np.concatenate(predicted);r=np.concatenate(reconstructed);values=np.concatenate(values);modes=np.rint(x[:,-1]*3).astype(int)
    policy=action_metrics(p,y);issues=[]
    if policy['buttons']['jump']['truth_rate']>.005 and policy['buttons']['jump']['recall']<.10:issues.append('Free-running policy misses more than 90% of replay jump inputs. Codec jump F1 cannot establish policy quality.')
    if policy['axis_mae'][1]>=policy['zero_axis_mae'][1]:issues.append('Policy steering MAE is no better than predicting zero steering on these validation examples.')
    if 2 not in modes:issues.append('No 2v2 validation examples: these data cannot validate 2v2 imitation.')
    ck=torch.load(model,map_location='cpu',weights_only=True)
    report=dict(version='v4.18-policy-audit',model_sha256=hashlib.sha256(model.read_bytes()).hexdigest(),samples=len(x),validation_files=files,dataset_matches_checkpoint=files==ck.get('dataset_recipe',{}).get('validation'),policy=policy,codec_reconstruction=action_metrics(r,y),by_mode={str(m):dict(samples=int((modes==m).sum()),policy=action_metrics(p[modes==m],y[modes==m])) for m in np.unique(modes)},value_mse=float(np.square(values[known]-v[known]).mean()) if known.any() else None,zero_value_mse=float(np.square(v[known]).mean()) if known.any() else None,diagnostic_issues=issues,training_performed=False,playing_strength_verified=False)
    out=root/'reports';out.mkdir(exist_ok=True);path=out/'v415_policy_audit.json';path.write_text(json.dumps(report,indent=2),encoding='utf8')
    print('POLICY_AUDIT:',path,flush=True);print('Policy jump metrics:',policy['buttons']['jump'],flush=True);print('Steering MAE / zero baseline:',policy['axis_mae'][1],policy['zero_axis_mae'][1],flush=True)
    for issue in issues:print('DIAGNOSTIC:',issue,flush=True)
    return report

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--model');a=p.parse_args();audit(model=a.model)
