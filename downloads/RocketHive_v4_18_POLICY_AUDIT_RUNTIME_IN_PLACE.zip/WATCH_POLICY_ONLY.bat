@echo off
setlocal
cd /d "%~dp0"
echo Same saved replay brain, search DISABLED. Blue Hive vs orange Galactus V2, 2v2.
".venv\Scripts\python.exe" -u -m tools.watch_hive_v415 --controller policy --seconds 60 --mode 2
if errorlevel 1 echo WATCH_FAILED - keep the error above and run menu 9.
pause
