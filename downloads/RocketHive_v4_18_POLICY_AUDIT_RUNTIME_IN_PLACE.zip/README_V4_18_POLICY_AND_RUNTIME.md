# RocketHive v4.18: separate imitation failure from search/runtime failure

Requires v4.15, v4.16 and v4.17 already installed. Extract into the existing project folder and replace the included code/launcher files. Your model weights, optimizer, dataset, configuration, environments and credentials are preserved. Training code and network definitions are byte-identical to v4.17 so existing training recipes are not invalidated.

## What this update fixes

The previous runtime used geometric driving whenever its background search plan arrived too late. A new read-only inference thread publishes the current replay policy on a separate channel while search runs. Fresh search plans keep priority; otherwise the client uses a fresh neural-policy plan. Both channels enforce team identity, roster, wall-clock age, simulation age and clock rewind checks. Missing/expired neural plans still have an explicitly labelled geometric safety fallback. Match startup waits for neural readiness instead of counting initialization as gameplay.

Wall time and simulation time are validated separately: a slow simulation is not itself evidence that an otherwise fresh plan is invalid. Plans beyond the 32-tick action chunk are rejected. The original Galactus adapter, physics, hitboxes and action timing are unchanged.

This improves controller continuity. It **does not repair a weak learned policy**, add self-play, change rewards, retrain your checkpoint, or establish a playing-strength improvement.

## Run these on your PC

1. `AUDIT_REPLAY_POLICY.bat`: evaluate free-running action predictions on existing validation chunks. The report separates codec reconstruction from policy imitation and includes jump precision/recall/F1, steering MAE versus zero steering, mode coverage, value MSE, dataset/model hashes and checkpoint dataset agreement. It performs no training.
2. `WATCH_POLICY_ONLY.bat`: 60 seconds of Blue RocketHive versus Orange frozen Galactus V2 in 2v2, using the saved replay policy with search disabled. All cars use Octane.
3. `WATCH_SEARCH_COMPARE.bat`: the same initial setup and saved weights with search enabled; late search uses the neural-policy channel. These short demonstrations are diagnostic, not statistically controlled evidence of superiority.
4. Menu **9** packages both saved match reports and the audit. Historical latest-match files are preserved before replacement. Reports show `REPLAY_BC_POLICY_ONLY`, `REPLAY_BC_WITH_LIVE_SEARCH`, `REPLAY_BC_POLICY_SEARCH_LATE`, or the explicit geometric fallback for each tick.

The viewer window can remain open after a run. Close that old viewer window before starting the next watch so only one instance listens to the viewer port.

## How to interpret it

Good codec reconstruction means the compressor can reconstruct actions when it sees the true replay controls. It does not mean the policy can predict those codes from a game state. Rare jump inputs can disappear from free-running predictions even when codec jump F1 appears acceptable. The audit measures these separately; its issue thresholds are diagnostics, not a promotion protocol or guarantee of skill.

Validation by 1v1 examples alone cannot establish 2v2 imitation. A goal-value MSE improvement likewise does not prove useful search decisions in unfamiliar simulated states. Watching matches does not train this replay-only system.

For controlled learner experiments, retain the old checkpoint and keep validation files held out. Provide training chunks separately; never train on the validation examples to make their measured errors look smaller. This update leaves the original trainer untouched rather than claiming an untested learning fix.
