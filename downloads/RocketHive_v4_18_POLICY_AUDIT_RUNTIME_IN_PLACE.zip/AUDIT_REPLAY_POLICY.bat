@echo off
setlocal
cd /d "%~dp0"
".venv\Scripts\python.exe" -u -m tools.audit_replay_policy_v418
if errorlevel 1 echo AUDIT_FAILED - keep the error above and run menu 9.
pause
