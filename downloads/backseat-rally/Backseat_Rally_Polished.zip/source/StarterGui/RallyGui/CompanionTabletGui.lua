--!strict
-- Passenger roadbook. The complete route comes from unstreamed shared course data.
local Players=game:GetService("Players")
local ReplicatedStorage=game:GetService("ReplicatedStorage")
local UserInputService=game:GetService("UserInputService")
local RunService=game:GetService("RunService")
local Workspace=game:GetService("Workspace")
local VehicleController=require(ReplicatedStorage.RallyClient.VehicleController)
local StageRemotes=require(ReplicatedStorage.RallyShared.Remotes.StageRemotes)
local player=Players.LocalPlayer
local gui=Instance.new("ScreenGui")
gui.Name,gui.ResetOnSpawn,gui.Enabled,gui.DisplayOrder="CompanionTabletGui",false,false,25
gui.ZIndexBehavior=Enum.ZIndexBehavior.Sibling
gui.Parent=player:WaitForChild("PlayerGui")
local ink=Color3.fromRGB(15,23,26)
local paper=Color3.fromRGB(225,237,225)
local accent=Color3.fromRGB(208,239,137)
local root=Instance.new("Frame")
root.Size,root.Position,root.AnchorPoint=UDim2.fromOffset(900,550),UDim2.fromScale(0.5,0.5),Vector2.new(0.5,0.5)
root.BackgroundColor3,root.BorderSizePixel,root.Parent=ink,0,gui
local scale=Instance.new("UIScale")
scale.Parent=root
local corner=Instance.new("UICorner")
corner.CornerRadius,corner.Parent=UDim.new(0,12),root
local function label(parent:Instance,value:string,x:number,y:number,w:number,h:number,size:number?):TextLabel
    local t=Instance.new("TextLabel")
    t.Text,t.Font,t.TextSize,t.TextColor3=value,Enum.Font.GothamMedium,size or 13,paper
    t.Position,t.Size,t.BackgroundTransparency=UDim2.fromOffset(x,y),UDim2.fromOffset(w,h),1
    t.TextXAlignment,t.Parent=Enum.TextXAlignment.Left,parent
    return t
end
local function button(parent:Instance,value:string,x:number,y:number,w:number,h:number,callback:()->()):TextButton
    local b=Instance.new("TextButton")
    b.Text,b.Font,b.TextSize,b.TextColor3=value,Enum.Font.GothamBold,12,ink
    b.Position,b.Size,b.BackgroundColor3=UDim2.fromOffset(x,y),UDim2.fromOffset(w,h),accent
    b.BorderSizePixel,b.Parent=0,parent
    local c=Instance.new("UICorner")
    c.CornerRadius,c.Parent=UDim.new(0,5),b
    b.Activated:Connect(callback)
    return b
end
label(root,"THE ROADBOOK",23,16,470,32,24).Font=Enum.Font.GothamBlack
local status=label(root,"Seat a friend in service to share the radio.",24,52,760,23,12)
button(root,"CLOSE [M]",758,23,116,30,function() gui.Enabled=false end)
local map=Instance.new("Frame")
map.Position,map.Size,map.BackgroundColor3,map.BorderSizePixel=UDim2.fromOffset(24,91),UDim2.fromOffset(415,386),Color3.fromRGB(24,36,37),0
map.ClipsDescendants,map.Parent=true,root
local road=Instance.new("Frame")
road.Size,road.BackgroundTransparency,road.Parent=UDim2.fromScale(1,1),1,map
local marker=Instance.new("TextLabel")
marker.Text,marker.Font,marker.TextColor3,marker.TextSize="▲",Enum.Font.GothamBlack,accent,22
marker.Size,marker.AnchorPoint,marker.BackgroundTransparency=UDim2.fromOffset(24,24),Vector2.new(0.5,0.5),1
marker.ZIndex,marker.Parent=8,map
local nextMarker=Instance.new("TextLabel")
nextMarker.Size,nextMarker.AnchorPoint,nextMarker.BackgroundTransparency=UDim2.fromOffset(25,25),Vector2.new(0.5,0.5),1
nextMarker.Text,nextMarker.Font,nextMarker.TextColor3,nextMarker.TextSize="◉",Enum.Font.GothamBlack,Color3.fromRGB(255,188,83),25
nextMarker.ZIndex,nextMarker.Parent=7,map
local list=Instance.new("ScrollingFrame")
list.Position,list.Size=UDim2.fromOffset(461,91),UDim2.fromOffset(413,386)
list.BackgroundTransparency,list.BorderSizePixel,list.ScrollBarThickness=1,0,3
list.AutomaticCanvasSize,list.CanvasSize,list.Parent=Enum.AutomaticSize.Y,UDim2.fromOffset(0,0),root
local layout=Instance.new("UIListLayout")
layout.Padding,layout.SortOrder,layout.Parent=UDim.new(0,6),Enum.SortOrder.LayoutOrder,list
local summary=label(root,"",24,490,412,30,13)
local noteHint=label(root,"",24,520,720,18,10)
button(root,"LEAVE CREW",737,503,137,28,function() StageRemotes.GetEvent("RaceAction"):FireServer("LeaveCrew");gui.Enabled=false end)
local data:any=nil
local generation:any=nil
local currentVehicle:any=nil
local points:any={}
local notes:any={}
local cards:any={}
local called:any={}
local nextNote:any=nil
local isPassenger=false
local lastRole=false
local mapScale=1
local centerX,centerZ=0,0
local function project(p:Vector3):Vector2
    return Vector2.new(207.5+(p.X-centerX)*mapScale,193-(p.Z-centerZ)*mapScale)
end
local function call(note:any)
    if not note or not isPassenger then return end
    local car=VehicleController.GetActiveVehicle()
    if not car or car:GetAttribute("RunState")~="Running" then return end
    if note.Distance-(car:GetAttribute("RouteDistance") or 0)>700 then return end
    StageRemotes.GetEvent("CompanionSync"):FireServer(note.Index)
end
StageRemotes.GetEvent("CompanionSync").OnClientEvent:Connect(function(index) called[index]=true end)
local nextButton=button(root,"CALL NEXT [F]",461,491,262,40,function() call(nextNote) end)
local function rebuild(folder:Instance)
    points,notes,cards={},{},{}
    road:ClearAllChildren()
    for _,child in ipairs(list:GetChildren()) do if child~=layout then child:Destroy() end end
    local route=folder:FindFirstChild("RouteSamples")
    if route then
        for _,p in ipairs(route:GetChildren()) do
            local position=p:GetAttribute("Position")
            if typeof(position)=="Vector3" then table.insert(points,{Position=position,Distance=p:GetAttribute("Distance") or 0}) end
        end
    end
    table.sort(points,function(a,b) return a.Distance<b.Distance end)
    local minX,maxX,minZ,maxZ=math.huge,-math.huge,math.huge,-math.huge
    for _,p in ipairs(points) do
        minX,maxX=math.min(minX,p.Position.X),math.max(maxX,p.Position.X)
        minZ,maxZ=math.min(minZ,p.Position.Z),math.max(maxZ,p.Position.Z)
    end
    if #points>0 then
        centerX,centerZ=(minX+maxX)/2,(minZ+maxZ)/2
        mapScale=math.min(365/math.max(100,maxX-minX),336/math.max(100,maxZ-minZ))
        for i=1,#points-1 do
            local a,b=project(points[i].Position),project(points[i+1].Position)
            local line=Instance.new("Frame")
            line.AnchorPoint=Vector2.new(0.5,0.5)
            line.Position=UDim2.fromOffset((a.X+b.X)/2,(a.Y+b.Y)/2)
            line.Size=UDim2.fromOffset((b-a).Magnitude+1,3)
            line.Rotation=math.deg(math.atan2(b.Y-a.Y,b.X-a.X))
            line.BackgroundColor3,line.BorderSizePixel,line.Parent=Color3.fromRGB(97,143,135),0,road
        end
    end
    local pace=folder:FindFirstChild("PaceNotes")
    if pace then
        for _,p in ipairs(pace:GetChildren()) do
            table.insert(notes,{Index=p:GetAttribute("Index"),Distance=p:GetAttribute("Distance") or 0,
                EndDistance=p:GetAttribute("EndDistance") or 0,Description=p:GetAttribute("Description") or "Straight",
                Position=p:GetAttribute("Position"),Severity=p:GetAttribute("Severity") or 6,Direction=p:GetAttribute("Direction") or "Straight"})
        end
    end
    table.sort(notes,function(a,b) return a.Distance<b.Distance end)
    for i,note in ipairs(notes) do
        local card=Instance.new("Frame")
        card.Size,card.BackgroundColor3,card.BorderSizePixel=UDim2.fromOffset(398,55),Color3.fromRGB(25,36,39),0
        card.LayoutOrder,card.Parent=i,list
        local arrow=note.Direction=="Left" and "◀" or note.Direction=="Right" and "▶" or "▲"
        local icon=label(card,arrow..tostring(note.Severity),10,8,56,35,20)
        icon.TextColor3=note.Severity<=3 and Color3.fromRGB(255,160,100) or accent
        label(card,note.Description:upper(),78,5,236,24,12)
        local distance=label(card,"",78,29,225,18,11)
        local callButton=button(card,"CALL",329,13,59,28,function() call(note) end)
        cards[note.Index]={Frame=card,Distance=distance,Button=callButton,Order=i}
    end
end
UserInputService.InputBegan:Connect(function(input,processed)
    if processed or UserInputService:GetFocusedTextBox() then return end
    if input.KeyCode==Enum.KeyCode.M then gui.Enabled=not gui.Enabled
    elseif input.KeyCode==Enum.KeyCode.F and isPassenger then call(nextNote) end
end)
StageRemotes.GetEvent("RaceState").OnClientEvent:Connect(function(kind)
    if kind=="Go" or kind=="Recovered" then called={} end
end)
local accumulator=0
RunService.RenderStepped:Connect(function(dt)
    accumulator+=dt
    if accumulator<0.1 then return end
    accumulator=0
    local car=VehicleController.GetActiveVehicle()
    isPassenger=car and car:GetAttribute("CoDriverUserId")==player.UserId or false
    if isPassenger and not lastRole then gui.Enabled=true end
    if not isPassenger and lastRole then gui.Enabled=false end
    lastRole=isPassenger
    local folder=ReplicatedStorage:FindFirstChild("ActiveStageData")
    if not gui.Enabled and not isPassenger then return end
    local size=Workspace.CurrentCamera and Workspace.CurrentCamera.ViewportSize or Vector2.new(1280,720)
    scale.Scale=math.min(1,(size.X-25)/900,(size.Y-50)/550)
    if folder and (folder~=data or #points~=folder:GetAttribute("SampleCount") or #notes~=folder:GetAttribute("NoteCount")) then
        if generation~=folder:GetAttribute("Generation") then called={} end
        generation=folder:GetAttribute("Generation")
        data=folder
        rebuild(folder)
    end
    if not car or not car.PrimaryPart then status.Text="Join a friend's passenger seat in the service park [V].";return end
    if currentVehicle~=car then currentVehicle=car;called={} end
    local progress=car:GetAttribute("RouteDistance") or car:GetAttribute("RecoveryDistance") or 0
    local pos=project(car.PrimaryPart.Position)
    marker.Position=UDim2.fromOffset(pos.X,pos.Y)
    local fwd=car.PrimaryPart.CFrame.LookVector
    marker.Rotation=math.deg(math.atan2(fwd.X,fwd.Z))
    status.Text=isPassenger and ("YOU ARE THE CO-DRIVER / "..(car:GetAttribute("DriverName") or "Friend").." is driving. Call the next turn with F.") or "ROUTE PREVIEW / calls are available in the passenger seat."
    nextNote=nil
    for _,note in ipairs(notes) do
        local card=cards[note.Index]
        local remaining=note.Distance-progress
        local passed=note.EndDistance<progress-8
        if not nextNote and not passed and not called[note.Index] then nextNote=note end
        card.Distance.Text=passed and "PASSED" or string.format("%d m %s",math.floor(math.max(0,remaining)*0.28),called[note.Index] and "/ CALLED" or "/ AHEAD")
        card.Button.Visible=isPassenger and not passed and remaining<700 and car:GetAttribute("RunState")=="Running"
        card.Frame.BackgroundColor3=nextNote==note and Color3.fromRGB(52,70,48) or Color3.fromRGB(25,36,39)
    end
    nextMarker.Visible=nextNote~=nil and typeof(nextNote.Position)=="Vector3"
    if nextMarker.Visible then
        local p=project(nextNote.Position)
        nextMarker.Position=UDim2.fromOffset(p.X,p.Y)
    end
    nextButton.Text=isPassenger and (nextNote and "CALL NEXT [F]" or "NO TURN AHEAD") or "PASSENGER CALLS THE ROAD"
    nextButton.Active=isPassenger
    summary.Text=string.format("%.2f km / %s / %s",progress*0.00028,Workspace:GetAttribute("RaceMode") or "LOOP",car:GetAttribute("RunState") or "READY")
    noteHint.Text=nextNote and ("NEXT / "..nextNote.Description:upper().." / "..math.floor(math.max(0,nextNote.Distance-progress)*0.28).." m") or "Stay on the road. The forest is solid."
end)
