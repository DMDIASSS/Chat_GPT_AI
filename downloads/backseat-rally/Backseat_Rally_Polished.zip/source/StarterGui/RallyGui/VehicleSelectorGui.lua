--!strict
-- Service park: five original cars, functional setups, shared course and optional crew.
local Players=game:GetService("Players")
local ReplicatedStorage=game:GetService("ReplicatedStorage")
local UserInputService=game:GetService("UserInputService")
local RunService=game:GetService("RunService")
local Workspace=game:GetService("Workspace")
local CarProfiles=require(ReplicatedStorage.RallyShared.Config.CarProfiles)
local StageRemotes=require(ReplicatedStorage.RallyShared.Remotes.StageRemotes)
local VehicleController=require(ReplicatedStorage.RallyClient.VehicleController)
local player=Players.LocalPlayer
local playerGui=player:WaitForChild("PlayerGui")
local remote=StageRemotes.GetFunction("GarageRequest")
local crewRemote=StageRemotes.GetFunction("CrewRequest")
local action=StageRemotes.GetEvent("RaceAction")
local gui=Instance.new("ScreenGui")
gui.Name,gui.ResetOnSpawn,gui.Enabled,gui.DisplayOrder="VehicleSelectorGui",false,false,20
gui.ZIndexBehavior=Enum.ZIndexBehavior.Sibling
gui.Parent=playerGui
local ink=Color3.fromRGB(15,23,26)
local panel=Color3.fromRGB(24,34,38)
local light=Color3.fromRGB(229,238,232)
local muted=Color3.fromRGB(144,163,158)
local accent=Color3.fromRGB(208,239,137)
local backdrop=Instance.new("Frame")
backdrop.Size,backdrop.BackgroundColor3,backdrop.BackgroundTransparency=UDim2.fromScale(1,1),Color3.new(0,0,0),0.28
backdrop.Parent=gui
local root=Instance.new("Frame")
root.Size,root.AnchorPoint,root.Position=UDim2.fromOffset(1000,650),Vector2.new(0.5,0.5),UDim2.fromScale(0.5,0.5)
root.BackgroundColor3,root.BorderSizePixel,root.Parent=ink,0,gui
local scale=Instance.new("UIScale")
scale.Parent=root
local corner=Instance.new("UICorner")
corner.CornerRadius,corner.Parent=UDim.new(0,14),root
local function text(parent:Instance,value:string,x:number,y:number,w:number,h:number,size:number?,color:Color3?):TextLabel
    local label=Instance.new("TextLabel")
    label.BackgroundTransparency=1
    label.Position,label.Size=UDim2.fromOffset(x,y),UDim2.fromOffset(w,h)
    label.Text,label.Font,label.TextSize=value,Enum.Font.GothamMedium,size or 13
    label.TextColor3,label.TextXAlignment= color or light,Enum.TextXAlignment.Left
    label.Parent=parent
    return label
end
local function button(parent:Instance,value:string,x:number,y:number,w:number,h:number,callback:()->()):TextButton
    local b=Instance.new("TextButton")
    b.Text,b.Font,b.TextSize=value,Enum.Font.GothamBold,12
    b.Position,b.Size=UDim2.fromOffset(x,y),UDim2.fromOffset(w,h)
    b.BackgroundColor3,b.TextColor3,b.BorderSizePixel=panel,light,0
    b.Parent=parent
    local c=Instance.new("UICorner")
    c.CornerRadius,c.Parent=UDim.new(0,6),b
    b.Activated:Connect(callback)
    return b
end
text(root,"BACKSEAT",28,18,320,36,30,accent).Font=Enum.Font.GothamBlack
text(root,"RALLY / SERVICE PARK",30,57,350,23,12,muted)
local status=text(root,"Choose a car. Bring a friend, or let the bot call the road.",30,594,720,22,12,muted)
button(root,"CLOSE  [V]",856,28,115,32,function() gui.Enabled=false end)
local selected="KazeRS"
local setups:any={}
local setup:any=CarProfiles.NormalizeSetup(nil)
local mode="Loop"
local weather="Clear"
local busy=false
local redraw:any
local function invoke(name:string,payload:any):any
    if busy then return nil end
    busy=true
    status.Text="Preparing..."
    local ok,result=pcall(function() return remote:InvokeServer(name,payload) end)
    busy=false
    if not ok or type(result)~="table" then status.Text="Connection unavailable. Try again.";return nil end
    status.Text=result.Message or (result.Ok and "Ready." or "Please try again.")
    return result
end
text(root,"01 / YOUR CAR",30,98,260,20,12,accent)
local carButtons:any={}
local ids=CarProfiles.GetAllIds()
for i,id in ipairs(ids) do
    local profile=CarProfiles.Cars[id]
    local b=button(root,profile.DisplayName:upper(),30,125+(i-1)*47,230,40,function()
        setups[selected]=table.clone(setup)
        selected=id
        setup=CarProfiles.NormalizeSetup(setups[id])
        redraw()
    end)
    b.TextXAlignment=Enum.TextXAlignment.Left
    local pad=Instance.new("UIPadding")
    pad.PaddingLeft,pad.Parent=UDim.new(0,13),b
    carButtons[id]=b
end
local viewport=Instance.new("ViewportFrame")
viewport.Position,viewport.Size=UDim2.fromOffset(285,105),UDim2.fromOffset(365,218)
viewport.BackgroundColor3,viewport.BorderSizePixel=panel,0
viewport.Ambient=Color3.fromRGB(186,192,181)
viewport.LightColor=Color3.fromRGB(255,242,210)
viewport.LightDirection=Vector3.new(-1,-1,-1)
viewport.Parent=root
local camera=Instance.new("Camera")
camera.FieldOfView,camera.Parent=38,viewport
viewport.CurrentCamera=camera
local world=Instance.new("WorldModel")
world.Parent=viewport
local carTitle=text(root,"",285,332,380,25,19,light)
local specs=text(root,"",285,360,380,42,12,muted)
specs.TextWrapped=true
specs.TextYAlignment=Enum.TextYAlignment.Top
text(root,"02 / BUILD",680,98,280,20,12,accent)
local stageButtons:any={}
for stage=0,3 do
    stageButtons[stage]=button(root,stage==0 and "STOCK" or "STG "..stage,680+stage*73,126,66,31,function() setup.Stage=stage;redraw() end)
end
local power=text(root,"",680,164,290,34,12,muted)
power.TextWrapped=true
local function cycleRow(label:string,key:string,values:any,y:number)
    text(root,label,680,y,138,27,12,muted)
    local b:TextButton
    b=button(root,"",818,y,151,28,function()
        local index=table.find(values,setup[key]) or 1
        setup[key]=values[index%#values+1]
        redraw()
    end)
    return b
end
local tyreButton=cycleRow("TYRES","Tyres",CarProfiles.TyreOptions,210)
local suspensionButton=cycleRow("SUSPENSION","Suspension",CarProfiles.SuspensionOptions,251)
local gearingButton=cycleRow("GEARING","Gearing",CarProfiles.GearingOptions,292)
local paintButton:TextButton
paintButton=button(root,"",680,335,140,30,function() setup.Paint=(setup.Paint+1)%#CarProfiles.Paints;redraw() end)
local rimButton:TextButton
rimButton=button(root,"",830,335,140,30,function() setup.Rim=(setup.Rim+1)%#CarProfiles.Rims;redraw() end)
text(root,"All parts unlocked. Build for the road.",680,375,290,23,11,muted)
text(root,"03 / COURSE",30,405,260,20,12,accent)
local modeButton:TextButton
modeButton=button(root,"LOOP / ONE LAP",30,435,230,32,function() mode=mode=="Loop" and "Infinite" or "Loop";redraw() end)
local weatherButton:TextButton
weatherButton=button(root,"CLEAR",30,477,111,32,function()
    local options={"Clear","Autumn","Rain","NightFog"}
    weather=options[(table.find(options,weather) or 1)%#options+1]
    redraw()
end)
local seed=Instance.new("TextBox")
seed.Position,seed.Size=UDim2.fromOffset(151,477),UDim2.fromOffset(109,32)
seed.BackgroundColor3,seed.TextColor3,seed.BorderSizePixel=panel,light,0
seed.Font,seed.TextSize,seed.Text,seed.PlaceholderText=Enum.Font.RobotoMono,13,"42","Seed"
seed.ClearTextOnFocus=false
seed.Parent=root
button(root,"BUILD COURSE",30,519,230,30,function()
    local result=invoke("Course",{Mode=mode,Seed=tonumber(seed.Text),Weather=weather})
    if result and result.Ok then mode=result.Mode;seed.Text=tostring(result.Seed) end
end)
local courseHint=text(root,"",30,554,245,32,10,muted)
courseHint.TextWrapped=true
text(root,"04 / CREW",285,405,360,20,12,accent)
local crewList=Instance.new("ScrollingFrame")
crewList.Position,crewList.Size=UDim2.fromOffset(285,435),UDim2.fromOffset(365,110)
crewList.BackgroundColor3,crewList.BorderSizePixel=panel,0
crewList.ScrollBarThickness,crewList.AutomaticCanvasSize,crewList.CanvasSize=3,Enum.AutomaticSize.Y,UDim2.fromOffset(0,0)
crewList.Parent=root
local crewLayout=Instance.new("UIListLayout")
crewLayout.Padding,crewLayout.Parent=UDim.new(0,4),crewList
local function refreshCrew()
    for _,child in ipairs(crewList:GetChildren()) do if child~=crewLayout then child:Destroy() end end
    local count=0
    for _,friend in ipairs(Players:GetPlayers()) do
        if friend==player then continue end
        count+=1
        local friendId=friend.UserId
        local b=button(crewList,"RIDE WITH  "..friend.DisplayName:upper(),0,0,354,29,function()
            local ok,result=pcall(function() return crewRemote:InvokeServer(friendId) end)
            if ok and result and result.Ok then gui.Enabled=false else status.Text=ok and result.Message or "Seat unavailable." end
        end)
        b.LayoutOrder=count
    end
    if count==0 then text(crewList,"Solo? Your bot co-driver is ready.\nFriends can join this server and take the seat.",10,8,340,67,12,muted) end
end
button(root,"LEAVE CREW",285,554,174,30,function()
    local ok,result=pcall(function() return crewRemote:InvokeServer(0) end)
    status.Text=ok and result.Ok and "Back in your own car." or "Unable to leave crew."
end)
button(root,"RETURN TO SERVICE",470,554,180,30,function() action:FireServer("Service") end)
button(root,"FIT SETUP",680,435,290,40,function()
    local result=invoke("Apply",{Car=selected,Setup=setup})
    if result and result.Ok then setups[selected]=table.clone(setup) end
end)
local function startWithSetup()
    if mode~=(Workspace:GetAttribute("RaceMode") or "Loop") or tonumber(seed.Text)~=Workspace:GetAttribute("StageSeed") or weather~=(Workspace:GetAttribute("WeatherPreset") or "Clear") then
        local course=invoke("Course",{Mode=mode,Seed=tonumber(seed.Text),Weather=weather})
        if not course or not course.Ok then return end
        mode=course.Mode
        seed.Text=tostring(course.Seed)
    end
    local result=invoke("Apply",{Car=selected,Setup=setup})
    if result and result.Ok then action:FireServer("Start");gui.Enabled=false end
end
local start=button(root,"START RACE  [ENTER]",680,486,290,58,startWithSetup)
start.BackgroundColor3,start.TextColor3,start.TextSize=accent,ink,16
text(root,"SPACE handbrake  /  C camera  /  Y recover",680,555,300,30,10,muted)
local templateNames={BrennerS1="GroupB",KazeRS="Sedan",FalkeE3="Saloon",KumoR1="Hybrid",FrecciaHF="Coupe"}
local bodyNames={Shell=true,DoorL=true,DoorR=true,RoofVent=true,BonnetScoop=true,MirrorL=true,MirrorR=true,FuelCap=true}
local factory={BrennerS1=Color3.fromRGB(235,230,210),KazeRS=Color3.fromRGB(22,68,195),FalkeE3=Color3.fromRGB(235,238,242),KumoR1=Color3.fromRGB(28,30,36),FrecciaHF=Color3.fromRGB(195,28,32)}
local function preview()
    world:ClearAllChildren()
    local assets=ReplicatedStorage:FindFirstChild("BackseatAssets")
    local cars=assets and assets:FindFirstChild("Cars")
    local source=cars and cars:FindFirstChild(templateNames[selected])
    if not source then return end
    local clone=source:Clone()
    clone:PivotTo(CFrame.identity)
    local paint=setup.Paint==0 and factory[selected] or CarProfiles.Paints[setup.Paint+1].Color
    for _,p in ipairs(clone:GetDescendants()) do
        if p:IsA("BasePart") then
            p.Anchored=true
            if p.Name=="Root" then p.Transparency=1 end
            if bodyNames[p.Name] then p.Color=paint end
        elseif p:IsA("LuaSourceContainer") then p:Destroy() end
    end
    clone.Parent=world
    local tuning=CarProfiles.Get(selected,setup)
    for _,side in ipairs({-1,1}) do
        for _,axle in ipairs({-1,1}) do
            local cf=CFrame.new(side*tuning.Chassis.TrackWidth/2,tuning.Chassis.WheelCenterY or -0.7,(tuning.Chassis.AxleOffset or 0)+axle*tuning.Chassis.Wheelbase/2)
            local wheel=assets:FindFirstChild("Wheel")
            if wheel and wheel:IsA("Model") then
                local w=wheel:Clone()
                local pivot=w:GetPivot()
                for _,p in ipairs(w:GetDescendants()) do
                    if p:IsA("BasePart") then
                        p.CFrame=pivot*CFrame.new(pivot:PointToObjectSpace(p.Position))
                        p.Anchored=true
                        if p.Name=="Root" then p.Transparency=1 end
                        if p.Name=="Rim" then p.Color=CarProfiles.Rims[setup.Rim+1].Color end
                    elseif p:IsA("JointInstance") or p:IsA("WeldConstraint") then p:Destroy() end
                end
                local tyre=w:FindFirstChild("Tyre")
                if tyre then w:ScaleTo(tuning.Tyres.Radius*2/tyre.Size.Y) end
                w:PivotTo(cf*(side>0 and CFrame.Angles(0,math.pi,0) or CFrame.identity))
                w.Parent=clone
            end
        end
    end
    camera.CFrame=CFrame.lookAt(Vector3.new(-15,8,-21),Vector3.new(0,0.8,0))
end
redraw=function()
    for id,b in pairs(carButtons) do b.BackgroundColor3=id==selected and accent or panel;b.TextColor3=id==selected and ink or light end
    for level,b in pairs(stageButtons) do b.BackgroundColor3=level==setup.Stage and accent or panel;b.TextColor3=level==setup.Stage and ink or light end
    local profile=CarProfiles.Cars[selected]
    carTitle.Text=profile.DisplayName
    specs.Text=profile.Class.."\n"..profile.Specs.Power.." stock / "..profile.Specs.Weight
    power.Text=string.format("+%d%% engine output / +%d%% braking",math.floor((CarProfiles.Stages[setup.Stage+1].Power-1)*100+0.5),math.floor((CarProfiles.Stages[setup.Stage+1].Brake-1)*100+0.5))
    tyreButton.Text=setup.Tyres:upper().." >"
    suspensionButton.Text=setup.Suspension:upper().." >"
    gearingButton.Text=setup.Gearing:upper().." >"
    paintButton.Text=CarProfiles.Paints[setup.Paint+1].Name.." >"
    rimButton.Text="RIM: "..CarProfiles.Rims[setup.Rim+1].Name
    modeButton.Text=mode=="Loop" and "LOOP / ONE LAP" or "INFINITE / KEEP GOING"
    weatherButton.Text=weather=="NightFog" and "NIGHT FOG" or weather:upper()
    courseHint.Text=mode=="Loop" and "A closed forest circuit. Finish one lap. The host builds the shared course." or "New road grows ahead. Checkpoints stay behind each crew. Host controls course."
    preview()
end
local function opened()
    refreshCrew()
    local result=invoke("Get",nil)
    if result and result.Ok then
        selected=result.Car
        setups=result.Setups or {}
        setup=CarProfiles.NormalizeSetup(setups[selected])
        mode=result.Mode
        weather=Workspace:GetAttribute("WeatherPreset") or "Clear"
        seed.Text=tostring(result.Seed)
        status.Text=result.Persistent and "Garage saves automatically. Changes fit in service." or "Session garage ready. Published games save setups automatically."
    end
    redraw()
end
gui:GetPropertyChangedSignal("Enabled"):Connect(function() if gui.Enabled then task.spawn(opened) end end)
UserInputService.InputBegan:Connect(function(input,processed)
    if processed or UserInputService:GetFocusedTextBox() then return end
    if input.KeyCode==Enum.KeyCode.V then gui.Enabled=not gui.Enabled
    elseif input.KeyCode==Enum.KeyCode.Return and gui.Enabled then startWithSetup() end
end)
local wasShown=false
StageRemotes.GetEvent("RaceState").OnClientEvent:Connect(function(kind)
    if kind=="Ready" and not wasShown then wasShown=true;gui.Enabled=true
    elseif kind=="Countdown" or kind=="Go" or kind=="Passenger" then gui.Enabled=false end
end)
RunService.RenderStepped:Connect(function()
    if not gui.Enabled then return end
    local size=Workspace.CurrentCamera and Workspace.CurrentCamera.ViewportSize or Vector2.new(1280,720)
    scale.Scale=math.min(1,(size.X-26)/1000,(size.Y-50)/650)
end)
Players.PlayerAdded:Connect(function() if gui.Enabled then refreshCrew() end end)
Players.PlayerRemoving:Connect(function() if gui.Enabled then task.defer(refreshCrew) end end)
redraw()

task.delay(2,function()
    local car=VehicleController.GetActiveVehicle()
    if not wasShown and car and car:GetAttribute("RunState")=="Ready" then wasShown=true;gui.Enabled=true end
end)
