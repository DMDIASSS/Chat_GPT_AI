--!strict
-- Authoritative race lifecycle, checkpoint recovery, crew routing and garage profiles.
local Players=game:GetService("Players")
local ReplicatedStorage=game:GetService("ReplicatedStorage")
local RunService=game:GetService("RunService")
local DataStoreService=game:GetService("DataStoreService")
local Workspace=game:GetService("Workspace")
-- Run UI controllers once from PlayerScripts. A Folder in StarterGui is
-- copied again on character respawn and would otherwise duplicate the menus.
local uiControllers=game:GetService("StarterGui"):FindFirstChild("RallyGui")
local clientScripts=game:GetService("StarterPlayer"):FindFirstChild("StarterPlayerScripts")
if uiControllers and uiControllers:IsA("Folder") and clientScripts then uiControllers.Parent=clientScripts end
local StageRemotes=require(ReplicatedStorage.RallyShared.Remotes.StageRemotes)
local CarProfiles=require(ReplicatedStorage.RallyShared.Config.CarProfiles)
local StageManager=require(script.Parent.StageManager)
local VehicleManager=require(script.Parent.VehicleManager)
StageRemotes.GetOrCreateRemotes()
local raceEvent=StageRemotes.GetEvent("RaceState")
local companionEvent=StageRemotes.GetEvent("CompanionSync")
local sessions:any={}
local profiles:any={}
local crewOwner:any={}
local limits:any={}
local host:Player?=nil
local generationBusy=false
local profileStore=DataStoreService:GetDataStore("BackseatRallyPolish_v2")
local lastCourseChange=-math.huge

local function now():number return Workspace:GetServerTimeNow() end
local function allowed(player:Player,key:string,interval:number):boolean
    local cache=limits[player] or {}
    limits[player]=cache
    if os.clock()-(cache[key] or -math.huge)<interval then return false end
    cache[key]=os.clock()
    return true
end
local function defaultProfile():any return {Car="KazeRS",Setups={},Best={},Dirty=false,Loaded=false} end
local function loadProfile(player:Player)
    local profile=defaultProfile()
    profiles[player]=profile
    if RunService:IsStudio() then return end
    local ok,data=pcall(function() return profileStore:GetAsync(tostring(player.UserId)) end)
    if ok then
        profile.Loaded=true
        if type(data)=="table" then
            if type(data.Car)=="string" and CarProfiles.Cars[data.Car] then profile.Car=data.Car end
            if type(data.Setups)=="table" then
                for carId in pairs(CarProfiles.Cars) do profile.Setups[carId]=CarProfiles.NormalizeSetup(data.Setups[carId]) end
            end
            if type(data.Best)=="table" then
                for key,value in pairs(data.Best) do
                    if type(key)=="string" and #key<180 and type(value)=="number" and value>0 and value<86400 then profile.Best[key]=value end
                end
            end
        end
    else warn("[Rally] Profile unavailable; this player uses session saves.") end
end
local function saveProfile(player:Player)
    local profile=profiles[player]
    if not profile or not profile.Dirty or not profile.Loaded or profile.Saving then return end
    profile.Saving=true
    local version=profile.Version or 0
    local payload={Car=profile.Car,Setups=profile.Setups,Best=profile.Best}
    local ok=pcall(function() profileStore:UpdateAsync(tostring(player.UserId),function() return payload end) end)
    profile.Saving=false
    if ok and version==(profile.Version or 0) then profile.Dirty=false end
end
local function dirty(profile:any)
    profile.Dirty=true
    profile.Version=(profile.Version or 0)+1
end
local function lockJump(player:Player,locked:boolean)
    local human=player.Character and player.Character:FindFirstChildOfClass("Humanoid")
    if human then
        human:SetStateEnabled(Enum.HumanoidStateType.Jumping,not locked)
        human.Jump=false
        human.AutoJumpEnabled=not locked
    end
end
local function driverOf(player:Player):Player return crewOwner[player] or player end
local function send(driver:Player,kind:string,payload:any?)
    raceEvent:FireClient(driver,kind,payload or {})
    local state=sessions[driver]
    if state and state.Passenger and state.Passenger.Parent==Players then raceEvent:FireClient(state.Passenger,kind,payload or {}) end
end
local function sendStage(driver:Player,eventName:string,...:any)
    local event=StageRemotes.GetEvent(eventName)
    event:FireClient(driver,...)
    local state=sessions[driver]
    if state and state.Passenger and state.Passenger.Parent==Players then event:FireClient(state.Passenger,...) end
end
local function crewAttributes(state:any)
    local vehicle=state.Vehicle
    if vehicle and vehicle.Parent then
        vehicle:SetAttribute("CoDriverUserId",state.Passenger and state.Passenger.UserId or 0)
        vehicle:SetAttribute("CoDriverMode",state.Passenger and "Human" or "Bot")
    end
end
local function hold(state:any,anchored:boolean)
    local vehicle=state.Vehicle
    local body=vehicle and vehicle.PrimaryPart
    if not body then return end
    local force=body:FindFirstChild("ChassisForce")
    local torque=body:FindFirstChild("ChassisTorque")
    if force then force.Force=Vector3.zero end
    if torque then torque.Torque=Vector3.zero end
    body.AssemblyLinearVelocity,body.AssemblyAngularVelocity=Vector3.zero,Vector3.zero
    body.Anchored=anchored
    if not anchored then pcall(function() body:SetNetworkOwner(state.Driver) end) end
end
local spawn:any
local recover:any
local leaveCrew:any
local function seatPassenger(state:any)
    local passenger=state.Passenger
    local seat=state.Vehicle and state.Vehicle:FindFirstChild("CoDriverSeat")
    local human=passenger and passenger.Character and passenger.Character:FindFirstChildOfClass("Humanoid")
    if seat and human and human.Health>0 then
        lockJump(passenger,true)
        passenger.Character:PivotTo(seat.CFrame*CFrame.new(0,1.5,0))
        seat:Sit(human)
        passenger.ReplicationFocus=state.Vehicle.PrimaryPart
    end
    crewAttributes(state)
end
local function validObstacle(hit:Instance?,vehicle:Model):boolean
    if not hit or not hit:IsA("BasePart") or not hit.CanCollide or hit:IsDescendantOf(vehicle) then return false end
    if hit:GetAttribute("SurfaceType") or hit:GetAttribute("IsCheckpoint") then return false end
    local ancestor=hit:FindFirstAncestorOfClass("Model")
    if ancestor and (ancestor:FindFirstChildOfClass("Humanoid") or ancestor:GetAttribute("IsRallyVehicle")) then return false end
    return true
end
spawn=function(driver:Player,cf:CFrame?,preserve:boolean?)
    local previous=sessions[driver]
    local profile=profiles[driver]
    if not profile or not driver.Parent or not driver.Character then return nil end
    local passenger=previous and previous.Passenger
    local setup=CarProfiles.NormalizeSetup(profile.Setups[profile.Car])
    local car=VehicleManager.SpawnVehicle(profile.Car,cf or StageManager.GetStartCFrame(),driver,setup)
    local state=preserve and previous or {
        Driver=driver,Passenger=passenger,State="Ready",Penalty=0,Progress=0,
        Checkpoint=0,CheckpointDistance=0,CheckpointCF=StageManager.GetStartCFrame(),
        LastSplit=0,SplitTimes={},Token=0,Resets=0,Started=0,
    }
    state.Vehicle=car
    state.LastPosition=car.PrimaryPart.Position
    state.LastVelocity=Vector3.zero
    state.LastFrameTime=now()
    state.OffRoadSince=nil
    state.RolledSince=nil
    state.SpawnClock=os.clock()
    sessions[driver]=state
    car:SetAttribute("RunState",state.State)
    car:SetAttribute("RecoveryDistance",state.CheckpointDistance)
    car:SetAttribute("PenaltySeconds",state.Penalty)
    car:SetAttribute("DriverUserId",driver.UserId)
    car:SetAttribute("DriverName",driver.DisplayName)
    hold(state,true)
    lockJump(driver,true)
    crewAttributes(state)
    local body=car.PrimaryPart
    body.Touched:Connect(function(hit)
        if sessions[driver]~=state or state.Vehicle~=car or state.State~="Running" then return end
        if validObstacle(hit,car) and os.clock()-state.SpawnClock>1.3 then
            local velocity=state.LastVelocity
            local delta=hit.Position-body.Position
            local normal=Vector3.new(delta.X,0,delta.Z)
            local closing=normal.Magnitude>0.1 and velocity:Dot(normal.Unit) or velocity.Magnitude
            if closing>34 then recover(driver,"CRASH",8) end
        end
    end)
    local driverSeat=car:FindFirstChild("VehicleSeat")
    driverSeat:GetPropertyChangedSignal("Occupant"):Connect(function()
        if not car.Parent then return end
        local human=driverSeat.Occupant
        if human and Players:GetPlayerFromCharacter(human.Parent)~=driver then human.Sit=false end
    end)
    local passengerSeat=car:FindFirstChild("CoDriverSeat")
    passengerSeat:GetPropertyChangedSignal("Occupant"):Connect(function()
        if not car.Parent or state.Vehicle~=car then return end
        local human=passengerSeat.Occupant
        if human and (not state.Passenger or Players:GetPlayerFromCharacter(human.Parent)~=state.Passenger) then human.Sit=false end
        -- A disconnected/ejected passenger immediately gives control back to the bot.
        if not human and state.Passenger and state.State=="Running" then
            local friend=state.Passenger
            task.delay(0.6,function()
                if car.Parent and state.Vehicle==car and not passengerSeat.Occupant and state.Passenger==friend then
                    state.Passenger=nil
                    crewOwner[friend]=nil
                    lockJump(friend,false)
                    crewAttributes(state)
                    send(driver,"Notice",{Message="Co-driver left. Bot is on the radio."})
                end
            end)
        end
    end)
    task.delay(0.25,function()
        if car.Parent and state.Vehicle==car then seatPassenger(state) end
    end)
    if not preserve then send(driver,"Ready",{Mode=StageManager.GetMode(),Seed=StageManager.GetSeed()}) end
    return car
end
recover=function(driver:Player,reason:string,penalty:number)
    local state=sessions[driver]
    if not state or state.State~="Running" then return end
    state.State="Crashing"
    state.Token+=1
    local token=state.Token
    state.Resets+=1
    state.Penalty+=penalty
    state.Vehicle:SetAttribute("RunState","Crashing")
    hold(state,true)
    send(driver,"Crash",{Reason=reason,Penalty=penalty,TotalPenalty=state.Penalty})
    task.delay(1.15,function()
        if sessions[driver]~=state or state.Token~=token or not driver.Parent then return end
        state.State="Recovering"
        if not spawn(driver,state.CheckpointCF,true) then return end
        state.Progress=state.CheckpointDistance
        -- Re-crossing an old checkpoint never awards another split.
        state.SpawnClock=os.clock()
        task.delay(0.6,function()
            if sessions[driver]~=state or state.Token~=token then return end
            state.State="Running"
            state.Vehicle:SetAttribute("RunState","Running")
            hold(state,false)
            send(driver,"Recovered",{Penalty=state.Penalty,Distance=state.Progress})
        end)
    end)
end
local function startRace(driver:Player)
    local state=sessions[driver]
    if not state or state.State=="Countdown" or state.State=="Running" or state.State=="Crashing" or state.State=="Recovering" then return end
    if not spawn(driver) then return end
    state=sessions[driver]
    state.State="Countdown"
    state.Vehicle:SetAttribute("RunState","Countdown")
    state.Token+=1
    local token=state.Token
    send(driver,"Countdown",{Seconds=3,Mode=StageManager.GetMode()})
    task.delay(3,function()
        if sessions[driver]~=state or state.Token~=token then return end
        state.State,state.Started="Running",now()
        state.RecordKey=table.concat({StageManager.GetMode(),StageManager.GetSeed(),profiles[driver].Car,state.Vehicle:GetAttribute("Setup_Stage"),state.Vehicle:GetAttribute("Setup_Tyres"),state.Vehicle:GetAttribute("Setup_Suspension"),state.Vehicle:GetAttribute("Setup_Gearing")},":")
        state.Vehicle:SetAttribute("RunState","Running")
        state.Vehicle:SetAttribute("RaceStarted",state.Started)
        hold(state,false)
        sendStage(driver,"StageStart",state.Started)
        send(driver,"Go",{Started=state.Started})
    end)
end
local function finishRace(driver:Player,state:any)
    state.State="Finished"
    state.Vehicle:SetAttribute("RunState","Finished")
    local elapsed=now()-state.Started+state.Penalty
    local profile=profiles[driver]
    local previous=profile.Best[state.RecordKey]
    local best=not previous or elapsed<previous
    if best then
        local count=0;for _ in pairs(profile.Best) do count+=1 end
        if count>=40 then profile.Best={} end
        profile.Best[state.RecordKey]=elapsed
        dirty(profile)
    end
    hold(state,true)
    sendStage(driver,"StageFinished",now(),elapsed)
    send(driver,"Finished",{Elapsed=elapsed,Penalty=state.Penalty,Resets=state.Resets,PersonalBest=best,Previous=previous})
end
leaveCrew=function(player:Player,returnToCar:boolean?)
    local driver=crewOwner[player]
    if not driver then return end
    local state=sessions[driver]
    crewOwner[player]=nil
    if state and state.Passenger==player then state.Passenger=nil;crewAttributes(state) end
    local human=player.Character and player.Character:FindFirstChildOfClass("Humanoid")
    if human then human.Sit=false end
    lockJump(player,false)
    player.ReplicationFocus=nil
    if driver.Parent then send(driver,"Notice",{Message="Co-driver left. Bot is on the radio."}) end
    if returnToCar and player.Parent then task.defer(function() spawn(player) end) end
end
local function courseChange(player:Player,seed:any,mode:any,weather:any):any
    if player~=host then return {Ok=false,Message="The host controls the shared course."} end
    if generationBusy or os.clock()-lastCourseChange<4 then return {Ok=false,Message="Course is preparing. Try again in a moment."} end
    for _,state in pairs(sessions) do
        if state.State=="Running" or state.State=="Countdown" or state.State=="Crashing" or state.State=="Recovering" then return {Ok=false,Message="End the active runs before changing the shared course."} end
    end
    lastCourseChange=os.clock()
    generationBusy=true
    local validSeed=type(seed)=="number" and seed==seed and math.clamp(math.floor(seed),1,999999) or math.random(1,999999)
    local validWeather=table.find({"Clear","Rain","Autumn","NightFog"},weather) and weather or "Clear"
    local ok,err=pcall(function() StageManager.BuildStage({Seed=validSeed,Mode=mode=="Infinite" and "Infinite" or "Loop",Weather=validWeather}) end)
    generationBusy=false
    if not ok then warn(err);return {Ok=false,Message="Course generation failed; reopen the place to restore it."} end
    for driver in pairs(sessions) do if not crewOwner[driver] then spawn(driver) end end
    return {Ok=true,Mode=StageManager.GetMode(),Seed=StageManager.GetSeed()}
end
StageRemotes.GetFunction("GarageRequest").OnServerInvoke=function(player:Player,action:any,payload:any)
    if not allowed(player,"Garage:"..tostring(action),0.25) then return {Ok=false,Message="Please wait a moment."} end
    local profile=profiles[player]
    if not profile then return {Ok=false,Message="Garage is loading."} end
    if action=="Get" then return {Ok=true,Car=profile.Car,Setups=profile.Setups,IsHost=player==host,Mode=StageManager.GetMode(),Seed=StageManager.GetSeed(),Persistent=profile.Loaded} end
    if action=="Course" then
        payload=type(payload)=="table" and payload or {}
        return courseChange(player,payload.Seed,payload.Mode,payload.Weather)
    end
    if action=="Apply" then
        local state=sessions[player]
        if crewOwner[player] or (state and state.State~="Ready" and state.State~="Finished") then return {Ok=false,Message="Return to service before changing the car."} end
        if type(payload)~="table" or type(payload.Car)~="string" or not CarProfiles.Cars[payload.Car] then return {Ok=false,Message="Choose a car."} end
        profile.Car=payload.Car
        profile.Setups[payload.Car]=CarProfiles.NormalizeSetup(payload.Setup)
        dirty(profile)
        spawn(player)
        return {Ok=true,Message="Setup fitted. Ready to race."}
    end
    return {Ok=false,Message="Unknown garage action."}
end
StageRemotes.GetFunction("CrewRequest").OnServerInvoke=function(player:Player,targetId:any)
    if not allowed(player,"Crew",1) then return {Ok=false,Message="Please wait a moment."} end
    if targetId==0 then leaveCrew(player,true);return {Ok=true} end
    local target=type(targetId)=="number" and Players:GetPlayerByUserId(targetId)
    local targetState=target and sessions[target]
    local own=sessions[player]
    if not target or target==player or crewOwner[target] or not targetState or targetState.Passenger then return {Ok=false,Message="That passenger seat is unavailable."} end
    if targetState.State~="Ready" and targetState.State~="Finished" then return {Ok=false,Message="Join your friend while their car is in service."} end
    if own and own.State~="Ready" and own.State~="Finished" then return {Ok=false,Message="Return to service before joining a crew."} end
    local passengerHuman=player.Character and player.Character:FindFirstChildOfClass("Humanoid")
    if not passengerHuman or passengerHuman.Health<=0 then return {Ok=false,Message="Wait for your character to spawn."} end
    leaveCrew(player,false)
    if own then own.Token+=1;if own.Vehicle then own.Vehicle:Destroy() end;sessions[player]=nil end
    targetState.Passenger=player
    crewOwner[player]=target
    seatPassenger(targetState)
    raceEvent:FireClient(player,"Passenger",{Driver=target.DisplayName})
    send(target,"Notice",{Message=player.DisplayName.." is your co-driver. Start when ready."})
    return {Ok=true}
end
StageRemotes.GetEvent("RaceAction").OnServerEvent:Connect(function(player:Player,action:any)
    if not allowed(player,"Race",0.75) then return end
    if action=="LeaveCrew" then leaveCrew(player,true);return end
    if crewOwner[player] then return end
    local state=sessions[player]
    if action=="Start" then startRace(player)
    elseif action=="Reset" then recover(player,"CHECKPOINT RESET",5)
    elseif action=="Service" and state then
        state.Token+=1
        state.State="Ready"
        spawn(player)
    end
end)
companionEvent.OnServerEvent:Connect(function(sender:Player,index:any)
    if not allowed(sender,"Call",0.65) or type(index)~="number" then return end
    local driver=crewOwner[sender]
    local state=driver and sessions[driver]
    local seat=state and state.Vehicle and state.Vehicle:FindFirstChild("CoDriverSeat")
    local human=sender.Character and sender.Character:FindFirstChildOfClass("Humanoid")
    if not state or state.State~="Running" or not human or not seat or seat.Occupant~=human then return end
    local note=StageManager.GetPaceNotes()[index]
    if not note or note.Distance>state.Progress+700 or note.EndDistance<state.Progress-40 then return end
    companionEvent:FireClient(driver,index,note.Description,note.Severity,note.Direction)
    companionEvent:FireClient(sender,index,note.Description,note.Severity,note.Direction)
end)
-- A client report is only a hint. Validate car ownership, obstacle, range and recent speed.
StageRemotes.GetEvent("CrashReport").OnServerEvent:Connect(function(player:Player,hit:any)
    if not allowed(player,"Impact",0.25) then return end
    local state=sessions[player]
    if not state or state.State~="Running" or typeof(hit)~="Instance" then return end
    if validObstacle(hit,state.Vehicle) and (hit.Position-state.Vehicle.PrimaryPart.Position).Magnitude<hit.Size.Magnitude/2+12 and state.LastVelocity.Magnitude>38 then recover(player,"CRASH",8) end
end)
StageRemotes.GetFunction("RequestVehicleSpawn").OnServerInvoke=function(player:Player,carId:any)
    if not allowed(player,"Spawn",1.5) or crewOwner[player] then return nil end
    local state=sessions[player]
    if state and state.State~="Ready" and state.State~="Finished" then return nil end
    if type(carId)=="string" and CarProfiles.Cars[carId] then profiles[player].Car=carId end
    return spawn(player)
end
StageRemotes.GetEvent("SelectVehicle").OnServerEvent:Connect(function(player:Player,carId:any)
    if not allowed(player,"Spawn",1.5) or crewOwner[player] or not profiles[player] then return end
    local state=sessions[player]
    if state and state.State~="Ready" and state.State~="Finished" then return end
    if type(carId)=="string" and CarProfiles.Cars[carId] then profiles[player].Car=carId;dirty(profiles[player]);spawn(player) end
end)
StageRemotes.GetFunction("RequestStageRegen").OnServerInvoke=function(player:Player,seed:any,weather:any)
    return courseChange(player,seed,StageManager.GetMode(),weather).Ok
end
StageRemotes.GetFunction("ToggleStageMode").OnServerInvoke=function(player:Player,mode:any)
    local result=courseChange(player,StageManager.GetSeed(),mode or (StageManager.GetMode()=="Loop" and "Infinite" or "Loop"),"Clear")
    if not result.Ok then send(player,"Notice",{Message=result.Message}) end
    return StageManager.GetMode()
end
StageRemotes.GetEvent("ApplySettings").OnServerEvent:Connect(function(player:Player,key:any,value:any)
    if player==host and allowed(player,"Weather",2) and key=="Weather" and table.find({"Clear","Rain","Autumn","NightFog"},value) then StageManager.SetWeather(value) end
end)
local initial=Workspace:FindFirstChild("RallyVehicles")
if initial then initial:ClearAllChildren() end
StageManager.BuildStage({Seed=42,Mode="Loop",Weather="Clear"})
local tickAccumulator=0
RunService.Heartbeat:Connect(function(dt)
    tickAccumulator+=dt
    if tickAccumulator<0.1 then return end
    tickAccumulator=0
    local leader=0
    local oldest=math.huge
    for driver,state in pairs(sessions) do
        if not state.Vehicle or not state.Vehicle.Parent or not state.Vehicle.PrimaryPart then continue end
        oldest=math.min(oldest,state.CheckpointDistance)
        leader=math.max(leader,state.Progress)
        if state.State~="Running" then continue end
        local body=state.Vehicle.PrimaryPart
        local position,velocity=body.Position,body.AssemblyLinearVelocity
        local currentTime=now()
        local progress,offRoad=StageManager.Project(position,state.Progress)
        local sampleCF=state.CheckpointCF
        if offRoad>70 or position.Y<sampleCF.Position.Y-42 then
            state.OffRoadSince=state.OffRoadSince or currentTime
            if currentTime-state.OffRoadSince>0.9 then recover(driver,"OFF COURSE",5);continue end
        else state.OffRoadSince=nil end
        if body.CFrame.UpVector.Y<0.15 then
            state.RolledSince=state.RolledSince or currentTime
            if currentTime-state.RolledSince>2.5 then recover(driver,"ROLLOVER",8);continue end
        else state.RolledSince=nil end
        local movement=position-state.LastPosition
        if movement.Magnitude>0.2 and movement.Magnitude<180 and os.clock()-state.SpawnClock>1.3 then
            local filter=RaycastParams.new()
            filter.FilterType=Enum.RaycastFilterType.Exclude
            local excluded:any={state.Vehicle}
            for _,p in ipairs(Players:GetPlayers()) do if p.Character then table.insert(excluded,p.Character) end end
            filter.FilterDescendantsInstances=excluded
            filter.RespectCanCollide=true
            local sweepCF=CFrame.new(state.LastPosition)*body.CFrame.Rotation
            local ok,result=pcall(function() return Workspace:Blockcast(sweepCF,Vector3.new(body.Size.X*0.8,0.7,body.Size.Z*0.8),movement,filter) end)
            if ok and result and validObstacle(result.Instance,state.Vehicle) and -state.LastVelocity:Dot(result.Normal)>34 then recover(driver,"CRASH",8);continue end
        end
        state.LastPosition,state.LastVelocity,state.LastFrameTime=position,velocity,currentTime
        if offRoad<19 and math.abs(progress-state.Progress)<180 then
            state.Progress=math.max(state.Progress-4,progress)
            for index,checkpoint in ipairs(StageManager.GetCheckpoints()) do
                if index==state.Checkpoint+1 and progress>=checkpoint.Distance and progress-checkpoint.Distance<90 then
                    state.Checkpoint=index
                    state.CheckpointDistance=checkpoint.Distance
                    state.CheckpointCF=checkpoint.CFrame
                    state.Vehicle:SetAttribute("CheckpointDistance",checkpoint.Distance)
                    send(driver,"Checkpoint",{Distance=checkpoint.Distance,Penalty=state.Penalty})
                end
            end
            if StageManager.GetMode()=="Loop" then
                local total=StageManager.GetTotalDistance()
                local split=math.min(3,math.floor(progress/total*4))
                if split>state.LastSplit then
                    state.LastSplit=split
                    local elapsed=currentTime-state.Started+state.Penalty
                    state.SplitTimes[split]=elapsed
                    sendStage(driver,"SplitCrossed",split,progress,currentTime,elapsed)
                end
                if progress>=total-10 and state.Checkpoint>=#StageManager.GetCheckpoints() then finishRace(driver,state) end
            end
        end
        state.Vehicle:SetAttribute("RouteDistance",state.Progress)
        state.Vehicle:SetAttribute("PenaltySeconds",state.Penalty)
    end
    StageManager.EnsureAhead(leader,oldest==math.huge and 0 or oldest)
end)
local function onPlayer(player:Player)
    if profiles[player] then return end
    if not host then host=player;Workspace:SetAttribute("CourseHostUserId",player.UserId) end
    loadProfile(player)
    if not player.Parent then return end
    local function characterReady()
        task.delay(0.8,function()
            if not player.Parent then return end
            if crewOwner[player] then
                local driver=crewOwner[player]
                leaveCrew(player,false)
                if sessions[driver] then crewAttributes(sessions[driver]) end
            end
            local state=sessions[player]
            if state and state.State=="Running" then recover(player,"DRIVER RESET",8) else spawn(player) end
        end)
    end
    player.CharacterAdded:Connect(characterReady)
    if player.Character then characterReady() end
end
Players.PlayerAdded:Connect(onPlayer)
for _,player in ipairs(Players:GetPlayers()) do task.spawn(onPlayer,player) end
Players.PlayerRemoving:Connect(function(player)
    leaveCrew(player,false)
    local state=sessions[player]
    if state then
        state.Token+=1
        if state.Passenger then leaveCrew(state.Passenger,true) end
        if state.Vehicle then state.Vehicle:Destroy() end
    end
    saveProfile(player)
    profiles[player],sessions[player],limits[player]=nil,nil,nil
    if host==player then
        host=nil
        for _,candidate in ipairs(Players:GetPlayers()) do if candidate~=player then host=candidate;break end end
        Workspace:SetAttribute("CourseHostUserId",host and host.UserId or 0)
    end
end)
task.spawn(function()
    while task.wait(30) do for player in pairs(profiles) do task.spawn(saveProfile,player) end end
end)
game:BindToClose(function()
    local pending=0
    for player in pairs(profiles) do pending+=1;task.spawn(function() saveProfile(player);pending-=1 end) end
    local deadline=os.clock()+8
    while pending>0 and os.clock()<deadline do task.wait(0.1) end
end)
print("[Backseat Rally] Loop / Infinite, garage, crew and crash recovery ready.")
