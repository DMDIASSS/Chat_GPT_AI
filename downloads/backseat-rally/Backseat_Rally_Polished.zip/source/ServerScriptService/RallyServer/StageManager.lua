--!strict
-- Shared seeded course, a finite closed loop or continuously streamed forest rally.
local Workspace=game:GetService("Workspace")
local ReplicatedStorage=game:GetService("ReplicatedStorage")
local Lighting=game:GetService("Lighting")
local CatmullRom=require(ReplicatedStorage.RallyShared.Splines.CatmullRom)
local BishopFrame=require(ReplicatedStorage.RallyShared.Splines.BishopFrame)
local CurvatureAnalyzer=require(ReplicatedStorage.RallyShared.Splines.CurvatureAnalyzer)
local SurfaceConfig=require(ReplicatedStorage.RallyShared.Config.SurfaceConfig)
local StageProgress=require(ReplicatedStorage.RallyShared.Splines.StageProgress)
local StageManager={}
export type StageConfig={Seed:number,Mode:string?,LengthStuds:number?,RoadWidth:number?,SegmentLength:number?,Curviness:number?,ElevationRange:number?,Weather:string?}
local config:any={Seed=42,Mode="Loop",LengthStuds=4200,RoadWidth=26,SegmentLength=14,Weather="Clear"}
local activeSamples:any={}
local activePaceNotes:any={}
local checkpointData:any={}
local activeStageFolder:Folder?=nil
local currentWeather="Clear"
local generation=0
local revision=0
local controls:any={}
local controlIndex=0
local startCFrame=CFrame.new(0,15,0)
local segmentSerial=0
local chunks:any={}
local growing=false

local function part(name:string,size:Vector3,cf:CFrame,material:Enum.Material,color:Color3,parent:Instance):Part
    local p=Instance.new("Part")
    p.Name,p.Size,p.CFrame,p.Material,p.Color=name,size,cf,material,color
    p.Anchored=true
    p.TopSurface,p.BottomSurface=Enum.SurfaceType.Smooth,Enum.SurfaceType.Smooth
    p.Parent=parent
    return p
end
local function obstacle(p:BasePart)
    p.CanCollide,p.CanQuery,p.CanTouch=true,true,true
    p:SetAttribute("CrashObstacle",true)
end
local function spawn3DProp(name:string,cf:CFrame,parent:Instance):Model?
    local assets=ReplicatedStorage:FindFirstChild("BackseatAssets")
    local props=assets and assets:FindFirstChild("Props")
    local source=props and props:FindFirstChild(name)
    if not source or not source:IsA("Model") then return nil end
    local clone=source:Clone()
    local pivot=clone:GetPivot()
    local bounds,size=clone:GetBoundingBox()
    local lift=pivot.Position.Y-(bounds.Position.Y-size.Y/2)
    clone:PivotTo(cf*CFrame.new(0,math.max(0,lift-0.25),0))
    local tree=name:find("Spruce") or name:find("Birch")
    local rock=name:find("Rock")
    for _,p in ipairs(clone:GetDescendants()) do
        if p:IsA("BasePart") then
            p.Anchored=true
            -- Trunks and rocks get reliable collision hulls below. Foliage stays soft.
            p.CanCollide=not tree and not rock
            p.CanTouch=false
            p.CanQuery=not tree and not rock
            if p.CanCollide then p:SetAttribute("CrashObstacle",true) end
        elseif p:IsA("LuaSourceContainer") then p:Destroy() end
    end
    if tree then
        local trunk=part("TrunkCollision",Vector3.new(2.4,math.min(15,size.Y),2.4),cf*CFrame.new(0,math.min(15,size.Y)/2,0),Enum.Material.Wood,Color3.fromRGB(75,57,38),clone)
        trunk.Transparency=1
        obstacle(trunk)
    elseif rock then
        local hull=part("RockCollision",Vector3.new(math.min(9,size.X)*0.85,math.max(2,size.Y)*0.8,math.min(9,size.Z)*0.85),cf*CFrame.new(0,math.max(2,size.Y)*0.4,0),Enum.Material.Rock,Color3.fromRGB(91,94,87),clone)
        hull.Transparency=1
        obstacle(hull)
    end
    clone.Parent=parent
    return clone
end
function StageManager.SetWeather(weatherName: string)
	currentWeather = weatherName
	Workspace:SetAttribute("WeatherPreset", weatherName)

	Lighting.GlobalShadows = true
	Lighting.EnvironmentDiffuseScale = 1.0
	Lighting.EnvironmentSpecularScale = 1.0
	Lighting.ShadowSoftness = 0.22

	local atmo = Lighting:FindFirstChildOfClass("Atmosphere")
	if not atmo then
		atmo = Instance.new("Atmosphere")
		atmo.Parent = Lighting
	end

	local bloom = Lighting:FindFirstChildOfClass("BloomEffect")
	if not bloom then
		bloom = Instance.new("BloomEffect")
		bloom.Parent = Lighting
	end
	bloom.Intensity = 0.45
	bloom.Size = 24
	bloom.Threshold = 1.8

	local sunRays = Lighting:FindFirstChildOfClass("SunRaysEffect")
	if not sunRays then
		sunRays = Instance.new("SunRaysEffect")
		sunRays.Parent = Lighting
	end
	sunRays.Intensity = 0.14
	sunRays.Spread = 0.65

	local cc = Lighting:FindFirstChildOfClass("ColorCorrectionEffect")
	if not cc then
		cc = Instance.new("ColorCorrectionEffect")
		cc.Parent = Lighting
	end

	if weatherName == "Rain" then
		Lighting.ClockTime = 16.5
		Lighting.Brightness = 1.5
		Lighting.OutdoorAmbient = Color3.fromRGB(85, 95, 110)
		Lighting.FogEnd = 900
		Lighting.FogColor = Color3.fromRGB(115, 128, 142)
		atmo.Density = 0.42
		atmo.Offset = 0.15
		atmo.Color = Color3.fromRGB(140, 152, 168)
		atmo.Decay = Color3.fromRGB(95, 105, 118)
		atmo.Haze = 2.2
		cc.Contrast = 0.10
		cc.Saturation = -0.08
		cc.TintColor = Color3.fromRGB(235, 242, 255)
	elseif weatherName == "NightFog" then
		Lighting.ClockTime = 21.2
		Lighting.Brightness = 0.6
		Lighting.OutdoorAmbient = Color3.fromRGB(32, 38, 52)
		Lighting.FogEnd = 450
		Lighting.FogColor = Color3.fromRGB(28, 34, 46)
		atmo.Density = 0.52
		atmo.Offset = 0.1
		atmo.Color = Color3.fromRGB(45, 55, 75)
		atmo.Decay = Color3.fromRGB(22, 28, 40)
		atmo.Haze = 3.0
		cc.Contrast = 0.16
		cc.Saturation = -0.05
		cc.TintColor = Color3.fromRGB(215, 228, 255)
	elseif weatherName == "Autumn" then
		Lighting.ClockTime = 15.8
		Lighting.Brightness = 2.6
		Lighting.OutdoorAmbient = Color3.fromRGB(135, 112, 92)
		Lighting.FogEnd = 2200
		Lighting.FogColor = Color3.fromRGB(215, 182, 145)
		atmo.Density = 0.30
		atmo.Offset = 0.2
		atmo.Color = Color3.fromRGB(235, 195, 150)
		atmo.Decay = Color3.fromRGB(175, 125, 85)
		atmo.Haze = 1.4
		cc.Contrast = 0.14
		cc.Saturation = 0.18
		cc.TintColor = Color3.fromRGB(255, 244, 228)
	else -- "Clear"
		Lighting.ClockTime = 15.1
		Lighting.Brightness = 2.85
		Lighting.OutdoorAmbient = Color3.fromRGB(118, 128, 138)
		Lighting.FogEnd = 3000
		Lighting.FogColor = Color3.fromRGB(188, 208, 230)
		atmo.Density = 0.26
		atmo.Offset = 0.22
		atmo.Color = Color3.fromRGB(198, 216, 238)
		atmo.Decay = Color3.fromRGB(130, 152, 178)
		atmo.Haze = 0.9
		cc.Contrast = 0.12
		cc.Saturation = 0.14
		cc.TintColor = Color3.fromRGB(255, 252, 245)
	end
end

local function nextControl(index:number,previous:Vector3):Vector3
    -- Z is strictly increasing. Bounded, filtered headings prevent overlaps and cusps.
    local heading=math.noise(index*0.29,config.Seed*0.001,1.7)*1.8
    if index<4 then heading=0 end
    local step=138
    local height=12+math.noise(index*0.15,config.Seed*0.003,4.2)*34
    return Vector3.new(previous.X+math.sin(heading)*step,height,previous.Z+math.cos(heading)*step)
end
function StageManager.GenerateControlPoints(custom:StageConfig):{Vector3}
    local points={}
    if custom.Mode=="Infinite" then
        local p=Vector3.new(0,12,-138)
        for i=1,19 do
            if i>1 then
                local heading=i<4 and 0 or math.noise(i*0.29,custom.Seed*0.001,1.7)*1.8
                p=Vector3.new(p.X+math.sin(heading)*138,12+math.noise(i*0.15,custom.Seed*0.003,4.2)*34,p.Z+math.cos(heading)*138)
            end
            table.insert(points,p)
        end
    else
        -- A periodic radial course; the radius stays well clear of the forest banks.
        local n=32
        local radius=(custom.LengthStuds or 4200)/(2*math.pi)
        local phase=custom.Seed*0.013
        for i=-1,n+1 do
            local theta=(i%n)/n*math.pi*2
            local r=radius*(1+0.105*math.sin(theta*3+phase)+0.045*math.sin(theta*5-phase))
            local y=16+12*math.sin(theta*2)*math.sin(theta/2)^2
            table.insert(points,Vector3.new(math.sin(theta)*r,y,(1-math.cos(theta))*r))
        end
    end
    return points
end
local function publish()
    revision+=1
    local data=Instance.new("Folder")
    data.Name="ActiveStageData"
    data:SetAttribute("Generation",generation)
    data:SetAttribute("Revision",revision)
    data:SetAttribute("Seed",config.Seed)
    data:SetAttribute("Mode",config.Mode)
    data:SetAttribute("RoadWidth",config.RoadWidth)
    data:SetAttribute("SampleCount",#activeSamples)
    local total=Instance.new("NumberValue")
    total.Name,total.Value,total.Parent="TotalDistance",activeSamples[#activeSamples].Distance,data
    local route=Instance.new("Folder")
    route.Name,route.Parent="RouteSamples",data
    for i,sample in ipairs(activeSamples) do
        local point=Instance.new("Configuration")
        point.Name=string.format("Point_%06d",i)
        point:SetAttribute("Position",sample.Position)
        point:SetAttribute("Distance",sample.Distance)
        point.Parent=route
    end
    local notes=CurvatureAnalyzer.AnalyzeStage(activeSamples)
    local folder=Instance.new("Folder")
    folder.Name,folder.Parent="PaceNotes",data
    activePaceNotes={}
    for _,note in ipairs(notes) do
        local distance=note.DistanceAlongTrack or note.Distance or 0
        local id=math.floor(distance*10+0.5)*16+math.clamp(note.Severity,1,9)
        note.Index=id
        note.Distance=distance
        activePaceNotes[id]=note
        local value=Instance.new("Configuration")
        value.Name=string.format("Note_%08d",id)
        value:SetAttribute("Index",id)
        value:SetAttribute("Distance",distance)
        value:SetAttribute("EndDistance",note.EndDistance or distance+(note.CornerLength or 30))
        value:SetAttribute("Direction",note.Direction)
        value:SetAttribute("Severity",note.Severity)
        value:SetAttribute("Modifier",note.Modifier or "")
        value:SetAttribute("Description",note.Description or CurvatureAnalyzer.FormatPaceNote(note))
        value:SetAttribute("Position",note.Position)
        value.Parent=folder
    end
    data:SetAttribute("NoteCount",#folder:GetChildren())
    local old=ReplicatedStorage:FindFirstChild("ActiveStageData")
    if old then old.Name="PreviousStageData" end
    data.Parent=ReplicatedStorage
    if old then old:Destroy() end
    Workspace:SetAttribute("RaceMode",config.Mode)
    Workspace:SetAttribute("StageSeed",config.Seed)
end
local function extrude(samples:any)
    local chunk=Instance.new("Model")
    chunk.Name=string.format("RoadChunk_%04d",#chunks+1)
    local firstDistance=samples[1].Distance
    local lastDistance=samples[#samples].Distance
    chunk:SetAttribute("StartDistance",firstDistance)
    chunk:SetAttribute("EndDistance",lastDistance)
    local road=Instance.new("Folder")
    road.Name,road.Parent="Roadbed",chunk
    local scenery=Instance.new("Folder")
    scenery.Name,scenery.Parent="Scenery",chunk
    local curvatures={}
    for i,s in ipairs(samples) do curvatures[i]=s.Curvature end
    local frames=BishopFrame.GenerateFrames(samples,curvatures,4)
    local rng=Random.new(config.Seed+math.floor(firstDistance)*17)
    local trees={"Spruce1","Spruce2","Birch1"}
    for i=1,#samples-1 do
        segmentSerial+=1
        local a,b=frames[i],frames[i+1]
        local delta=b.Position-a.Position
        local dir=delta.Unit
        local right=dir:Cross(Vector3.yAxis).Unit
        local up=right:Cross(dir).Unit
        local center=(a.Position+b.Position)*0.5
        local cf=CFrame.fromMatrix(center,right,up,-dir)
        local surfaceIndex=math.floor((samples[i].Distance+config.Seed*3)/650)%5
        local surfaceName=surfaceIndex==0 and (currentWeather=="Rain" and "Wet" or "Tarmac") or surfaceIndex==4 and "Mud" or "Gravel"
        local surface=SurfaceConfig.Get(surfaceName)
        local roadSlice=part(string.format("Road_%06d",segmentSerial),Vector3.new(config.RoadWidth,1.2,delta.Magnitude+1.2),cf,surface.Material,surface.Color,road)
        roadSlice:SetAttribute("SurfaceType",surfaceName)
        roadSlice:SetAttribute("Distance",samples[i].Distance)
        -- A thick, continuous forest floor extends well beyond the drivable shoulder.
        local bank=part("ForestFloor",Vector3.new(228,38,delta.Magnitude+5),cf*CFrame.new(0,-19.2,0),Enum.Material.Grass,currentWeather=="Autumn" and Color3.fromRGB(99,83,49) or Color3.fromRGB(57,79,44),road)
        bank:SetAttribute("SurfaceType","Grass")
        for _,side in ipairs({-1,1}) do
            local shoulder=part("Shoulder",Vector3.new(7,1.1,delta.Magnitude+1.3),cf*CFrame.new(side*(config.RoadWidth/2+3.5),-0.08,0),Enum.Material.Ground,Color3.fromRGB(105,99,74),road)
            shoulder:SetAttribute("SurfaceType","Grass")
            -- Visible rock banks contain the outer forest, with a recovery net beyond.
            local berm=part("RockBank",Vector3.new(14,9,delta.Magnitude+4),cf*CFrame.new(side*99,3.6,0)*CFrame.Angles(0,0,side*0.16),Enum.Material.Rock,Color3.fromRGB(82,89,77),scenery)
            obstacle(berm)
            if segmentSerial%2==0 then
                for row=1,2 do
                    local lateral=config.RoadWidth/2+(row==1 and rng:NextNumber(13,24) or rng:NextNumber(36,66))
                    local localPoint=Vector3.new(side*lateral,-0.2,rng:NextNumber(-4,4))
                    local world=cf:PointToWorldSpace(localPoint)
                    local treeCF=CFrame.new(world)*CFrame.Angles(0,rng:NextNumber(0,math.pi*2),0)
                    if not spawn3DProp(trees[rng:NextInteger(1,#trees)],treeCF,scenery) then
                        local trunk=part("RallyTree",Vector3.new(2.4,18,2.4),treeCF*CFrame.new(0,9,0),Enum.Material.Wood,Color3.fromRGB(78,59,39),scenery)
                        obstacle(trunk)
                        local crown=part("TreeCrown",Vector3.new(10,15,10),treeCF*CFrame.new(0,19,0),Enum.Material.Grass,Color3.fromRGB(37,65,40),scenery)
                        crown.Shape=Enum.PartType.Ball
                        crown.CanCollide,crown.CanQuery=false,false
                    end
                end
            end
            if segmentSerial%5==0 then
                local rockCF=cf*CFrame.new(side*(config.RoadWidth/2+12),0,0)
                spawn3DProp(segmentSerial%10==0 and "Rock1" or "Rock2",rockCF,scenery)
                spawn3DProp("MarkerPole",cf*CFrame.new(side*(config.RoadWidth/2+1.8),0,0),scenery)
            end
            if segmentSerial%3==0 and math.abs(samples[i].Curvature)>0.0015 then
                local outside=samples[i].Curvature<0 and 1 or -1
                if side==outside then spawn3DProp("ChevronSign",cf*CFrame.new(side*(config.RoadWidth/2+6),0,0),scenery) end
            end
        end
    end
    chunk.Parent=activeStageFolder
    table.insert(chunks,chunk)
end
local function gate(name:string,sample:any,text:string)
    local cf=CFrame.lookAt(sample.Position,sample.Position+sample.Tangent)
    local model=Instance.new("Model")
    model.Name,model.Parent=name,activeStageFolder
    for _,side in ipairs({-1,1}) do
        local post=part("GatePost",Vector3.new(1.2,12,1.2),cf*CFrame.new(side*(config.RoadWidth/2+2),6,0),Enum.Material.Metal,Color3.fromRGB(214,231,183),model)
        obstacle(post)
    end
    local beam=part("Banner",Vector3.new(config.RoadWidth+6,2.8,0.8),cf*CFrame.new(0,12,0),Enum.Material.Metal,Color3.fromRGB(22,31,31),model)
    obstacle(beam)
    for _,face in ipairs({Enum.NormalId.Front,Enum.NormalId.Back}) do
        local gui=Instance.new("SurfaceGui")
        gui.Face,gui.CanvasSize,gui.Parent=face,Vector2.new(800,100),beam
        local label=Instance.new("TextLabel")
        label.Size,label.BackgroundTransparency=UDim2.fromScale(1,1),1
        label.Text,label.Font,label.TextSize=text,Enum.Font.GothamBold,42
        label.TextColor3=Color3.fromRGB(217,244,151)
        label.Parent=gui
    end
end
local function makeCheckpoints(fromDistance:number)
    local last=checkpointData[#checkpointData]
    local threshold=last and last.Distance+240 or 250
    for _,sample in ipairs(activeSamples) do
        if sample.Distance>math.max(threshold,fromDistance) then
            local cf=CFrame.lookAt(sample.Position,sample.Position+sample.Tangent)
            table.insert(checkpointData,{Distance=sample.Distance,CFrame=cf*CFrame.new(0,2.8,0)})
            threshold=sample.Distance+240
        end
    end
end
function StageManager.BuildStage(custom:StageConfig?):Folder
    if growing then error("Course generation already in progress") end
    local raw=custom or {}
    config={Seed=raw.Seed or 42,Mode=raw.Mode=="Infinite" and "Infinite" or "Loop",LengthStuds=4200,RoadWidth=26,SegmentLength=14,Weather=raw.Weather or "Clear"}
    generation+=1
    revision,segmentSerial=0,0
    StageManager.SetWeather(config.Weather)
    local existing=Workspace:FindFirstChild("RallyStage")
    if existing then existing:Destroy() end
    local baseplate=Workspace:FindFirstChild("Baseplate")
    if baseplate and baseplate:IsA("BasePart") then baseplate.Transparency,baseplate.CanCollide=1,false end
    activeStageFolder=Instance.new("Folder")
    activeStageFolder.Name,activeStageFolder.Parent="RallyStage",Workspace
    chunks,checkpointData,activePaceNotes={},{},{}
    controls=StageManager.GenerateControlPoints(config)
    controlIndex=#controls
    activeSamples=CatmullRom.GenerateUniformSpline(controls,config.SegmentLength)
    if config.Mode=="Loop" then
        -- Preserve the exact seam and its periodic tangent.
        activeSamples[#activeSamples].Position=activeSamples[1].Position
        activeSamples[#activeSamples].Tangent=activeSamples[1].Tangent
    end
    extrude(activeSamples)
    if config.Mode=="Loop" then
        -- Fill the whole valley, including the inside of the loop. The course
        -- is a forest landscape rather than a strip suspended over the void.
        local minX,maxX,minZ,maxZ=math.huge,-math.huge,math.huge,-math.huge
        for _,sample in ipairs(activeSamples) do
            minX,maxX=math.min(minX,sample.Position.X),math.max(maxX,sample.Position.X)
            minZ,maxZ=math.min(minZ,sample.Position.Z),math.max(maxZ,sample.Position.Z)
        end
        local valley=Instance.new("Folder")
        valley.Name,valley.Parent="Valley",activeStageFolder
        for x=math.floor((minX-250)/400)*400,maxX+400,400 do
            for z=math.floor((minZ-250)/400)*400,maxZ+400,400 do
                local ground=part("ValleyGround",Vector3.new(402,20,402),CFrame.new(x,-38,z),Enum.Material.Grass,Color3.fromRGB(49,70,40),valley)
                ground:SetAttribute("SurfaceType","Grass")
            end
        end
    end
    makeCheckpoints(0)
    local start=activeSamples[1]
    startCFrame=CFrame.lookAt(start.Position,start.Position+start.Tangent)*CFrame.new(0,2.8,0)
    gate("StartFinish",start,config.Mode=="Loop" and "BACKSEAT / START + FINISH" or "BACKSEAT / INFINITE")
    publish()
    return activeStageFolder :: Folder
end
function StageManager.EnsureAhead(leaderDistance:number,oldestCheckpoint:number)
    if config.Mode~="Infinite" or growing or leaderDistance<activeSamples[#activeSamples].Distance-950 then return end
    growing=true
    local ok,err=pcall(function()
        local tail={controls[#controls-2],controls[#controls-1],controls[#controls]}
        for _=1,10 do
            controlIndex+=1
            table.insert(tail,nextControl(controlIndex,tail[#tail]))
        end
        controls=tail
        local more=CatmullRom.GenerateUniformSpline(tail,config.SegmentLength)
        local offset=activeSamples[#activeSamples].Distance
        for i,sample in ipairs(more) do
            sample.Distance+=offset
            if i>1 then table.insert(activeSamples,sample) end
        end
        extrude(more)
        makeCheckpoints(offset)
        -- Retain the slowest crew's recovery point. A faster driver cannot delete it.
        local cutoff=math.max(0,oldestCheckpoint-400)
        local retained={}
        for _,chunk in ipairs(chunks) do
            if chunk:GetAttribute("EndDistance")<cutoff then chunk:Destroy() else table.insert(retained,chunk) end
        end
        chunks=retained
        while #activeSamples>3 and activeSamples[2].Distance<cutoff do table.remove(activeSamples,1) end
        publish()
    end)
    growing=false
    if not ok then warn("[Rally] Extension failed: "..tostring(err)) end
end
function StageManager.GetStartCFrame():CFrame return startCFrame end
function StageManager.GetSamples():any return activeSamples end
function StageManager.GetPaceNotes():any return activePaceNotes end
function StageManager.GetCheckpoints():any return checkpointData end
function StageManager.GetMode():string return config.Mode end
function StageManager.GetSeed():number return config.Seed end
function StageManager.GetTotalDistance():number return activeSamples[#activeSamples].Distance end
function StageManager.Project(position:Vector3,previous:number?):(number,number)
    -- Restrict projection near the current section to prevent jumping across the loop seam.
    local window={}
    if previous then
        for _,sample in ipairs(activeSamples) do
            if sample.Distance>=previous-170 and sample.Distance<=previous+230 then table.insert(window,sample) end
        end
    end
    return StageProgress.Project(#window>=2 and window or activeSamples,position,previous)
end
return StageManager
