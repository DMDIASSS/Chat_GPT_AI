--!strict
-- MainClient.luau
-- Client coordinator for vehicle physics, camera controller, co-driver engine, and PB ghost system.

local ReplicatedStorage = game:GetService("ReplicatedStorage")

print("[RallyClient] Initializing client subsystems...")

local rallyClientFolder = ReplicatedStorage:WaitForChild("RallyClient")
local VehicleController = require(rallyClientFolder:WaitForChild("VehicleController"))
local CameraController = require(rallyClientFolder:WaitForChild("CameraController"))
local CoDriverClient = require(rallyClientFolder:WaitForChild("CoDriverClient"))
local GhostClient = require(rallyClientFolder:WaitForChild("GhostClient"))

-- Connect stage remotes
local StageRemotes = require(ReplicatedStorage.RallyShared.Remotes.StageRemotes)
local splitEvent = StageRemotes.GetEvent("SplitCrossed")
local finishEvent = StageRemotes.GetEvent("StageFinished")

splitEvent.OnClientEvent:Connect(function(splitIndex, distance, timestamp)
    print(string.format("[RallyClient] Checkpoint %d cleared! Dist: %.1fm", splitIndex, distance * 0.28))
end)

finishEvent.OnClientEvent:Connect(function(timestamp)
    print("[RallyClient] Stage finished! Stop control reached.")
end)

print("[RallyClient] Dirt Rally 2.0 Client initialized successfully.")

-- Race presentation is driven by server state, including the full-black crash reset.
local Players=game:GetService("Players")
local UserInputService=game:GetService("UserInputService")
local RunService=game:GetService("RunService")
local TweenService=game:GetService("TweenService")
local Workspace=game:GetService("Workspace")
local player=Players.LocalPlayer
local playerGui=player:WaitForChild("PlayerGui")
local action=StageRemotes.GetEvent("RaceAction")
local ui=Instance.new("ScreenGui")
ui.Name,ui.ResetOnSpawn,ui.IgnoreGuiInset,ui.DisplayOrder="RacePresentation",false,true,60
ui.Parent=playerGui
local accent=Color3.fromRGB(208,239,137)
local ink=Color3.fromRGB(15,23,26)
local function label(parent:Instance,value:string,size:UDim2,position:UDim2,fontSize:number):TextLabel
    local t=Instance.new("TextLabel")
    t.Text,t.Font,t.TextSize,t.TextColor3=value,Enum.Font.GothamBold,fontSize,Color3.fromRGB(231,240,233)
    t.Size,t.Position,t.BackgroundTransparency=size,position,1
    t.Parent=parent
    return t
end
local function button(parent:Instance,value:string,size:UDim2,position:UDim2,callback:()->()):TextButton
    local b=Instance.new("TextButton")
    b.Text,b.Font,b.TextSize,b.BackgroundColor3,b.TextColor3=value,Enum.Font.GothamBold,12,accent,ink
    b.Size,b.Position,b.BorderSizePixel,b.Parent=size,position,0,parent
    local corner=Instance.new("UICorner")
    corner.CornerRadius,corner.Parent=UDim.new(0,6),b
    b.Activated:Connect(callback)
    return b
end
local function toggle(name:string)
    local g=playerGui:FindFirstChild(name)
    if g and g:IsA("ScreenGui") then g.Enabled=not g.Enabled end
end
local notice=label(ui,"",UDim2.new(1,-40,0,30),UDim2.new(0,20,0,160),14)
notice.TextColor3=accent
local noticeToken=0
local function showNotice(message:string)
    noticeToken+=1
    local token=noticeToken
    notice.Text=message
    task.delay(4,function() if token==noticeToken then notice.Text="" end end)
end
local footer=Instance.new("Frame")
footer.Size,footer.Position,footer.AnchorPoint=UDim2.fromOffset(665,60),UDim2.new(0.5,0,1,-12),Vector2.new(0.5,1)
footer.BackgroundTransparency,footer.Parent=1,ui
local footerScale=Instance.new("UIScale")
footerScale.Parent=footer
local crewStatus=label(footer,"BACKSEAT RALLY / SERVICE",UDim2.fromOffset(665,20),UDim2.fromOffset(0,0),11)
local startButton=button(footer,"START [ENTER]",UDim2.fromOffset(154,30),UDim2.fromOffset(0,27),function() action:FireServer("Start") end)
local resetButton=button(footer,"RECOVER [Y]",UDim2.fromOffset(154,30),UDim2.fromOffset(0,27),function() action:FireServer("Reset") end)
button(footer,"GARAGE [V]",UDim2.fromOffset(154,30),UDim2.fromOffset(170,27),function() toggle("VehicleSelectorGui") end)
button(footer,"ROADBOOK [M]",UDim2.fromOffset(154,30),UDim2.fromOffset(340,27),function() toggle("CompanionTabletGui") end)
button(footer,"CAMERA [C]",UDim2.fromOffset(154,30),UDim2.fromOffset(510,27),function() CameraController.CycleMode() end)
local countdown=label(ui,"",UDim2.fromOffset(400,180),UDim2.new(0.5,-200,0.5,-90),104)
countdown.Font,countdown.TextColor3=Enum.Font.GothamBlack,accent
countdown.Visible=false
local blackout=Instance.new("Frame")
blackout.Name="CrashBlackout"
blackout.Size,blackout.BackgroundColor3,blackout.BackgroundTransparency=UDim2.fromScale(1,1),Color3.new(0,0,0),1
blackout.Visible,blackout.ZIndex,blackout.Parent=false,50,ui
local crashText=label(blackout,"",UDim2.new(1,-40,0,65),UDim2.new(0,20,0.45,0),32)
crashText.ZIndex=51
local crashHint=label(blackout,"",UDim2.new(1,-40,0,55),UDim2.new(0,20,0.55,0),14)
crashHint.ZIndex=51
local shade=Instance.new("Frame")
shade.Size,shade.BackgroundColor3,shade.BackgroundTransparency=UDim2.fromScale(1,1),Color3.new(0,0,0),0.4
shade.Visible,shade.Parent=false,ui
local results=Instance.new("Frame")
results.Size,results.Position,results.AnchorPoint=UDim2.fromOffset(530,338),UDim2.fromScale(0.5,0.5),Vector2.new(0.5,0.5)
results.BackgroundColor3,results.BorderSizePixel,results.Parent=ink,0,shade
local resultScale=Instance.new("UIScale")
resultScale.Parent=results
local corner=Instance.new("UICorner")
corner.CornerRadius,corner.Parent=UDim.new(0,12),results
label(results,"ONE LAP / COMPLETE",UDim2.fromOffset(470,35),UDim2.fromOffset(30,22),14).TextColor3=accent
local resultTime=label(results,"00:00.000",UDim2.fromOffset(470,75),UDim2.fromOffset(30,67),48)
resultTime.Font=Enum.Font.GothamBlack
local resultDetail=label(results,"",UDim2.fromOffset(470,55),UDim2.fromOffset(30,150),14)
local bestLabel=label(results,"",UDim2.fromOffset(470,30),UDim2.fromOffset(30,206),14)
bestLabel.TextColor3=accent
button(results,"RACE AGAIN [ENTER]",UDim2.fromOffset(223,43),UDim2.fromOffset(30,259),function() action:FireServer("Start") end)
button(results,"BACK TO SERVICE",UDim2.fromOffset(223,43),UDim2.fromOffset(277,259),function()
    action:FireServer("Service")
    local garage=playerGui:FindFirstChild("VehicleSelectorGui")
    if garage then garage.Enabled=true end
end)
local hasResults=false
local transition=0
local currentTween:any=nil
local function fadeBack()
    transition+=1
    if currentTween then currentTween:Cancel() end
    crashText.Text,crashHint.Text="",""
    currentTween=TweenService:Create(blackout,TweenInfo.new(0.45),{BackgroundTransparency=1})
    currentTween:Play()
    local token=transition
    task.delay(0.5,function() if token==transition then blackout.Visible=false end end)
end
StageRemotes.GetEvent("RaceState").OnClientEvent:Connect(function(kind:string,payload:any)
    if kind=="Countdown" then
        hasResults=false
        transition+=1
        local token=transition
        shade.Visible=false
        blackout.Visible=false
        countdown.Visible=true
        for _,name in ipairs({"VehicleSelectorGui","ReplayGui"}) do local g=playerGui:FindFirstChild(name);if g then g.Enabled=false end end
        task.spawn(function()
            for i=payload.Seconds or 3,1,-1 do
                if token~=transition then return end
                countdown.Text=tostring(i)
                task.wait(1)
            end
        end)
    elseif kind=="Go" then
        transition+=1
        countdown.Text,countdown.Visible="GO",true
        local token=transition
        task.delay(0.75,function() if token==transition then countdown.Visible=false end end)
    elseif kind=="Crash" then
        transition+=1
        local token=transition
        countdown.Visible=false
        shade.Visible=false
        blackout.Visible=true
        if currentTween then currentTween:Cancel() end
        currentTween=TweenService:Create(blackout,TweenInfo.new(0.12),{BackgroundTransparency=0})
        currentTween:Play()
        crashText.Text=payload.Reason or "CRASH"
        crashHint.Text=string.format("Returning to checkpoint / +%d s",payload.Penalty or 8)
        task.delay(9,function()
            if token~=transition then return end
            fadeBack()
            showNotice("Recovery is taking longer than expected. Open the garage and return to service.")
        end)
    elseif kind=="Recovered" then
        fadeBack()
        showNotice(string.format("Back at checkpoint / total penalties +%d s",payload.Penalty or 0))
    elseif kind=="Ready" then
        hasResults=false
        fadeBack()
        countdown.Visible=false
        shade.Visible=false
    elseif kind=="Passenger" then
        fadeBack()
        showNotice("Co-driving with "..payload.Driver..". Use M for the map and F to call turns.")
    elseif kind=="Checkpoint" then showNotice(string.format("CHECKPOINT / %.2f km",(payload.Distance or 0)*0.00028))
    elseif kind=="Notice" then showNotice(payload.Message or "")
    elseif kind=="Finished" then
        hasResults=true
        countdown.Visible=false
        shade.Visible=true
        local elapsed=payload.Elapsed or 0
        resultTime.Text=string.format("%02d:%06.3f",math.floor(elapsed/60),elapsed%60)
        resultDetail.Text=string.format("Penalties +%d s  /  %d recoveries\nTime includes all penalties. R opens your recorded replay.",payload.Penalty or 0,payload.Resets or 0)
        bestLabel.Text=payload.PersonalBest and "PERSONAL BEST / THIS COURSE + SETUP" or (payload.Previous and string.format("BEST  %02d:%06.3f",math.floor(payload.Previous/60),payload.Previous%60) or "FINISH RECORDED")
    end
end)
UserInputService.InputBegan:Connect(function(input,processed)
    if processed or UserInputService:GetFocusedTextBox() then return end
    if input.KeyCode==Enum.KeyCode.Return then
        local garage=playerGui:FindFirstChild("VehicleSelectorGui")
        if not garage or not garage.Enabled then action:FireServer("Start") end
    elseif input.KeyCode==Enum.KeyCode.Y then action:FireServer("Reset") end
end)
RunService.RenderStepped:Connect(function()
    local camera=Workspace.CurrentCamera
    local size=camera and camera.ViewportSize or Vector2.new(1280,720)
    footerScale.Scale=math.min(1,(size.X-30)/665)
    resultScale.Scale=math.min(1,(size.X-30)/530,(size.Y-40)/338)
    local car=VehicleController.GetActiveVehicle()
    local state=car and car:GetAttribute("RunState") or "Ready"
    local passenger=car and car:GetAttribute("CoDriverUserId")==player.UserId
    startButton.Visible=not passenger and (state=="Ready" or state=="Finished")
    resetButton.Visible=not passenger and state=="Running"
    local role=passenger and "CO-DRIVER / F CALLS NEXT TURN" or (car and car:GetAttribute("CoDriverMode")=="Human" and "HUMAN CO-DRIVER" or "BOT CO-DRIVER")
    crewStatus.Text=string.format("%s / %s / %s / +%d s",Workspace:GetAttribute("RaceMode") or "Loop",state,role,car and car:GetAttribute("PenaltySeconds") or 0):upper()
    local replay=playerGui:FindFirstChild("ReplayGui")
    local garage=playerGui:FindFirstChild("VehicleSelectorGui")
    shade.Visible=hasResults and not (replay and replay.Enabled) and not (garage and garage.Enabled)
end)
