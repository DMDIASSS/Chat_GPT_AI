# Backseat Rally / Polished

The main project is the place from `Backseat_Rally_Redone_Fixed.zip`.

- Rebuilt wheel component orientation around the local X axle, preserving the original tyre and rim meshes. Both sides face outward; tyres match the suspension radius on all five cars.
- Space and controller A use a high-priority handbrake action. Both occupants' jump states are disabled while seated. The passenger observes the shared vehicle without applying driving forces.
- Added server race states: service, countdown, running, crash, recovery and finished. A hard crash triggers a full black screen, repairs the vehicle, reseats both crew members and resumes at the last checkpoint. Rollovers and off-course escapes also recover. Penalties remain in the final time.
- Added frequent recovery checkpoints, ordered finish validation, measured split times, server-clock timing and results with a best time per seed, car and performance setup. The previous random split deltas are removed.
- Loop is an actual seeded closed circuit with one lap and a finish. Infinite extends connected spline sections ahead; joins share exact endpoints. Scenery and checkpoints follow the extended road, and old chunks are retained until the slowest crew can safely recover past them.
- Expanded the forest floor and added a solid valley beneath the loop. Supplied scenery remains in use, with collidable trunk and rock hulls, soft foliage, readable shoulders, markers, chevrons and visible outer rock banks.
- Added a service park with a 3D car preview, all five cars, stock through Stage 3 engine/brake/shift upgrades, surface-specific tyre choices, suspension and gearing options, paint and rim colours.
- Added a real passenger seat and crew selection. Pace-note requests are checked against the passenger's current seat and the authoritative route book, then sent only to that crew. An empty passenger seat automatically restores bot calls. The map reads shared route samples even when road geometry is outside streaming range.
- Added course/seed/weather controls, responsive garage, roadbook, countdown, results and crash interfaces. M shows the passenger's live route and F calls the next turn. Audio settings now persist through the vehicle sound update loop.
- Restored live chase-camera selection and the passenger's own cockpit viewpoint. Replay uses a separate local clone, and both the HUD button and R follow the same lifecycle. Replay score comparisons include penalties while playback duration follows the recorded motion.
- Published servers persist garage setup and best times when DataStore access succeeds. Studio and unavailable DataStore sessions remain playable with session state.
- Existing saved objects, models, asset references and non-Source properties are preserved. Runtime UI controllers move from StarterGui's folder to PlayerScripts to avoid duplication on character respawn.

`VALIDATION.json` distinguishes compiled and simulated checks from the remaining Roblox Studio playtest.
