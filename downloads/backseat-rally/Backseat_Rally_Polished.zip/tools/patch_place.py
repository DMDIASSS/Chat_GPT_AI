"""Rebuild script Sources in an existing place without rewriting its assets."""
import argparse,json,sys
from pathlib import Path
from rbx import Place
p=argparse.ArgumentParser()
p.add_argument('place',type=Path)
p.add_argument('output',type=Path)
p.add_argument('--source',type=Path,default=Path(__file__).resolve().parents[1]/'source')
a=p.parse_args()
if a.place.resolve()==a.output.resolve():
    p.error('Choose a different output path to retain your input place.')
sources={'.'.join(path.relative_to(a.source).with_suffix('').parts):path.read_text(encoding='utf8') for path in a.source.rglob('*.lua')}
place=Place(a.place)
missing=sorted(set(sources)-set(place.paths.values()))
if missing:raise SystemExit('Source paths absent from the place: '+', '.join(missing))
changed=place.patch_sources(sources,a.output)
print(json.dumps({'output':str(a.output),'changed_sources':len(changed)},indent=2))
