"""Lossless Roblox binary source patcher. Unchanged chunks are copied byte for byte."""
import struct, hashlib
from pathlib import Path
import lz4.block, zstandard

def u32(b,p=0): return struct.unpack_from('<I', b, p)[0]
def string(b,p=0):
    n=u32(b,p); return b[p+4:p+4+n],p+4+n
def putstr(s):
    b=s.encode() if isinstance(s,str) else s
    return struct.pack('<I',len(b))+b
def ints(b,n):
    values=[int.from_bytes(bytes(b[j*n+i] for j in range(4)),'big') for i in range(n)]
    return [(v>>1)^-(v&1) for v in values]
def refs(b,n):
    acc=0;out=[]
    for v in ints(b,n): acc+=v;out.append(acc)
    return out
def floats(b,n):
    out=[]
    for i in range(n):
        v=int.from_bytes(bytes(b[j*n+i] for j in range(4)),'big')
        v=(v>>1)|((v&1)<<31)
        out.append(struct.unpack('<f',struct.pack('<I',v))[0])
    return out

class Place:
    def __init__(self,path):
        self.path=Path(path);self.original=self.path.read_bytes();self.header=self.original[:32]
        self.chunks=[];self.classes={};self.objects={};self.properties={};self.parents={}
        p=32
        while p<len(self.original):
            name,cl,ul,res=struct.unpack_from('<4sIII',self.original,p)
            raw=self.original[p:p+16+(cl or ul)];b=raw[16:]
            if cl:
                b=zstandard.ZstdDecompressor().decompress(b,max_output_size=ul) if b[:4]==b'\x28\xb5\x2f\xfd' else lz4.block.decompress(b,uncompressed_size=ul)
            assert len(b)==ul
            self.chunks.append([name,b,raw]);p+=len(raw)
            if name==b'INST':
                cid=u32(b);cn,q=string(b,4);service=b[q];n=u32(b,q+1);rs=refs(b[q+5:q+5+n*4],n)
                self.classes[cid]=(cn.decode(),rs)
                for r in rs:self.objects[r]={'ClassName':cn.decode(),'Name':cn.decode()}
            elif name==b'PROP':
                cid=u32(b);pn,q=string(b,4);typ=b[q];data=b[q+1:];pn=pn.decode();rs=self.classes[cid][1];n=len(rs)
                self.properties[(cid,pn)]=(typ,data,len(self.chunks)-1,q+1)
                vals=None
                if typ==1:
                    vals=[];o=0
                    for _ in rs:v,o=string(data,o);vals.append(v.decode('utf8',errors='replace'))
                elif typ==2: vals=[bool(x) for x in data]
                elif typ==3: vals=ints(data,n)
                elif typ==4: vals=floats(data,n)
                elif typ==0x13: vals=refs(data,n)
                elif typ==0x0e: vals=list(zip(*(floats(data[j*n*4:(j+1)*n*4],n) for j in range(3))))
                elif typ==0x10:
                    rots=[];o=0
                    for _ in rs:
                        rot=data[o];o+=1
                        if rot==0:rots.append(struct.unpack_from('<9f',data,o));o+=36
                        else:rots.append(rot)
                    pos=list(zip(*(floats(data[o+j*n*4:o+(j+1)*n*4],n) for j in range(3))))
                    vals=[(pos[i],rots[i]) for i in range(n)]
                if vals is not None:
                    for r,v in zip(rs,vals):self.objects[r][pn]=v
            elif name==b'PRNT':
                n=u32(b,1);children=refs(b[5:5+n*4],n);parents=refs(b[5+n*4:],n)
                self.parents.update(zip(children,parents))
            if name==b'END\x00':break
        self.paths={r:self.pathof(r) for r in self.objects}
    def pathof(self,r,depth=0):
        if r<0:return ''
        if depth>100:raise ValueError('cycle')
        parent=self.pathof(self.parents.get(r,-1),depth+1)
        return (parent+'.' if parent else '')+self.objects[r]['Name']
    def patch_sources(self,sources,target):
        changed=[];changes={}
        for (cid,pn),(typ,data,idx,offset) in self.properties.items():
            if pn!='Source':continue
            assert typ==1
            parts=[]
            for r in self.classes[cid][1]:
                before=self.objects[r].get('Source','');after=sources.get(self.paths[r],before)
                parts.append(putstr(after))
                if after!=before:changed.append({'ref':r,'path':self.paths[r],'before_sha256':hashlib.sha256(before.encode()).hexdigest(),'after_sha256':hashlib.sha256(after.encode()).hexdigest()})
            if any(x['ref'] in self.classes[cid][1] for x in changed):
                changes[idx]=self.chunks[idx][1][:offset]+b''.join(parts)
        output=bytearray(self.header)
        for idx,(name,b,raw) in enumerate(self.chunks):
            if idx in changes:
                b=changes[idx];packed=lz4.block.compress(b,store_size=False)
                output+=struct.pack('<4sIII',name,len(packed),len(b),0)+packed
            else:output+=raw
        Path(target).write_bytes(output)
        return changed

if __name__=='__main__':
    import sys,json
    p=Place(sys.argv[1]);print('Objects',len(p.objects),'Classes',len(p.classes),'Chunks',len(p.chunks))
    for r,path in p.paths.items():
        if 'BackseatAssets.Wheel' in path:
            obj={k:v for k,v in p.objects[r].items() if k in ['Name','Size','CFrame','PivotOffset','WorldPivotData','MeshId','CanCollide']}
            print(r,path,json.dumps(obj))
