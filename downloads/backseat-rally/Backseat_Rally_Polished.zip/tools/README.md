# Rebuild after editing sources

The included place already contains the updated sources. These tools are optional for future edits.

Install Python 3 and run:

```sh
python -m pip install -r tools/requirements.txt
python tools/patch_place.py Backseat_Rally_Polished.rbxl Backseat_Rally_My_Edit.rbxl
```

The patcher matches the `source/` hierarchy to saved instance paths. It copies every other chunk unchanged, preserving meshes, assets and original backup modules. It does not add new script instances; new modules would require a separate Studio installation step.
