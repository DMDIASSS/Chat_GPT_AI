# Roblox Studio playtest

The headless suite simulates Roblox services; it cannot evaluate Roblox's physics engine, mesh renderer, streaming behaviour, asset permissions or real network replication. Use this short check before publishing.

1. Open the included `.rbxl`, press Play and start a Loop run. Inspect all five cars in the garage and live chase camera. Tyres should be vertical, run in the forward direction and have outward-facing rims.
2. Hold and release Space while driving. The rear wheels should brake and the avatar must remain seated. Confirm E/Q, T, C and the settings controls.
3. Hit a tree or rock at speed. Confirm the full black screen, repaired car at the last checkpoint, +8 seconds and a clean fade back. Try Y (+5), a rollover (+8) and a fall/escape from the course (+5). Confirm inputs and the camera recover.
4. Complete a Loop lap through every checkpoint. Confirm three measured splits, a single finish, results including penalties, and Enter to retry. Open and close replay from both R and the HUD button; the live car should stay parked.
5. Return every driver to service. Change the host's mode to Infinite, then start and drive beyond the first road section. Check the seam, new scenery, continuing notes and no finish. Repeat with different seeds and weather.
6. Use Studio's Server & Clients test with two players. Join the driver's crew through V, start and confirm the passenger keeps the seat through a crash. Check M, F and CALL, and that the passenger cannot steer the car. Leave the crew and confirm bot notes resume.
7. Add a third player. Their calls must not reach another crew, and their garage must not change an active shared course. Watch both clients for wheel rendering, streaming and checkpoint recovery.
8. Reset a character and rejoin. Confirm one copy of each UI, correct seats and no duplicated physics handlers. In a published test experience, apply a setup, allow an autosave, rejoin and confirm the setup and best time persist.

Sound and speech checks should use the experience in which the supplied assets have permission. Studio uses session profile data by design.
