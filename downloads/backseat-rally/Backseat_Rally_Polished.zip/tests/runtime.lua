-- Roblox API simulation for executable logic tests; it does not simulate engine physics/rendering.
local clock=0
local testCount=0
local function check(value,message)
    testCount+=1
    assert(value,message)
end
local V={}
local vmt={}
function V.new(x,y,z) return setmetatable({X=x or 0,Y=y or 0,Z=z or 0,_kind="Vector3"},vmt) end
vmt.__index=function(v,key)
    if key=="Magnitude" then return math.sqrt(v.X*v.X+v.Y*v.Y+v.Z*v.Z) end
    if key=="Unit" then local m=v.Magnitude;return m>0 and v/m or V.new() end
    return V[key]
end
vmt.__add=function(a,b) return V.new(a.X+b.X,a.Y+b.Y,a.Z+b.Z) end
vmt.__sub=function(a,b) return V.new(a.X-b.X,a.Y-b.Y,a.Z-b.Z) end
vmt.__unm=function(a) return V.new(-a.X,-a.Y,-a.Z) end
vmt.__mul=function(a,b) if type(a)=="number" then a,b=b,a end;return V.new(a.X*b,a.Y*b,a.Z*b) end
vmt.__div=function(a,b) return V.new(a.X/b,a.Y/b,a.Z/b) end
vmt.__eq=function(a,b) return a.X==b.X and a.Y==b.Y and a.Z==b.Z end
function V:Dot(b) return self.X*b.X+self.Y*b.Y+self.Z*b.Z end
function V:Cross(b) return V.new(self.Y*b.Z-self.Z*b.Y,self.Z*b.X-self.X*b.Z,self.X*b.Y-self.Y*b.X) end
function V:Lerp(b,t) return self+(b-self)*t end
V.zero=V.new();V.xAxis=V.new(1,0,0);V.yAxis=V.new(0,1,0);V.zAxis=V.new(0,0,1)
local CF={}
local cmt={}
function CF.fromMatrix(pos,r,u,b) return setmetatable({_kind="CFrame",p=pos,r=r,u=u,b=b or r:Cross(u)},cmt) end
function CF.new(x,y,z)
    local p=type(x)=="table" and x or V.new(x,y,z)
    return CF.fromMatrix(p,V.xAxis,V.yAxis,V.zAxis)
end
CF.identity=CF.new()
cmt.__index=function(c,k)
    if k=="Position" or k=="p" then return rawget(c,"p") end
    if k=="RightVector" then return c.r end
    if k=="UpVector" then return c.u end
    if k=="LookVector" then return -c.b end
    if k=="Rotation" then return CF.fromMatrix(V.zero,c.r,c.u,c.b) end
    return CF[k]
end
function CF:VectorToWorldSpace(v) return self.r*v.X+self.u*v.Y+self.b*v.Z end
function CF:PointToWorldSpace(v) return self.p+self:VectorToWorldSpace(v) end
function CF:VectorToObjectSpace(v) return V.new(self.r:Dot(v),self.u:Dot(v),self.b:Dot(v)) end
function CF:PointToObjectSpace(v) return self:VectorToObjectSpace(v-self.p) end
cmt.__mul=function(a,b)
    if b._kind=="Vector3" then return a:PointToWorldSpace(b) end
    return CF.fromMatrix(a*b.p,a:VectorToWorldSpace(b.r),a:VectorToWorldSpace(b.u),a:VectorToWorldSpace(b.b))
end
function CF:Inverse()
    local r=V.new(self.r.X,self.u.X,self.b.X)
    local u=V.new(self.r.Y,self.u.Y,self.b.Y)
    local b=V.new(self.r.Z,self.u.Z,self.b.Z)
    local rotation=CF.fromMatrix(V.zero,r,u,b)
    return CF.fromMatrix(rotation:VectorToWorldSpace(-self.p),r,u,b)
end
function CF:ToObjectSpace(b) return self:Inverse()*b end
function CF.lookAt(a,b,up)
    local f=(b-a).Unit
    local r=f:Cross(up or V.yAxis).Unit
    return CF.fromMatrix(a,r,r:Cross(f),-f)
end
function CF.Angles(x,y,z)
    local sx,cx,sy,cy,sz,cz=math.sin(x),math.cos(x),math.sin(y),math.cos(y),math.sin(z),math.cos(z)
    local rx=CF.fromMatrix(V.zero,V.xAxis,V.new(0,cx,sx),V.new(0,-sx,cx))
    local ry=CF.fromMatrix(V.zero,V.new(cy,0,-sy),V.yAxis,V.new(sy,0,cy))
    local rz=CF.fromMatrix(V.zero,V.new(cz,sz,0),V.new(-sz,cz,0),V.zAxis)
    return rx*ry*rz
end
function CF:Lerp(b,t) return CF.fromMatrix(self.p:Lerp(b.p,t),self.r:Lerp(b.r,t),self.u:Lerp(b.u,t),self.b:Lerp(b.b,t)) end
local function color(r,g,b) return {R=r or 0,G=g or 0,B=b or 0} end
local Color3={new=color,fromRGB=function(r,g,b) return color(r/255,g/255,b/255) end}
local ColorSequence={new=function(...) return {...} end}
local function signal()
    local s={callbacks={}}
    function s:Connect(f)
        local connection={Connected=true}
        function connection:Disconnect() self.Connected=false end
        table.insert(self.callbacks,{f,connection})
        return connection
    end
    function s:Fire(...) for _,pair in ipairs(table.clone(self.callbacks)) do if pair[2].Connected then pair[1](...) end end end
    function s:Wait() error("Unexpected signal wait") end
    return s
end
local Enum=setmetatable({}, {__index=function(t,k)
    local sub=setmetatable({}, {__index=function(s,key)
        local value={Name=key,Value=key=="High" and 3000 or 1,EnumType=k}
        rawset(s,key,value)
        return value
    end})
    rawset(t,k,sub);return sub
end})
local function dim(s,o) return {Scale=s or 0,Offset=o or 0} end
local UDim={new=dim}
local UDim2={new=function(xs,xo,ys,yo) return {X=dim(xs,xo),Y=dim(ys,yo)} end}
function UDim2.fromOffset(x,y) return UDim2.new(0,x,0,y) end
function UDim2.fromScale(x,y) return UDim2.new(x,0,y,0) end
local v2mt={}
v2mt.__sub=function(a,b) return setmetatable({X=a.X-b.X,Y=a.Y-b.Y},v2mt) end
v2mt.__index=function(a,k) if k=="Magnitude" then return math.sqrt(a.X*a.X+a.Y*a.Y) end end
local Vector2={new=function(x,y) return setmetatable({X=x,Y=y},v2mt) end}
local methods={}
local imt={}
local Instance={}
local services={}
local function ispart(class) return class=="Part" or class=="MeshPart" or class=="Seat" or class=="VehicleSeat" or class=="WedgePart" end
function methods:IsA(class)
    return self.ClassName==class or class=="Instance" or class=="BasePart" and ispart(self.ClassName)
        or class=="LuaSourceContainer" and (self.ClassName=="ModuleScript" or self.ClassName=="LocalScript" or self.ClassName=="Script")
        or class=="JointInstance" and (self.ClassName=="Weld" or self.ClassName=="Motor6D")
end
function methods:GetChildren() return table.clone(self._children) end
function methods:GetDescendants()
    local result={}
    local function scan(o) for _,c in ipairs(o:GetChildren()) do table.insert(result,c);scan(c) end end
    scan(self);return result
end
function methods:FindFirstChild(name,recursive)
    for _,c in ipairs(self._children) do if c.Name==name then return c end end
    if recursive then for _,c in ipairs(self._children) do local found=c:FindFirstChild(name,true);if found then return found end end end
    return nil
end
function methods:WaitForChild(name) return assert(self:FindFirstChild(name),"Missing instance "..self.Name.."."..name) end
function methods:FindFirstChildOfClass(class) for _,c in ipairs(self._children) do if c.ClassName==class then return c end end end
function methods:FindFirstAncestorOfClass(class)
    local p=self.Parent
    while p do if p.ClassName==class then return p end;p=p.Parent end
end
methods.FindFirstAncestorWhichIsA=methods.FindFirstAncestorOfClass
function methods:IsDescendantOf(other) local p=self.Parent;while p do if p==other then return true end;p=p.Parent end;return false end
function methods:GetPropertyChangedSignal(name)
    if not self._signals[name] then self._signals[name]=signal() end
    return self._signals[name]
end
function methods:SetAttribute(name,value) self._attributes[name]=value end
function methods:GetAttribute(name) return self._attributes[name] end
function methods:GetAttributes() return table.clone(self._attributes) end
function methods:Destroy()
    for _,c in ipairs(self:GetChildren()) do c:Destroy() end
    self.Parent=nil;self._destroyed=true
end
function methods:ClearAllChildren() for _,c in ipairs(self:GetChildren()) do c:Destroy() end end
function methods:GetPivot() return self.PrimaryPart and self.PrimaryPart.CFrame or self._pivot or CF.identity end
function methods:PivotTo(cf)
    local old=self:GetPivot()
    local change=cf*old:Inverse()
    for _,c in ipairs(self:GetDescendants()) do if c:IsA("BasePart") then c.CFrame=change*c.CFrame end end
    if self.PrimaryPart then self.PrimaryPart.CFrame=cf end
    self._pivot=cf
end
function methods:ScaleTo(scale)
    local pivot=self:GetPivot()
    local ratio=scale/(self._scale or 1)
    for _,p in ipairs(self:GetDescendants()) do if p:IsA("BasePart") then
        local relative=pivot:ToObjectSpace(p.CFrame)
        p.CFrame=pivot*CF.new(relative.Position*ratio)*relative.Rotation
        p.Size=p.Size*ratio
    end end
    self._scale=scale
end
function methods:GetBoundingBox()
    local min,max=V.new(math.huge,math.huge,math.huge),V.new(-math.huge,-math.huge,-math.huge)
    for _,p in ipairs(self:GetDescendants()) do if p:IsA("BasePart") then
        local r,u,b=p.CFrame.RightVector,p.CFrame.UpVector,p.CFrame.LookVector
        local h=p.Size/2
        local extent=V.new(math.abs(r.X)*h.X+math.abs(u.X)*h.Y+math.abs(b.X)*h.Z,math.abs(r.Y)*h.X+math.abs(u.Y)*h.Y+math.abs(b.Y)*h.Z,math.abs(r.Z)*h.X+math.abs(u.Z)*h.Y+math.abs(b.Z)*h.Z)
        local a,z=p.Position-extent,p.Position+extent
        min=V.new(math.min(min.X,a.X),math.min(min.Y,a.Y),math.min(min.Z,a.Z))
        max=V.new(math.max(max.X,z.X),math.max(max.Y,z.Y),math.max(max.Z,z.Z))
    end end
    if min.X==math.huge then return CF.identity,V.new(1,1,1) end
    return CF.new((min+max)/2),max-min
end
function methods:Clone()
    local map={}
    local function copy(o)
        local clone=Instance.new(o.ClassName)
        map[o]=clone
        for key,value in pairs(o._p) do if key~="Parent" then clone._p[key]=value end end
        clone._attributes=table.clone(o._attributes)
        for _,c in ipairs(o:GetChildren()) do local child=copy(c);child.Parent=clone end
        return clone
    end
    local clone=copy(self)
    for _,o in pairs(map) do for key,value in pairs(o._p) do if type(value)=="table" and map[value] then o._p[key]=map[value] end end end
    return clone
end
function methods:SetNetworkOwner(player) self._owner=player end
function methods:Sit(human)
    local old=human.SeatPart
    if old then old.Occupant=nil end
    human.SeatPart=self
    self.Occupant=human
    human.Sit=true
end
function methods:SetStateEnabled(state,enabled) self._states=self._states or {};self._states[state.Name]=enabled end
function methods:GetStateEnabled(state) return not self._states or self._states[state.Name]~=false end
function methods:Play() self.IsPlaying=true end
function methods:Stop() self.IsPlaying=false end
function methods:Emit() end
function methods:FireClient(player,...)
    table.insert(self._messages,{Player=player,Args={...}})
    if player==services.Players.LocalPlayer then self.OnClientEvent:Fire(...) end
end
function methods:FireAllClients(...) for _,p in ipairs(services.Players:GetPlayers()) do self:FireClient(p,...) end end
function methods:FireServer(...) self.OnServerEvent:Fire(services.Players.LocalPlayer,...) end
function methods:InvokeServer(...) return self.OnServerInvoke(services.Players.LocalPlayer,...) end
function methods:RequestStreamAroundAsync() end
function methods:LoadAsync() return Enum.AssetFetchStatus.Success end
function methods:GetFullName() return self.Parent and self.Parent:GetFullName().."."..self.Name or self.Name end
imt.__index=function(o,k)
    if methods[k] then return methods[k] end
    if k=="Position" and o._p.CFrame then return o._p.CFrame.Position end
    if k=="AssemblyMass" then return 1200 end
    local value=o._p[k]
    if value~=nil then return value end
    return methods.FindFirstChild(o,k)
end
imt.__newindex=function(o,k,v)
    if k:sub(1,1)=="_" then rawset(o,k,v);return end
    local old=o._p[k]
    if k=="Parent" then
        if old then local i=table.find(old._children,o);if i then table.remove(old._children,i) end end
        o._p[k]=v
        if v then table.insert(v._children,o);v.ChildAdded:Fire(o) end
    elseif k=="Position" and o._p.CFrame then o._p.CFrame=CF.new(v)*o._p.CFrame.Rotation
    else o._p[k]=v end
    if old~=v and o._signals[k] then o._signals[k]:Fire() end
end
function Instance.new(class)
    local o=setmetatable({_p={ClassName=class,Name=class},_children={},_attributes={},_signals={},_messages={}},imt)
    for _,name in ipairs({"ChildAdded","ChildRemoved","Touched","Changed","Activated","MouseButton1Click","MouseButton1Down","InputBegan","InputEnded","OnClientEvent","OnServerEvent","Ended","CharacterAdded","AncestryChanged"}) do o._p[name]=signal() end
    if ispart(class) then
        o._p.CFrame=CF.identity;o._p.Size=V.new(4,1,2);o._p.CanCollide=true;o._p.CanQuery=true;o._p.CanTouch=true
        o._p.AssemblyLinearVelocity=V.zero;o._p.AssemblyAngularVelocity=V.zero;o._p.Transparency=0;o._p.LocalTransparencyModifier=0
    elseif class=="Humanoid" then o._p.Health=100;o._p.AutoJumpEnabled=true
    elseif class=="Camera" then o._p.CFrame=CF.identity;o._p.ViewportSize=Vector2.new(1280,800)
    elseif class=="Sound" then o._p.IsPlaying=false
    end
    o._p.AbsolutePosition=Vector2.new(0,0);o._p.AbsoluteSize=Vector2.new(400,40)
    return o
end
local queue={}
local task={}
local function enqueue(thread,at) table.insert(queue,{Thread=thread,Time=at}) end
local function resume(thread,...)
    local ok,delay=coroutine.resume(thread,...)
    assert(ok,delay)
    if coroutine.status(thread)~="dead" then enqueue(thread,clock+(delay or 0)) end
end
function task.spawn(f,...) local args={...};local t=coroutine.create(function() f(unpack(args)) end);resume(t);return t end
function task.defer(f,...) local args={...};enqueue(coroutine.create(function() f(unpack(args)) end),clock) end
function task.delay(seconds,f,...) local args={...};enqueue(coroutine.create(function() f(unpack(args)) end),clock+seconds) end
function task.wait(seconds) return coroutine.yield(seconds or 0.03) end
local server=true
services.RunService={Heartbeat=signal(),RenderStepped=signal(),IsServer=function() return server end,IsRunning=function() return true end,IsStudio=function() return true end}
services.UserInputService={InputBegan=signal(),InputEnded=signal(),InputChanged=signal(),WindowFocusReleased=signal(),JumpRequest=signal(),IsKeyDown=function() return false end,GetFocusedTextBox=function() return nil end}
services.ContextActionService={Actions={}}
function services.ContextActionService:BindActionAtPriority(name,f) self.Actions[name]=f end
function services.ContextActionService:SetTitle() end
function services.ContextActionService:SetPosition() end
function services.ContextActionService:GetButton() return nil end
services.TweenService={Create=function(_,o,_,props) return {Play=function() for k,v in pairs(props) do o[k]=v end end,Cancel=function() end} end}
services.DataStoreService={GetDataStore=function() return {GetAsync=function() return nil end,UpdateAsync=function(_,_,f) return f(nil) end} end}
services.PhysicsService={RegisterCollisionGroup=function() end,CollisionGroupSetCollidable=function() end}
services.CollectionService={AddTag=function() end}
services.Debris={AddItem=function(_,item,lifetime) task.delay(lifetime,function() item:Destroy() end) end}
services.Players=Instance.new("Players")
services.Players._p.PlayerAdded=signal();services.Players._p.PlayerRemoving=signal()
function services.Players:GetPlayers() return self:GetChildren() end
function services.Players:GetPlayerByUserId(id) for _,p in ipairs(self:GetPlayers()) do if p.UserId==id then return p end end end
function services.Players:GetPlayerFromCharacter(character) for _,p in ipairs(self:GetPlayers()) do if p.Character==character then return p end end end
for _,name in ipairs({"Workspace","ReplicatedStorage","ServerScriptService","StarterPlayer","StarterGui","SoundService","Lighting"}) do services[name]=Instance.new(name);services[name].Name=name end
services.Workspace._p.Gravity=196.2
services.Workspace._p.CurrentCamera=Instance.new("Camera")
function services.Workspace:GetServerTimeNow() return 1000+clock end
function services.Workspace:Raycast() return nil end
function services.Workspace:Blockcast() return nil end
local game={GetService=function(_,name) return assert(services[name],"Missing service "..name) end,BindToClose=function() end}
local function advance(seconds)
    local ending=clock+seconds
    while clock<ending-0.00001 do
        local dt=math.min(0.1,ending-clock)
        clock+=dt
        local pending=queue;queue={}
        for _,item in ipairs(pending) do if item.Time<=clock+1e-8 then resume(item.Thread) else table.insert(queue,item) end end
        services.RunService.Heartbeat:Fire(dt)
        services.RunService.RenderStepped:Fire(dt)
    end
end
local random={}
function random.new(seed)
    local state=seed or 1
    local obj={}
    function obj:NextNumber(a,b) state=(state*48271)%2147483647;local v=state/2147483647;return (a or 0)+v*((b or 1)-(a or 0)) end
    function obj:NextInteger(a,b) return math.floor(self:NextNumber(a,b+1)) end
    return obj
end
local globals={game=game,workspace=services.Workspace,Vector3=V,Vector2=Vector2,CFrame=CF,Instance=Instance,Enum=Enum,Color3=Color3,
    ColorSequence=ColorSequence,ColorSequenceKeypoint={new=function(...) return {...} end},NumberSequence=ColorSequence,NumberRange=ColorSequence,
    NumberSequenceKeypoint=ColorSequence,PhysicalProperties=ColorSequence,RaycastParams={new=function() return {} end},Random=random,
    UDim=UDim,UDim2=UDim2,task=task,TweenInfo=ColorSequence,typeof=function(x) return type(x)=="table" and (x._kind or (x.ClassName and "Instance")) or type(x) end,
    warn=function(...) print("WARN",...) end,os={clock=function() return clock end}}
setmetatable(globals,{__index=getfenv()})
local sources={} -- Embedded below by the test builder.
