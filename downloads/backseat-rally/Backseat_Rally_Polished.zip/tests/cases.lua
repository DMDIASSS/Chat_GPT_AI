local nodes={}
for path,source in pairs(sources) do
    local previous=nil
    local prefix=""
    local parts=string.split(path,".")
    for i,name in ipairs(parts) do
        prefix=prefix=="" and name or prefix.."."..name
        if not nodes[prefix] then
            local node=i==1 and services[name] or Instance.new(i==#parts and (name=="MainServer" and "Script" or path:find("Starter") and "LocalScript" or "ModuleScript") or "Folder")
            node.Name=name
            if previous then node.Parent=previous end
            node._modulePath=prefix
            nodes[prefix]=node
        end
        previous=nodes[prefix]
    end
end
local loaded={}
local function loadModule(path)
    if type(path)=="table" then path=path._modulePath end
    assert(sources[path],"Unknown module "..tostring(path))
    if loaded[path]~=nil then return loaded[path] end
    local fn,err=loadstring(sources[path],"@"..path)
    assert(fn,err)
    local env=setmetatable({script=nodes[path],require=loadModule},{__index=globals})
    setfenv(fn,env)
    local value=fn()
    loaded[path]=value or true
    return value
end
local profiles=loadModule("ReplicatedStorage.RallyShared.Config.CarProfiles")
local tuning=profiles.Get("KazeRS",{Stage=3,Gearing="Short"})
check(tuning.Engine.PowerMultiplier==1.55,"Stage 3 power")
check(profiles.Cars.KazeRS.Engine.PowerMultiplier==nil,"Stock data is immutable")
check(tuning.Transmission.FinalDrive>profiles.Cars.KazeRS.Transmission.FinalDrive,"Short gearing changes final drive")
local invalid=profiles.NormalizeSetup({Stage=0/0,Paint=999,Tyres="Exploit",Suspension={},Rim=-9,Gearing="Long"})
check(invalid.Stage==0 and invalid.Paint==5 and invalid.Tyres=="Rally" and invalid.Rim==0,"Untrusted setup values sanitized")
local assets=Instance.new("Folder")
assets.Name,assets.Parent="BackseatAssets",services.ReplicatedStorage
local wheel=Instance.new("Model")
wheel.Name,wheel.Parent="Wheel",assets
local wheelRoot=Instance.new("Part")
wheelRoot.Name,wheelRoot.CFrame,wheelRoot.Parent="Root",CF.identity,wheel
wheel.PrimaryPart=wheelRoot
for _,spec in ipairs({{"Tyre",V.new(0.9,2.296,2.296),-0.002},{"Rim",V.new(0.1386,1.588,1.5793),-0.3707},{"Nuts",V.new(0.057,0.4594,0.4594),-0.4435},{"Barrel",V.new(0.794,1.4,1.4),-0.017}}) do
    local p=Instance.new("MeshPart")
    p.Name,p.Size,p.CFrame,p.Parent=spec[1],spec[2],CF.new(spec[3],0,0)*CF.Angles(0,0,math.pi/2),wheel
end
local manager=loadModule("ServerScriptService.RallyServer.VehicleManager")
for _,id in ipairs(profiles.GetAllIds()) do
    local setup={Stage=2,Paint=2,Rim=3}
    local tune=profiles.Get(id,setup)
    local car=manager.BuildVehicleModel(id,tune,setup)
    check(car:FindFirstChild("CoDriverSeat")~=nil,id.." passenger seat exists")
    check(car:GetAttribute("Setup_Stage")==2 and car:GetAttribute("BrakeMultiplier")>1,id.." upgrade attributes match")
    for _,visual in ipairs(car.VisualWheels:GetChildren()) do
        local tyre=visual.Mesh3D.Tyre
        local side=visual.Position.X<0 and -1 or 1
        check(math.abs(tyre.CFrame.RightVector.X)>0.999,id.." wheel axle is X, never Y/Z")
        check(math.abs(tyre.Size.Y-tune.Tyres.Radius*2)<0.001,id.." wheel diameter matches physics")
        check(math.sign((visual.Mesh3D.Rim.Position-visual.Position).X)==side,id.." rims face outward")
    end
    car:Destroy()
end
local spline=loadModule("ReplicatedStorage.RallyShared.Splines.CatmullRom")
local stage=loadModule("ServerScriptService.RallyServer.StageManager")
local function samplesValid(samples,loop)
    check(#samples>20,"Route has sufficient samples")
    for i=2,#samples do
        local distance=(samples[i].Position-samples[i-1].Position).Magnitude
        check(distance>0.00001 and distance<=14.1,"No gaps or zero road segments")
        check(samples[i].Distance>samples[i-1].Distance,"Distances are strictly ordered")
        check(math.abs(samples[i].Tangent.Magnitude-1)<1e-5,"Normalized tangent")
        check(math.abs(samples[i].Position.Y-samples[i-1].Position.Y)/distance<0.38,"Driveable grades")
    end
    if loop then check((samples[1].Position-samples[#samples].Position).Magnitude<0.001,"Loop closes exactly") end
end
for _,seed in ipairs({1,42,67,999,8172,999999}) do
    local points=stage.GenerateControlPoints({Seed=seed,Mode="Loop",LengthStuds=4200})
    local s=spline.GenerateUniformSpline(points,14)
    samplesValid(s,true)
    local same=spline.GenerateUniformSpline(stage.GenerateControlPoints({Seed=seed,Mode="Loop",LengthStuds=4200}),14)
    check((s[31].Position-same[31].Position).Magnitude<1e-9,"Seeded loop is repeatable")
end
stage.BuildStage({Seed=42,Mode="Loop"})
check(stage.GetMode()=="Loop" and stage.GetTotalDistance()>4000,"Finite course length")
check(#stage.GetCheckpoints()>10,"Recovery checkpoints at useful intervals")
local obstacleCount=0
for _,p in ipairs(services.Workspace.RallyStage:GetDescendants()) do
    if p:IsA("BasePart") and p:GetAttribute("CrashObstacle") then obstacleCount+=1;check(p.CanCollide,"Roadside obstacles really collide") end
end
check(obstacleCount>100,"Course has physical containment")
stage.BuildStage({Seed=872,Mode="Infinite"})
for i=1,12 do
    local previous=stage.GetTotalDistance()
    local samples=stage.GetSamples()
    local endpoint=samples[#samples].Position
    local oldest=math.max(0,previous-1400)
    stage.EnsureAhead(previous-100,oldest)
    check(stage.GetTotalDistance()>previous+1000,"Infinite adds road ahead")
    local found=false
    for _,s in ipairs(stage.GetSamples()) do if math.abs(s.Distance-previous)<0.001 then found=(s.Position-endpoint).Magnitude<0.001 end end
    check(found,"Infinite extension shares the exact previous endpoint")
end
samplesValid(stage.GetSamples(),false)
local chunks=services.Workspace.RallyStage:GetChildren()
check(#chunks<7,"Old infinite chunks are pruned behind the slowest checkpoint")
local cached=stage.GetTotalDistance()
stage.EnsureAhead(0,0)
check(stage.GetTotalDistance()==cached,"No unnecessary distant extension")
local function player(name,id)
    local p=Instance.new("Player")
    p.Name,p.DisplayName,p.UserId=name,name,id
    local gui=Instance.new("PlayerGui")
    gui.Name,gui.Parent="PlayerGui",p
    local character=Instance.new("Model")
    character.Name,character.Parent=name,services.Workspace
    local root=Instance.new("Part")
    root.Name,root.Parent="HumanoidRootPart",character
    character.PrimaryPart=root
    local human=Instance.new("Humanoid")
    human.Parent=character
    p.Character=character
    p.Parent=services.Players
    return p
end
loadModule("ServerScriptService.RallyServer.MainServer")
check(services.StarterPlayer.StarterPlayerScripts:FindFirstChild("RallyGui")~=nil,"UI controllers persist with PlayerScripts across respawns")
local driver=player("Driver",101)
services.Players.LocalPlayer=driver
services.Players.PlayerAdded:Fire(driver)
advance(1)
local function ownCar(p)
    for _,car in ipairs(services.Workspace.RallyVehicles:GetChildren()) do if car:GetAttribute("OwnerUserId")==p.UserId then return car end end
end
local car=ownCar(driver)
check(car and car:GetAttribute("RunState")=="Ready","Driver starts in service")
check(car.PrimaryPart.Anchored,"Service car is safely held")
local remotes=services.ReplicatedStorage.RallyRemotes
local result=remotes.GarageRequest.OnServerInvoke(driver,"Apply",{Car="KumoR1",Setup={Stage=3,Paint=2,Tyres="Gravel",Suspension="Firm",Gearing="Short"}})
check(result.Ok and ownCar(driver):GetAttribute("Setup_Stage")==3,"Garage equips a real car")
local friend=player("Friend",202)
services.Players.PlayerAdded:Fire(friend)
advance(1)
local outsider=player("Outsider",303)
services.Players.PlayerAdded:Fire(outsider)
advance(1)
result=remotes.CrewRequest.OnServerInvoke(friend,driver.UserId)
check(result.Ok,"Friend joins passenger seat")
car=ownCar(driver)
check(car:GetAttribute("CoDriverMode")=="Human" and car.CoDriverSeat.Occupant.Parent==friend.Character,"Crew is bound to the correct seat")
check(not ownCar(friend),"Passenger's parked car is removed")
remotes.RaceAction.OnServerEvent:Fire(driver,"Start")
advance(3.3)
car=ownCar(driver)
check(car:GetAttribute("RunState")=="Running" and not car.PrimaryPart.Anchored,"Countdown releases the car")
check(car.CoDriverSeat.Occupant.Parent==friend.Character,"Passenger survives race respawn")
local note=nil
for _,n in pairs(stage.GetPaceNotes()) do if n.Distance<700 and (not note or n.Distance<note.Distance) then note=n end end
check(note~=nil,"Course has pace notes ahead")
local count=#remotes.CompanionSync._messages
remotes.CompanionSync.OnServerEvent:Fire(outsider,note.Index,"INJECTED")
check(#remotes.CompanionSync._messages==count,"Unseated players cannot broadcast notes")
remotes.CompanionSync.OnServerEvent:Fire(friend,note.Index,"INJECTED")
check(#remotes.CompanionSync._messages==count+2,"Calls go to exactly the driver and passenger")
check(remotes.CompanionSync._messages[count+1].Args[2]==note.Description,"Server chooses the note text")
advance(0.4)
result=remotes.GarageRequest.OnServerInvoke(outsider,"Course",{Mode="Infinite"})
check(not result.Ok,"Non-host cannot change the shared course")
result=remotes.GarageRequest.OnServerInvoke(driver,"Course",{Mode="Infinite"})
check(not result.Ok and stage.GetMode()=="Loop","Course cannot be rebuilt under an active crew")
-- Compile and execute client initialization against the same service API.
server=false
local vc=loadModule("ReplicatedStorage.RallyClient.VehicleController")
loadModule("ReplicatedStorage.RallyClient.CameraController")
local codriver=loadModule("ReplicatedStorage.RallyClient.CoDriverClient")
loadModule("ReplicatedStorage.RallyClient.GhostClient")
for _,name in ipairs({"DirtRallyHud","SettingsMenuGui","VehicleSelectorGui","CompanionTabletGui","ReplayGui"}) do loadModule("StarterGui.RallyGui."..name) end
loadModule("StarterPlayer.StarterPlayerScripts.RallyClient.MainClient")
advance(0.3)
check(vc.GetActiveVehicle()==car,"Driver client binds the seated car")
local bind=services.ContextActionService.Actions.RallyHandbrake
check(bind~=nil,"Handbrake action is bound")
check(bind("RallyHandbrake",Enum.UserInputState.Begin)==Enum.ContextActionResult.Sink,"Space consumes Roblox jump input")
check(driver.Character.Humanoid:GetStateEnabled(Enum.HumanoidStateType.Jumping)==false,"Jump state is disabled while driving")
advance(0.1)
check(vc.GetTelemetry().Handbrake,"Space reaches handbrake telemetry")
bind("RallyHandbrake",Enum.UserInputState.End)
advance(0.1)
check(not vc.GetTelemetry().Handbrake,"Releasing Space releases handbrake")
check(not codriver.GetActiveCall().IsActive,"Bot stays quiet with human co-driver")
services.Players.LocalPlayer=friend
car.PrimaryPart.ChassisForce.Force=V.new(111,222,333)
advance(0.2)
check(vc.GetActiveVehicle()==car,"Passenger observes the crew car")
check(car.PrimaryPart.ChassisForce.Force==V.new(111,222,333),"Passenger cannot write driving forces")
services.Players.LocalPlayer=driver
server=true
advance(1)
-- Drive through actual samples to a recovery checkpoint.
for _,sample in ipairs(stage.GetSamples()) do
    if sample.Distance>600 then break end
    car:PivotTo(CF.lookAt(sample.Position,sample.Position+sample.Tangent)*CF.new(0,2.8,0))
    car.PrimaryPart.AssemblyLinearVelocity=sample.Tangent*70
    advance(0.1)
end
local checkpoint=car:GetAttribute("CheckpointDistance")
check(checkpoint and checkpoint>250,"Driving updates a recovery checkpoint")
local tree=Instance.new("Part")
tree.Position=car.PrimaryPart.Position+car.PrimaryPart.CFrame.LookVector*4
tree:SetAttribute("CrashObstacle",true)
tree.Parent=services.Workspace
car.PrimaryPart.Touched:Fire(tree)
check(car:GetAttribute("RunState")=="Crashing","Hard obstacle impact enters crash state")
check(driver.PlayerGui.RacePresentation.CrashBlackout.Visible and driver.PlayerGui.RacePresentation.CrashBlackout.BackgroundTransparency==0,"Crash is shown as a full black screen")
advance(2)
car=ownCar(driver)
check(car:GetAttribute("RunState")=="Running","Blackout automatically restarts race")
check(car:GetAttribute("RecoveryDistance")==checkpoint,"Recovery uses last passed checkpoint")
check(car:GetAttribute("PenaltySeconds")==8,"Crash adds an honest time penalty")
check(car.CoDriverSeat.Occupant.Parent==friend.Character,"Crew is reseated after the crash")
remotes.RaceAction.OnServerEvent:Fire(driver,"Reset")
advance(2)
car=ownCar(driver)
check(car:GetAttribute("PenaltySeconds")==13,"Manual recovery carries five seconds")
-- Off-map escape is recovered even if no obstacle touch was observed.
car:PivotTo(CF.new(car.PrimaryPart.Position+V.new(500,-120,0)))
advance(3.5)
car=ownCar(driver)
check(car:GetAttribute("RunState")=="Running" and car:GetAttribute("PenaltySeconds")==18,"Off-map recovery is independent of collision events")
advance(1)
result=remotes.CrewRequest.OnServerInvoke(friend,0)
check(result.Ok and car:GetAttribute("CoDriverMode")=="Bot","Leaving the crew restores the bot")
advance(1)
check(ownCar(friend)~=nil,"Leaving returns passenger to their own car")
-- Complete a full lap using the ordered road to test finish validation and real results.
local recovery=car:GetAttribute("RecoveryDistance")
for _,sample in ipairs(stage.GetSamples()) do
    if sample.Distance<recovery then continue end
    if car:GetAttribute("RunState")~="Running" then break end
    car:PivotTo(CF.lookAt(sample.Position,sample.Position+sample.Tangent)*CF.new(0,2.8,0))
    car.PrimaryPart.AssemblyLinearVelocity=sample.Tangent*70
    advance(0.1)
end
check(car:GetAttribute("RunState")=="Finished","One complete lap has a real finish")
check(car.PrimaryPart.Anchored,"Finished car is safely held")
local lastResult=nil
for _,message in ipairs(remotes.RaceState._messages) do if message.Player==driver and message.Args[1]=="Finished" then lastResult=message.Args[2] end end
check(lastResult and lastResult.Elapsed>lastResult.Penalty and lastResult.Penalty==18,"Results include measured elapsed time and all penalties")
-- A replay uses a detached local clone; live racing physics never gets scrubbed.
local ghost=loadModule("ReplicatedStorage.RallyClient.GhostClient")
local codec=loadModule("ReplicatedStorage.RallyShared.TelemetryCodec")
local livePosition=car.PrimaryPart.Position
local frame0=codec.CreateFrame(0,CF.new(livePosition),V.new(10,0,0),0,1,3000,2)
local frame1=codec.CreateFrame(1,CF.new(livePosition+V.new(10,0,0)),V.new(10,0,0),0,1,3500,2)
ghost.SetPersonalBest({CarId=car:GetAttribute("CarId"),TotalTime=1,StageSeed=stage.GetSeed(),Frames={frame0,frame1}})
driver.PlayerGui.ReplayGui.Enabled=true
advance(0.2)
check(services.Workspace:FindFirstChild("LocalReplay")~=nil,"HUD replay button creates a local replay clone")
check((car.PrimaryPart.Position-livePosition).Magnitude<1e-8,"Replay never moves the live car")
driver.PlayerGui.ReplayGui.Enabled=false
check(services.Workspace:FindFirstChild("LocalReplay")==nil,"Closing replay cleans up its clone")
local cameraController=loadModule("ReplicatedStorage.RallyClient.CameraController")
cameraController.SetMode("Chase")
check(cameraController.GetMode()=="Chase","Live chase camera can be selected")
-- The same server can switch courses after a finish, then continue endlessly.
advance(1)
result=remotes.GarageRequest.OnServerInvoke(driver,"Course",{Mode="Infinite",Seed=77,Weather="Autumn"})
check(result.Ok and stage.GetMode()=="Infinite","Host can switch to Infinite after active runs end")
advance(1)
remotes.RaceAction.OnServerEvent:Fire(driver,"Start")
advance(3.5)
car=ownCar(driver)
check(car:GetAttribute("RunState")=="Running" and car:GetAttribute("CoDriverMode")=="Bot","Solo Infinite starts with the bot")
local originalEnd=stage.GetTotalDistance()
local heardBot=false
local route=table.clone(stage.GetSamples())
for _,sample in ipairs(route) do
    if sample.Distance>1700 then break end
    car:PivotTo(CF.lookAt(sample.Position,sample.Position+sample.Tangent)*CF.new(0,2.8,0))
    car.PrimaryPart.AssemblyLinearVelocity=sample.Tangent*70
    advance(0.1)
    if codriver.GetActiveCall().IsActive then heardBot=true end
end
check(car:GetAttribute("RunState")=="Running","Infinite never triggers the loop finish")
check(stage.GetTotalDistance()>originalEnd,"A live Infinite run requests extension automatically")
check(heardBot,"An empty passenger seat gives automatic pace notes")
check(not driver.PlayerGui.RacePresentation.CrashBlackout.Visible,"Recovery finishes with the black screen removed")
print(string.format("PASS / %d assertions: geometry, tuning, wheel axes, infinite seams/pruning, server races, crew isolation, client startup, handbrake, crash/reset/off-map and finite finish.",testCount))
