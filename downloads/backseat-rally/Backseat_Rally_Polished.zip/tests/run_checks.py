"""Compile the Luau sources and execute the simulated Roblox-service suite."""
import argparse,subprocess,tempfile
from pathlib import Path
p=argparse.ArgumentParser()
p.add_argument('--luau',default='luau')
p.add_argument('--compiler',default='luau-compile')
a=p.parse_args()
root=Path(__file__).resolve().parents[1]
sources=sorted((root/'source').rglob('*.lua'))
subprocess.run([a.compiler,'--null',*[str(f) for f in sources]],check=True)
with tempfile.TemporaryDirectory(prefix='backseat-rally-checks-') as temp:
    suite=Path(temp)/'suite.lua'
    import sys
    subprocess.run([sys.executable,str(root/'tests/build_tests.py'),'--output',str(suite)],check=True)
    subprocess.run([a.luau,str(suite)],check=True)
