from pathlib import Path
import argparse
p=argparse.ArgumentParser()
p.add_argument('--source',type=Path,default=Path(__file__).resolve().parents[1]/'source')
p.add_argument('--output',type=Path,required=True)
a=p.parse_args()
root=Path(__file__).resolve().parent
parts=[(root/'runtime.lua').read_text(encoding='utf8')]
for file in sorted(a.source.rglob('*.lua')):
    source=file.read_text(encoding='utf8')
    if ']====]' in source:raise ValueError('Embedded-source delimiter collision')
    path='.'.join(file.relative_to(a.source).with_suffix('').parts)
    parts.append(f'sources["{path}"]=[====[\n{source}\n]====]\n')
parts.append((root/'cases.lua').read_text(encoding='utf8'))
a.output.write_text('\n'.join(parts),encoding='utf8')
