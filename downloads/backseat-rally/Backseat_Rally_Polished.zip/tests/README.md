# Automated checks

Install or build the official Luau CLI (`luau` and `luau-compile`) from https://github.com/luau-lang/luau, then run this from the package root:

```sh
python tests/run_checks.py
```

For binaries outside PATH, pass `--luau /path/to/luau --compiler /path/to/luau-compile`.

The suite embeds and executes the actual shipped sources against a deterministic Roblox API simulation. It checks setup validation and cloning, all five cars' wheel axes, loop closure and gradients, repeatable seeds, Infinite joins and pruning, crew seat/routing authority, client/UI startup, handbrake capture, recovery penalties and blackout, full-lap results, isolated replay and a live Infinite extension.

It does not simulate Roblox engine physics, rendering or real networking. Follow `STUDIO_PLAYTEST.md` for those checks.
