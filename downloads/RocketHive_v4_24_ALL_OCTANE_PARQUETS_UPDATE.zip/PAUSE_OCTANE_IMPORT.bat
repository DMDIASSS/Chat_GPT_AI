@echo off
setlocal
set "OPENBLAS_NUM_THREADS=1"
set "OMP_NUM_THREADS=1"
cd /d "%~dp0"
".venv\Scripts\python.exe" -c "from pathlib import Path; Path('STOP_OCTANE_IMPORT').touch(); print('Pause requested; completed replay libraries are preserved.')"
if errorlevel 1 echo COMMAND_FAILED - keep this output and use menu 9 for diagnostics.
pause
