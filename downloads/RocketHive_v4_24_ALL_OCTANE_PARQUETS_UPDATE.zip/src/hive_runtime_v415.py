"""One asynchronous worker per team, joint plan shared only with teammates.

RLBot callbacks never wait for search. Expired/missing plans use an explicit
geometric fallback, not the legacy collapsed policy and not stale throttle.
"""
from pathlib import Path
import hashlib,json,os,tempfile,time,traceback,sys,subprocess,threading
import numpy as np
from .live_hive_v415 import HiveSettings,safe_drive,control_tuple

def atomic_json(path,value):
    path=Path(path);path.parent.mkdir(parents=True,exist_ok=True)
    fd,name=tempfile.mkstemp(dir=path.parent,suffix='.tmp')
    try:
        with os.fdopen(fd,'w') as f:json.dump(value,f,default=lambda x:x.tolist() if isinstance(x,np.ndarray) else x,allow_nan=False)
        try:os.replace(name,path)
        except PermissionError:
            # A Windows reader may briefly hold an existing file without delete
            # sharing. Skip this publication; never stall or crash the callback.
            if not path.exists():raise
            return False
    finally:
        if os.path.exists(name):os.unlink(name)

def public_state(state):
    # Drop any caller-provided plans/future references. Only current observations.
    return {k:state[k] for k in ('cars','ball','mode','hitboxes','flags','timers') if k in state}

def read_state(raw):
    s=public_state(raw)
    for k in ('cars','ball','flags','hitboxes'):
        if k in s:s[k]=np.asarray(s[k])
    if not np.isfinite(s['cars']).all() or not np.isfinite(s['ball']).all():raise ValueError('Nonfinite public game state')
    return s

class TeamLock:
    def __init__(self,path):self.path=Path(path);self.file=None
    def acquire(self):
        self.path.parent.mkdir(parents=True,exist_ok=True);self.file=self.path.open('a+b')
        if self.file.tell()==0:self.file.write(b'0');self.file.flush()
        self.file.seek(0)
        try:
            if os.name=='nt':
                import msvcrt;msvcrt.locking(self.file.fileno(),msvcrt.LK_NBLCK,1)
            else:
                import fcntl;fcntl.flock(self.file.fileno(),fcntl.LOCK_EX|fcntl.LOCK_NB)
            return True
        except OSError:self.file.close();self.file=None;return False
    def close(self):
        if self.file:self.file.close();self.file=None

def worker_main(root,team,project,settings):
    # Spawn-safe target: no RLBot imports and no other team's namespace access.
    os.chdir(project)
    lock=TeamLock(Path(root)/'leader.lock')
    if not lock.acquire():return
    stop=threading.Event();fast=None
    try:
        try:
            import torch;torch.set_num_threads(1)
        except ImportError:pass
        import RocketSim as rs
        from .live_hive_v415 import HivePlanner
        planner=HivePlanner(rs,HiveSettings(**settings));last=-1;seen=time.monotonic()
        if planner.brain and planner.cfg.search_enabled:
            # Read-only inference uses a separate channel/thread so expensive
            # search cannot replace a usable neural policy with geometric driving.
            fast=threading.Thread(target=policy_loop,args=(root,team,planner,stop),daemon=True);fast.start()
        while time.monotonic()-seen<12:
            try:request=json.loads((Path(root)/'request.json').read_text())
            except (OSError,ValueError):time.sleep(.01);continue
            if request['team']!=team:raise ValueError('Wrong team request')
            if request['sequence']==last:time.sleep(.005);continue
            if time.monotonic()-request['posted']>3:time.sleep(.02);continue
            seen=time.monotonic();last=request['sequence'];s=read_state(request['state'])
            result=planner.plan(s,team) if planner.cfg.search_enabled else policy_plan(planner,s,team)
            result.update(posted=request['posted'],roster=request['roster'],state_time=request['state_time'])
            atomic_json(Path(root)/'plan.json',result)
    except BaseException as exc:
        atomic_json(Path(root)/'error.json',dict(error=str(exc),trace=traceback.format_exc()[-5000:]))
    finally:
        stop.set()
        if fast:fast.join(timeout=1)
        lock.close()

def policy_plan(planner,state,team):
    if planner.brain is None:raise ValueError('Policy-only mode requires a trained replay brain')
    m=int(state['mode'])
    if getattr(planner,'retriever',None):
        matches=planner.retriever.find(state,team,count=1,fallback=planner.brain.modal([state])[0]) if getattr(planner.retriever,'per_player',False) else planner.retriever.find(state,team,count=1,shortlist=128)
        if matches:
            match=matches[0];prefix='REPLAY_SCENE_OCTANE_CLIPS_NEAREST' if getattr(planner.retriever,'per_player',False) else 'REPLAY_SCENE_NEAREST'
            if match['metadata'].get('retrieved_players',m)<m:prefix+='_PARTIAL'
            return dict(team=team,controls=match['own'].tolist(),controller=prefix if match['metadata']['close'] else prefix+'_LOW_SIMILARITY',retrieval=match['metadata'],relative_start_on_receipt=bool(getattr(planner.retriever,'per_player',False)))
        controls=planner.brain.modal([state])[0][team*m:(team+1)*m]
        return dict(team=team,controls=controls.tolist(),controller='REPLAY_BC_NO_COMPATIBLE_REPLAY_SCENE',retrieval={'matched':False})
    controls=planner.modal([state])[0][team*m:(team+1)*m]
    return dict(team=team,controls=controls.tolist(),controller='REPLAY_BC_POLICY_ONLY')

def policy_loop(root,team,planner,stop):
    last=-1
    try:
        while not stop.wait(.005):
            try:r=json.loads((Path(root)/'request.json').read_text())
            except (OSError,ValueError):continue
            if r['team']!=team:raise ValueError('Wrong team in fast policy request')
            if r['sequence']==last or time.monotonic()-r['posted']>1:continue
            last=r['sequence'];result=policy_plan(planner,read_state(r['state']),team)
            result.update(controller=(result['controller']+'_SEARCH_LATE' if getattr(planner,'retriever',None) else 'REPLAY_BC_POLICY_SEARCH_LATE'),posted=r['posted'],state_time=r['state_time'],roster=r['roster'])
            atomic_json(Path(root)/'policy_plan.json',result)
    except BaseException as exc:
        atomic_json(Path(root)/'policy_error.json',dict(error=str(exc),trace=traceback.format_exc()[-5000:]))

class TeamClient:
    def __init__(self,team,session='local',project=None,settings=None,base=None):
        if team not in (0,1):raise ValueError('Invalid team')
        self.team=team;self.settings=settings or HiveSettings();self.project=str(Path(project or Path(__file__).resolve().parents[1]).resolve())
        ident=hashlib.sha256(str(session).encode()).hexdigest()[:20]
        self.root=Path(base or Path(tempfile.gettempdir())/'RocketHive-v415')/ident/f'team_{team}'
        self.process=None;self.last_submit=-1e9;self.last_spawn=-1e9;self.sequence=0;self.status='waiting';self.previous_time=None;self.previous_roster=None;self.last_error=None;self.last_search_seconds=None;self.last_retrieval=None;self.clip_receipts={}
    def _spawn(self):
        now=time.monotonic()
        if (self.process is None or self.process.poll() is not None) and now-self.last_spawn>5:
            python=os.environ.get('ROCKETHIVE_WORKER_PYTHON',sys.executable)
            binding=Path(self.project)/'worker_python.json'
            if 'ROCKETHIVE_WORKER_PYTHON' not in os.environ and binding.is_file():
                candidate=json.loads(binding.read_text()).get('python')
                if candidate and Path(candidate).is_file():python=candidate
            self.process=subprocess.Popen([python,'-u','-m','tools.hive_worker_v415',
                '--root',str(self.root),'--team',str(self.team),'--settings',json.dumps(self.settings.__dict__)],cwd=self.project)
            self.last_spawn=now
    def controls(self,state,game_time,roster='local'):
        now=time.monotonic();self._spawn()
        reset=self.previous_time is not None and game_time<self.previous_time
        self.previous_time=game_time
        roster_changed=self.previous_roster!=str(roster);self.previous_roster=str(roster)
        if reset or roster_changed:self.clip_receipts.clear()
        if now-self.last_submit>=self.settings.request_ticks/120 or reset or roster_changed:
            self.sequence=time.monotonic_ns();self.last_submit=now
            atomic_json(self.root/'request.json',dict(team=self.team,sequence=self.sequence,posted=now,state_time=float(game_time),roster=str(roster),state=public_state(state)))
        for filename in ('plan.json','policy_plan.json'):
            try:
                plan=json.loads((self.root/filename).read_text());age=now-plan['posted'];game_age=float(game_time)-plan['state_time']
                # Validate simulation age as well as wall age; clock rewinds invalidate it.
                if plan['team']!=self.team or plan['roster']!=str(roster) or reset or not 0<=age<=min(self.settings.plan_max_age,31/120) or not 0<=game_age<=31/120:raise ValueError('Expired/foreign team plan')
                i=min(31,max(0,int(game_age*120)));commands=[]
                people=plan.get('retrieval',{}).get('players',[]) if plan.get('relative_start_on_receipt') else []
                for j,p in enumerate(plan['controls']):
                    at=i
                    if j<len(people) and 'source_sha256' in people[j]:
                        person=people[j];key=(person['source_sha256'],person['player_index'],person['row'],person.get('mirror',False),person.get('shard',''));previous=self.clip_receipts.get(j)
                        if previous is None or previous[0]!=key:self.clip_receipts[j]=(key,float(game_time))
                        at=min(31,max(0,int((float(game_time)-self.clip_receipts[j][1])*120+1e-5)))
                    commands.append(control_tuple(p[at]))
                if len(commands)!=int(state['mode']):raise ValueError('Wrong team size')
                self.status=plan['controller']
                self.last_retrieval=plan.get('retrieval')
                if self.status.endswith('_WITH_LIVE_SEARCH'):self.last_search_seconds=plan.get('elapsed')
                return commands
            except (OSError,ValueError,KeyError,TypeError,IndexError):continue
        self.status='GEOMETRIC_FALLBACK_SEARCH_NOT_READY'
        for name in ('error.json','policy_error.json'):
            try:
                path=self.root/name
                if time.time()-path.stat().st_mtime<30:
                    error=json.loads(path.read_text())['error'];self.status='GEOMETRIC_FALLBACK_SEARCH_ERROR' if name=='error.json' else 'GEOMETRIC_FALLBACK_POLICY_ERROR'
                    if error!=self.last_error:print('[RocketHive worker]',name,error,flush=True);self.last_error=error
            except (OSError,ValueError,KeyError):pass
        m=int(state['mode']);return [safe_drive(state,self.team*m+j) for j in range(m)]
    def close(self):
        if self.process is not None:
            if self.process.poll() is None:self.process.terminate()
            try:self.process.wait(timeout=2)
            except subprocess.TimeoutExpired:self.process.kill();self.process.wait()
            self.process=None
