"""Disk-backed per-Octane replay clips, with a small global coarse index."""
from pathlib import Path
from collections import OrderedDict
import json,threading,time
import numpy as np
from .replay_final import canonical,mirror_sign,ACTION_MIRROR
from .search_teacher import make_observation
CONTRACT='OCTANE_PARQUET_CLIPS_V424'
PER_PLAYER=True
COARSE=np.array(list(range(15))+list(range(21,43))+list(range(43,49))+list(range(111,117)))
WEIGHTS=np.ones(221,np.float32);WEIGHTS[11:21]=.25;WEIGHTS[11]=1
for b in range(43,213,34):WEIGHTS[b+17:b+27]=.2;WEIGHTS[b+27:b+34]=.1
WEIGHTS[214:]=.1

def candidate_starts(data,controls,ticks,stride=8):
    n=len(ticks)
    if n<33:return np.zeros(0,np.int64)
    good=np.asarray(data['valid'],bool);valid=np.isfinite(controls).all(1)&(abs(controls[:,:5])<=1.001).all(1)&np.isin(controls[:,5:],[0,1]).all(1)
    state_bad=np.r_[0,np.cumsum(~good)];control_bad=np.r_[0,np.cumsum(~valid)]
    bad_edge=(np.diff(ticks)!=1)|(np.diff(data['segment'])!=0);edge=np.r_[0,np.cumsum(bad_edge)]
    s=np.arange(n-32);ok=(state_bad[s+33]==state_bad[s])&(control_bad[s+32]==control_bad[s])&(edge[s+32]==edge[s])
    # Include the last complete window of each usable run as well as stride grid.
    take=ok&((s%stride==0)|~np.r_[ok[1:],False]);return s[take]

def inactive_release_starts(data,arrays):
    keys=['car_controls_'+k for k in ('throttle','steer','pitch','yaw','roll','jump','boost','handbrake')]
    n=len(data['time']);a=np.stack([np.asarray(arrays[k]) for k in keys],-1);neutral=np.isfinite(a).all((1,2))&(np.max(abs(a),axis=(1,2))<.05)
    prefix=np.r_[0,np.cumsum(neutral)];frozen=(np.linalg.norm(data['ball'][:,:2],axis=1)<80)&(np.linalg.norm(data['ball'][:,7:10],axis=1)<30)&(np.linalg.norm(data['cars'][:,:2*int(data['mode']),7:10],axis=-1)<120).all(1)
    out=np.zeros(n,bool)
    if n>=8:out[:n-7]=frozen[:n-7]&((prefix[8:]-prefix[:-8])==8)
    return out

def write_player(folder,data,arrays,slot,player,stride=8):
    folder=Path(folder);folder.mkdir(parents=True,exist_ok=True)
    keys=['car_controls_'+k for k in ('throttle','steer','pitch','yaw','roll','jump','boost','handbrake')]
    controls=np.stack([np.asarray(arrays[k])[:,player['index']] for k in keys],1).astype(np.float32)
    starts=candidate_starts(data,controls,np.asarray(arrays['sim_tick']),stride)
    if 'inactive_release' in data:starts=starts[~data['inactive_release'][starts]]
    if not len(starts):return None
    features=np.lib.format.open_memmap(folder/'features.npy',mode='w+',dtype='float16',shape=(len(starts),221))
    for lo in range(0,len(starts),256):
        observations=[]
        for row in starts[lo:lo+256]:
            n=2*int(data['mode']);state=dict(mode=int(data['mode']),cars=data['cars'][row,:n],ball=data['ball'][row],flags=data['car_flags'][row,:n],hitboxes=data['hitboxes'][:n])
            observations.append(make_observation(state,slot,allow_unknown=True))
        x=canonical(np.stack(observations))
        if not np.isfinite(x).all() or (abs(x)>60000).any():raise ValueError('Invalid/out-of-range replay features')
        features[lo:lo+len(x)]=x
    features.flush();del features
    f=np.load(folder/'features.npy',mmap_mode='r');c=f[:,COARSE].astype(np.float32)*WEIGHTS[COARSE];centre=c.mean(0)
    planes=np.random.default_rng(424).normal(size=(len(COARSE),6)).astype(np.float32);code=((c-centre)@planes>0).astype(np.uint8)@np.array([1,2,4,8,16,32],np.uint8)
    order=np.argsort(code,kind='stable');centres=[];ranges=[]
    sorted_features=np.lib.format.open_memmap(folder/'sorted.npy',mode='w+',dtype='float16',shape=f.shape)
    for lo in range(0,len(order),1024):sorted_features[lo:lo+1024]=f[order[lo:lo+1024]]
    sorted_features.flush();del sorted_features;del f
    (folder/'features.npy').unlink();(folder/'sorted.npy').replace(folder/'features.npy')
    sorted_code=code[order]
    for k in np.unique(sorted_code):
        ids=np.flatnonzero(sorted_code==k);start,end=int(ids[0]),int(ids[-1])+1;centres.append(c[order[start:end]].mean(0));ranges.append([start,end])
    # Store each controller tick ONCE, not 32 duplicate copies per clip.
    np.save(folder/'controls.npy',controls);np.save(folder/'starts.npy',starts[order]);np.save(folder/'ticks.npy',np.asarray(arrays['sim_tick'])[starts[order]])
    return dict(player_index=int(player['index']),mode=int(data['mode']),clips=len(starts),centres=np.asarray(centres,np.float32).tolist(),ranges=ranges)

class OctaneClipIndex:
    per_player=True
    def __init__(self,path):
        self.path=Path(path);meta=json.loads((self.path/'catalog.json').read_text())
        if meta.get('contract')!=CONTRACT:raise ValueError('Unknown Octane clip library contract')
        self.shards=meta['shards'];self.centres=np.load(self.path/meta['centres_file'],mmap_mode='r');self.refs=np.load(self.path/meta['references_file'],mmap_mode='r');self.modes=np.load(self.path/meta['modes_file'],mmap_mode='r');self.cache=OrderedDict();self.lock=threading.RLock();self.sign=mirror_sign();self.backend='disk_backed_octane_clips'
        if not len(self.centres) or self.centres.shape[1]!=len(COARSE) or self.refs.shape!=(len(self.centres),2):raise ValueError('Empty/malformed training clip library')
        if not np.isfinite(self.centres).all() or not np.isin(self.modes,[1,2,3]).all() or (self.refs<0).any() or (self.refs[:,0]>=len(self.shards)).any():raise ValueError('Invalid clip index references')
        from .dataset import dataset_split
        for item in self.shards:
            if item['split']!='train' or dataset_split(item['source_sha256'])!='train':raise ValueError('Held-out replay in runtime clip library')
        self.tree={};self.groups={m:np.flatnonzero(self.modes==m) for m in (1,2,3)}
        try:
            from scipy.spatial import cKDTree
            self.tree={m:cKDTree(self.centres[ix]) for m,ix in self.groups.items() if len(ix)}
        except ImportError:pass
    def _open(self,i):
        with self.lock:
            if i in self.cache:self.cache.move_to_end(i);return self.cache[i]
            relative=Path(self.shards[i]['path']);folder=(self.path/relative).resolve()
            if not folder.is_relative_to(self.path.resolve()):raise ValueError('Clip shard escapes library')
            entry={k:np.load(folder/(k+'.npy'),mmap_mode='r') for k in ('features','controls','starts','ticks')}
            f,a,s,t=[entry[k] for k in ('features','controls','starts','ticks')]
            if f.ndim!=2 or f.shape[1]!=221 or a.ndim!=2 or a.shape[1]!=8 or s.shape!=(len(f),) or t.shape!=(len(f),) or (s<0).any() or (s+32>len(a)).any():raise ValueError('Malformed clip shard')
            self.cache[i]=entry
            while len(self.cache)>8:self.cache.popitem(last=False)
            return entry
    def find_player(self,state,player,count=1):
        if str(state['hitboxes'][player])!='octane':return []
        mode=int(state['mode']);group=self.groups.get(mode)
        if group is None or not len(group):return []
        started=time.perf_counter();q=canonical(make_observation(state,player,allow_unknown=True)[None])[0];found=[]
        for mirror in (False,True):
            target=q*self.sign if mirror else q;c=target[COARSE]*WEIGHTS[COARSE];k=min(len(group),12)
            if mode in self.tree:_,local=self.tree[mode].query(c,k=k);buckets=group[np.atleast_1d(local)]
            else:
                d=((self.centres[group]-c)**2).sum(1);buckets=group[np.argpartition(d,k-1)[:k]]
            for b in buckets:
                shard,part=map(int,self.refs[b]);entry=self._open(shard);lo,hi=self.shards[shard]['ranges'][part];f=entry['features'][lo:hi].astype(np.float32);distance=(((f-target)*WEIGHTS)**2).mean(1);n=min(len(distance),max(count*2,4));ix=np.argpartition(distance,n-1)[:n]
                for j in ix:found.append((float(distance[j]),shard,int(lo+j),mirror,target))
        result=[];seen=set()
        for d,shard,row,mirror,target in sorted(found,key=lambda x:x[0]):
            entry=self._open(shard);start=int(entry['starts'][row]);controls=np.array(entry['controls'][start:start+32],np.float32,copy=True)
            if mirror:controls*=ACTION_MIRROR
            key=np.round(controls,3).tobytes()
            if key in seen:continue
            seen.add(key);feature=entry['features'][row].astype(np.float32);local_error=float(np.linalg.norm(feature[21:24]-target[21:24])*3000);boost=float(abs(feature[10]-target[10]));velocity=float(np.linalg.norm(feature[:3]-target[:3])*2300)
            meta=dict(shard=self.shards[shard]['path'],source_sha256=self.shards[shard]['source_sha256'],player_index=self.shards[shard]['player_index'],row=start,sim_tick=int(entry['ticks'][row]),distance=float(np.sqrt(d)),close=bool(np.sqrt(d)<.35 and local_error<600 and velocity<700 and boost<.35),local_ball_error=local_error,local_velocity_error=velocity,boost_difference=boost,mirror=mirror,backend=self.backend)
            result.append(dict(controls=controls,metadata=meta))
            if len(result)>=count:break
        for item in result:item['metadata']['query_ms']=(time.perf_counter()-started)*1000
        return result
    def find(self,state,team=0,count=12,shortlist=512,fallback=None):
        m=int(state['mode']);clips=[self.find_player(state,team*m+j,count) for j in range(m)]
        available=[len(c) for c in clips if c]
        if not available:return []
        if any(not c for c in clips):
            if fallback is None:return []
            clips=[c if c else [dict(controls=fallback[team*m+j],metadata=dict(matched=False,close=False,backend='neural_fallback'))] for j,c in enumerate(clips)]
        n=min(available);out=[];seen=set()
        for i in range(n):
            chosen=[clips[j][(1+(i-1+3*j)%(n-1) if i else 0)%len(clips[j])] for j in range(m)];own=np.stack([c['controls'] for c in chosen]);key=np.round(own,3).tobytes()
            if key in seen:continue
            seen.add(key);meta=dict(chosen[0]['metadata']);meta.update(close=all(c['metadata']['close'] for c in chosen),players=[c['metadata'] for c in chosen],independent_player_clips=True,retrieved_players=sum('source_sha256' in c['metadata'] for c in chosen),players_total=m)
            out.append(dict(own=own,metadata=meta))
        return out


def export_library(source,dest):
    import shutil
    source=Path(source);dest=Path(dest);raw=(source/'catalog.json').read_bytes();meta=json.loads(raw);dest.mkdir(parents=True,exist_ok=True);(dest/'catalog.json').write_bytes(raw)
    for name in (meta['centres_file'],meta['references_file'],meta['modes_file']):shutil.copy2(source/name,dest/name)
    for shard in meta['shards']:
        relative=Path(shard['path']);original=(source/relative).resolve()
        if not original.is_relative_to(source.resolve()):raise ValueError('Invalid shard path')
        folder=dest/relative;folder.mkdir(parents=True,exist_ok=True)
        for name in ('features.npy','controls.npy','starts.npy','ticks.npy'):shutil.copy2(original/name,folder/name)
