import hashlib,json,sys
from pathlib import Path
from types import SimpleNamespace as NS
import numpy as np
import pytest
from tests.test_v415_live_replay_hive import state
from tests.test_v417_replay_preparation import replays

def fixture_arrays(n=80):
    s=state(2);s['hitboxes']=np.array(['octane','breakout','octane','unknown']);s['cars'][:,0]=[-500,900,-1200,300];s['flags'][:,0]=1;s['cars'][:,13]=[.2,.4,.6,.8]
    a=dict(sim_tick=np.arange(n),frame=np.arange(n),replay_time=np.arange(n)/120,segment=np.zeros(n),clock_phase=np.full(n,'running'),car_status=np.full((n,4),'active'))
    for prefix,x in [('ball',s['ball']),('car',s['cars'])]:
        offset=0
        for name,size in [('position',3),('rotation',4),('velocity',3),('angular_velocity',3)]:
            data=x[...,offset:offset+size];a[prefix+'_'+name]=np.repeat(data[None],n,axis=0);offset+=size
    a['ball_position'][:,0]=np.arange(n)*10+100;a['car_boost']=np.repeat((s['cars'][:,13]*100)[None],n,axis=0);a['car_is_on_ground']=np.ones((n,4),bool)
    for key in ('throttle','steer','pitch','yaw','roll','jump','boost','handbrake'):a['car_controls_'+key]=np.zeros((n,4),np.float32)
    a['car_controls_throttle'][:]=1;a['car_controls_steer'][:]=[.2,.4,.6,.8];a['car_controls_jump'][8]=1
    return a

def header(sha,step=1):
    return dict(format_version=1,replay_sha256=sha,rows='ticks',tick_step=step,groups=['state','game'],players=[dict(index=i,team=i//2,body_product_id=[23,24,23,999][i],hitbox=['octane','breakout','octane','octane'][i],name=str(i)) for i in range(4)])

def parquet(path,h):
    import pyarrow as pa,pyarrow.parquet as pq
    path.parent.mkdir(parents=True,exist_ok=True);table=pa.table({'sim_tick':[0,1],'car_0_controls_jump':[False,False]}).replace_schema_metadata({b'replicar':json.dumps(h).encode()});pq.write_table(table,path)

def setup(root,monkeypatch,counts={'train':1,'val':1},low=False):
    import pyarrow as pa,pyarrow.parquet as pq
    made=replays(root,counts);calls=[]
    def read(p):
        h=json.loads(pq.read_metadata(p).metadata[b'replicar']);calls.append(Path(p));a=fixture_arrays();a['sim_tick']*=h['tick_step'];return NS(header=h,arrays=lambda:a,records=lambda kind:pa.table({}))
    def convert(raw,out,**kwargs):
        assert kwargs['tick_step']==1;parquet(Path(out),header(hashlib.sha256(Path(raw).read_bytes()).hexdigest()))
    monkeypatch.setitem(sys.modules,'replicar',NS(read=read,convert=convert))
    import src.replicar_dataset as rd
    monkeypatch.setattr(rd,'read_catalog',lambda root:{23:dict(hitbox='octane',name='Octane'),24:dict(hitbox='breakout',name='Breakout')});monkeypatch.setattr(rd,'find_meshes',lambda root:str(root/'meshes'))
    for split,items in made.items():
        for i,(_,sha) in enumerate(items):parquet(root/'replicar_parquet'/f'{split}{i}.parquet',header(sha,8 if low else 1))
    return made,calls

def test_all_files_all_octane_players_mixed_unknown_context_and_cached_resume(tmp_path,monkeypatch):
    from tools.import_octane_parquets_v424 import import_all
    from src.octane_clips_v424 import OctaneClipIndex
    made,calls=setup(tmp_path,monkeypatch,{'train':2,'val':1,'test':1});r=import_all(tmp_path)
    assert r['files_scanned']==4 and r['unique_replays']==4 and r['per_car_shards']==8
    assert r['clips_by_split']=={'train':28,'val':14,'test':14} and r['no_global_clip_cap']
    bank=OctaneClipIndex(tmp_path/'models/octane_clips424');assert len(bank.shards)==4
    assert {s['player_index'] for s in bank.shards}=={0,2}
    assert all(s['hitbox']=='octane' and s['split']=='train' for s in bank.shards)
    for i,s in enumerate(bank.shards):
        entry=bank._open(i);np.testing.assert_array_equal(entry['controls'][:,5],fixture_arrays()['car_controls_jump'][:,s['player_index']]);assert len(entry['starts'])==7
    import_all(tmp_path);assert len(calls)==4 # complete replay shards reused, not re-read

def test_low_rate_replays_reconstructed_to_120hz_and_originals_untouched(tmp_path,monkeypatch):
    from tools.import_octane_parquets_v424 import import_all
    made,calls=setup(tmp_path,monkeypatch,{'train':1},low=True);original=tmp_path/'replicar_parquet/train0.parquet';before=original.read_bytes();r=import_all(tmp_path)
    assert r['clips_by_split']['train']==14 and original.read_bytes()==before
    assert calls[0].parent.name=='replicar_120hz_octane424'

def test_missing_raw_is_reported_and_not_upsampled(tmp_path,monkeypatch):
    from tools.import_octane_parquets_v424 import import_all
    made,calls=setup(tmp_path,monkeypatch,{'train':2});p=tmp_path/'replicar_parquet/train1.parquet';parquet(p,header(made['train'][1][1],8));made['train'][1][0].unlink()
    r=import_all(tmp_path);assert r['training_shards']==2
    assert any('NEEDS_RAW_120HZ' in x.get('reason','') for x in r['records'])

def test_clip_windows_do_not_cross_segments_or_tick_gaps():
    from src.octane_clips_v424 import candidate_starts
    data=dict(valid=np.ones(80,bool),segment=np.r_[np.zeros(40),np.ones(40)]);a=np.zeros((80,8));t=np.arange(80)
    np.testing.assert_array_equal(candidate_starts(data,a,t,8),[0,7,40,47])
    t[40:]+=100;np.testing.assert_array_equal(candidate_starts(data,a,t,8),[0,7,40,47])

def test_per_car_runtime_works_with_mixed_hitboxes_and_heldouts_excluded(tmp_path,monkeypatch):
    from tools.import_octane_parquets_v424 import import_all
    from src.octane_clips_v424 import OctaneClipIndex
    from src.replicar_dataset import normalize_arrays
    from src.hive_runtime_v415 import policy_plan
    made,_=setup(tmp_path,monkeypatch,{'train':1});import_all(tmp_path);reader=sys.modules['replicar'].read(tmp_path/'replicar_parquet/train0.parquet')
    from src.replicar_dataset import verified_players,read_catalog
    players=verified_players(reader.header,'',{},read_catalog(tmp_path));d=normalize_arrays(reader,players,120);s=dict(mode=2,cars=d['cars'][8,:4],ball=d['ball'][8],flags=d['car_flags'][8,:4],hitboxes=d['hitboxes'][:4]);bank=OctaneClipIndex(tmp_path/'models/octane_clips424')
    hit=bank.find_player(s,0,1)[0];assert hit['metadata']['player_index']==0 and hit['metadata']['distance']<.001
    np.testing.assert_array_equal(hit['controls'][0],fixture_arrays()['car_controls_jump'][8,0]*np.array([1,.2,0,0,0,1,0,0],np.float32))
    assert bank.find_player(s,1,1)==[] # Breakout gets no invented Octane demonstration
    fallback=np.zeros((1,4,32,8),np.float32);planner=NS(retriever=bank,brain=NS(modal=lambda _:fallback))
    plan=policy_plan(planner,s,0);assert np.shape(plan['controls'])==(2,32,8) and plan['controller'].startswith('REPLAY_SCENE_OCTANE_CLIPS')
    assert plan['retrieval']['players'][1]['backend']=='neural_fallback'

def test_duplicate_parquet_copies_do_not_duplicate_car_clips(tmp_path,monkeypatch):
    from tools.import_octane_parquets_v424 import import_all
    setup(tmp_path,monkeypatch,{'train':1});target=tmp_path/'replicar_parquet/sub/copy.parquet';target.parent.mkdir();target.write_bytes((tmp_path/'replicar_parquet/train0.parquet').read_bytes())
    r=import_all(tmp_path);assert r['files_scanned']==2 and r['unique_replays']==1 and r['clips_by_split']['train']==14

def test_frozen_neutral_release_excluded_but_waiting_defender_retained():
    from src.octane_clips_v424 import inactive_release_starts
    a=fixture_arrays();a['ball_position'][:]=[0,0,93]
    for k in ('throttle','steer','pitch','yaw','roll','jump','boost','handbrake'):a['car_controls_'+k][:]=0
    data=dict(time=np.arange(80)/120,mode=2,ball=np.zeros((80,13)),cars=np.zeros((80,6,14)))
    frozen=inactive_release_starts(data,a);assert frozen[0]
    a['car_controls_throttle'][:,1]=1
    assert not inactive_release_starts(data,a)[0]

def test_delayed_first_clip_tick_keeps_jump_press_and_does_not_restart_same_clip(tmp_path):
    from unittest.mock import patch
    from src.hive_runtime_v415 import TeamClient,atomic_json
    c=TeamClient(0,'pulse',base=tmp_path);controls=np.zeros((1,32,8));controls[0,0,5]=1
    who=dict(source_sha256='a'*64,player_index=0,row=8,mirror=False)
    plan=dict(team=0,posted=99.99,state_time=9.99,roster='round',controls=controls.tolist(),controller='REPLAY_SCENE_OCTANE_CLIPS_NEAREST',relative_start_on_receipt=True,retrieval=dict(players=[who]))
    with patch('src.hive_runtime_v415.time.monotonic',return_value=100.),patch.object(c,'_spawn'):
        atomic_json(c.root/'plan.json',plan);assert c.controls(state(),10,'round')[0][5]
        plan.update(posted=99.995,state_time=10.);atomic_json(c.root/'plan.json',plan)
        assert not c.controls(state(),10+1/120,'round')[0][5]
