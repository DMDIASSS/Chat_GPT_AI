@echo off
setlocal
set "OPENBLAS_NUM_THREADS=1"
set "OMP_NUM_THREADS=1"
cd /d "%~dp0"
".venv\Scripts\python.exe" -u -m tools.watch_hive_v415 --octane-clips --controller policy --model runs/replay_final/best_validation.pt --mode 2 --seconds 0
if errorlevel 1 echo COMMAND_FAILED - keep this output and use menu 9 for diagnostics.
pause
