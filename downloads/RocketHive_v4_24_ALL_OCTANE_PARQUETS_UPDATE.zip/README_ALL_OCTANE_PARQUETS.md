# Import every parsed replay's Octane players — v4.24

Extract into your existing RocketHive folder beside V415_MENU.bat. Pause other trainers and close viewers first.

1. Run **IMPORT_ALL_OCTANE_REPLAYS.bat**. It recursively scans replicar_parquet, replicar_120hz and the new reconstruction cache. Every file is examined; duplicate versions of the same raw replay are merged. There is no global replay/clip cap.
2. Wait for **OCTANE_LIBRARY_READY**. The console prints progress for each replay and each Octane player. For a large collection this can take a long time, especially if raw replays need reconversion. **PAUSE_OCTANE_IMPORT.bat** or Ctrl+C requests a pause. Completed replay generations are reused on the next import; the current unfinished replay restarts. A paused import does not replace an existing runtime catalog.
3. Run **WATCH_OCTANE_CLIPS.bat**. It uses the new per-player library against Galactus in live 2v2. It retains the existing actor as a labelled fallback for unsupported players/modes. Your controlled cars use Octane in this watch.
4. Optional: **WATCH_OCTANE_CLIPS_SEARCH.bat** adds native search and your previously trained Galactus judge. It is slower and requires that judge. Try direct retrieval first.
5. Optional: **EXPORT_OCTANE_CLIPS_BOT.bat** creates an RLBot4 export including the active training clip library and fallback actor. A large library means a large export and longer packaging time. Validation/test libraries and obsolete generations are excluded from this export.
6. Menu 9 packages diagnostics. Detailed import results, including skipped-file reasons and clip counts, are in **reports/v415_octane_import424.json**.

## Which players are included

Every verified Octane HITBOX player is extracted separately. Fennec and other bodies using the verified Octane preset qualify. A match can contain Breakout or any other body on either team; it is not rejected just because other players are non-Octane. Non-Octane players' positions, orientation, velocity, angular velocity and boost remain part of the context. Unknown context hitboxes are masked as unknown, never guessed to be Octane. Only the target player's own hitbox must be verified as Octane through the existing body catalog or hitbox CSV override.

The currently supported match formats remain balanced standard 1v1/2v2/3v3 with at most six players. Unsupported layouts, unknown TARGET hitboxes, corrupt data and unavailable control timing are reported. Every usable replay is processed; invalid data is not silently called usable.

## Clip extraction and timing

Each player's entire usable timeline is split into 32-tick controller sequences (about 0.267 seconds). They overlap, starting every 8 ticks by default, plus the last complete window of each valid run. There is no old 12,000-scene sampling cap. To choose a different stride, use .venv\Scripts\python.exe -m tools.import_octane_parquets_v424 --stride N. Changing it produces a new cache generation.

Clips preserve the original reconstructed 120 Hz controls, including one-tick jump presses. They cannot cross tick gaps, segment boundaries, inactive countdowns or invalid states. Fully neutral frozen kickoff-release scenes are excluded, while a stationary defender is retained if somebody else is acting. Controls are inferred by Replicar, not the original recorded human button presses.

A 15 Hz or frame-only Parquet does not contain the missing 120 Hz button timing. If the matching raw .replay exists under replays/, the importer hashes raw files once as needed, reconverts to tick-step 1 using existing Soccar meshes, and caches that result in replicar_120hz_octane424. Existing Parquets are preserved. If the raw replay or required meshes/converter are unavailable, the report records NEEDS_RAW_120HZ or the corresponding error. It does not interpolate imaginary jump presses.

Train/validation/test assignment uses the raw replay hash from the Parquet header. All usable partitions are extracted, but the live runtime catalog uses only training replays. Reserved games stay outside the controller's retrieval database.

## Storage and live matching

The new library is models/octane_clips424. A replay/car owns its controller timeline once; overlapping clips point into that timeline instead of duplicating all 32 control ticks. Current-state descriptors are saved in disk-backed arrays. A small hierarchy of coarse buckets shortlists nearby clips, then the full car-local state descriptor is compared. Each Octane car chooses its own clip using the ball and every player's current state, with valid left/right mirroring.

Features use compact float16 storage; the controller values themselves remain float32. Only eight shard mappings are kept in the runtime cache. This avoids loading every clip into RAM, though large collections still need disk space and coarse-index memory. Completed generations remain available; modifying/reconverting a replay can add another generation.

These per-car clips can come from different replays. They do not preserve the previous mode's requirement that all teammates imitate the same recorded instant. The metadata reports each player's actual source and any neural fallback. This change expands usable demonstrations without claiming identical human trajectories or a stronger bot. More data alone does not guarantee better play.

The previous BUILD_REPLAY_SCENES and WATCH_MATCHED_REPLAY tools remain available. Use the new IMPORT_ALL_OCTANE_REPLAYS and WATCH_OCTANE_CLIPS launchers for this library.

In direct clip mode, a newly selected clip starts when its controls reach the client. Repeated selections of that same source clip advance its timeline instead of restarting the first button every frame. This keeps a one-tick jump press from being skipped solely because the asynchronous response arrived late. Existing stale-plan timeouts still apply.
