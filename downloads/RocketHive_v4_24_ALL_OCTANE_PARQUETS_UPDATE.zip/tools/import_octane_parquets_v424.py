"""Scan every Parquet, extract every usable Octane player's timeline into clips."""
from pathlib import Path
import argparse,hashlib,json,os,shutil,signal,time
import numpy as np
from src.dataset import dataset_split
from src.octane_clips_v424 import CONTRACT,write_player,inactive_release_starts
from src.hive_runtime_v415 import TeamLock
ROOT=Path(__file__).resolve().parents[1]

def digest(path):
    with Path(path).open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()

def import_all(root=ROOT,stride=8):
    import pyarrow.parquet as pq
    import replicar
    from src.replicar_dataset import read_catalog,verified_players,normalize_arrays,find_meshes
    from src.hitboxes import load_overrides
    from tools.prepare_chunks_v415 import convert_one
    root=Path(root).resolve();library=root/'models/octane_clips424';library.mkdir(parents=True,exist_ok=True);lock=TeamLock(root/'runs/octane_clips424/import.lock')
    if not lock.acquire():raise ValueError('Octane clip import is already running')
    stop=root/'STOP_OCTANE_IMPORT';stop.unlink(missing_ok=True);old=signal.signal(signal.SIGINT,lambda *_:stop.touch())
    try:
        files=sorted({p.resolve() for folder in ('replicar_parquet','replicar_120hz','replicar_120hz_octane424') for p in (root/folder).rglob('*.parquet') if p.name!='index.parquet' and not any(s in p.name for s in ('.tmp.','.partial'))})
        if not files:raise ValueError('No Parquet files in replicar_parquet or replicar_120hz')
        choices={};records=[];raw_map=None;catalog=read_catalog(root);overrides=load_overrides(root/'replays/hitboxes.csv')
        legacy_manifest=root/'replicar_parquet/manifest.json';legacy=json.loads(legacy_manifest.read_text()) if legacy_manifest.exists() else {}
        def resolve_players(h,path,original):
            relative=legacy.get(original.stem,original.name)
            side=path.with_suffix('.source.json')
            if side.exists():relative=json.loads(side.read_text()).get('source',relative)
            relative=str(relative).replace('\\','/')
            players=verified_players(h,relative,overrides,catalog)
            alternative=relative[8:] if relative.startswith('replays/') else 'replays/'+relative
            alt=verified_players(h,alternative,overrides,catalog)
            return [b if a['hitbox']=='unknown' and b['hitbox']!='unknown' else a for a,b in zip(players,alt)]
        for p in files:
            try:
                header=json.loads((pq.read_metadata(p).metadata or {})[b'replicar']);sha=header.get('replay_sha256')
                if not isinstance(sha,str) or len(sha)!=64 or any(c not in '0123456789abcdef' for c in sha.lower()):
                    sidecar=p.with_suffix('.source.json');sha=json.loads(sidecar.read_text()).get('replay_sha256') if sidecar.exists() else None
                if not isinstance(sha,str) or len(sha)!=64 or any(c not in '0123456789abcdef' for c in sha.lower()):raise ValueError('No valid raw replay SHA in header/source sidecar')
                sha=sha.lower();columns=pq.read_schema(p).names;has_controls=any(n.endswith('_controls_jump') for n in columns);rank=int(header.get('tick_step')==1 and header.get('rows')=='ticks' and has_controls)
                if sha not in choices or rank>choices[sha][0]:choices[sha]=(rank,p,header)
            except Exception as e:records.append(dict(file=str(p),status='skipped',reason=str(e)))
        f=data=arrays=None;all_shards=[];split_counts={s:0 for s in ('train','val','test')};games=0
        for no,(sha,(_,original,header)) in enumerate(sorted(choices.items()),1):
            if stop.exists():break
            row=dict(file=str(original),source_sha256=sha,split=dataset_split(sha));temp=None
            try:
                p=original
                initial_players=resolve_players(header,p,original)
                if all(q['hitbox']!='octane' for q in initial_players):
                    row.update(status='no_verified_octane',unverified_players=sum(q['hitbox']=='unknown' for q in initial_players));records.append(row);continue
                # Read header rate first; low-rate files cannot supply missing jump presses.
                if header.get('tick_step')!=1 or header.get('rows')!='ticks' or not any(n.endswith('_controls_jump') for n in pq.read_schema(p).names):
                    if raw_map is None:
                        print('INDEX_RAW_REPLAYS: matching lower-rate files to their raw originals',flush=True)
                        from tools.prepare_replay_training_v417 import index_replays
                        raw_map={h:p for entries in index_replays(root).values() for p,h in entries}
                    raw=raw_map.get(sha)
                    if raw is None:raise ValueError('NEEDS_RAW_120HZ: low-rate/frame-only Parquet; matching raw .replay is absent')
                    meshes=find_meshes(root)
                    if not meshes:raise ValueError('NEEDS_MESHES: existing Soccar meshes required for 120 Hz reconstruction')
                    converted=root/'replicar_120hz_octane424';converted.mkdir(exist_ok=True);p=converted/(sha+'.parquet')
                    if not p.exists():
                        pending=p.with_suffix('.tmp.parquet')
                        try:
                            print('RECONVERT_120HZ',no,'/',len(choices),raw.name,flush=True)
                            replicar.convert(raw,pending,tick_step=1,meshes=meshes);os.replace(pending,p)
                        finally:pending.unlink(missing_ok=True)
                        p.with_suffix('.source.json').write_text(json.dumps(dict(source=raw.relative_to(root/'replays').as_posix(),replay_sha256=sha,tick_step=1)))
                    header=json.loads((pq.read_metadata(p).metadata or {})[b'replicar'])
                    if header.get('replay_sha256',sha)!=sha:raise ValueError('Reconverted raw identity differs')
                players=resolve_players(header,p,original)
                if all(q['hitbox']!='octane' for q in players):row.update(status='no_verified_octane');records.append(row);continue
                tag=hashlib.sha256((digest(p)+CONTRACT+str(stride)+json.dumps(players,sort_keys=True)).encode()).hexdigest()[:20];base=library/'replays'/sha[:20]/tag;complete=base/'complete.json'
                if complete.exists():
                    info=json.loads(complete.read_text())
                    if info.get('source_sha256')!=sha:raise ValueError('Cached replay identity mismatch')
                    if not all((library/x['path']/'features.npy').exists() and (library/x['path']/'controls.npy').exists() for x in info['shards']):raise ValueError('Cached clip shard files are missing')
                    shards=info['shards'];row.update(status='cached',clips=sum(x['clips'] for x in shards))
                else:
                    f=replicar.read(p);arrays=f.arrays();ticks=np.asarray(arrays.get('sim_tick',[]))
                    if len(ticks)<33 or np.count_nonzero(np.diff(ticks)==1)<.9*(len(ticks)-1):raise ValueError('NEEDS_RAW_120HZ: actual tick stream is not 120 Hz')
                    data=normalize_arrays(f,players,120.)
                    if 'clock_phase' in arrays:data['valid'] &= ~np.isin(np.asarray(arrays['clock_phase']).astype(str),['pregame','countdown','goal_pause','decided'])
                    data['inactive_release']=inactive_release_starts(data,arrays)
                    temp=base.with_name(base.name+'.building');temp.mkdir(parents=True,exist_ok=True);shards=[]
                    for slot,player in enumerate(players):
                        if stop.exists():break
                        if player['hitbox']!='octane':continue
                        sub='car_'+str(player['index'])
                        try:result=write_player(temp/sub,data,arrays,slot,player,stride)
                        except (KeyError,ValueError,IndexError) as error:
                            row.setdefault('car_errors',[]).append(dict(player_index=player['index'],reason=str(error)));print('OCTANE_CAR_SKIPPED',player['index'],str(error),flush=True);continue
                        if result:
                            result.update(path=(base/sub).relative_to(library).as_posix(),source_sha256=sha,split=row['split'],hitbox='octane',context_hitboxes=[p['hitbox'] for p in players],platform=header.get('platform'),replicar_version=header.get('replicar_version'),label_source='Replicar inferred 120 Hz controls');shards.append(result)
                            print('OCTANE_CAR',no,'/',len(choices),'player',player['index'],'clips',result['clips'],flush=True)
                    if stop.exists():shutil.rmtree(temp);print('IMPORT_PAUSED: completed replay shards retained; current replay restarts on resume',flush=True);break
                    (temp/'complete.json').write_text(json.dumps(dict(contract=CONTRACT,source_sha256=sha,shards=shards),indent=2));base.parent.mkdir(parents=True,exist_ok=True);os.replace(temp,base);temp=None;row.update(status='imported',clips=sum(x['clips'] for x in shards))
                games+=1;split_counts[row['split']]+=sum(x['clips'] for x in shards);all_shards.extend(shards)
            except Exception as e:
                row.update(status='skipped',reason=type(e).__name__+': '+str(e))
                if temp and temp.exists():shutil.rmtree(temp)
            f=data=arrays=None
            records.append(row);print('OCTANE_REPLAY',no,'/',len(choices),row.get('status'),row.get('clips',0),row.get('reason',''),flush=True)
        train=[s for s in all_shards if s['split']=='train'];centres=[];references=[];modes=[]
        for i,item in enumerate(train):
            centres.extend(item['centres']);references.extend([[i,j] for j in range(len(item['centres']))]);modes.extend([item['mode']]*len(item['centres']))
        if train and not stop.exists():
            generation=str(time.time_ns());cname='centres_'+generation+'.npy';rname='references_'+generation+'.npy';mname='modes_'+generation+'.npy'
            np.save(library/cname,np.asarray(centres,np.float32));np.save(library/rname,np.asarray(references,np.int64));np.save(library/mname,np.asarray(modes,np.uint8))
            cat=dict(contract=CONTRACT,shards=[{k:v for k,v in item.items() if k!='centres'} for item in train],centres_file=cname,references_file=rname,modes_file=mname,stride=stride,partition='train')
            new=library/'catalog.tmp';new.write_text(json.dumps(cat,indent=2));os.replace(new,library/'catalog.json')
        report=dict(contract=CONTRACT,files_scanned=len(files),unique_replays=len(choices),replays_imported_or_cached=games,per_car_shards=len(all_shards),clips_by_split=split_counts,training_shards=len(train),records=records,stopped=stop.exists(),no_global_clip_cap=True)
        reports=root/'reports';reports.mkdir(exist_ok=True);(reports/'v415_octane_import424.json').write_text(json.dumps(report,indent=2))
        print('OCTANE_IMPORT_PAUSED' if stop.exists() else 'OCTANE_LIBRARY_READY' if train else 'NO_TRAINING_OCTANE_CLIPS',dict(files=len(files),games=games,clips=split_counts,training_shards=len(train)),flush=True)
        if not train and not stop.exists():raise ValueError('No usable training clips; inspect reports/v415_octane_import424.json for per-file reasons')
        return report
    finally:signal.signal(signal.SIGINT,old);lock.close()
if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--stride',type=int,default=8);a=p.parse_args()
    if a.stride<1:p.error('Stride must be positive')
    import_all(stride=a.stride)
