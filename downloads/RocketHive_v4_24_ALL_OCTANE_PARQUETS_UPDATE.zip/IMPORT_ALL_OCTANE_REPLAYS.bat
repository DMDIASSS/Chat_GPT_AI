@echo off
setlocal
set "OPENBLAS_NUM_THREADS=1"
set "OMP_NUM_THREADS=1"
cd /d "%~dp0"
".venv\Scripts\python.exe" -u -m tools.import_octane_parquets_v424
if errorlevel 1 echo COMMAND_FAILED - keep this output and use menu 9 for diagnostics.
pause
