# RocketHive v4.19 — contact correctness and a larger independent research pool

Install over v4.15–v4.18 in the existing project folder. This ZIP changes code and adds diagnostic/preparation launchers. It does not replace model weights, optimizer checkpoints, environments, keys, old chunks or configuration.

## Proven correctness fixes

* Native wheel contacts are read from RocketSim's `wheels_with_contact` tuple. Previously all four wheel flags could be zero despite the tyres touching the ground, which disagreed with the replay inputs. Search-state reconstruction restores those four flags as well.
* The geometric attack fallback aims at the predicted ball centre and maintains contact speed. Previously its behind-ball target and braking radius could leave it stopped outside contact range. Cover/retreat braking remains available. This is explicitly a geometric fallback fix, not a trained-policy improvement.
* The live watcher uses standard Soccar kickoff positions, mirrored orientations, normal 33⅓ boost and grounded spawn flags. The earlier arbitrary 2v2 row with 65 boost differed from the replay kickoff distribution. Both teams receive the same standard conditions; Galactus weights and hitboxes are unchanged.
* Kickoffs reset boost pads, and a new round identity invalidates plans from before a goal. Match reports record the new kickoff contract; scores from different kickoff contracts should not be treated as a matched performance comparison.

Run `CHECK_BALL_CONTACT.bat` for a short native fallback regression. It checks actual ball-hit events on 24 randomized ground setups. It does not evaluate the neural brain or establish match strength. `AUDIT_REPLAY_POLICY.bat` remains the separate held-out neural-action audit.

## Larger dataset preparation

The previous 24-game pool was a pilot. In addition, the legacy trainer capped data at the first 24,000 examples, so simply converting hundreds of games would leave many of them unused. A new research loader samples across every game with a bounded row budget; raw replay IDs are checked to keep training and validation separate. The legacy trainer is retained unchanged for exact resume, and does not automatically switch to the new pool.

1. Run **`PREPARE_LARGER_REPLAY_DATA.bat`**.
2. It reuses existing valid chunks and converted files, then prepares more of your existing raw replays at native 120 Hz. It aims for **96 training games, 12 validation games (including at least two 2v2 games), and two test games**. Original whole-replay hash assignments remain unchanged.
3. It writes only the new dataset under **`data/replay419`**, additional shared conversion-cache files and reports. Your original `data/v415_chunks` and checkpoints remain unchanged. Unknown hitboxes and bad replays are rejected with reasons.
4. Each invocation attempts at most **96 new conversions** and checks a **30-minute deadline between games**. A conversion already running can finish beyond that deadline. Re-running the launcher reuses completed work. A research pool marked frozen by an experiment refuses additional changes.
5. At completion it prints **`RESEARCH_DATA_SHARE:`** paths under `reports`. Upload **all** those `Replay419_data_...zip` files for controlled research. Parts are kept below the attachment size limit. They contain training and validation NPZs only; test data, raw replays, models, keys and environments are excluded.

Preparation performs no training and does not upgrade the watched policy. The old menu 6 resumes the old pilot. This stage creates a broader dataset for measured learning experiments, rather than replacing a model because a loss or reconstruction score looks promising.

## Research outcome and limits

Several bounded supervised baselines were tested on the provided training chunks while keeping validation games out of optimization. Some improved action metrics, but native ball-contact and short match checks did not establish a dependable playing-strength improvement. None is promoted or bundled as a new champion. The original checkpoint is preserved for comparison.

These correctness fixes do not make the existing neural policy Galactus-level. The larger pool and action audit are the next research inputs. Passing Python/native regression tests verifies code behaviour, not strong Rocket League play.
