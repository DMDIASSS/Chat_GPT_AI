@echo off
setlocal
cd /d "%~dp0"
:menu
cls
echo RocketHive FINAL v4.20 - replay-only training and live option search
echo.
echo 1 Verify live native search
echo 2 Set up RocketSimVis and verified Galactus V2 assets
echo 3 Watch FINAL best validation model vs Galactus V2 in 2v2
echo 4 Audit parsed Parquet sampling rate and control columns
echo 5 Prepare larger replay data pool - optional
echo 6 Start or resume FINAL replay training - continuous
echo 7 Request safe training pause
echo 8 Export FINAL replay model for RLBot v4
echo 9 Package feedback report
echo 0 Exit
echo Extra tools: AUDIT_REPLAY_POLICY, WATCH_POLICY_ONLY, WATCH_SEARCH_COMPARE
echo Research: CHECK_BALL_CONTACT, PREPARE_LARGER_REPLAY_DATA
echo.
echo No pretrained strong bot is included. Existing data and models are preserved.
choice /c 1234567890 /n /m "Choose: "
set "PICK=%errorlevel%"
if "%PICK%"=="10" exit /b 0
if "%PICK%"=="1" call VERIFY_LIVE_HIVE.bat
if "%PICK%"=="2" call SETUP_ROCKETSIMVIS.bat
if "%PICK%"=="3" call WATCH_REPLAY_FINAL.bat
if "%PICK%"=="4" call AUDIT_PARQUET_FILES.bat
if "%PICK%"=="5" call PREPARE_LARGER_REPLAY_DATA.bat
if "%PICK%"=="6" call START_REPLAY_TRAINING_FINAL.bat
if "%PICK%"=="7" call PAUSE_REPLAY_FINAL.bat
if "%PICK%"=="8" call EXPORT_REPLAY_FINAL_RLBOT4.bat
if "%PICK%"=="9" call REPORT_LIVE_HIVE.bat
goto menu
