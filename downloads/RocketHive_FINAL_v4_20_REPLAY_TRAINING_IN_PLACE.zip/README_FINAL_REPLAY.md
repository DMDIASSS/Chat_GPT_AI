# RocketHive FINAL v4.20

Extract this update into your existing `RocketHive_Replicar_v2` folder, beside
`V415_MENU.bat`, `src`, `tools` and `.venv`. Replace the included code files.
Do not delete your environments, replays, data, models or exports. No reinstall
or new CUDA download is required for an already working installation.

## Start and leave it training

1. Close any older RocketHive trainers before installing the update.
2. Run **START_REPLAY_TRAINING_FINAL.bat** (or **menu 6**).
3. Let it run. It selects CUDA automatically when your existing PyTorch supports
   it; otherwise it uses CPU. Initial data loading and option-book construction
   precede the first progress lines. The first `REPLAY_VALIDATION` appears at
   update 500 and saves the first usable model. Updates are optimizer batches,
   not simulated game steps.
4. To watch, preferably pause training first with **PAUSE_REPLAY_FINAL.bat**
   (or **menu 7**) and wait for `REPLAY_FINAL_PAUSED` in the training console.
   **Ctrl+C** also requests a graceful save. A conversion already in progress
   finishes before pausing; do not forcibly close the console while saving.
5. Run **WATCH_REPLAY_FINAL.bat** (or **menu 3**). Blue is your new replay model;
   orange is frozen Galactus V2. This is live 2v2 RocketSim gameplay, not replay
   playback. Existing RocketSimVis setup is reused. Ctrl+C stops watching.
6. Run the same **START_REPLAY_TRAINING_FINAL.bat** to resume the exact optimizer,
   options, normalization, random sampler and validation split.
7. **EXPORT_REPLAY_FINAL_RLBOT4.bat** (or **menu 8**) packages the best validation
   model into `exports/RocketHive_Final_Replay_RLBot4.zip`. Extract that export,
   follow its INSTALL instructions, and add its CFG to your RLBot v4 runner.
   This export is **RLBot v4**, not a verified v5 TOML/LT export. The existing
   project Python is reused for the background neural/search worker.

There is no fixed number of hours that guarantees good play. You can leave this
trainer running until you pause it. Once validation has stopped improving,
additional passes over the same data can overfit; the separate best-validation
checkpoint is retained. Watching and exporting use that checkpoint, not the
last unvalidated update. Restart watching to load a newer checkpoint.

## What this version learns

Training uses parsed human replays only: reconstructed 120 Hz controller
sequences, current game state, and hindsight next-goal targets. There is no
self-play, PPO or search-generated training label. Reconstructed controls are
estimates; they are not the original recorded human button presses.

The initial training-only option book contains up to 256 actual replay-derived
32-tick control sequences, including valid lateral reflections. It uses medoids
(real sequences), rather than averaging incompatible driving and jump choices.
A car-local neural policy learns which option fits the current situation, with
small continuous-axis corrections; discrete jump/boost/handbrake timing remains
part of the chosen sequence. A value head estimates which team scores next,
discounted by time. These are design choices, not a reproduction of a private
RocketLM implementation or a guarantee of equivalent results.

At play time the search proposes 12 options per player by default (CLI supports
12–64), assembles joint teammate plans and simulates four flat chunks: the first
proposal plus three policy continuations re-predicted from simulated states.
Opponents use predicted policy moves. Each team's worker sees only public game
state; it cannot read the other team's actual selected plan. Late search uses
the learned policy when available; geometric fallback remains explicitly logged.
The CPU search can become late under heavy load, especially with 64 candidates.

## Data and unattended operation

- The prepared `data/replay419` pool is copied into a separate `data/replay_final`
  pool. Every game participates in sampling; it no longer trains on only the
  first file prefix. Sampling also includes extra stationary and kickoff states.
- Existing 120 Hz parsed games are reused. Every 4,000 updates, the continuous
  trainer saves and tries to ingest up to four more raw replays from `replays`,
  with a three-minute budget checked between games. One conversion can exceed
  that budget. Conversion failures are recorded; existing data remains usable.
- Replay-hash train/validation/test partitions remain separate. The validation
  file list is fixed at first start and verified on resume. Test games are never
  training examples. The option book and normalization stay fixed on resume;
  added training games are mapped to the existing options.
- **AUDIT_PARQUET_FILES.bat** checks rates and input columns in
  `replicar_parquet` and `replicar_120hz`. File size does not establish quality.
  Lower-rate Parquets cannot recover missing 120 Hz jump timing. They are reused
  for **value targets only** when their legacy manifest, raw replay hash and
  hitboxes can be verified. Files without that provenance are skipped. Their
  raw replays can still be converted to 120 Hz for policy training.
- Fully neutral frozen joint kickoff scenes and known countdown/goal-pause
  intervals are excluded, so waiting for kickoff does not become a GO command.
- Native quaternion signs are canonicalized, and the new policy uses rotation
  features invariant to equivalent quaternion signs. Unavailable per-wheel
  contact fields are masked in its policy inputs. Ball angular velocity remains
  represented in features, physics and viewer packets.

## Checkpoints and reports

All new training artifacts live in `runs/replay_final`:

| File | Purpose |
|---|---|
| `assets.pt` | Frozen replay option book, normalization and validation identities |
| `training_state.pt` | Resumable model, optimizer, sampler and data manifest |
| `latest.pt` | Most recently checkpointed model |
| `best_validation.pt` | Best supervised validation result; **not a match champion** |
| `watch_pins` | Exact checkpoint generations used for watching |
| `value_cache` | Provenance-checked lower-rate value-only examples |

Checkpoints use writable-file flush/fsync and atomic replacement. They save
every 250 updates, after validation every 500 updates, and on a graceful pause.
The trainer lock prevents two final trainers from writing simultaneously.
Your old `models/v415_*` models and optimizer remain untouched and incompatible
old weights are not silently resumed into this new architecture.

Local progress is always written to `reports/v415_final_status.json` and
`reports/v415_final_metrics.jsonl`. If the existing W&B run binding and saved
credentials are available, the trainer attempts to resume that run; failure
falls back to local logging without an account prompt or creating another run.
Menu 9 collects diagnostics and code hashes without model tensors or keys.

The new controller was checked for checkpoint resume, held-out file integrity,
controller formats, native policy/search execution and export weight agreement.
Those checks establish operation, **not pro-level performance**. This release
does not include a strong pretrained checkpoint or claim to beat Galactus.
