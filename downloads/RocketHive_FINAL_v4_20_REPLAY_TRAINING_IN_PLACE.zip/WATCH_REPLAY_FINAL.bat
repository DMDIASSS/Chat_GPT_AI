@echo off
setlocal
cd /d "%~dp0"
echo Best VALIDATION checkpoint - playing strength is unverified. Blue Hive, orange Galactus V2, 2v2.
".venv\Scripts\python.exe" -u -m tools.run_stage_v416 --stage 3 --final-replay
if errorlevel 1 echo WATCH_FAILED - run training until the first best validation checkpoint is saved, or inspect menu 9.
pause
