@echo off
setlocal
cd /d "%~dp0"
".venv\Scripts\python.exe" -u -m tools.export_hive_v415 --model runs/replay_final/best_validation.pt --output exports/RocketHive_Final_Replay_RLBot4.zip
if errorlevel 1 echo EXPORT_FAILED - keep this output. Existing models were preserved.
pause
