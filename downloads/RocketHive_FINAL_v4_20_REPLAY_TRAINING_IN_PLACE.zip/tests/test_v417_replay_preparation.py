import hashlib,json,sys
from pathlib import Path
from types import SimpleNamespace as NS
import numpy as np
import pytest
from src.dataset import dataset_split
from src.search_teacher import OBS_DIM

def replays(root,counts):
    (root/'replays').mkdir(parents=True,exist_ok=True);made={s:[] for s in counts}
    for i in range(10000):
        b=f'replay fixture {i}'.encode();h=hashlib.sha256(b).hexdigest();s=dataset_split(h)
        if s in counts and len(made[s])<counts[s]:
            p=root/'replays'/f'{i}.replay';p.write_bytes(b);made[s].append((p,h))
        if all(len(made[s])==counts[s] for s in counts):return made
    raise AssertionError('fixture indexing failed')

def fake_conversion(monkeypatch,root,reject_first=False):
    import src.replay_chunks_v415 as c
    import src.replicar_dataset as d
    calls=[]
    def convert(src,dest,**kwargs):
        assert kwargs['tick_step']==1;calls.append(Path(src));Path(dest).write_bytes(Path(src).read_bytes())
    monkeypatch.setitem(sys.modules,'replicar',NS(convert=convert,read=lambda p:NS(header={'path':str(p)})))
    monkeypatch.setattr(d,'find_meshes',lambda *_:root/'meshes')
    monkeypatch.setattr(c,'read_catalog',lambda *_:{})
    monkeypatch.setattr(c,'load_overrides',lambda *_:{})
    monkeypatch.setattr(c,'verified_players',lambda *_:[{'hitbox':'octane'}])
    seen=[]
    def examples(f,*args):
        seen.append(f.header['path'])
        if reject_first and f.header['path']==seen[0]:raise ValueError('fixture invalid hitbox')
        n=128
        return dict(obs=np.zeros((n,OBS_DIM),np.float32),actions=np.zeros((n,32,8),np.float32),value=np.ones(n,np.float32),value_known=np.ones(n,bool))
    monkeypatch.setattr(c,'chunk_examples',examples)
    return calls

def test_preparation_fills_missing_validation_using_original_replay_hashes(tmp_path,monkeypatch):
    from tools.prepare_replay_training_v417 import prepare
    made=replays(tmp_path,{'train':2,'val':2,'test':1});calls=fake_conversion(monkeypatch,tmp_path)
    r=prepare(tmp_path,max_files=8,targets={'train':2,'val':2,'test':1})
    assert r['training_requirements_met'] and not r['training_started']
    assert len(calls)==5 and dataset_split(hashlib.sha256(calls[0].read_bytes()).hexdigest())=='val'
    for s,files in made.items():
        actual=[]
        for p in (tmp_path/'data/v415_chunks'/s).glob('*.npz'):
            with np.load(p,allow_pickle=False) as z:actual.append(str(z['source_sha256'].item()))
        assert set(actual)=={h for _,h in files}
    assert not (tmp_path/'models').exists()

def test_preparation_honors_replay_budget_and_reports_not_ready(tmp_path,monkeypatch):
    from tools.prepare_replay_training_v417 import prepare
    replays(tmp_path,{'train':2,'val':2,'test':1});calls=fake_conversion(monkeypatch,tmp_path)
    r=prepare(tmp_path,max_files=1,targets={'train':2,'val':2,'test':1})
    assert len(calls)==1 and not r['training_requirements_met']
    assert (tmp_path/'reports/v415_preparation.json').exists()

def test_prepared_splits_enter_real_optimizer_but_unready_model_is_not_deployed(tmp_path,monkeypatch):
    from tools.prepare_replay_training_v417 import prepare
    from tools.train_replay_brain_v415 import train
    from tools.replay_readiness_v417 import require_brain
    replays(tmp_path,{'train':2,'val':2,'test':1});fake_conversion(monkeypatch,tmp_path)
    prepare(tmp_path,max_files=8,targets={'train':2,'val':2,'test':1})
    train(tmp_path,codec_steps=1,policy_steps=1,minutes=1,device='cpu',batch=16)
    assert (tmp_path/'models/v415_training_state.pt').is_file()
    assert (tmp_path/'models/v415_replay_brain.pt').is_file()
    with pytest.raises(ValueError,match='failed'):require_brain(tmp_path)

def test_rejected_replay_does_not_block_next_validation_game(tmp_path,monkeypatch):
    from tools.prepare_replay_training_v417 import prepare
    replays(tmp_path,{'train':2,'val':3,'test':1});fake_conversion(monkeypatch,tmp_path,reject_first=True)
    r=prepare(tmp_path,max_files=8,targets={'train':2,'val':2,'test':1})
    assert r['training_requirements_met']
    assert r['attempts'][0]['status']=='rejected' and r['summary']['val']['usable_files']==2

def test_preparation_preserves_frozen_dataset_after_training_started(tmp_path):
    from tools.prepare_replay_training_v417 import prepare
    (tmp_path/'models').mkdir();p=tmp_path/'models/v415_training_state.pt';p.write_bytes(b'original-checkpoint')
    with pytest.raises(ValueError,match='exact resume'):prepare(tmp_path)
    assert p.read_bytes()==b'original-checkpoint' and not (tmp_path/'data').exists()

def test_index_deduplicates_identical_replays(tmp_path):
    from tools.prepare_replay_training_v417 import index_replays
    made=replays(tmp_path,{'train':1,'val':1});p,_=made['train'][0];(p.parent/'duplicate.replay').write_bytes(p.read_bytes())
    assert sum(map(len,index_replays(tmp_path).values()))==2

def test_missing_brain_stops_watch_and_export_before_match_or_files(tmp_path,monkeypatch):
    import tools.watch_hive_v415 as w
    import tools.export_hive_v415 as e
    monkeypatch.setattr(w,'ROOT',tmp_path);monkeypatch.setattr(e,'ROOT',tmp_path)
    with pytest.raises(ValueError,match='NO_TRAINED_REPLAY_BRAIN'):w.run(render=False)
    with pytest.raises(ValueError,match='NO_TRAINED_REPLAY_BRAIN'):e.export(tmp_path/'no.zip')
    assert not (tmp_path/'no.zip').exists()

def test_missing_brain_requires_explicit_diagnostic_opt_in(tmp_path):
    from tools.replay_readiness_v417 import require_brain
    with pytest.raises(ValueError,match='NO_TRAINED'):require_brain(tmp_path)
    assert require_brain(tmp_path,allow_geometric=True) is None

def test_failed_conversion_cleans_temporary_output(tmp_path):
    from tools.prepare_chunks_v415 import convert_one
    p=tmp_path/'a.replay';p.write_bytes(b'raw')
    def fail(src,dest,**kwargs):Path(dest).write_bytes(b'partial');raise RuntimeError('conversion failed')
    with pytest.raises(RuntimeError):convert_one(tmp_path,p,tmp_path,fail)
    assert not list((tmp_path/'replicar_120hz').glob('*.parquet'))

def test_native_chunks_are_preferred_over_known_legacy_files(tmp_path,monkeypatch):
    from src.replay_chunks_v415 import build
    replays(tmp_path,{'train':1});calls=fake_conversion(monkeypatch,tmp_path)
    (tmp_path/'replicar_120hz').mkdir();(tmp_path/'replicar_120hz/real.parquet').write_bytes(b'converted')
    (tmp_path/'replicar_parquet').mkdir();(tmp_path/'replicar_parquet/old.parquet').write_bytes(b'legacy')
    rows=build(tmp_path)
    assert len(rows)==1 and rows[0]['file'].endswith('real.parquet')
