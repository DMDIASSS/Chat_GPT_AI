import json,sys,zipfile
from types import SimpleNamespace as NS
import numpy as np
import pytest

def chunk(folder,name='a',n=128):
    folder.mkdir(parents=True,exist_ok=True)
    np.savez_compressed(folder/(name+'.npz'),obs=np.zeros((n,240),np.float32),actions=np.zeros((n,32,8),np.float32),value=np.zeros(n,np.float32),value_known=np.ones(n,bool))

def test_report_explains_missing_validation_without_loading_weights(tmp_path,monkeypatch):
    from tools import report_hive_v415 as r
    monkeypatch.setattr(r,'ROOT',tmp_path)
    chunk(tmp_path/'data/v415_chunks/train','a');chunk(tmp_path/'data/v415_chunks/train','b')
    (tmp_path/'models').mkdir();(tmp_path/'models/v415_replay_brain.pt').write_bytes(b'never deserialize this')
    (tmp_path/'reports').mkdir();(tmp_path/'reports/v415_test.json').write_text(json.dumps({'api_key':'do-not-upload'}))
    (tmp_path/'replays').mkdir();(tmp_path/'replays/private.replay').write_bytes(b'private-replay-body')
    dest=r.report(tmp_path)
    with zipfile.ZipFile(dest) as z:
        summary=json.loads(z.read('SUMMARY.json'))
        assert summary['chunk_splits']['train']['known_values_within_cap']==256
        assert summary['chunk_splits']['val']['files']==0
        assert any('No validation chunk' in x for x in summary['issues'])
        assert set(summary['stages'])==set('123456')
        assert not any(n.endswith(('.pt','.replay')) for n in z.namelist())
        contents=b''.join(z.read(n) for n in z.namelist())
        assert b'do-not-upload' not in contents and b'private-replay-body' not in contents

def test_chunk_caps_count_only_known_values_seen_by_trainer(tmp_path):
    from tools.report_hive_v415 import chunks
    chunk(tmp_path,'a',100);chunk(tmp_path,'b',100)
    s=chunks(tmp_path,150)
    assert s['total_rows']==200 and s['training_cap_rows']==150 and s['known_values_within_cap']==150

def test_stage_retains_failure_and_redacts_console(tmp_path):
    from tools.run_stage_v416 import execute
    code=execute(6,[sys.executable,'-c',"import sys;print('api_key=private_key');print('missing validation',file=sys.stderr);sys.exit(3)"],tmp_path)
    assert code==3
    folder=tmp_path/'reports/v416_stages'
    status=json.loads(next(folder.glob('*.json')).read_text())
    assert status['status']=='failed' and status['exit_code']==3
    output=next(folder.glob('*.log')).read_text()
    assert 'missing validation' in output and 'private_key' not in output

def test_ball_spin_packet_omits_only_frozen_ball_axes():
    from tools.rocketsimvis_v415 import packet
    v=lambda a:NS(as_tuple=lambda:a)
    s=NS(pos=v((0,0,93)),vel=v((0,0,0)),ang_vel=v((1,2,3)),rot_mat=NS(forward=v((1,0,0)),up=v((0,0,1))))
    arena=NS(get_cars=lambda:[],ball=NS(get_state=lambda:s),get_boost_pads=lambda:[],get_config=lambda:NS(no_ball_rot=True))
    p=packet(arena)['ball_phys'];assert p['ang_vel']==[1,2,3] and 'forward' not in p
    arena.get_config=lambda:NS(no_ball_rot=False)
    assert packet(arena)['ball_phys']['forward']==[1,0,0]

def test_galactus_does_not_substitute_unverified_weights(tmp_path,monkeypatch):
    from src import galactus_v416 as g
    (tmp_path/'POLICY.lt').write_bytes(b'bad');(tmp_path/'SHARED_HEAD.lt').write_bytes(b'bad')
    monkeypatch.setenv('GALACTUS_MODELS',str(tmp_path))
    with pytest.raises(ValueError,match='hashes'):g.locate()
    assert g.TABLE.shape==(90,8) and len(np.unique(g.TABLE,axis=0))==90
    assert set(np.unique(g.TABLE[:,5:]))=={0,1}

def test_galactus_seven_tick_delay_and_reset():
    import torch
    from unittest.mock import patch
    from src import galactus_v416 as g
    team=g.GalactusTeam.__new__(g.GalactusTeam);team.torch=torch;team.team=1;team.rng=np.random.default_rng(1)
    team.head=lambda x:x;team.policy=lambda x:torch.arange(90).float().repeat(len(x),1)
    car=NS(team=1,get_state=lambda:NS());cars=[car,car]
    b=NS(pos=NS(as_tuple=lambda:(0,0,93)),vel=NS(as_tuple=lambda:(0,0,0)))
    arena=NS(tick_count=0,get_ball_prediction=lambda *_:[b]*273)
    team.reset(arena,cars)
    with patch.object(g,'features',return_value=np.zeros(258,np.float32)),patch.object(g,'mask',return_value=np.ones(90,bool)):
        assert not np.any(team.commands(arena,cars))
        arena.tick_count=6;assert not np.any(team.commands(arena,cars))
        arena.tick_count=7;assert np.any(team.commands(arena,cars))
        team.reset(arena,cars);assert not np.any(team.commands(arena,cars))

def test_native_cpp_2v2_feature_mask_and_control_fixtures():
    from pathlib import Path
    from src import galactus_v416 as g
    data=np.load(Path(__file__).parent/'fixtures/galactus_v416_native.npz',allow_pickle=False)
    def vec(v):
        v=np.array(v)
        return NS(x=v[0],y=v[1],z=v[2],as_tuple=lambda:tuple(v),as_numpy=lambda:v)
    for row,reference in zip(data['inputs'],data['reference']):
        controlled=int(row[0]);cursor=10;cars=[];previous=[]
        ball=NS(pos=vec(row[1:4]),vel=vec(row[4:7]),ang_vel=vec(row[7:10]),rot_mat=NS(forward=vec((1,0,0)),right=vec((0,1,0)),up=vec((0,0,1))))
        for _ in range(4):
            a=row[cursor:cursor+33];cursor+=33
            team=int(a[0]);s=NS(pos=vec(a[1:4]),vel=vec(a[4:7]),ang_vel=vec(a[7:10]),rot_mat=NS(forward=vec(a[10:13]),right=vec(a[13:16]),up=vec(a[16:19])),boost=a[19],is_on_ground=bool(a[20]),has_jumped=bool(a[21]),has_flipped=bool(a[22]),has_double_jumped=bool(a[23]),is_demoed=False,has_world_contact=False,world_contact_normal=vec((0,0,0)))
            s.has_flip_or_jump=bool(a[20] or (not a[22] and not a[23] and a[24]<1.25))
            previous.append(a[25:33]);cars.append(NS(team=team,get_state=lambda s=s:s))
        timers=row[cursor:cursor+34];cursor+=34
        pads=[NS(get_pos=lambda p=p:vec(p),get_state=lambda t=t:NS(is_active=t==0,cooldown=t)) for p,t in zip(g.BOOST_POSITIONS,timers)]
        arena=NS(get_boost_pads=lambda:list(reversed(pads)),ball=NS(get_state=lambda:ball))
        actual=g.features(arena,cars,controlled,previous[controlled],row[cursor:].reshape(5,6),np.random.default_rng(4))
        np.testing.assert_allclose(actual[:83],reference[:83],atol=2e-6,rtol=2e-6)
        for lo,hi in ((83,141),(141,228)):
            a=sorted(actual[lo:hi].reshape(-1,29),key=lambda x:tuple(x));b=sorted(reference[lo:hi].reshape(-1,29),key=lambda x:tuple(x))
            np.testing.assert_allclose(a,b,atol=2e-6,rtol=2e-6)
        np.testing.assert_allclose(actual[228:],reference[228:258],atol=2e-6,rtol=2e-6)
        np.testing.assert_array_equal(g.mask(cars[controlled].get_state()),reference[258:348])
        np.testing.assert_array_equal(g.TABLE,reference[348:].reshape(90,8))
