import copy,hashlib,json
from pathlib import Path
import numpy as np
import pytest
import torch
from tests.test_v415_live_replay_hive import state
from src.search_teacher import make_observation

def observations(n=4):
    s=state(2);s['ball'][0]=300;s['cars'][:,0]=[-600,600,-800,800]
    s['cars'][:,7:10]=np.arange(12).reshape(4,3)*20
    s['flags'][:,0]=1
    return np.stack([make_observation(s,i%4) for i in range(n)])

def test_quaternion_sign_does_not_change_features_or_native_orientation():
    from src.replay_final import canonical
    from src.physics_search import normal_quaternion,rotation_axes
    x=observations();y=x.copy()
    for lo in [3,16,29]+list(range(43,124,14)):y[:,lo:lo+4]*=-1
    np.testing.assert_allclose(canonical(x),canonical(y),atol=1e-6)
    q=np.array([.1,.2,.3,-.9]);a=normal_quaternion(q);assert a[3]>0
    np.testing.assert_allclose(rotation_axes(q),rotation_axes(-q))

def test_reflection_is_physically_consistent_with_feature_signs():
    from src.replay_final import canonical,mirror_sign,rotation
    from src.physics_search import quaternion_from_axes
    rng=np.random.default_rng(29);s=state(2)
    for a in list(s['cars'])+[s['ball']]:
        a[:3]=rng.uniform(-1000,1000,3);q=rng.normal(size=4);a[3:7]=q/np.linalg.norm(q);a[7:13]=rng.uniform(-100,100,6)
    t=copy.deepcopy(s);reflection=np.diag([-1.,1,1]);local=np.diag([1.,-1,1])
    for a in list(t['cars'])+[t['ball']]:
        a[:3]=reflection@a[:3];a[7:10]=reflection@a[7:10];a[10:13]=-reflection@a[10:13]
        r=reflection@rotation(a[None,3:7])[0]@local;a[3:7]=quaternion_from_axes(*r.T)
    x=np.stack([make_observation(s,i) for i in range(4)]);y=np.stack([make_observation(t,i) for i in range(4)])
    np.testing.assert_allclose(canonical(y),canonical(x)*mirror_sign(),atol=3e-6)

def test_wheel_masks_remove_only_unavailable_contact_features():
    from src.replay_final import canonical
    x=observations();y=x.copy();y[:,178:238].reshape(-1,6,10)[:,:,6:]=1
    np.testing.assert_allclose(canonical(x),canonical(y))
    y[:,178]=0;assert not np.array_equal(canonical(x),canonical(y))

def test_inactive_kickoff_requires_complete_joint_neutral_observations():
    from src.replay_final_data import active_mask
    s=state(1);x=np.stack([make_observation(s,i) for i in (0,1)]);a=np.zeros((2,32,8),np.float32);r=np.zeros(2,int)
    assert not active_mask(x,a,r).any()
    a[0,0,0]=1;assert active_mask(x,a,r).all() # stationary defender remains
    a[:]=0;assert active_mask(x[:1],a[:1],r[:1]).all() # incomplete joint row
    x[:,7]=.1;assert active_mask(x,a,r).all() # ball already moving

def rich_actions(n,seed=28):
    rng=np.random.default_rng(seed);a=rng.uniform(-1,1,(n,32,8)).astype(np.float32);a[:,:,5:]=(a[:,:,5:]>0).astype(np.float32);return a

def test_option_book_uses_real_replay_chunks_instead_of_mean_controls():
    from tools.train_replay_final import make_book
    from src.replay_final import ACTION_MIRROR
    torch.set_num_threads(1);a=rich_actions(160);b=make_book(a,64).numpy()
    assert len(b)==64
    valid={x.tobytes() for x in a}|{x.tobytes() for x in a*ACTION_MIRROR}
    assert all(x.tobytes() in valid for x in b)

def checkpoint(path):
    from src.replay_final import TYPE,FEATURE_VERSION,ReplayOptionsNet
    book=torch.from_numpy(rich_actions(64));net=ReplayOptionsNet(64)
    ck=dict(type=TYPE,feature_version=FEATURE_VERSION,steps=1,network=net.state_dict(),codebook=book,mean=torch.zeros(221),std=torch.ones(221),validation={})
    torch.save(ck,path);return ck

def test_brain_modal_and_proposal_contract_and_pinned_generation(tmp_path):
    from src.replay_final import load_brain,pin_checkpoint
    p=tmp_path/'a.pt';checkpoint(p);brain=load_brain(p);s=state(2)
    obs=np.stack([make_observation(s,i) for i in range(4)]);expected=brain.predict_observations(obs)[0]
    np.testing.assert_allclose(brain.modal([s])[0],expected,atol=1e-6)
    for n in (12,64):
        plans=np.stack(brain.propose_team(s,0,n));assert plans.shape==(n,2,32,8) and np.isin(plans[:,:,:,5:],[0,1]).all()
    pin,h=pin_checkpoint(p,tmp_path/'pins');p.write_bytes(b'replaced later');assert hashlib.sha256(pin.read_bytes()).hexdigest()==h
    np.testing.assert_allclose(load_brain(pin).predict_observations(obs)[0],expected)

def test_parquet_quality_depends_on_metadata_not_file_size(tmp_path):
    import pyarrow as pa,pyarrow.parquet as pq
    from src.replay_final_data import audit_parquets
    folder=tmp_path/'replicar_parquet';folder.mkdir()
    data={'sim_tick':[0,1]}
    for key in ('throttle','steer','pitch','yaw','roll','jump','boost','handbrake'):data['car_0_controls_'+key]=[0.,0.]
    for step in (1,8):
        t=pa.table(data).replace_schema_metadata({b'replicar':json.dumps(dict(tick_step=step,rows='ticks')).encode()});pq.write_table(t,folder/f'{step}.parquet')
    rows=audit_parquets(tmp_path);assert [r['use'] for r in rows]==['tick_action_candidate','lower_rate_state_value_only']

def source_id(split):
    from src.dataset import dataset_split
    return next(h for i in range(1000) if dataset_split(h:=hashlib.sha256(str(i).encode()).hexdigest())==split)

def pool_fixture(tmp_path):
    pool=tmp_path/'data/replay419'
    for split,n in [('train',320),('val',80)]:
        p=pool/split;p.mkdir(parents=True);x=observations(n)
        np.savez_compressed(p/'game.npz',obs=x,actions=rich_actions(n),value=np.ones(n,np.float32)*.3,value_known=np.ones(n,bool),rows=np.arange(n),source_sha256=source_id(split))
    return pool

def test_real_optimizer_resume_and_fixed_validation_preserve_old_model(tmp_path):
    from tools.train_replay_final import train
    from src.replay_final import load_brain
    pool_fixture(tmp_path);old=tmp_path/'models/v415_replay_brain.pt';old.parent.mkdir();old.write_bytes(b'old model')
    r=train(tmp_path,updates=2,books=64,batch=32,ingest=False,legacy=False,remote=False,validation_every=1)
    run=Path(r['run']);before=torch.load(run/'training_state.pt',weights_only=True);book=before['assets']['codebook'].clone()
    assert r['step']==2 and before['optimizer']['state'] and load_brain(run/'best_validation.pt').steps>=1
    r=train(tmp_path,updates=1,books=64,batch=32,ingest=False,legacy=False,remote=False,validation_every=1)
    after=torch.load(run/'training_state.pt',weights_only=True);assert r['step']==3
    assert torch.equal(after['assets']['codebook'],book) and old.read_bytes()==b'old model'
    assert json.loads((tmp_path/'reports/v415_final_status.json').read_text())['state']=='budget_complete'
    fixed=next((tmp_path/'data/replay_final/val').glob('*.npz'));fixed.write_bytes(b'modified')
    with pytest.raises(ValueError,match='Fixed validation replay changed'):train(tmp_path,updates=1,books=64,ingest=False,legacy=False,remote=False)
    assert torch.load(run/'training_state.pt',weights_only=True)['step']==3

def test_pause_during_training_saves_current_optimizer(tmp_path,monkeypatch):
    import tools.train_replay_final as trainer
    pool_fixture(tmp_path);original=trainer.validate
    def pause(*args,**kwargs):
        result=original(*args,**kwargs);(tmp_path/'STOP_REPLAY_FINAL').touch();return result
    monkeypatch.setattr(trainer,'validate',pause)
    r=trainer.train(tmp_path,continuous=True,books=64,batch=32,ingest=False,legacy=False,remote=False,validation_every=1)
    assert r['step']==1 and json.loads((tmp_path/'reports/v415_final_status.json').read_text())['state']=='paused'

def test_legacy_value_cache_rejects_heldout_games(tmp_path):
    from tools.cache_legacy_values_final import load
    p=tmp_path/'runs/replay_final/value_cache';p.mkdir(parents=True)
    np.savez(p/'heldout.npz',obs=observations(),value=np.zeros(4),source_sha256=source_id('val'))
    with pytest.raises(ValueError,match='held-out'):load(tmp_path)

def test_known_countdown_is_excluded_from_new_action_chunks(monkeypatch):
    import src.replay_chunks_v415 as chunks
    n=40;arr={'sim_tick':np.arange(n),'clock_phase':np.full(n,'countdown')}
    data=dict(time=np.arange(n)/120,valid=np.ones(n,bool),segment=np.zeros(n),goal_rows=np.array([],int),goal_teams=np.array([],int))
    for key in ('throttle','steer','pitch','yaw','roll','jump','boost','handbrake'):arr['car_controls_'+key]=np.zeros((n,2))
    monkeypatch.setattr(chunks,'normalize_arrays',lambda *_:data)
    with pytest.raises(ValueError,match='No valid complete'):chunks.chunk_examples(type('F',(),{'arrays':lambda _:arr})(),[])
