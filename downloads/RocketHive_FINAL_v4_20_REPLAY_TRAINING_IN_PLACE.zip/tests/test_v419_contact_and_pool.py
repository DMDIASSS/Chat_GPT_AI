import hashlib,json
from pathlib import Path
from types import SimpleNamespace as NS
from unittest.mock import patch
import numpy as np
import pytest
from tests.test_v415_live_replay_hive import state

def test_live_flags_use_native_wheel_contact_tuple():
    from src.policy_inference import live_state_flags
    s=NS(is_on_ground=True,wheels_with_contact=(True,False,True,False));car=NS(get_state=lambda:s)
    assert live_state_flags(car)[6:]==[1,0,1,0]
    s.wheel_0_contact=False
    assert live_state_flags(car)[6:]==[0,0,1,0]

def test_standard_spawn_geometry_is_mirrored_and_uses_normal_boost():
    from src.kickoff_v419 import layout
    a=layout(2,slots=[0,3])
    for blue,orange in zip(a[:2],a[2:]):
        np.testing.assert_allclose(orange['pos'][:2],-np.array(blue['pos'][:2]));np.testing.assert_allclose(orange['forward'],-np.array(blue['forward']))
        assert blue['boost']==pytest.approx(100/3)
        assert np.linalg.norm(blue['forward'])==pytest.approx(1)

def test_goal_scene_change_discards_old_plan_and_submits_immediately(tmp_path):
    import time
    from src.hive_runtime_v415 import TeamClient,atomic_json
    c=TeamClient(0,'goal',base=tmp_path)
    with patch.object(c,'_spawn'):
        c.controls(state(),10,roster='round0')
        atomic_json(c.root/'plan.json',dict(team=0,posted=time.monotonic(),state_time=10,roster='round0',controls=[[[1,0,0,0,0,0,0,0]]*32],controller='REPLAY_BC_WITH_LIVE_SEARCH'))
        c.controls(state(),10,roster='round1')
    assert c.status.startswith('GEOMETRIC') and json.loads((c.root/'request.json').read_text())['roster']=='round1'

def test_attack_keeps_contact_speed_instead_of_stopping_short():
    from src.live_hive_v415 import safe_drive
    s=state();s['cars'][0,:3]=[0,-180,17];s['cars'][0,3:7]=[0,0,np.sqrt(.5),np.sqrt(.5)];s['cars'][0,7:10]=[0,500,0]
    a=safe_drive(s,0,'attack');assert a[0]>0 and abs(a[1])<.01

def test_reconstructed_search_state_restores_individual_contacts():
    from src.physics_search import to_car_state
    stored=NS(is_on_ground=False,wheels_with_contact=(False,False,False,False))
    rs=NS(CarState=lambda:stored,Vec=lambda **kw:NS(**kw),RotMat=lambda *args:args)
    x=state()['cars'][0];to_car_state(rs,x,[1,0,0,0,0,0,1,0,1,0])
    assert stored.is_on_ground and stored.wheels_with_contact==(True,False,True,False)

def chunk(folder,name,source,rows=10):
    folder.mkdir(parents=True,exist_ok=True);obs=np.zeros((rows,240),np.float32);obs[:,0]=int(name);obs[:,-1]=2/3
    np.savez_compressed(folder/(name+'.npz'),obs=obs,actions=np.zeros((rows,32,8),np.float32),value=np.ones(rows,np.float32),value_known=np.ones(rows,bool),source_sha256=source)

def test_loader_samples_every_game_instead_of_file_prefix(tmp_path):
    from src.research_data_v419 import load_split
    for i in range(3):chunk(tmp_path,str(i),str(i)*64)
    data,files,sources=load_split(tmp_path,max_rows=6)
    assert len(data[0])==6 and set(data[0][:,0])=={0,1,2} and len(files)==3
    again=load_split(tmp_path,max_rows=6)[0]
    np.testing.assert_array_equal(data[0],again[0])

def test_pool_loader_rejects_raw_replay_overlap(tmp_path):
    from src.research_data_v419 import load_pool
    chunk(tmp_path/'train','0','a'*64);chunk(tmp_path/'val','1','a'*64)
    with pytest.raises(ValueError,match='leaked'):load_pool(tmp_path)

def test_pool_loader_keeps_test_replays_out_of_development(tmp_path):
    from src.research_data_v419 import load_pool
    chunk(tmp_path/'train','0','a'*64);chunk(tmp_path/'val','1','b'*64);chunk(tmp_path/'test','2','a'*64)
    with pytest.raises(ValueError,match='Test replay'):load_pool(tmp_path)

def test_pool_pack_excludes_test_and_private_environment(tmp_path):
    from tools.prepare_research_pool_v419 import pack
    import zipfile
    for s in ['train','val','test']:chunk(tmp_path/'data/replay419'/s,'0',s)
    (tmp_path/'keys.txt').write_text('private-key');archives=pack(tmp_path)
    with zipfile.ZipFile(archives[0]) as z:assert set(z.namelist())=={'train/0.npz','val/0.npz'}

def test_new_pool_preserves_original_dataset_and_checkpoint(tmp_path,monkeypatch):
    from tests.test_v417_replay_preparation import replays,fake_conversion
    from tools.prepare_research_pool_v419 import prepare
    import src.replay_chunks_v415 as c
    made=replays(tmp_path,{'train':2,'val':2,'test':1});fake_conversion(monkeypatch,tmp_path)
    original=c.chunk_examples
    def examples(*args):
        d=original(*args);d['obs'][:,-1]=2/3;return d
    monkeypatch.setattr(c,'chunk_examples',examples)
    ck=tmp_path/'models/v415_training_state.pt';ck.parent.mkdir();ck.write_bytes(b'old checkpoint')
    old=tmp_path/'data/v415_chunks';old.mkdir(parents=True);(old/'keep.txt').write_text('old frozen data')
    r=prepare(tmp_path,max_files=8,targets={'train':2,'val':2,'test':1})
    assert r['targets_met'] and ck.read_bytes()==b'old checkpoint' and (old/'keep.txt').read_text()=='old frozen data'
    assert not list(old.rglob('*.npz'))
    assert r['counts']['val']['modes']['2']==2

def test_new_pool_does_not_report_ready_when_replays_run_out(tmp_path,monkeypatch):
    from tests.test_v417_replay_preparation import replays,fake_conversion
    from tools.prepare_research_pool_v419 import prepare
    import src.replay_chunks_v415 as c
    replays(tmp_path,{'train':1,'val':1});fake_conversion(monkeypatch,tmp_path)
    original=c.chunk_examples
    def examples(*args):
        d=original(*args);d['obs'][:,-1]=2/3;return d
    monkeypatch.setattr(c,'chunk_examples',examples)
    r=prepare(tmp_path,max_files=8,targets={'train':2,'val':2,'test':1})
    assert not r['targets_met'] and r['counts']['train']['files']==1
