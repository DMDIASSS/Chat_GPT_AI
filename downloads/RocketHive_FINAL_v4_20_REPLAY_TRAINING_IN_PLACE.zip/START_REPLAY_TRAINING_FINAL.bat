@echo off
setlocal
cd /d "%~dp0"
echo FINAL REPLAY TRAINER - actual replay-derived action options and next-goal value.
echo Runs until PAUSE_REPLAY_FINAL or Ctrl+C. Old models are preserved.
".venv\Scripts\python.exe" -u -m tools.run_stage_v416 --stage 6 --final-replay
if errorlevel 1 echo TRAINING_FAILED - checkpoint and console log were preserved. Use menu 9 for the report.
pause
