# RocketHive v4.16 in-place update

Extract this ZIP directly into your existing `RocketHive_Replicar_v2` folder, accepting replacement of the listed code/launcher files. It requires the v4.15 replay/live-hive update already installed. No models, environments, replay data, keys or root configuration files are included or replaced.

## Send one report for steps 1–6

Run `REPORT_ALL_STEPS.bat`, or menu **9**, now. Send the resulting `reports/RocketHive_steps_1_to_6_*.zip` back for diagnosis. You do **not** need to rerun training or conversion first. Collection is read-only except for writing its report ZIP, and uses only Python's standard library.

It includes stage status, future captured console errors, installed diagnostic source and hashes, dependency versions, replay/chunk counts, validation split sizes and known-value counts, chunk rejection reasons, viewer readiness and model file metadata. It excludes model tensors, optimizer contents, replay bodies and credential files; recognized secret fields are redacted. Source code, local paths and error text are included, so share the report privately. Previous console text that was never saved cannot be recovered.

The updated launchers automatically capture each future use of menu **1–6** under `reports/v416_stages`. The report does not execute those stages.

Your reported training failure means `data/v415_chunks/val` contains no validation chunks. Possible causes include too few distinct converted games selecting the validation hash partition, or validation games being rejected during chunk building. This update reports the evidence; it does not move training frames into validation, invent controller labels, or start training with invalid data. Stage 4 currently converts up to eight new replay files per invocation; additional distinct replays may be needed. Stage 5 rebuilds chunks after conversion. Check the report before deciding what to redo.

## Watch two RocketHive bots against two Galactus V2 bots

1. Run menu **2** once. It prepares RocketSimVis and the frozen Galactus V2 assets. Existing verified `Chat_GPT_AI/NovaForge/assets/galactus` files are reused when found; otherwise about 22 MB of pinned, hash-checked public model files are downloaded. `SETUP_GALACTUS.bat` prepares only the opponent assets.
2. Run menu **3**, or `WATCH_LIVE_HIVE_ROCKETSIMVIS.bat`.
3. **Blue: two RocketHive bots. Orange: two frozen Galactus V2 bots. All four use Octane.** Ctrl+C stops viewing.

This is live controller-driven RocketSim physics, not replay playback. The blue team uses the existing learned replay brain if it passes the existing readiness gates, otherwise it explicitly reports the geometric diagnostic fallback. This update does not supply a pretrained strong RocketHive brain. Galactus model identity is printed and checked; missing/mismatched weights fail without substituting another opponent. Orange is independently controlled; blue's search does not receive Orange's chosen actions. Search still predicts opponents using its own existing model. Galactus is frozen, not trained by watching.

The native Galactus adapter uses padded teammate/opponent observations, its original 90-action contract, eight-tick decisions and seven-tick action delay. Model source: `SoldierDoge/GalactusV2`, commit `217324c2fc516048effe0407595fa61c2ebc6863`. RocketSimVis remains the pinned ZealanL viewer from v4.15.

## Ball spin

Ball angular velocity already enters replay observations, simulator state and viewer packets. Spin affects contacts and bounces in RocketSim. The default simulator option freezes the ball's orientation matrix; the viewer now integrates its actual angular velocity instead of displaying that frozen matrix. This changes display, not physics. A live progress line and saved match report include spin measurements. It does not add a Magnus-force model or alter collision parameters.

## Verification and limits

The update has focused tests for missing-validation reporting, dataset row caps, failed-stage logs, secret-field redaction, ball spin packets, frozen model identity and Galactus action delay. The existing test suite remains applicable. A native headless 2v2 smoke match exercised all four controllers. These are correctness checks, not evidence that an untrained RocketHive policy is competitive with Galactus. Windows launchers and GUI behavior still need feedback on your PC.
