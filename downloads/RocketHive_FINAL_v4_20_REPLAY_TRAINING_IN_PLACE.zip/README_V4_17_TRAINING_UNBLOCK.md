# RocketHive v4.17 — prepare a real replay brain before watching

Requires v4.15 plus v4.16 already installed. Extract this small update directly into your existing `RocketHive_Replicar_v2` folder and replace its included code files. Existing raw replays, converted files, models, environments, keys and configuration are preserved. No trained model is bundled.

## What was wrong

The old conversion launcher processed only eight replays. A small batch can contain no games in the fixed validation partition. Training then correctly stops before creating a model. A running geometric controller/search is not a trained replay policy, even when the native verification passes.

The update fills the existing whole-replay validation partition first and then collects additional training examples. It never moves games between partitions or uses test data for training. It preserves existing converted files and chunks. Newly converted games contribute up to 1,024 action chunks each; previously cached chunks are retained. Training still caps its dataset at 24,000 training and 6,000 validation examples.

## Steps on your PC

1. Stop any running match/trainer, then extract this ZIP into the existing project folder. Open `V415_MENU.bat`; the title must say v4.17.
2. Choose **4**. Preparation converts and builds chunks automatically, prioritizing missing validation games. It aims for 24 accepted training games, four validation games and two held-out test games. An invocation attempts at most 32 new games and checks a 20-minute deadline between games. One conversion can run beyond that deadline; completed outputs are saved. Progress names the split, counts and rejection reasons.
3. Wait for **`DATA_READY_FOR_PILOT_TRAINING`**. If it instead says **`DATA_NOT_READY`**, run menu **9** and send the report. You may run **4** again to continue an unfinished preparation; completed conversions are reused. Menu **5** remains available to rebuild existing converted files, but step 4 now builds them itself.
4. Choose **6** to train. The existing codec/policy trainer runs for up to 30 minutes per invocation, saves optimizer state and can resume with menu 6. It may finish its update budget earlier. Watch for the printed `health_ready` result. It is not an unattended infinite training loop.
5. If training finishes with **`REPLAY_BC_COMPLETE_UNVERIFIED`**, choose **3** for blue RocketHive vs orange frozen Galactus V2 in 2v2. If it says **`REPLAY_BC_FINISHED_NOT_READY`**, send menu **9**'s report before choosing another training recipe. Do not repeatedly rerun a completed budget expecting additional updates; the report is needed to decide the next experiment.
6. After a match, stop with Ctrl+C and run **9** again. Send that new report. It now includes preparation evidence, neural validation metrics, controller usage and jump-command counts for each car.

Menu 3 and menu 8 now require an actual replay checkpoint that passes the existing health checks. They fail clearly before opening a match/export if it is missing or unready. Advanced explicit geometric diagnostics are still available with `--allow-geometric` on `tools.watch_hive_v415` / `tools.export_hive_v415`; these are not trained bots. Native menu 1 verifies execution and can still pass without a trained model.

## Preservation and limits

Once an optimizer checkpoint exists, menu 4 refuses dataset changes to keep resume reproducible. Menu 6 resumes the same recipe; a changed dataset needs a separate project/run. Preparation does not delete checkpoints to work around that rule.

Only actual 120 Hz reconstructed controller labels are used. Legacy 15 Hz Parquets are retained, and native Parquets are preferred during chunk building. Rejected unknown hitboxes are reported rather than silently assumed to be Octane. The original raw replay's content hash still determines its partition; duplicate raw files are indexed once.

Passing reconstruction, diversity and value checks makes a pilot policy eligible for testing. It does not establish good mechanics, Galactus-level strength or reliable improvement. New training must be evaluated in live matches and held-out tests. This update fixes the missing-data and misleading-deployment path; it does not claim a competitive model before training and evaluation.
