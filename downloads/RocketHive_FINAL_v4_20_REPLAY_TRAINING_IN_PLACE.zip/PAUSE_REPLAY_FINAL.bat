@echo off
setlocal
cd /d "%~dp0"
".venv\Scripts\python.exe" -c "from pathlib import Path; Path('STOP_REPLAY_FINAL').touch(); print('Pause requested. The current batch or conversion finishes, then the optimizer checkpoint is saved.')"
pause
