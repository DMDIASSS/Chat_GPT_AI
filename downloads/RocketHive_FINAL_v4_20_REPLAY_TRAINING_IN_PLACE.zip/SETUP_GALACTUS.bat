@echo off
cd /d "%~dp0"
".venv\Scripts\python.exe" -c "from src.galactus_v416 import setup; setup()"
pause
