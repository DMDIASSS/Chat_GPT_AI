@echo off
setlocal
cd /d "%~dp0"
echo Prepare a separate larger research pool. Existing model and frozen data stay unchanged.
".venv\Scripts\python.exe" -u -m tools.run_stage_v416 --stage 4 --research-pool
if errorlevel 1 echo RESEARCH_PREPARATION_FAILED - keep this output and use menu 9.
pause
