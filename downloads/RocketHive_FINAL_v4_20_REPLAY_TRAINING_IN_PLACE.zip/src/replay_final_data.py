"""Read-only, game-balanced replay loading and inactive-kickoff exclusion."""
from pathlib import Path
import hashlib,json
import numpy as np
from .dataset import dataset_split

def active_mask(obs,actions,rows):
    own=obs[:,33:36]*2300;other=obs[:,40:124].reshape(-1,6,14);present=obs[:,124:130]>.5;world=other[:,:,7:10]*2300+own[:,None]
    frozen=np.all((np.linalg.norm(world,axis=-1)<120)|~present,1)&(np.linalg.norm(obs[:,:2]*6000,axis=1)<80)&(np.linalg.norm(obs[:,7:10]*6000,axis=1)<30)
    neutral=np.max(abs(actions[:,:8]),axis=(1,2))<.05
    _,first,inverse,count=np.unique(rows,return_index=True,return_inverse=True,return_counts=True)
    bad=(np.bincount(inverse,weights=(frozen&neutral).astype(int))==count)&(count==np.rint(obs[first,-1]*6).astype(int))
    return ~bad[inverse]

def load_split(folder,max_rows=128000,seed=420,names=None):
    files=sorted(Path(folder).glob('*.npz'))
    if names is not None:
        found={p.name:p for p in files}
        if set(names)-set(found):raise ValueError('Fixed validation files are missing')
        files=[found[n] for n in sorted(names)]
    if not files or max_rows<len(files):raise ValueError('Replay pool is empty or row budget is too small')
    per=max_rows//len(files);rng=np.random.default_rng(seed);parts=[[],[],[],[]];identity={};sources=set();dropped=0;modes={}
    for p in files:
        digest=hashlib.sha256(p.read_bytes()).hexdigest()
        if names is not None and names[p.name]!=digest:raise ValueError('Fixed validation replay changed: '+p.name)
        identity[p.name]=digest
        with np.load(p,allow_pickle=False) as z:
            source=str(z['source_sha256'].item())
            expected='val' if Path(folder).name=='val' else 'train'
            if dataset_split(source)!=expected:raise ValueError('Wrong raw-replay hash partition: '+p.name)
            if source in sources:raise ValueError('Duplicate raw replay in pool')
            sources.add(source);x=z['obs'];y=z['actions'];v=z['value'];k=z['value_known']
            if x.shape!=(len(x),240) or y.shape!=(len(x),32,8):raise ValueError('Invalid action chunk shapes')
            if not all(np.isfinite(a).all() for a in (x,y,v,k)) or not np.isin(y[:,:,5:],[0,1]).all():raise ValueError('Invalid replay controls')
            keep=active_mask(x,y,z['rows']) if 'rows' in z else np.ones(len(x),bool);dropped+=int((~keep).sum());available=np.flatnonzero(keep)
            if not len(available):continue
            ix=np.sort(rng.choice(available,min(per,len(available)),replace=False))
            for a,b in zip(parts,(x,y,v,k)):a.append(b[ix])
            m=str(int(round(float(x[ix[0],-1])*3)));modes[m]=modes.get(m,0)+len(ix)
    if not parts[0]:raise ValueError('No active gameplay examples remain')
    return tuple(np.concatenate(a) for a in parts),identity,sources,dict(files=len(files),rows=sum(len(x) for x in parts[0]),excluded_inactive_kickoff_rows=dropped,modes=modes)

def load_pool(pool,validation=None):
    p=Path(pool);tr,th,ts,tm=load_split(p/'train');va,vh,vs,vm=load_split(p/'val',12000,421,names=validation)
    if ts&vs:raise ValueError('Training/validation raw-replay overlap')
    for f in (p/'test').glob('*.npz'):
        with np.load(f,allow_pickle=False) as z:
            if str(z['source_sha256'].item()) in ts|vs:raise ValueError('Test data leaked into development pool')
    return tr,va,dict(train=th,validation=vh),dict(train=tm,validation=vm)

def audit_parquets(root):
    """Inspect metadata only; bytes alone do not establish control-label quality."""
    import pyarrow.parquet as pq
    root=Path(root);rows=[]
    for folder in ('replicar_parquet','replicar_120hz'):
        for p in sorted((root/folder).glob('*.parquet')):
            try:
                meta=pq.read_metadata(p);header=json.loads((meta.metadata or {}).get(b'replicar',b'{}'));step=header.get('tick_step');kind=header.get('rows');columns=set(pq.read_schema(p).names)
                has_tick='sim_tick' in columns
                controls=all(any(n.endswith('_controls_'+a) for n in columns) for a in ('throttle','steer','pitch','yaw','roll','jump','boost','handbrake'))
                if step==1 and has_tick and controls:use='tick_action_candidate'
                elif step is not None and step>1:use='lower_rate_state_value_only'
                else:use='requires_schema_check'
                rows.append(dict(file=str(p.relative_to(root)),bytes=p.stat().st_size,rows=meta.num_rows,tick_step=step,row_kind=kind,control_columns=controls,use=use))
            except Exception as e:rows.append(dict(file=str(p),error=str(e)))
    out=root/'reports';out.mkdir(exist_ok=True);(out/'v415_final_parquet_audit.json').write_text(json.dumps(rows,indent=2),encoding='utf8')
    from collections import Counter
    print('PARQUET_AUDIT:',dict(Counter(x.get('use','error') for x in rows)),flush=True);return rows
