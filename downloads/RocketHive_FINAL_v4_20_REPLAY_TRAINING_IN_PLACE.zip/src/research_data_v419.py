"""A bounded loader that samples across every game instead of a file prefix."""
from pathlib import Path
import hashlib
import numpy as np

def load_split(folder,max_rows=128000,seed=419):
    files=sorted(Path(folder).glob('*.npz'))
    if not files:raise ValueError('No replay chunks: '+str(folder))
    if max_rows<len(files):raise ValueError('Row budget must allow at least one example per game')
    per_game=max_rows//len(files);rng=np.random.default_rng(seed);parts=[[],[],[],[]];identity={};sources=set()
    for p in files:
        identity[p.name]=hashlib.sha256(p.read_bytes()).hexdigest()
        with np.load(p,allow_pickle=False) as z:
            source=str(z['source_sha256'].item())
            if source in sources:raise ValueError('Duplicate raw replay in a split')
            sources.add(source);n=len(z['obs']);take=min(n,per_game)
            if not take:raise ValueError('Empty replay chunk file')
            ix=np.sort(rng.choice(n,take,replace=False))
            for a,key in zip(parts,('obs','actions','value','value_known')):a.append(z[key][ix])
    data=tuple(np.concatenate(p) for p in parts)
    if data[0].shape[1]!=240 or data[1].shape[1:]!=(32,8) or not all(np.isfinite(a).all() for a in data):raise ValueError('Invalid replay research dataset')
    return data,identity,sources

def load_pool(pool):
    pool=Path(pool);train,th,ts=load_split(pool/'train');val,vh,vs=load_split(pool/'val',max_rows=12000,seed=420)
    if ts&vs:raise ValueError('Raw replay leaked between training and validation')
    for p in (pool/'test').glob('*.npz'):
        with np.load(p,allow_pickle=False) as z:
            if str(z['source_sha256'].item()) in ts|vs:raise ValueError('Test replay leaked into development data')
    return train,val,dict(train=th,validation=vh)
