"""Standard Soccar kickoff geometry, mirrored for equal starting conditions."""
import math
import numpy as np
SPAWNS=((-2048.,-2560.,math.pi/4),(2048.,-2560.,3*math.pi/4),(-256.,-3840.,math.pi/2),(256.,-3840.,math.pi/2),(0.,-4608.,math.pi/2))

def layout(mode,slots=None,rng=None):
    if mode not in (1,2,3):raise ValueError('Standard balanced Soccar teams required')
    if slots is None:slots=(rng or np.random.default_rng(419)).choice(5,size=mode,replace=False).tolist()
    if len(slots)!=mode or len(set(slots))!=mode or any(i not in range(5) for i in slots):raise ValueError('Invalid kickoff spawn slots')
    result=[]
    for team in (0,1):
        d=1-2*team
        for i in slots:
            x,y,yaw=SPAWNS[i];f=(d*math.cos(yaw),d*math.sin(yaw),0.)
            result.append(dict(team=team,pos=(d*x,d*y,17.5),forward=f,right=(-f[1],f[0],0.),boost=100/3))
    return result

def kickoff(rs,arena,cars,mode,rng=None):
    if len(cars)!=2*mode:raise ValueError('Wrong number of cars')
    for car,p in zip(cars,layout(mode,rng=rng)):
        s=rs.CarState();s.pos=rs.Vec(*p['pos']);s.rot_mat=rs.RotMat(rs.Vec(*p['forward']),rs.Vec(*p['right']),rs.Vec(0,0,1));s.boost=p['boost']
        # These known kickoff poses put all four tyres on the flat floor.
        if hasattr(s,'is_on_ground'):s.is_on_ground=True
        if hasattr(s,'wheels_with_contact'):s.wheels_with_contact=(True,True,True,True)
        car.set_state(s)
    arena.ball.set_state(rs.BallState(pos=rs.Vec(0,0,93)))
    for pad in arena.get_boost_pads():
        state=pad.get_state();state.is_active=True;state.cooldown=0;pad.set_state(state)
