"""12-64 control candidates for BOTH teams, robust short-horizon minimax.

Real RocketSim physics is mandatory. This cannot predict legal aerial, wall,
ball collisions by extrapolating or teleporting states. Each candidate is a
joint controls plan for all allied or opposing cars; replan every 8 ticks.

The verified mtheall RocketSim binding must support distinct CarConfig presets.
A missing preset raises an exception rather than silently using Octane.
"""
from __future__ import annotations
from dataclasses import dataclass
import math
import random
import numpy as np
from .planner import PlanResult
from .tracking_v4 import replay_score,should_terminate

# [throttle,steer,pitch,yaw,roll,jump,boost,handbrake]
ACTIONS=[
    (1,0,0,0,0,False,False,False),
    (1,-1,0,0,0,False,False,False),(1,1,0,0,0,False,False,False),
    (1,-.5,0,0,0,False,True,False),(1,.5,0,0,0,False,True,False),
    (1,0,0,0,0,False,True,False),
    (-1,0,0,0,0,False,False,False),
    (1,1,0,0,0,False,False,True),(1,-1,0,0,0,False,False,True),
    (1,0,-1,0,0,True,False,False), # jump and aerial launch
    (1,0,-1,0,0,True,True,False),
    (1,0,-1,-1,0,False,True,False),(1,0,-1,1,0,False,True,False),
    (0,0,1,0,0,False,True,False),(0,0,-1,0,0,False,True,False),
    (0,0,0,0,1,False,True,False),(0,0,0,0,-1,False,True,False),
    (0,0,0,1,0,False,True,False),(0,0,0,-1,0,False,True,False),
    (0,0,1,1,0,True,False,False),(0,0,-1,-1,0,True,False,False),
    (1,0,0,0,0,True,False,False),
]
HITBOX_PRESETS=('octane','dominus','plank','breakout','hybrid','merc','psyclops')


def normal_quaternion(q):
    q=np.asarray(q,dtype=float)
    if np.linalg.norm(q)<0.5:raise ValueError('Invalid quaternion')
    q=q/np.linalg.norm(q)
    # Replicar exports the equivalent quaternion with nonnegative w. Native
    # matrix conversion can choose the opposite sign; an MLP sees that as a
    # different input even though the physical orientation is identical.
    if q[3]<0 or (q[3]==0 and q[np.argmax(np.abs(q[:3]))]<0):q=-q
    return q


def rotation_axes(q):
    # Replicar v2 quaternions are x,y,z,w (confirmed in its file-format docs).
    x,y,z,w=normal_quaternion(q)
    mat=np.array([
        [1-2*(y*y+z*z),2*(x*y-z*w),2*(x*z+y*w)],
        [2*(x*y+z*w),1-2*(x*x+z*z),2*(y*z-x*w)],
        [2*(x*z-y*w),2*(y*z+x*w),1-2*(x*x+y*y)]])
    return mat[:,0],mat[:,1],mat[:,2]


def quaternion_from_axes(f,r,u):
    """Return stable xyzw from proper rotation basis for state snapshots."""
    m=np.stack([f,r,u],axis=1);t=np.trace(m)
    if t>0:
        s=math.sqrt(1+t)*2
        q=np.array([(m[2,1]-m[1,2])/s,(m[0,2]-m[2,0])/s,
                    (m[1,0]-m[0,1])/s,.25*s])
    else:
        i=int(np.argmax(np.diag(m)));j=(i+1)%3;k=(i+2)%3
        s=math.sqrt(max(1e-8,1+m[i,i]-m[j,j]-m[k,k]))*2
        q=np.zeros(4);q[i]=s*.25;q[j]=(m[j,i]+m[i,j])/s
        q[k]=(m[k,i]+m[i,k])/s;q[3]=(m[k,j]-m[j,k])/s
    return normal_quaternion(q)


def vec(rs,v):
    return rs.Vec(x=float(v[0]),y=float(v[1]),z=float(v[2]))


def to_car_state(rs,features,flags=None):
    f=np.asarray(features,dtype=float)
    fw,ri,up=rotation_axes(f[3:7]);s=rs.CarState()
    s.pos=vec(rs,f[:3]);s.vel=vec(rs,f[7:10]);s.ang_vel=vec(rs,f[10:13])
    s.rot_mat=rs.RotMat(vec(rs,fw),vec(rs,ri),vec(rs,up))
    s.boost=float(np.clip(f[13]*100,0,100))
    # Replicar exposes causal internal car flags. Restore all fields supported
    # by the binding. Physics-only poses cannot restore timers or suspension.
    flag_fields=('is_on_ground','has_jumped','has_double_jumped','has_flipped',
                 'is_flipping','is_jumping')
    if flags is not None:
        for name,flag in zip(flag_fields,flags):
            if hasattr(s,name):
                try:setattr(s,name,bool(flag))
                except (AttributeError,TypeError):pass  # some bindings expose read-only status
        if len(flags)>=10 and hasattr(s,'wheels_with_contact'):
            try:s.wheels_with_contact=tuple(bool(v) for v in flags[6:10])
            except (AttributeError,TypeError):pass
    return s


def to_ball_state(rs,features):
    f=np.asarray(features,dtype=float)
    fw,ri,up=rotation_axes(f[3:7])
    s=rs.BallState()
    s.pos=vec(rs,f[:3]);s.vel=vec(rs,f[7:10]);s.ang_vel=vec(rs,f[10:13])
    s.rot_mat=rs.RotMat(vec(rs,fw),vec(rs,ri),vec(rs,up))
    return s


class UnsupportedHitboxError(RuntimeError):
    """A replay hitbox cannot be faithfully simulated by this RocketSim binding.

    Do not silently substitute Octane or discard this distinction during
    per-replay compatibility checks.
    """


def _hitbox_preset(rs, hitbox):
    """Find a *named* native car preset; never invent hitbox geometry.

    Different native bindings expose the same physical presets as
    ``CarConfig.dominus()``, ``CAR_CONFIG_DOMINUS``, or ``DOMINUS``.
    The final form is supported by pyrocketsim-style bindings.
    """
    if hitbox not in HITBOX_PRESETS:
        raise UnsupportedHitboxError('Unverified/non-physical hitbox: ' + str(hitbox))
    cls = getattr(rs, 'CarConfig', None)
    candidates = [
        getattr(cls, hitbox, None) if cls is not None else None,
        getattr(cls, hitbox.upper(), None) if cls is not None else None,
        getattr(cls, hitbox.capitalize(), None) if cls is not None else None,
        getattr(rs, 'CAR_CONFIG_' + hitbox.upper(), None),
        getattr(rs, hitbox.upper(), None),
    ]
    # Additional bindings call their enum CarBodyConfig.
    body = getattr(rs, 'CarBodyConfig', None)
    if body is not None:
        candidates.append(getattr(body, hitbox.upper(), None))
    for preset in candidates:
        if preset is not None:
            try:
                return preset() if callable(preset) else preset
            except (TypeError, ValueError) as exc:
                raise UnsupportedHitboxError(
                    f'{hitbox} preset is present but could not be constructed: {exc}') from exc
    return None


def configure_car(arena, rs, team, hitbox):
    preset = _hitbox_preset(rs, hitbox)
    if preset is None:
        if hitbox != 'octane':
            raise UnsupportedHitboxError(
                f'Installed RocketSim Python binding cannot set {hitbox} hitbox. '
                'This replay must be skipped until a compatible binding is available; '
                'substituting Octane would corrupt the training target.')
        # RocketSim's documented default is Octane for bindings that only
        # expose the one-argument add_car(team) signature.
        try:
            car = arena.add_car(team)
        except TypeError as exc:
            raise UnsupportedHitboxError(f'Binding cannot add Octane: {exc}') from exc
    else:
        try:
            car = arena.add_car(team, preset)
        except TypeError as exc:
            raise UnsupportedHitboxError(
                f'Binding exposes {hitbox} but add_car rejected its preset: {exc}') from exc
    if not hasattr(car, 'set_state'):
        raise UnsupportedHitboxError(
            'Binding add_car did not return a Car object with set_state; '
            'this project needs a compatible Arena adapter.')
    return car


def replay_arena(rs,state):
    """Reconstruct short tactical search world from a verified replay pose.
    WARNING: 14-feature poses omit internal suspension/flip timers and pads;
    this is approximate around flips and wall contacts. For exact replay
    continuation, use Replicar full-state or `resimulate` bridge.
    """
    from tools.native_rlviser import init_arena
    arena=init_arena(rs)
    cars=[];mode=int(state['mode'])
    for i in range(2*mode):
        team=rs.Team.BLUE if i<mode else rs.Team.ORANGE
        car=configure_car(arena,rs,team,str(state['hitboxes'][i]))
        car.set_state(to_car_state(rs,state['cars'][i],
                                   state['flags'][i] if 'flags' in state else None))
        cars.append(car)
    arena.ball.set_state(to_ball_state(rs,state['ball']))
    return arena,cars


def car_features(s):
    m=s.rot_mat
    out=np.zeros(14,dtype=np.float32)
    out[:3]=[s.pos.x,s.pos.y,s.pos.z]
    f=np.array([m.forward.x,m.forward.y,m.forward.z]);r=np.array([m.right.x,m.right.y,m.right.z]);u=np.array([m.up.x,m.up.y,m.up.z])
    out[3:7]=quaternion_from_axes(f,r,u)
    out[7:10]=[s.vel.x,s.vel.y,s.vel.z]
    out[10:13]=[s.ang_vel.x,s.ang_vel.y,s.ang_vel.z]
    out[13]=s.boost/100
    return out


def ball_features(s):return car_features_like_ball(s)


def car_features_like_ball(s):
    m=s.rot_mat
    f=np.array([m.forward.x,m.forward.y,m.forward.z]);r=np.array([m.right.x,m.right.y,m.right.z]);u=np.array([m.up.x,m.up.y,m.up.z])
    out=np.r_[[s.pos.x,s.pos.y,s.pos.z],quaternion_from_axes(f,r,u),
              [s.vel.x,s.vel.y,s.vel.z],[s.ang_vel.x,s.ang_vel.y,s.ang_vel.z]]
    return out.astype(np.float32)


def action_controls(rs,action):
    th,st,pi,ya,ro,ju,bo,ha=action
    return rs.CarControls(throttle=float(th),steer=float(st),pitch=float(pi),yaw=float(ya),
                          roll=float(ro),jump=bool(ju),boost=bool(bo),handbrake=bool(ha))


def sample_joint(rng,n,cars=None,start=0):
    """One legal 8-tick action per car. Air and wall actions are included."""
    return tuple(ACTIONS[rng.randrange(len(ACTIONS))] for _ in range(n))


def replay_conditioned_pool(rng, state, team, count, replay_ref=None):
    """Generate diverse joint actions, including replay-relevant jump/air actions.

    The reference is allowed ONLY in the *offline teacher search*, never in
    the inference policy observation. The action vocabulary is unchanged, so
    old search-controller checkpoints stay loadable.
    """
    n=int(state['mode'])
    pool=[sample_joint(rng,n) for _ in range(count)]
    if replay_ref is None:
        return pool
    _target_ball, target_cars = replay_ref
    start=0 if team==0 else n
    for k in range(min(count, 8)):
        candidate=list(pool[k])
        for slot in range(n):
            idx=start+slot
            now=np.asarray(state['cars'][idx])
            target=np.asarray(target_cars[idx])
            altitude_gain=float(target[2]-now[2])
            flags=state.get('flags')
            grounded=(bool(flags[idx,0]) if flags is not None else False) or now[2]<45
            if altitude_gain>55 and grounded:
                # Include jump, jump+boost, and delayed jump controls across
                # candidates rather than relying on random 1-in-22 coverage.
                candidate[slot]=ACTIONS[[9,10,21,9][k%4]]
            elif (altitude_gain>40 or now[2]>240) and not grounded:
                candidate[slot]=ACTIONS[[11,12,13,14,15,16,17,18][k%8]]
        pool[k]=tuple(candidate)
    return pool


@dataclass
class SearchContext:
    simulator:object
    our_team:int=0
    team_candidates:int=12
    opponent_pool:int=12
    opponent_responses:int=4
    ticks:int=16
    risk:float=0.8

    def __post_init__(self):
        if not 12<=self.team_candidates<=64:raise ValueError('team_candidates must be 12-64')
        if not 12<=self.opponent_pool<=64:raise ValueError('opponent_pool must be 12-64')
        if not 1<=self.opponent_responses<=self.opponent_pool:raise ValueError('Invalid response budget')
        if self.our_team not in (0,1):raise ValueError('our_team is 0 or 1')
        if not 1<=self.ticks<=120:raise ValueError('Invalid horizon')

    def rollout(self,state,plan,reply):
        rs=self.simulator
        arena,cars=replay_arena(rs,state)
        mode=int(state['mode'])
        if self.our_team==0:all_actions=plan+reply
        else:all_actions=reply+plan
        if len(all_actions)!=len(cars):raise ValueError('Every car requires an action')
        ctrl=[action_controls(rs,a) for a in all_actions]
        for car,act in zip(cars,ctrl):car.set_controls(act)
        arena.step(self.ticks)
        b=ball_features(arena.ball.get_state())
        c=np.asarray([car_features(x.get_state()) for x in cars])
        return dict(ball=b,cars=c,team=state['team'],hitboxes=state['hitboxes'],
                    mask=state['mask'],mode=mode)

    def search(self,state,evaluator=None,replay_ref=None,seed=None):
        """Select our joint move against worst-scoring likely opponent replies.
        Opponent pool is generated independently and all candidates are legal
        controls, but the response budget is a pruned approximation, not a
        full game-theoretic equilibrium solver.
        """
        rng=random.Random(seed)
        mode=int(state['mode'])
        # Each car takes part in 12..64 candidate *joint* team plans.
        # Screen every opponent joint candidate for every team candidate;
        # the worst responses approximate a minimax opponent. Unlike random
        # response subsampling, the best enemy response cannot be discarded.
        enemy_pool=replay_conditioned_pool(rng,state,1-self.our_team,self.opponent_pool,replay_ref)
        friendly_pool=replay_conditioned_pool(rng,state,self.our_team,self.team_candidates,replay_ref)
        def evaluate(s):
            if evaluator is not None:base=float(evaluator(s,self.our_team))
            else:
                # Weak goal direction/ball speed prior; not a calibrated chess engine.
                b=s['ball'];base=float(np.tanh((b[1]/4000+b[8]/2600)*(1 if self.our_team==0 else -1)))
            if replay_ref is not None:
                target_ball,target_cars=replay_ref
                if should_terminate(s['ball'],s['cars'],target_ball,target_cars,s['mask']):return base-5.
                base+=0.35*replay_score(s['ball'],s['cars'],target_ball,target_cars,mask=s['mask'])
            return base
        best=None
        total_rollouts=0
        for friendly in friendly_pool:
            scores=[]
            for enemy in enemy_pool:
                score=evaluate(self.rollout(state,friendly,enemy))
                scores.append(score)
                total_rollouts+=1
            scores.sort()  # low = opponent's best counter to us
            worst=float(scores[0]);mean_worst=float(np.mean(scores[:self.opponent_responses]))
            robust=self.risk*worst+(1-self.risk)*mean_worst
            if best is None or robust>best.robust_score:
                best=PlanResult(friendly,robust,mean_worst,worst,total_rollouts)
        best.num_rollouts=total_rollouts
        return best
