"""Replay-derived control options with a causal ego-frame policy and goal value."""
from pathlib import Path
import hashlib,os,tempfile
import numpy as np
import torch
from torch import nn
FEATURE_VERSION='ego221_wheelmask_v1'
TYPE='REPLAY_OPTIONS_FINAL_V420'

def rotation(q):
    q=q/np.maximum(1e-8,np.linalg.norm(q,axis=-1,keepdims=True));x,y,z,w=np.moveaxis(q,-1,0)
    return np.stack((1-2*(y*y+z*z),2*(x*y-z*w),2*(x*z+y*w),2*(x*y+z*w),1-2*(x*x+z*z),2*(y*z-x*w),2*(x*z-y*w),2*(y*z+x*w),1-2*(x*x+y*y)),axis=-1).reshape(q.shape[:-1]+(3,3))

def canonical(x):
    """Current causal state only, local car frame, group-sorted entities."""
    x=np.asarray(x,np.float32);me=x[:,26:40].copy();me[:,:3]*=6000;me[:,7:10]*=2300;me[:,10:13]*=6
    rot=rotation(me[:,3:7]);local=lambda v:np.einsum('bi,bij->bj',v,rot)
    b=x[:,:13].copy();b[:,:3]*=6000;b[:,7:10]*=6000;b[:,10:13]*=6
    mode=np.rint(x[:,-1]*3).astype(int);team=np.where(x[:,-2]>0,0,1);direction=1-2*team
    rel=x[:,40:124].reshape(-1,6,14).copy();present=x[:,124:130];relation=x[:,130:136];flags=x[:,178:238].reshape(-1,6,10)
    own=np.argmin(np.linalg.norm(rel[:,:,:3],axis=-1)+100*(1-present),axis=1);ownflags=flags[np.arange(len(x)),own]
    goal=np.zeros((len(x),3),np.float32);goal[:,1]=5120*direction;goal[:,2]=321;back=goal.copy();back[:,1]*=-1
    gravity=np.zeros_like(goal);gravity[:,2]=1
    out=[local(me[:,7:10])/2300,local(me[:,10:13])/6,local(gravity),me[:,2:3]/2044,me[:,13:14],ownflags,local(b[:,:3]-me[:,:3])/3000,local(b[:,7:10])/2300,local(b[:,7:10]-me[:,7:10])/2300,local(b[:,10:13])/6,b[:,2:3]/2044,local(goal-me[:,:3])/6000,local(back-me[:,:3])/6000,me[:,:3]*np.stack((direction,direction,np.ones(len(x))),1)/[4096,5120,2044]]
    rp=rel[:,:,:3]*6000;rv=rel[:,:,7:10]*2300
    othrot=rotation(rel[:,:,3:7]);lvec=lambda v:np.einsum('bni,bij->bnj',v,rot)
    entities=np.concatenate((lvec(rp)/6000,lvec(rv)/2300,lvec(othrot[:,:,:,0]),lvec(othrot[:,:,:,2]),lvec(rel[:,:,10:13]*6)/6,rel[:,:,13:14],present[:,:,None],flags),axis=-1)
    # No cosmetic hitbox guess: retain the verified seven-way identity.
    boxes=x[:,136:178].reshape(-1,6,7);entities=np.concatenate((entities,boxes),-1)
    for relsign,count in [(1,2),(-1,3)]:
        score=np.linalg.norm(rp,axis=-1);valid=(present>0)&(relation==relsign);valid[np.arange(len(x)),own]=False
        ids=np.argsort(np.where(valid,score,np.inf),axis=1,kind='stable')[:,:count]
        chosen=entities[np.arange(len(x))[:,None],ids];mask=valid[np.arange(len(x))[:,None],ids];out.append((chosen*mask[:,:,None]).reshape(len(x),-1))
    out.append(mode[:,None]/3);out.append(boxes[np.arange(len(x)),own])
    z=np.concatenate(out,axis=1).astype(np.float32)
    wheel=[17,18,19,20]+[b+j for b in range(43,213,34) for j in (23,24,25,26)]
    z[:,wheel]=0 # These per-wheel fields are unavailable in some RLBot packets.
    if not np.isfinite(z).all():raise ValueError('Nonfinite replay features')
    return z

def mirror_sign():
    sign=np.ones(221,np.float32);negative=[1,3,5,7,22,25,28,30,32,35,38,40]
    for base in range(43,213,34):negative += [base+i for i in (1,4,7,10,12,14)]
    sign[negative]=-1;return sign

ACTION_MIRROR=np.array([1,-1,1,-1,-1,1,1,1],np.float32)

def action_features(y):
    a=y.reshape(-1,8,4,8).mean(2).copy();a[:,:,5:]=y.reshape(-1,8,4,8)[:,:,:,5:].max(2)
    return (a*np.array([.8,1.5,1,1,1,3.5,1.5,1.5],np.float32)).reshape(len(y),-1)

class ReplayOptionsNet(nn.Module):
    def __init__(self,k):
        super().__init__();self.trunk=nn.Sequential(nn.Linear(221,256),nn.LayerNorm(256),nn.SiLU(),nn.Linear(256,256),nn.SiLU(),nn.Linear(256,256),nn.SiLU())
        self.code=nn.Linear(256,k);self.emb=nn.Embedding(k,32);self.residual=nn.Sequential(nn.Linear(288,128),nn.SiLU(),nn.Linear(128,160));self.value=nn.Linear(256,1)
    def forward(self,x):
        h=self.trunk(x);return h,self.code(h),torch.tanh(self.value(h)).flatten()
    def decode(self,h,ids,books):
        out=books[ids].clone();delta=.2*torch.tanh(self.residual(torch.cat((h,self.emb(ids)),1)).reshape(-1,32,5));out[:,:,:5]=(out[:,:,:5]+delta).clamp(-1,1);return out

class ReplayOptionsBrain:
    def __init__(self,path,ck):
        if ck.get('type')!=TYPE or ck.get('feature_version')!=FEATURE_VERSION or ck.get('steps',0)<1:raise ValueError('Not a trained final replay-options checkpoint')
        self.path=str(Path(path).resolve());self.books=ck['codebook'].float();self.mean=ck['mean'].numpy();self.std=ck['std'].numpy()
        if self.books.ndim!=3 or self.books.shape[1:]!=(32,8) or not 64<=len(self.books)<=512:raise ValueError('Invalid replay option book')
        if self.mean.shape!=(221,) or self.std.shape!=(221,) or np.any(self.std<=0):raise ValueError('Invalid feature normalization')
        if not torch.isfinite(self.books).all() or not np.isfinite(self.mean).all() or not np.isfinite(self.std).all():raise ValueError('Nonfinite checkpoint')
        if not torch.isin(self.books[:,:,5:],torch.tensor([0.,1.])).all() or self.books[:,:,:5].abs().max()>1.001:raise ValueError('Invalid replay controller options')
        self.net=ReplayOptionsNet(len(self.books)).eval();self.net.load_state_dict(ck['network']);self.net.requires_grad_(False)
        self.source='REPLAY_DERIVED_OPTIONS_WITH_GOAL_VALUE';self.validation=ck.get('validation',{});self.steps=ck['steps']
    def _input(self,obs):return torch.from_numpy((canonical(obs)-self.mean)/self.std)
    @torch.inference_mode()
    def predict_observations(self,obs):
        h,z,v=self.net(self._input(obs));return self.net.decode(h,z.argmax(1),self.books).numpy(),v.numpy()
    @torch.inference_mode()
    def modal(self,states):
        from .search_teacher import make_observation
        obs=np.stack([make_observation(s,i) for s in states for i in range(len(s['cars']))]);out,_=self.predict_observations(obs)
        return out.reshape(len(states),len(states[0]['cars']),32,8)
    @torch.inference_mode()
    def propose_team(self,state,team,count):
        from .search_teacher import make_observation
        m=int(state['mode']);plans=[]
        for player in range(team*m,(team+1)*m):
            h,z,v=self.net(self._input(make_observation(state,player)[None]));ids=z[0].topk(count).indices
            plans.append(self.net.decode(h.expand(count,-1),ids,self.books).numpy())
        result=[np.stack([plans[j][(i+3*j)%count if i else 0] for j in range(m)]) for i in range(count)]
        return result
    @torch.inference_mode()
    def team_values(self,states,team):
        from .search_teacher import make_observation
        m=int(states[0]['mode']);obs=np.stack([make_observation(s,team*m+j) for s in states for j in range(m)])
        return self.net(self._input(obs))[2].reshape(len(states),m).mean(1).numpy()

def load_brain(path):
    ck=torch.load(path,map_location='cpu',weights_only=True)
    if ck.get('type')==TYPE:return ReplayOptionsBrain(path,ck)
    from .replay_bc_v415 import ReplayBrain
    return ReplayBrain(path)

def pin_checkpoint(path,directory):
    """Read one atomic checkpoint generation, so watch/export cannot mix updates."""
    raw=Path(path).read_bytes();digest=hashlib.sha256(raw).hexdigest();directory=Path(directory);directory.mkdir(parents=True,exist_ok=True)
    dest=directory/(digest+'.pt')
    if not dest.exists():
        fd,name=tempfile.mkstemp(dir=directory,suffix='.tmp')
        try:
            with os.fdopen(fd,'wb') as f:f.write(raw);f.flush();os.fsync(f.fileno())
            load_brain(name)
            os.replace(name,dest)
        finally:
            if os.path.exists(name):os.unlink(name)
    elif hashlib.sha256(dest.read_bytes()).hexdigest()!=digest:raise ValueError('Pinned checkpoint hash mismatch')
    return dest,digest
