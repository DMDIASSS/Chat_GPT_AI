"""Frozen Galactus V2 simulator port, 1v1/2v2/3v3 padded native observations.

Source/model identity: SoldierDoge/GalactusV2 @ 217324c2fc516048effe0407595fa61c2ebc6863.
This is a simulator adapter, not a claim of identical live-game physics.
"""
from pathlib import Path
import hashlib,json,os,tempfile,urllib.request
import numpy as np
COMMIT='217324c2fc516048effe0407595fa61c2ebc6863'
HASHES={'POLICY.lt':'f31e15e118f14713ffc5d4af84ab0d8018c04f1451805f50a2e2df9d396603ed','SHARED_HEAD.lt':'a38be9da0a57141d0bf8e38bd51944f77aa04912f7912e9c4bc49f93db7285a4'}
ROOT=Path(__file__).resolve().parents[1]
# RLGymCPP order is not a y/x sort: the middle three small pads in each
# half deliberately have a different order. Match by position like upstream.
BOOST_POSITIONS=np.array([(0,-4240,70),(-1792,-4184,70),(1792,-4184,70),(-3072,-4096,73),(3072,-4096,73),(-940,-3308,70),(940,-3308,70),(0,-2816,70),(-3584,-2484,70),(3584,-2484,70),(-1788,-2300,70),(1788,-2300,70),(-2048,-1036,70),(0,-1024,70),(2048,-1036,70),(-3584,0,73),(-1024,0,70),(1024,0,70),(3584,0,73),(-2048,1036,70),(0,1024,70),(2048,1036,70),(-1788,2300,70),(1788,2300,70),(-3584,2484,70),(3584,2484,70),(0,2816,70),(-940,3310,70),(940,3308,70),(-3072,4096,73),(3072,4096,73),(-1792,4184,70),(1792,4184,70),(0,4240,70)],np.float32)
def ordered_pads(arena):
    pads=list(arena.get_boost_pads())
    if len(pads)!=34:raise ValueError('Galactus requires standard Soccar boost pads')
    pos=np.array([p.get_pos().as_tuple() for p in pads]);dist=((BOOST_POSITIONS[:,None,:2]-pos[None,:,:2])**2).sum(2);ids=dist.argmin(1)
    if len(set(ids))!=34 or np.any(dist[np.arange(34),ids]>=10):raise ValueError('Unrecognized Soccar boost pad layout')
    return [pads[i] for i in ids]
def identity(folder):
    p=Path(folder);return {n:hashlib.sha256((p/n).read_bytes()).hexdigest() for n in HASHES}
def locate():
    paths=[Path(os.environ['GALACTUS_MODELS'])] if os.environ.get('GALACTUS_MODELS') else []
    paths += [ROOT/'models/galactus_v2']
    paths += [ROOT.parent/base/n/'assets/galactus' for base in ('Chat_GPT_AI','chat_gpt_ai','') for n in ('NovaForge','novaforge')]
    for p in paths:
        if all((p/n).is_file() for n in HASHES):
            if identity(p)==HASHES:return p
            if p==paths[0] and os.environ.get('GALACTUS_MODELS'):raise ValueError('Explicit Galactus model hashes differ from the pinned V2 bot')
    raise FileNotFoundError('Pinned Galactus V2 weights not found. Run SETUP_GALACTUS.bat (existing Chat_GPT_AI/NovaForge assets are reused) or set GALACTUS_MODELS. No substitute opponent is used.')
def setup():
    try:p=locate();print('GALACTUS_REUSED:',p,flush=True);return p
    except FileNotFoundError:pass
    p=ROOT/'models/galactus_v2';p.mkdir(parents=True,exist_ok=True)
    for n,h in HASHES.items():
        dest=p/n
        if dest.exists():
            if hashlib.sha256(dest.read_bytes()).hexdigest()!=h:raise ValueError('Existing Galactus file differs; preserve it and restore separately: '+str(dest))
            continue
        print('Downloading verified Galactus V2:',n,flush=True)
        with urllib.request.urlopen(f'https://raw.githubusercontent.com/SoldierDoge/GalactusV2/{COMMIT}/rlbot/{n}',timeout=120) as r:b=r.read(32*1024**2)
        if hashlib.sha256(b).hexdigest()!=h:raise ValueError('Galactus download hash mismatch')
        temp=dest.with_suffix('.tmp');temp.write_bytes(b);os.replace(temp,dest)
    (p/'IDENTITY.json').write_text(json.dumps(dict(source_commit=COMMIT,files=HASHES,role='frozen Galactus V2 opponent'),indent=2));return p

def table():
    out=[]
    for th in (-1,0,1):
        for st in (-1,0,1):
            for bo in (0,1):
                for ha in (0,1):
                    if bo and th!=1:continue
                    out.append((th,st,0,st,0,0,bo,ha))
    for pi in (-1,0,1):
        for ya in (-1,0,1):
            for ro in (-1,0,1):
                for ju in (0,1):
                    for bo in (0,1):
                        if (ju and ya) or (pi==ro==ju==0):continue
                        out.append((bo,ya,pi,ya,ro,ju,bo,int(bool(ju and (pi or ya or ro)))))
    return np.asarray(out,np.float32)
TABLE=table()
def mask(s):
    ground=np.arange(90)<24;jump=TABLE[:,5]!=0;air=(np.arange(90)>24)&~jump
    air|=ground&(TABLE[:,0]==TABLE[:,6])&((TABLE[:,3]!=0)==(TABLE[:,7]!=0));m=(ground if s.is_on_ground else air).copy()
    if s.boost==0:m&=TABLE[:,6]==0
    flip=s.has_flip_or_jump() if callable(s.has_flip_or_jump) else s.has_flip_or_jump
    turtle=bool(s.has_world_contact and s.world_contact_normal.z>.9)
    if flip or turtle:m|=jump
    return m

def phys(s,invert):
    sign=np.array([-1,-1,1] if invert else [1,1,1],np.float32)
    rot=np.stack([s.rot_mat.forward.as_numpy(),s.rot_mat.right.as_numpy(),s.rot_mat.up.as_numpy()],1)*sign[:,None]
    return np.array(s.pos.as_tuple())*sign,np.array(s.vel.as_tuple())*sign,np.array(s.ang_vel.as_tuple())*sign,rot

def player(s,inv,ball):
    pos,vel,ang,rot=phys(s,inv);flip=s.has_flip_or_jump() if callable(s.has_flip_or_jump) else s.has_flip_or_jump
    return np.r_[pos/5000,rot[:,0],rot[:,2],vel/2300,ang/3,ang@rot/3,(ball[0]-pos)@rot/5000,(ball[1]-vel)@rot/2300,s.boost/100,s.is_on_ground,flip,s.is_demoed,s.has_jumped]

def features(arena,cars,index,previous,predictions,rng,slots=None):
    own=cars[index];inv=int(own.team)==1;s=own.get_state();ball=phys(arena.ball.get_state(),inv)
    pads=ordered_pads(arena)
    active=np.array([p.get_state().is_active for p in pads]);timers=np.array([p.get_state().cooldown for p in pads]);positions=BOOST_POSITIONS
    if inv:active=active[::-1];timers=timers[::-1]
    rel=np.zeros(3);distance=1500**2
    for i in (3,4,15,18,29,30):
        d=positions[i]-phys(s,inv)[0];dd=np.square(d[:2]).sum()
        if active[i] and dd<=distance:distance=dd;rel=d
    allies=[i for i,c in enumerate(cars) if i!=index and c.team==own.team];enemies=[i for i,c in enumerate(cars) if c.team!=own.team]
    if len(allies)>2 or len(enemies)>3:raise ValueError('Galactus supports up to 3v3')
    allies += [None]*(2-len(allies));enemies += [None]*(3-len(enemies))
    if slots is None:rng.shuffle(allies);rng.shuffle(enemies)
    else:allies,enemies=slots
    out=[ball[0]/5000,ball[1]/2300,ball[2]/3,np.asarray(previous),np.where(active,1.,1/(1+timers)),rel/5000,player(s,inv,ball)]
    out += [np.zeros(29) if i is None else player(cars[i].get_state(),inv,ball) for i in allies+enemies]
    pred=predictions.copy()
    if inv:pred*=np.array([-1,-1,1,-1,-1,1])
    pred[:,:3]/=5000;pred[:,3:]/=2300;out.append(pred.ravel());x=np.concatenate(out).astype(np.float32)
    if x.shape!=(258,) or not np.isfinite(x).all():raise ValueError('Invalid Galactus observations')
    return x

class GalactusTeam:
    def __init__(self,arena,cars,team=1,seed=416):
        import torch
        from torch import nn
        self.torch=torch;torch.set_num_threads(1);self.path=locate();self.identity=identity(self.path);self.team=team;self.rng=np.random.default_rng(seed)
        def seq(name,widths,first,output=None):
            layers=[]
            for w in widths:layers.extend([nn.Linear(first,w),nn.LayerNorm(w),nn.LeakyReLU()]);first=w
            if output:layers.append(nn.Linear(first,output))
            net=nn.Sequential(*layers);archive=torch.jit.load(str(self.path/name),map_location='cpu');net.load_state_dict(dict(archive.named_parameters()),strict=True);return net.eval().requires_grad_(False)
        self.head=seq('SHARED_HEAD.lt',[1024,1024],258);self.policy=seq('POLICY.lt',[1024]*4,1024,90);self.reset(arena,cars)
    def reset(self,arena,cars):
        self.own=[i for i,c in enumerate(cars) if int(c.team)==self.team];self.previous={i:np.zeros(8,np.float32) for i in self.own};self.held={i:np.zeros(8,np.float32) for i in self.own};self.pending=None;self.origin=int(arena.tick_count);self.pred_tick=None
    def commands(self,arena,cars):
        tick=int(arena.tick_count);relative=tick-self.origin
        if relative%8==0:
            if self.pred_tick is None or tick-self.pred_tick>=32:
                states=arena.get_ball_prediction(273,1)
                # Binding predictions start at current state (verified in tests).
                self.pred=np.array([[*b.pos.as_tuple(),*b.vel.as_tuple()] for b in states]);self.pred_tick=tick
            age=tick-self.pred_tick;pred=self.pred[np.array([30,60,120,180,240])+age]
            x=np.stack([features(arena,cars,i,self.previous[i],pred,self.rng) for i in self.own])
            with self.torch.inference_mode():z=self.policy(self.head(self.torch.from_numpy(x))).numpy()
            actions={i:TABLE[np.where(mask(cars[i].get_state()),z[j],-np.inf).argmax()].copy() for j,i in enumerate(self.own)}
            self.previous={i:a.copy() for i,a in actions.items()};self.pending=(tick+7,actions)
        if self.pending is not None and tick>=self.pending[0]:self.held=self.pending[1];self.pending=None
        return [tuple(float(v) for v in self.held[i]) for i in self.own]
