@echo off
setlocal
cd /d "%~dp0"
echo Test fallback ball contact in native physics. This does not test the trained neural policy.
".venv\Scripts\python.exe" -u -m tools.check_ball_contact_v419
if errorlevel 1 echo CONTACT_CHECK_FAILED - run menu 9 and keep the output above.
pause
