"""Explicit deployment gate: a runnable geometric diagnostic is not a trained bot."""
from pathlib import Path
def require_brain(root,allow_geometric=False,model=None):
    root=Path(root).resolve();path=Path(model) if model is not None else root/'models/v415_replay_brain.pt'
    if not path.is_absolute():path=root/path
    if not path.is_file():
        if allow_geometric:
            print('UNTRAINED_DIAGNOSTIC: no replay brain; geometric controls only. Watching does not train.',flush=True);return None
        if model is not None:raise ValueError('NO_TRAINED_REPLAY_BRAIN at '+str(path)+'. Run START_REPLAY_TRAINING_FINAL.bat and wait for the first saved best validation checkpoint.')
        raise ValueError('NO_TRAINED_REPLAY_BRAIN: models/v415_replay_brain.pt is missing. Run menu 4 to prepare train/validation data, then menu 6 for supervised training. Wait for health_ready=True before watching or exporting. --allow-geometric is only for explicit diagnostic use.')
    from src.replay_final import load_brain
    brain=load_brain(path)
    print('TRAINED_REPLAY_BRAIN:',path,'validation:',brain.validation,'Playing strength is unverified.',flush=True)
    if brain.validation.get('greedy_jump_rate',1)<.005:
        print('LOW_JUMP_POLICY: the saved validation metrics report very few policy jump commands. Run AUDIT_REPLAY_POLICY.bat; the legacy health flag does not establish good imitation.',flush=True)
    return brain
