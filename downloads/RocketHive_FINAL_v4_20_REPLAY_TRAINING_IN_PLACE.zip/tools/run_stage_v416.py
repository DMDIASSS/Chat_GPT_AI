"""Capture stages 1-6 as they are requested; report generation never runs them."""
from pathlib import Path
import argparse,datetime,json,os,subprocess,sys,time
from tools.report_hive_v415 import scrub
ROOT=Path(__file__).resolve().parents[1]
COMMANDS={1:['tools.verify_hive_v415'],2:['tools.setup_match_v416'],3:['tools.watch_hive_v415','--seconds','0','--mode','2','--opponent','galactus'],4:['tools.prepare_replay_training_v417','--max-files','32','--minutes','20'],5:['tools.prepare_chunks_v415','build'],6:['tools.train_replay_brain_v415']}

def execute(stage,command=None,root=None):
    root=Path(root or ROOT);folder=root/'reports/v416_stages';folder.mkdir(parents=True,exist_ok=True)
    ident=f'{time.time_ns()}_step_{stage}';log=folder/(ident+'.log');status=folder/(ident+'.json')
    cmd=command or [sys.executable,'-u','-m',*COMMANDS[stage]]
    info=dict(stage=stage,status='running',command=cmd,python=sys.executable,started_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),log=log.name)
    def save():
        temp=status.with_suffix('.tmp');temp.write_text(json.dumps(scrub(info),indent=2),encoding='utf8');os.replace(temp,status)
    save();code=1
    try:
        with log.open('w',encoding='utf8') as f:
            env=dict(os.environ,PYTHONIOENCODING='utf-8',PYTHONUNBUFFERED='1')
            p=subprocess.Popen(cmd,cwd=root,env=env,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True,encoding='utf8',errors='replace',bufsize=1)
            info['pid']=p.pid;save()
            while True:
                try:
                    line=p.stdout.readline()
                    if line:line=scrub(line);print(line,end='',flush=True);f.write(line);f.flush()
                    elif p.poll() is not None:break
                except KeyboardInterrupt:
                    if stage==6:(root/('STOP_REPLAY_FINAL' if 'tools.train_replay_final' in cmd else 'STOP_REPLAY_BC')).touch()
                    print('Stop requested. Waiting for child cleanup/checkpoint.',flush=True)
            code=p.wait()
        info.update(status='completed' if code==0 else 'failed',exit_code=code)
    except Exception as e:info.update(status='failed',error=type(e).__name__+': '+str(e));print(info['error'],flush=True)
    finally:info['finished_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat();save();print('STAGE_LOG:',log,flush=True)
    return code
if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--stage',required=True,type=int,choices=range(1,7));p.add_argument('--research-pool',action='store_true');p.add_argument('--final-replay',action='store_true');a=p.parse_args()
    if a.research_pool and a.stage!=4:p.error('--research-pool is a preparation stage')
    command=[sys.executable,'-u','-m','tools.prepare_research_pool_v419','--max-files','96','--minutes','30'] if a.research_pool else None
    if a.final_replay:
        if a.stage==6:command=[sys.executable,'-u','-m','tools.train_replay_final','--continuous','--device','auto']
        elif a.stage==3:command=[sys.executable,'-u','-m','tools.watch_hive_v415','--model','runs/replay_final/best_validation.pt','--mode','2','--seconds','0']
        else:p.error('--final-replay supports training stage 6 or watch stage 3')
    raise SystemExit(execute(a.stage,command=command))
