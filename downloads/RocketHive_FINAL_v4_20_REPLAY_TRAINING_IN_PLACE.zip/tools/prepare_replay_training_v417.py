"""Bounded preparation of existing whole-replay hash partitions, never training.

Selection depends on replay hash and missing split counts, not match outcomes.
Existing test assignments and datasets are preserved. No frame-level reshuffle.
"""
from pathlib import Path
import argparse,collections,hashlib,json,time
from src.dataset import dataset_split
from tools.report_hive_v415 import chunks

TARGETS={'train':24,'val':4,'test':2}
def split_summary(root):
    return {s:chunks(Path(root)/'data/v415_chunks'/s,24000 if s=='train' else 6000) for s in TARGETS}

def readiness(summary):
    issues=[]
    for split,files,rows,known in [('train',2,256,32),('val',2,64,16)]:
        s=summary[split]
        if s['usable_files']<files or s['training_cap_rows']<rows or s['known_values_within_cap']<known:
            issues.append(f'{split}: need {files} files/{rows} rows/{known} known values; have {s["usable_files"]}/{s["training_cap_rows"]}/{s["known_values_within_cap"]}')
    return issues

def index_replays(root):
    groups={s:[] for s in TARGETS};seen=set()
    for p in sorted((Path(root)/'replays').rglob('*.replay')):
        with p.open('rb') as f:h=hashlib.file_digest(f,'sha256').hexdigest()
        if h in seen:continue
        seen.add(h);groups[dataset_split(h)].append((p,h))
    return groups

def next_replay(groups,summary,attempted,targets):
    missing=[s for s in targets if summary[s]['usable_files']<targets[s] or (s in ('train','val') and any(x.startswith(s+':') for x in readiness(summary)))]
    # Fill absent validation before spending the budget on more training data.
    missing.sort(key=lambda s:(s!='val',summary[s]['usable_files']/max(1,targets[s])))
    for s in missing:
        for p,h in groups[s]:
            if h not in attempted:return s,p,h
    return None

def prepare(root='.',max_files=32,minutes=20,targets=None):
    root=Path(root).resolve();targets=dict(targets or TARGETS)
    if max_files<=0 or minutes<=0:raise ValueError('Preparation budgets must be positive')
    if (root/'models/v415_training_state.pt').exists():
        raise ValueError('An optimizer checkpoint already exists. Dataset preparation is locked to preserve exact resume. Use menu 6 to resume; use a separate project copy for a changed dataset.')
    import replicar
    from src.replicar_dataset import find_meshes
    from src.replay_chunks_v415 import build
    from tools.prepare_chunks_v415 import convert_one
    meshes=find_meshes(root)
    if not meshes:raise ValueError('REPLICAR_MESHES must point to existing Soccar collision meshes')
    deadline=time.monotonic()+minutes*60;groups=index_replays(root);rows=[];attempted=set()
    # Recover sidecars for existing raw-hash-named converted files first.
    for items in groups.values():
        for p,h in items:
            dest=root/'replicar_120hz'/(h+'.parquet')
            if dest.is_file():convert_one(root,p,meshes,replicar.convert)
    if any((root/'replicar_120hz').glob('*.parquet')):build(root)
    summary=split_summary(root)
    # Do not reconvert accepted or previously rejected converted games on each
    # invocation: their saved chunk-import evidence explains the rejection.
    for s,items in groups.items():
        for p,h in items:
            if (root/'replicar_120hz'/(h+'.parquet')).is_file():attempted.add(h)
    try:
        while len(rows)<max_files and time.monotonic()<deadline:
            choice=next_replay(groups,summary,attempted,targets)
            if choice is None:break
            split,p,h=choice;attempted.add(h)
            print('PREPARE',split,'replay',len(rows)+1,'/',max_files,p.name,flush=True)
            row=dict(source=str(p.relative_to(root)),replay_sha256=h,assigned_split=split)
            try:
                dest=convert_one(root,p,meshes,replicar.convert);result=build(root,limit=1024,paths=[dest])
                row.update(result[0] if result else dict(status='rejected',reason='No build result'))
            except Exception as e:row.update(status='rejected',reason=type(e).__name__+': '+str(e))
            rows.append(row);summary=split_summary(root)
            print('PREPARE_COUNTS',{s:v['usable_files'] for s,v in summary.items()},row.get('status'),row.get('reason',''),flush=True)
    except KeyboardInterrupt:print('PREPARATION_PAUSED: completed conversions and chunks preserved',flush=True)
    finally:
        if any((root/'replicar_120hz').glob('*.parquet')):build(root)
        summary=split_summary(root);issues=readiness(summary)
        report=dict(version='v4.17',targets=targets,unique_raw_replays_by_split={s:len(v) for s,v in groups.items()},attempts=rows,summary=summary,training_requirements_met=not issues,issues=issues,training_started=False,deadline_checked_between_replays=True,split_definition='Existing dataset_split(raw_replay_sha256); no files moved between partitions')
        folder=root/'reports';folder.mkdir(exist_ok=True);(folder/'v415_preparation.json').write_text(json.dumps(report,indent=2),encoding='utf8')
    for split in TARGETS:
        s=summary[split];print('DATA',split,s['usable_files'],'files',s['training_cap_rows'],'rows',s['known_values_within_cap'],'known values',flush=True)
    print('DATA_READY_FOR_PILOT_TRAINING' if not issues else 'DATA_NOT_READY: '+'; '.join(issues),flush=True)
    print('No training was started. Minimum readiness is not evidence of playing strength.',flush=True)
    return report

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--max-files',type=int,default=32);p.add_argument('--minutes',type=float,default=20);a=p.parse_args()
    r=prepare(max_files=a.max_files,minutes=a.minutes)
    raise SystemExit(0 if r['training_requirements_met'] else 2)
