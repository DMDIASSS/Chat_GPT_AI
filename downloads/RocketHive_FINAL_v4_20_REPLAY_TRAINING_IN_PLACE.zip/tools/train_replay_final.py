"""Continuous, resumable replay-only control-option imitation and goal-value fitting."""
from pathlib import Path
import argparse,hashlib,json,os,shutil,signal,tempfile,time
import numpy as np
import torch
from torch import nn
from src.replay_final import TYPE,FEATURE_VERSION,ReplayOptionsNet,canonical,mirror_sign,ACTION_MIRROR,action_features
from src.replay_final_data import load_pool,audit_parquets
from src.hive_runtime_v415 import TeamLock
from tools.audit_replay_policy_v418 import action_metrics

def atomic_save(path,obj):
    path=Path(path);path.parent.mkdir(parents=True,exist_ok=True);fd,name=tempfile.mkstemp(dir=path.parent,suffix='.tmp')
    try:
        with os.fdopen(fd,'wb') as f:torch.save(obj,f);f.flush();os.fsync(f.fileno())
        for retry in range(8):
            try:os.replace(name,path);break
            except PermissionError:
                if retry==7:raise
                time.sleep(.1)
    finally:
        if os.path.exists(name):os.unlink(name)

def make_book(actions,k=256,seed=420):
    rng=np.random.default_rng(seed);n=min(16384,len(actions));ix=rng.choice(len(actions),n,replace=False);samples=actions[ix].copy();samples[::2]*=ACTION_MIRROR
    x=torch.from_numpy(action_features(samples));k=min(k,len(x));centres=x[torch.randperm(len(x),generator=torch.Generator().manual_seed(seed))[:k]].clone()
    for iteration in range(16):
        distance=(x.square().sum(1)[:,None]+centres.square().sum(1)[None]-2*x@centres.T).clamp_min(0);ids=distance.argmin(1);count=torch.bincount(ids,minlength=k);sums=torch.zeros_like(centres);sums.index_add_(0,ids,x);centres=sums/count.clamp_min(1)[:,None]
        missing=count==0
        if missing.any():centres[missing]=x[distance.min(1).values.topk(int(missing.sum())).indices]
        if iteration%4==0:print('BUILD_REPLAY_OPTIONS',iteration+1,'/16',flush=True)
    dist=x.square().sum(1)[:,None]+centres.square().sum(1)[None]-2*x@centres.T;book=samples[dist.argmin(0).numpy()]
    _,unique=np.unique(np.round(action_features(book),4),axis=0,return_index=True);book=book[np.sort(unique)]
    if len(book)<64:
        known={tuple(v) for v in np.round(action_features(book),4)};extra=list(book)
        for sample,key in zip(samples,np.round(action_features(samples),4)):
            t=tuple(key)
            if t not in known:known.add(t);extra.append(sample)
            if len(extra)>=64:break
        book=np.asarray(extra,np.float32)
    if len(book)<64:raise ValueError('Fewer than 64 distinct replay action options; more varied tick-level replay data is required')
    return torch.from_numpy(book.copy())

def assign(actions,book):
    x=torch.from_numpy(action_features(actions));b=torch.from_numpy(action_features(book.numpy()));bn=b.square().sum(1);result=[]
    for lo in range(0,len(x),2048):
        a=x[lo:lo+2048];result.append((a.square().sum(1)[:,None]+bn[None]-2*a@b.T).argmin(1))
    return torch.cat(result)

def score_metrics(metrics):
    return float(np.mean(metrics['axis_mae'])+.2*(1-metrics['buttons']['jump']['f1'])+.1*(1-metrics['buttons']['boost']['f1']))

def validate(net,book,val,mean,std,device):
    x,y,v,known=val;z=torch.from_numpy((canonical(x)-mean)/std);pred=[];values=[];choices=[];net.eval()
    with torch.inference_mode():
        for lo in range(0,len(z),256):
            h,logits,value=net(z[lo:lo+256].to(device));ids=logits.argmax(1);pred.append(net.decode(h,ids,book).cpu().numpy());values.append(value.cpu().numpy());choices.append(ids.cpu().numpy())
    p=np.concatenate(pred);values=np.concatenate(values);modes=np.rint(x[:,-1]*3).astype(int);per={};scores=[]
    for m in np.unique(modes):
        ix=modes==m;a=action_metrics(p[ix,:8],y[ix,:8]);a['samples']=int(ix.sum());per[str(m)]=a;scores.append(score_metrics(a))
    result=dict(samples=len(x),first8=action_metrics(p[:,:8],y[:,:8]),full_chunk=action_metrics(p,y),by_mode=per,unique_options=int(len(np.unique(np.concatenate(choices)))),value_mse=float(np.square(values[known]-v[known]).mean()),zero_value_mse=float(np.square(v[known]).mean()))
    result['selection_loss']=float(np.mean(scores)+.1*result['value_mse']);net.train();return result

def remote_logger(root):
    # Resume only the user's existing bound run. No key prompts or new runs.
    binding=root/'reports/wandb_run_binding.json'
    if not binding.exists():return None
    try:
        import wandb
        from src.wandb_resume_v45 import load_binding
        b=load_binding(binding);token=os.environ.get('WANDB_API_KEY')
        if not token:
            from tools.credentials_popup import load_saved_tokens
            saved=load_saved_tokens();token=saved[1] if saved else None
        if not token:return None
        os.environ['WANDB_API_KEY']=token
        return wandb.init(project=b['project'],entity=b['entity'],id=b['run_id'],resume='must',settings=wandb.Settings(init_timeout=10))
    except Exception as e:print('REMOTE_METRICS_UNAVAILABLE:',type(e).__name__,'local metrics continue',flush=True);return None

def ensure_pool(root,pool):
    for split in ('train','val','test'):
        out=pool/split;out.mkdir(parents=True,exist_ok=True)
        for p in (root/'data/replay419'/split).glob('*.npz'):
            target=out/p.name
            if not target.exists():shutil.copy2(p,target)
    if not list((pool/'train').glob('*.npz')) or not list((pool/'val').glob('*.npz')):
        from tools.prepare_research_pool_v419 import prepare
        prepare(root,max_files=96,minutes=30,pool=pool)

def train(root='.',pool=None,updates=4000,continuous=False,device='auto',books=256,batch=256,ingest=True,legacy=True,remote=True,validation_every=500):
    root=Path(root).resolve();root.mkdir(parents=True,exist_ok=True);pool=Path(pool).resolve() if pool else root/'data/replay_final';run=root/'runs/replay_final';run.mkdir(parents=True,exist_ok=True)
    lock=TeamLock(run/'training.lock')
    if not lock.acquire():raise ValueError('The final replay trainer is already running')
    stop=root/'STOP_REPLAY_FINAL';stop.unlink(missing_ok=True);previous=signal.signal(signal.SIGINT,lambda *_:stop.touch());wb=None
    torch.set_num_threads(1);torch.manual_seed(420);rng=np.random.default_rng(420)
    device=torch.device('cuda' if device=='auto' and torch.cuda.is_available() else 'cpu' if device=='auto' else device)
    reports=root/'reports';reports.mkdir(exist_ok=True);step=0;best=float('inf');assets=None;net=None;opt=None;validation={};info={};plateau=0;hashes={}
    statefile=run/'training_state.pt'
    def packet():
        return dict(type=TYPE,feature_version=FEATURE_VERSION,steps=step,network={k:v.detach().cpu() for k,v in net.state_dict().items()},codebook=assets['codebook'],mean=assets['mean'],std=assets['std'],validation=validation,options_source='Actual reconstructed training-replay chunks and valid lateral reflections',playing_strength_verified=False)
    def save():
        if net is None:return
        p=packet();atomic_save(run/'latest.pt',p);atomic_save(statefile,dict(type='REPLAY_FINAL_TRAINING_STATE',model=p,optimizer=opt.state_dict(),assets=assets,step=step,best=best,plateau=plateau,rng=rng.bit_generator.state,train_manifest=hashes['train']))
    try:
        print('FINAL_REPLAY_TRAINER:',device,'continuous:',continuous,'No self-play or live-game training.',flush=True)
        ensure_pool(root,pool)
        try:audit_parquets(root)
        except Exception as e:print('PARQUET_AUDIT_UNAVAILABLE:',type(e).__name__,flush=True)
        ck=torch.load(statefile,map_location='cpu',weights_only=True) if statefile.exists() else None
        assets=ck['assets'] if ck else torch.load(run/'assets.pt',map_location='cpu',weights_only=True) if (run/'assets.pt').exists() else None
        tr,va,hashes,info=load_pool(pool,validation=assets['validation_files'] if assets else None)
        if len(tr[0])<256 or len(va[0])<64 or tr[3].sum()<32 or va[3].sum()<16:raise ValueError('Insufficient active replay examples or known next-goal labels')
        if ck:
            for name,h in ck['train_manifest'].items():
                if hashes['train'].get(name)!=h:raise ValueError('A previously used training file changed or disappeared; original checkpoint preserved')
        z=canonical(tr[0]);sign=mirror_sign()
        if assets is None:
            print('INITIAL_DATA:',info,flush=True);book=make_book(tr[1],books);normal=np.concatenate((z,z*sign));mean=normal.mean(0);std=np.maximum(normal.std(0),.15)
            assets=dict(feature_version=FEATURE_VERSION,codebook=book,mean=torch.from_numpy(mean),std=torch.from_numpy(std),validation_files=hashes['validation'],fixed_option_book=True)
            atomic_save(run/'assets.pt',assets)
        if assets['feature_version']!=FEATURE_VERSION:raise ValueError('Feature contract changed; do not resume incompatible experiments')
        mean=assets['mean'].numpy();std=assets['std'].numpy();net=ReplayOptionsNet(len(assets['codebook'])).to(device);opt=torch.optim.AdamW(net.parameters(),lr=3e-4,weight_decay=1e-4)
        if ck:
            net.load_state_dict(ck['model']['network']);opt.load_state_dict(ck['optimizer']);step=int(ck['step']);best=float(ck['best']);rng.bit_generator.state=ck['rng'];validation=ck['model'].get('validation',{});print('RESUMED_STEP:',step,flush=True)
        book=assets['codebook'].to(device);end=step+updates;started=time.monotonic();since=step;lr=float(opt.param_groups[0]['lr']);plateau=int(ck.get('plateau',0)) if ck else 0
        x=y=v=known=labels=mirrored=weights=stationary=kickoff=aux_x=aux_v=None
        def prepare_tensors():
            nonlocal x,y,v,known,labels,mirrored,weights,stationary,kickoff,aux_x,aux_v,z
            z=canonical(tr[0]);x=torch.from_numpy((z-mean)/std);y=torch.from_numpy(tr[1]);v=torch.from_numpy(tr[2]);known=torch.from_numpy(tr[3]);labels=assign(tr[1],assets['codebook']);mirrored=assign(tr[1]*ACTION_MIRROR,assets['codebook'])
            count=torch.bincount(torch.cat((labels,mirrored)),minlength=len(book)).float();weights=(2*len(labels)/len(book)/count.clamp_min(1)).pow(.25).clamp(.5,3).to(device)
            stationary=np.flatnonzero(np.linalg.norm(z[:,:3]*2300,axis=1)<300);raw=tr[0];kickoff=np.flatnonzero((np.linalg.norm(raw[:,:2]*6000,axis=1)<80)&(np.linalg.norm(raw[:,7:10]*6000,axis=1)<30)&(np.linalg.norm(z[:,:3]*2300,axis=1)<300))
            aux_x=aux_v=None
            if legacy:
                try:
                    from tools.cache_legacy_values_final import load
                    aux=load(root)
                    if aux is not None:aux_x=torch.from_numpy((canonical(aux[0])-mean)/std);aux_v=torch.from_numpy(aux[1])
                except Exception as e:print('LEGACY_VALUE_CACHE_UNAVAILABLE:',type(e).__name__,flush=True)
        if legacy:
            try:
                from tools.cache_legacy_values_final import cache
                cache(root,8,stop)
            except Exception as e:print('LEGACY_VALUE_PREPARATION_UNAVAILABLE:',type(e).__name__,flush=True)
        prepare_tensors();tsign=torch.from_numpy(sign);shift=torch.from_numpy((mean*sign-mean)/std);asign=torch.from_numpy(ACTION_MIRROR)
        if remote:wb=remote_logger(root)
        while not stop.exists() and (continuous or step<end):
            quarter=batch//8;ids=[rng.integers(len(x),size=batch-2*quarter)]
            for collection in (stationary,kickoff):ids.append(rng.choice(collection if len(collection) else np.arange(len(x)),quarter))
            ix=torch.from_numpy(np.concatenate(ids));flip=torch.from_numpy(rng.random(len(ix))<.5);xx=x[ix].clone();xx[flip]=xx[flip]*tsign+shift;yy=y[ix].clone();yy[flip]*=asign;target=torch.where(flip,mirrored[ix],labels[ix]).to(device)
            h,logits,value=net(xx.to(device));prediction=net.decode(h,target,book);km=known[ix].to(device);vv=v[ix].to(device)
            value_loss=(value[km]-vv[km]).square().mean() if km.any() else value.sum()*0
            loss=nn.functional.cross_entropy(logits,target,weight=weights,label_smoothing=.01)+2*(prediction[:,:,:5]-yy[:,:,:5].to(device)).square().mean()+.25*value_loss
            if aux_x is not None:
                j=torch.from_numpy(rng.integers(len(aux_x),size=min(128,batch)));av=net(aux_x[j].to(device))[2];loss=loss+.1*(av-aux_v[j].to(device)).square().mean()
            if not torch.isfinite(loss):raise ValueError('Nonfinite replay training loss; last checkpoint preserved')
            opt.zero_grad(set_to_none=True);loss.backward();nn.utils.clip_grad_norm_(net.parameters(),1);opt.step();step+=1
            if step%100==0:print('REPLAY_UPDATE',step,'loss',round(float(loss.detach().cpu()),4),'examples/s',round((step-since)*batch/max(.001,time.monotonic()-started)),flush=True)
            if step%validation_every==0 or (not continuous and step==end):
                validation=validate(net,book,va,mean,std,device);improved=validation['selection_loss']<best
                if improved:best=validation['selection_loss'];atomic_save(run/'best_validation.pt',packet());plateau=0
                else:plateau+=1
                if plateau>=10:
                    lr=max(1e-5,lr*.7)
                    for g in opt.param_groups:g['lr']=lr
                    plateau=0
                status=dict(state='training',step=step,device=str(device),best_validation_loss=best,validation=validation,data=info,option_count=len(book),best_model=str(run/'best_validation.pt'),latest_model=str(run/'latest.pt'),continuous=continuous,training_source='parsed replay controls only; legacy lower-rate states are value-only',playing_strength_verified=False)
                (reports/'v415_final_status.json').write_text(json.dumps(status,indent=2),encoding='utf8')
                with (reports/'v415_final_metrics.jsonl').open('a',encoding='utf8') as f:f.write(json.dumps(status)+'\n')
                print('REPLAY_VALIDATION',step,'loss',round(validation['selection_loss'],4),'jump_F1',round(validation['first8']['buttons']['jump']['f1'],3),'options used',validation['unique_options'],'best updated',improved,flush=True)
                if wb:
                    try:wb.log({'replay_final/updates':step,'replay_final/validation_loss':validation['selection_loss'],'replay_final/jump_f1':validation['first8']['buttons']['jump']['f1'],'replay_final/steering_mae':validation['first8']['axis_mae'][1],'replay_final/value_mse':validation['value_mse'],'replay_final/option_usage':validation['unique_options']})
                    except Exception:wb=None;print('Remote logging stopped; local metrics continue.',flush=True)
                save()
            elif step%250==0:save()
            if continuous and ingest and step%4000==0 and not stop.exists():
                save();print('INGEST_MORE_REPLAYS: checkpoint saved; validation games stay fixed',flush=True)
                try:
                    from tools.prepare_research_pool_v419 import prepare
                    prepare(root,max_files=4,minutes=3,targets={'train':999999,'val':len(assets['validation_files']),'test':2},pool=pool,stop_path=stop)
                    new_tr,new_va,new_hashes,new_info=load_pool(pool,validation=assets['validation_files'])
                    for name,hsh in hashes['train'].items():
                        if new_hashes['train'].get(name)!=hsh:raise ValueError('An existing training file changed during ingestion')
                    tr,va,hashes,info=new_tr,new_va,new_hashes,new_info
                    if legacy:
                        from tools.cache_legacy_values_final import cache
                        cache(root,8,stop)
                    prepare_tensors()
                except Exception as e:print('INGESTION_UNAVAILABLE:',type(e).__name__,str(e),'continuing with the existing replay pool',flush=True)
        save()
        status_path=reports/'v415_final_status.json'
        status=json.loads(status_path.read_text()) if status_path.exists() else {}
        status.update(state='paused' if stop.exists() else 'budget_complete',step=step,best_validation_loss=best,best_model=str(run/'best_validation.pt'),playing_strength_verified=False)
        status_path.write_text(json.dumps(status,indent=2),encoding='utf8')
        print('REPLAY_FINAL_PAUSED: complete optimizer and checkpoints saved at',run,flush=True)
        return dict(step=step,best=best,run=str(run),validation=validation)
    finally:
        signal.signal(signal.SIGINT,previous);lock.close()
        if wb:
            try:wb.finish()
            except Exception:pass

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--root',default='.');p.add_argument('--pool');p.add_argument('--updates',type=int,default=4000);p.add_argument('--continuous',action='store_true');p.add_argument('--device',choices=['auto','cpu','cuda'],default='auto');p.add_argument('--books',type=int,default=256);p.add_argument('--no-ingest',action='store_true');p.add_argument('--no-legacy',action='store_true');p.add_argument('--no-remote',action='store_true');p.add_argument('--validation-every',type=int,default=500);a=p.parse_args()
    if a.updates<=0 or not 64<=a.books<=512 or a.validation_every<=0:p.error('Positive update/evaluation budgets and 64–512 options required')
    train(a.root,a.pool,a.updates,a.continuous,a.device,a.books,ingest=not a.no_ingest,legacy=not a.no_legacy,remote=not a.no_remote,validation_every=a.validation_every)
