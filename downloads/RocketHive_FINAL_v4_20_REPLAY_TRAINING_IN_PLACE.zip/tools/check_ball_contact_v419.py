"""Native regression of the geometric fallback, not trained-policy evaluation."""
from pathlib import Path
import argparse,json,math
import numpy as np

def run(cases=24,seed=419031):
    import RocketSim as rs
    from tools.watch_bot_rlviser import make_match
    from src.live_hive_v415 import snapshot,safe_drive
    from src.physics_search import action_controls
    rng=np.random.default_rng(seed);worlds=[];rosters=[];teams=[]
    for i in range(cases):
        arena,cars=make_match(rs,1);team=i%2;d=1-2*team;s=cars[team].get_state()
        s.pos=rs.Vec(float(rng.uniform(-1800,1800)),float(-d*rng.uniform(1800,3500)),17.5);yaw=float(rng.uniform(-math.pi,math.pi));s.rot_mat=rs.RotMat(rs.Vec(math.cos(yaw),math.sin(yaw),0),rs.Vec(-math.sin(yaw),math.cos(yaw),0),rs.Vec(0,0,1));s.boost=70;cars[team].set_state(s)
        other=cars[1-team].get_state();other.pos=rs.Vec(3500,4500*d,17.5);cars[1-team].set_state(other)
        arena.ball.set_state(rs.BallState(pos=rs.Vec(float(rng.uniform(-1700,1700)),float(rng.uniform(-400,400)),93)))
        worlds.append(arena);rosters.append(cars);teams.append(team)
    hit=np.zeros(cases,bool)
    for tick in range(8*120):
        if tick%8==0:
            commands=[safe_drive(snapshot(a,c,dict(mode=1,hitboxes=['octane']*2)),t) for a,c,t in zip(worlds,rosters,teams)]
        for cars,team,a in zip(rosters,teams,commands):cars[team].set_controls(action_controls(rs,a));cars[1-team].set_controls(rs.CarControls())
        rs.Arena.multi_step(worlds,1)
        for i,(cars,t) in enumerate(zip(rosters,teams)):hit[i]|=bool(cars[t].get_state().ball_hit_info.is_valid)
    result=dict(version='v4.19',controller='GEOMETRIC_FALLBACK_CONTACT_REGRESSION',seed=seed,cases=cases,hits=int(hit.sum()),hit_fraction=float(hit.mean()),physics_seconds_per_case=8,learned_policy_evaluated=False,playing_strength_verified=False)
    folder=Path('reports');folder.mkdir(exist_ok=True);(folder/'v415_contact_probe.json').write_text(json.dumps(result,indent=2));print('FALLBACK_CONTACT_RESULT:',result,flush=True);return result
if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--cases',type=int,default=24);p.add_argument('--seed',type=int,default=419031);a=p.parse_args()
    if not 2<=a.cases<=128:p.error('Use 2–128 cases')
    r=run(a.cases,a.seed);raise SystemExit(0 if r['hit_fraction']>=.9 else 2)
