"""Optional value-only reuse of lower-rate Replicar files with proven raw identity."""
from pathlib import Path
import hashlib,json
import numpy as np

def cache(root,max_files=8,stop=None):
    import replicar
    from src.dataset import dataset_split
    from src.replicar_dataset import normalize_arrays,read_catalog,verified_players
    from src.hitboxes import load_overrides
    from src.search_teacher import replay_state,make_observation
    root=Path(root).resolve();folder=root/'replicar_parquet';out=root/'runs/replay_final/value_cache';out.mkdir(parents=True,exist_ok=True);record=out/'attempts.json'
    tried=json.loads(record.read_text()) if record.exists() else {};manifest=json.loads((folder/'manifest.json').read_text()) if (folder/'manifest.json').exists() else {}
    catalog=read_catalog(root);overrides=load_overrides(root/'replays/hitboxes.csv');count=0
    for p in sorted(folder.glob('*.parquet')):
        if p.name in tried:continue
        if count>=max_files or (stop is not None and Path(stop).exists()):break
        count+=1
        try:
            relative=manifest.get(p.stem)
            if not isinstance(relative,str):raise ValueError('No verified raw-replay mapping in legacy manifest')
            raw=(root/'replays'/relative).resolve()
            if not raw.is_relative_to((root/'replays').resolve()) or not raw.is_file():raise ValueError('Legacy raw-replay mapping is unavailable')
            with raw.open('rb') as f:group=hashlib.file_digest(f,'sha256').hexdigest()
            if dataset_split(group)!='train':tried[p.name]='excluded_holdout';continue
            target=out/(group+'.npz')
            if target.exists():tried[p.name]='cached';continue
            f=replicar.read(p);players=verified_players(f.header,relative,overrides,catalog)
            if any(q['hitbox']=='unknown' for q in players):raise ValueError('Unverified legacy hitbox')
            data=normalize_arrays(f,players,15.);arrays=f.arrays();valid=data['valid'].copy()
            if 'clock_phase' in arrays:valid &= ~np.isin(np.asarray(arrays['clock_phase']).astype(str),['pregame','countdown','goal_pause','decided'])
            candidates=np.random.default_rng(420).permutation(np.flatnonzero(valid));xs=[];ys=[]
            goals=np.asarray(data['goal_rows']);teams=np.asarray(data['goal_teams'])
            for row in candidates:
                future=np.flatnonzero((goals>row)&(data['segment'][goals]==data['segment'][row]))
                if not len(future):continue
                k=int(future[0]);state=replay_state(data,int(row));discount=float(np.exp(-(data['time'][goals[k]]-data['time'][row])/5.))
                for who in range(len(players)):
                    xs.append(make_observation(state,who));ys.append(discount*(1 if teams[k]==who//int(data['mode']) else -1))
                    if len(xs)>=128:break
                if len(xs)>=128:break
            if not xs:raise ValueError('No known next-goal targets')
            temp=target.with_suffix('.tmp.npz');np.savez_compressed(temp,obs=np.asarray(xs,np.float32),value=np.asarray(ys,np.float32),source_sha256=group,label_source='legacy replay state next-goal value only; no controller labels');temp.replace(target);tried[p.name]='value_only_cached'
            print('LEGACY_VALUE_ONLY:',p.name,len(xs),'states',flush=True)
        except Exception as e:tried[p.name]='skipped: '+str(e)
    temp=record.with_suffix('.tmp');temp.write_text(json.dumps(tried,indent=2),encoding='utf8');temp.replace(record)
    return len(list(out.glob('*.npz')))

def load(root,max_rows=32000):
    from src.dataset import dataset_split
    files=sorted((Path(root)/'runs/replay_final/value_cache').glob('*.npz'))
    if not files:return None
    per=max(1,max_rows//len(files));xs=[];ys=[]
    for p in files:
        with np.load(p,allow_pickle=False) as z:
            if dataset_split(str(z['source_sha256'].item()))!='train':raise ValueError('Legacy value cache contains held-out replay')
            xs.append(z['obs'][:per]);ys.append(z['value'][:per])
    return np.concatenate(xs),np.concatenate(ys)
