from tools.rocketsimvis_v415 import install
from src.galactus_v416 import setup
if __name__=='__main__':
    setup();install()
