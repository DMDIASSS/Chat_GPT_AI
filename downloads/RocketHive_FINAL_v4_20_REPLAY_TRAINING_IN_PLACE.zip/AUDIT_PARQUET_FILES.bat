@echo off
setlocal
cd /d "%~dp0"
".venv\Scripts\python.exe" -u -c "from src.replay_final_data import audit_parquets; audit_parquets('.')"
if errorlevel 1 echo PARQUET_AUDIT_FAILED - keep this output.
pause
