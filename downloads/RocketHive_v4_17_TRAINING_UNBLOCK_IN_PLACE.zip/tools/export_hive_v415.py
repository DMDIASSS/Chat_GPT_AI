"""Portable RLBot4 live search. No keys, replay logs, or existing model overwrite."""
from pathlib import Path
import argparse,json,shutil,tempfile,zipfile,sys
ROOT=Path(__file__).resolve().parents[1]

def export(output='exports/RocketHive_Live_Hive_RLBot4.zip',allow_geometric=False):
    from tools.replay_readiness_v417 import require_brain
    require_brain(ROOT,allow_geometric)
    output=Path(output).resolve();output.parent.mkdir(parents=True,exist_ok=True)
    from tools.native_rlviser import find_meshes
    meshes=find_meshes()
    if meshes is None:raise ValueError('Live search export needs your installed Soccar meshes; keep them in third_party/collision_meshes or set REPLICAR_MESHES')
    brain=ROOT/'models/v415_replay_brain.pt'
    if brain.exists():
        from src.replay_bc_v415 import ReplayBrain
        ReplayBrain(brain) # fail on incompatible/untrained/degenerate codec
    with tempfile.TemporaryDirectory() as temp:
        base=Path(temp)/'RocketHiveBot';shutil.copytree(ROOT/'rlbot_hive/RocketHiveBot',base,ignore=shutil.ignore_patterns('__pycache__','*.pyc'))
        for folder in ('src','tools'):
            (base/folder).mkdir()
            names=[p.name for p in (ROOT/folder).glob('*.py')] if folder=='src' else ['native_rlviser.py','hive_worker_v415.py']
            for name in names:shutil.copy2(ROOT/folder/name,base/folder/name)
        (base/'worker_python.json').write_text(json.dumps(dict(python=sys.executable,purpose='Reuse the exporting project Python for the background search worker; no second Torch/CUDA install'),indent=2))
        if brain.exists():
            (base/'models').mkdir();shutil.copy2(brain,base/'models'/brain.name)
        shutil.copytree(meshes,base/'third_party/collision_meshes')
        (base/'EXPORT_STATUS.json').write_text(json.dumps(dict(controller='REPLAY_BC_WITH_LIVE_SEARCH' if brain.exists() else 'GEOMETRIC_SEARCH_DIAGNOSTIC_NOT_TRAINED',format='RLBot4',playing_strength_verified=False),indent=2))
        (base/'INSTALL.bat').write_text('@echo off\r\ncd /d "%~dp0"\r\npython -m pip install -r requirements.txt\r\nif errorlevel 1 exit /b 1\r\necho If EXPORT_STATUS says replay BC, use your existing PyTorch-enabled Python for RLBot.\r\npause\r\n')
        with zipfile.ZipFile(output,'w',zipfile.ZIP_DEFLATED) as z:
            for p in base.rglob('*'):
                if p.is_file():z.write(p,p.relative_to(base.parent))
    print('EXPORTED:',output,'replay brain included:',brain.exists(),flush=True);return output
if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--output',default='exports/RocketHive_Live_Hive_RLBot4.zip');p.add_argument('--allow-geometric',action='store_true');a=p.parse_args();export(a.output,a.allow_geometric)
