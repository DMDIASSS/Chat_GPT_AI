"""Explicit deployment gate: a runnable geometric diagnostic is not a trained bot."""
from pathlib import Path
def require_brain(root,allow_geometric=False):
    path=Path(root)/'models/v415_replay_brain.pt'
    if not path.is_file():
        if allow_geometric:
            print('UNTRAINED_DIAGNOSTIC: no replay brain; geometric controls only. Watching does not train.',flush=True);return None
        raise ValueError('NO_TRAINED_REPLAY_BRAIN: models/v415_replay_brain.pt is missing. Run menu 4 to prepare train/validation data, then menu 6 for supervised training. Wait for health_ready=True before watching or exporting. --allow-geometric is only for explicit diagnostic use.')
    from src.replay_bc_v415 import ReplayBrain
    brain=ReplayBrain(path)
    print('TRAINED_REPLAY_BRAIN:',path,'validation:',brain.validation,'Playing strength is unverified.',flush=True)
    return brain
